﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Fusion.StatsInternal
{
	// Token: 0x02000644 RID: 1604
	public static class FusionStatsUtilities
	{
		// Token: 0x17000442 RID: 1090
		// (get) Token: 0x060025A3 RID: 9635 RVA: 0x000B8714 File Offset: 0x000B6914
		public static List<string> CachedTelemetryNames
		{
			get
			{
				if (FusionStatsUtilities._cachedGraphVisualizationNames == null)
				{
					Type typeFromHandle = typeof(FusionGraphVisualization);
					string[] names = Enum.GetNames(typeFromHandle);
					FusionStatsUtilities._cachedGraphVisualizationNames = new List<string>(names.Length);
					for (int i = 0; i < names.Length; i++)
					{
						string item;
						try
						{
							item = ((DescriptionAttribute)typeFromHandle.GetMember(names[i])[0].GetCustomAttributes(typeof(DescriptionAttribute), false)[0]).Description;
						}
						catch
						{
							item = names[i];
						}
						FusionStatsUtilities._cachedGraphVisualizationNames.Add(item);
					}
				}
				return FusionStatsUtilities._cachedGraphVisualizationNames;
			}
		}

		// Token: 0x17000443 RID: 1091
		// (get) Token: 0x060025A4 RID: 9636 RVA: 0x000B87A8 File Offset: 0x000B69A8
		private static Texture2D MeterTexture
		{
			get
			{
				if (FusionStatsUtilities._meterTexture == null)
				{
					Texture2D texture2D = new Texture2D(512, 2);
					for (int i = 0; i < 512; i++)
					{
						for (int j = 0; j < 2; j++)
						{
							Color color = (i != 0 && i % 16 == 0) ? new Color(1f, 1f, 1f, 0.75f) : new Color(1f, 1f, 1f, 1f);
							texture2D.SetPixel(i, j, color);
						}
					}
					texture2D.Apply();
					return FusionStatsUtilities._meterTexture = texture2D;
				}
				return FusionStatsUtilities._meterTexture;
			}
		}

		// Token: 0x17000444 RID: 1092
		// (get) Token: 0x060025A5 RID: 9637 RVA: 0x000B8844 File Offset: 0x000B6A44
		public static Sprite MeterSprite
		{
			get
			{
				if (FusionStatsUtilities._meterSprite == null)
				{
					FusionStatsUtilities._meterSprite = Sprite.Create(FusionStatsUtilities.MeterTexture, new Rect(0f, 0f, 512f, 2f), default(Vector2));
				}
				return FusionStatsUtilities._meterSprite;
			}
		}

		// Token: 0x17000445 RID: 1093
		// (get) Token: 0x060025A6 RID: 9638 RVA: 0x000B8894 File Offset: 0x000B6A94
		private static Texture2D Circle32Texture
		{
			get
			{
				if (FusionStatsUtilities._circle32Texture == null)
				{
					Texture2D texture2D = new Texture2D(128, 128);
					for (int i = 0; i < 64; i++)
					{
						for (int j = 0; j < 64; j++)
						{
							double num = Math.Abs(Math.Sqrt((double)(i * i + j * j)));
							float a = (num > 64.0) ? 0f : ((num < 63.0) ? 1f : ((float)(64.0 - num)));
							Color color = new Color(1f, 1f, 1f, a);
							texture2D.SetPixel(64 + i, 64 + j, color);
							texture2D.SetPixel(63 - i, 64 + j, color);
							texture2D.SetPixel(64 + i, 63 - j, color);
							texture2D.SetPixel(63 - i, 63 - j, color);
						}
					}
					texture2D.Apply();
					return FusionStatsUtilities._circle32Texture = texture2D;
				}
				return FusionStatsUtilities._circle32Texture;
			}
		}

		// Token: 0x17000446 RID: 1094
		// (get) Token: 0x060025A7 RID: 9639 RVA: 0x000B899C File Offset: 0x000B6B9C
		public static Sprite CircleSprite
		{
			get
			{
				if (FusionStatsUtilities._circle32Sprite == null)
				{
					FusionStatsUtilities._circle32Sprite = Sprite.Create(FusionStatsUtilities.Circle32Texture, new Rect(0f, 0f, 128f, 128f), new Vector2(64f, 64f), 10f, 0U, SpriteMeshType.Tight, new Vector4(63f, 63f, 63f, 63f));
				}
				return FusionStatsUtilities._circle32Sprite;
			}
		}

		// Token: 0x060025A8 RID: 9640 RVA: 0x000B8A14 File Offset: 0x000B6C14
		public static bool TryFindActiveRunner(FusionStats fusionStats, out NetworkRunner runner, SimulationModes? mode = null)
		{
			GameObject gameObject = fusionStats.gameObject;
			Scene scene = fusionStats.gameObject.scene;
			List<NetworkRunner>.Enumerator instancesEnumerator = NetworkRunner.GetInstancesEnumerator();
			while (instancesEnumerator.MoveNext())
			{
				NetworkRunner networkRunner = instancesEnumerator.Current;
				if (networkRunner && networkRunner.IsRunning && (mode == null || (mode.Value & networkRunner.Mode) != (SimulationModes)0))
				{
					if (fusionStats.EnforceSingle)
					{
						runner = networkRunner;
						return true;
					}
					if (networkRunner.SimulationUnityScene == scene)
					{
						runner = networkRunner;
						return true;
					}
				}
			}
			runner = null;
			return false;
		}

		// Token: 0x060025A9 RID: 9641 RVA: 0x000B8A9C File Offset: 0x000B6C9C
		public static RectTransform CreateRectTransform(this Transform parent, string name, bool expand = false)
		{
			RectTransform rectTransform = new GameObject(name).AddComponent<RectTransform>();
			rectTransform.SetParent(parent);
			rectTransform.localPosition = default(Vector3);
			rectTransform.localScale = default(Vector3);
			rectTransform.localScale = new Vector3(1f, 1f, 1f);
			if (expand)
			{
				rectTransform.ExpandAnchor(null);
			}
			return rectTransform;
		}

		// Token: 0x060025AA RID: 9642 RVA: 0x000B8B08 File Offset: 0x000B6D08
		[Obsolete]
		internal static RectTransform CreateRectTransform(string name, Transform parent, bool expand = false)
		{
			RectTransform rectTransform = new GameObject(name).AddComponent<RectTransform>();
			rectTransform.SetParent(parent);
			rectTransform.localPosition = default(Vector3);
			rectTransform.localScale = default(Vector3);
			rectTransform.localScale = new Vector3(1f, 1f, 1f);
			if (expand)
			{
				rectTransform.ExpandAnchor(null);
			}
			return rectTransform;
		}

		// Token: 0x060025AB RID: 9643 RVA: 0x000B8B74 File Offset: 0x000B6D74
		public static Dropdown CreateDropdown(this RectTransform rt, float padding, Color fontColor)
		{
			RectTransform rectTransform = rt.CreateRectTransform("Dropdown", false).ExpandAnchor(new float?((float)-6));
			Image image = rectTransform.gameObject.AddComponent<Image>();
			Dropdown dropdown = rectTransform.gameObject.AddComponent<Dropdown>();
			image.color = new Color(0f, 0f, 0f, 0f);
			dropdown.image = image;
			RectTransform rectTransform2 = rectTransform.CreateRectTransform("Template", true).ExpandTopAnchor(null).SetOffsets(0f, 0f, -150f, 0f);
			RectTransform rectTransform3 = rectTransform2.CreateRectTransform("Content", false).ExpandTopAnchor(null).SetOffsets(0f, 0f, -150f, 0f).CreateRectTransform("Item", true).SetAnchors(0f, 1f, 1f, 1f).SetPivot(0.5f, 1f).SetSizeDelta(0f, 50f);
			Toggle toggle = rectTransform3.gameObject.AddComponent<Toggle>();
			toggle.colors = new ColorBlock
			{
				colorMultiplier = 1f,
				normalColor = new Color(0.2f, 0.2f, 0.2f, 1f),
				highlightedColor = new Color(0.3f, 0.3f, 0.3f, 1f),
				pressedColor = new Color(0.4f, 0.4f, 0.4f, 4f),
				selectedColor = new Color(0.25f, 0.25f, 0.25f, 1f)
			};
			Image targetGraphic = rectTransform3.CreateRectTransform("Item Background", true).gameObject.AddComponent<Image>();
			Image image2 = rectTransform3.CreateRectTransform("Item Checkmark", true).SetAnchors(0.05f, 0.1f, 0.1f, 0.9f).SetOffsets(0f, 0f, 0f, 0f).gameObject.AddComponent<Image>();
			image2.sprite = FusionStatsUtilities.CircleSprite;
			image2.preserveAspect = true;
			Text text = rectTransform3.CreateRectTransform("Item Label", true).SetAnchors(0.15f, 0.9f, 0.1f, 0.9f).SetOffsets(0f, 0f, 0f, 0f).AddText("Sample", TextAnchor.UpperLeft, fontColor);
			text.alignment = TextAnchor.MiddleLeft;
			text.resizeTextMaxSize = 24;
			toggle.targetGraphic = targetGraphic;
			toggle.graphic = image2;
			toggle.isOn = true;
			dropdown.template = rectTransform2;
			dropdown.itemText = text;
			rectTransform2.gameObject.SetActive(false);
			return dropdown;
		}

		// Token: 0x060025AC RID: 9644 RVA: 0x000B8E30 File Offset: 0x000B7030
		public static Text AddText(this RectTransform rt, string label, TextAnchor anchor, Color FontColor)
		{
			Text text = rt.gameObject.AddComponent<Text>();
			text.text = label;
			text.color = FontColor;
			text.alignment = anchor;
			text.fontSize = 12;
			text.raycastTarget = false;
			text.resizeTextMinSize = 4;
			text.resizeTextMaxSize = 200;
			text.resizeTextForBestFit = true;
			return text;
		}

		// Token: 0x060025AD RID: 9645 RVA: 0x000B8E88 File Offset: 0x000B7088
		internal static void MakeButton(this RectTransform parent, ref Button button, string iconText, string labelText, out Text icon, out Text text, UnityAction action)
		{
			RectTransform rectTransform = parent.CreateRectTransform(labelText, false);
			button = rectTransform.gameObject.AddComponent<Button>();
			RectTransform rectTransform2 = rectTransform.CreateRectTransform("Icon", true);
			rectTransform2.anchorMin = new Vector2(0f, 0.175f);
			rectTransform2.anchorMax = new Vector2(1f, 1f);
			rectTransform2.offsetMin = new Vector2(0f, 0f);
			rectTransform2.offsetMax = new Vector2(0f, 0f);
			icon = rectTransform2.gameObject.AddComponent<Text>();
			button.targetGraphic = icon;
			icon.text = iconText;
			icon.alignment = TextAnchor.MiddleCenter;
			icon.fontStyle = FontStyle.Bold;
			icon.fontSize = 100;
			icon.resizeTextMinSize = 0;
			icon.resizeTextMaxSize = 100;
			icon.alignByGeometry = true;
			icon.resizeTextForBestFit = true;
			RectTransform rectTransform3 = rectTransform.CreateRectTransform("Label", true);
			rectTransform3.anchorMin = new Vector2(0f, 0f);
			rectTransform3.anchorMax = new Vector2(1f, 0.175f);
			rectTransform3.pivot = new Vector2(0.5f, 0.0875f);
			rectTransform3.offsetMin = new Vector2(0f, 0f);
			rectTransform3.offsetMax = new Vector2(0f, 0f);
			text = rectTransform3.gameObject.AddComponent<Text>();
			text.color = Color.black;
			text.text = labelText;
			text.alignment = TextAnchor.MiddleCenter;
			text.fontStyle = FontStyle.Bold;
			text.fontSize = 0;
			text.resizeTextMinSize = 0;
			text.resizeTextMaxSize = 100;
			text.resizeTextForBestFit = true;
			text.horizontalOverflow = HorizontalWrapMode.Overflow;
			ColorBlock colors = button.colors;
			colors.normalColor = new Color(0f, 0f, 0f, 0.925f);
			colors.pressedColor = new Color(0.5f, 0.5f, 0.5f, 0.925f);
			colors.highlightedColor = new Color(0.3f, 0.3f, 0.3f, 0.925f);
			colors.selectedColor = new Color(0f, 0f, 0f, 0.925f);
			button.colors = colors;
			button.onClick.AddListener(action);
		}

		// Token: 0x060025AE RID: 9646 RVA: 0x000B90E8 File Offset: 0x000B72E8
		public static RectTransform AddHorizontalLayoutGroup(this RectTransform rt, float spacing, int? rgtPad = null, int? lftPad = null, int? topPad = null, int? botPad = null)
		{
			HorizontalLayoutGroup horizontalLayoutGroup = rt.gameObject.AddComponent<HorizontalLayoutGroup>();
			horizontalLayoutGroup.childControlHeight = true;
			horizontalLayoutGroup.childControlWidth = true;
			horizontalLayoutGroup.spacing = spacing;
			horizontalLayoutGroup.padding = new RectOffset((rgtPad != null) ? rgtPad.Value : 0, (lftPad != null) ? lftPad.Value : 0, (topPad != null) ? topPad.Value : 0, (botPad != null) ? botPad.Value : 0);
			return rt;
		}

		// Token: 0x060025AF RID: 9647 RVA: 0x000B916C File Offset: 0x000B736C
		public static RectTransform AddVerticalLayoutGroup(this RectTransform rt, float spacing, int? rgtPad = null, int? lftPad = null, int? topPad = null, int? botPad = null)
		{
			VerticalLayoutGroup verticalLayoutGroup = rt.gameObject.AddComponent<VerticalLayoutGroup>();
			verticalLayoutGroup.childControlHeight = true;
			verticalLayoutGroup.childControlWidth = true;
			verticalLayoutGroup.spacing = spacing;
			return rt;
		}

		// Token: 0x060025B0 RID: 9648 RVA: 0x000B918E File Offset: 0x000B738E
		public static GridLayoutGroup AddGridlLayoutGroup(this RectTransform rt, float spacing, int? rgtPad = null, int? lftPad = null, int? topPad = null, int? botPad = null)
		{
			GridLayoutGroup gridLayoutGroup = rt.gameObject.AddComponent<GridLayoutGroup>();
			gridLayoutGroup.spacing = new Vector2(spacing, spacing);
			return gridLayoutGroup;
		}

		// Token: 0x060025B1 RID: 9649 RVA: 0x000B91A8 File Offset: 0x000B73A8
		public static RectTransform AddImage(this RectTransform rt, Color color)
		{
			Image image = rt.gameObject.AddComponent<Image>();
			image.color = color;
			image.raycastTarget = false;
			return rt;
		}

		// Token: 0x060025B2 RID: 9650 RVA: 0x000B91C4 File Offset: 0x000B73C4
		public static RectTransform AddCircleSprite(this RectTransform rt, Color color)
		{
			Image image;
			rt.AddCircleSprite(color, out image);
			return rt;
		}

		// Token: 0x060025B3 RID: 9651 RVA: 0x000B91DC File Offset: 0x000B73DC
		public static RectTransform AddCircleSprite(this RectTransform rt, Color color, out Image image)
		{
			image = rt.gameObject.AddComponent<Image>();
			image.sprite = FusionStatsUtilities.CircleSprite;
			image.type = Image.Type.Sliced;
			image.pixelsPerUnitMultiplier = 100f;
			image.color = color;
			image.raycastTarget = false;
			return rt;
		}

		// Token: 0x060025B4 RID: 9652 RVA: 0x000B921C File Offset: 0x000B741C
		public static RectTransform ExpandAnchor(this RectTransform rt, float? padding = null)
		{
			rt.anchorMax = new Vector2(1f, 1f);
			rt.anchorMin = new Vector2(0f, 0f);
			rt.pivot = new Vector2(0.5f, 0.5f);
			if (padding != null)
			{
				rt.offsetMin = new Vector2(padding.Value, padding.Value);
				rt.offsetMax = new Vector2(-padding.Value, -padding.Value);
			}
			else
			{
				rt.sizeDelta = default(Vector2);
				rt.anchoredPosition = default(Vector2);
			}
			return rt;
		}

		// Token: 0x060025B5 RID: 9653 RVA: 0x000B92C8 File Offset: 0x000B74C8
		public static RectTransform ExpandTopAnchor(this RectTransform rt, float? padding = null)
		{
			rt.anchorMax = new Vector2(1f, 1f);
			rt.anchorMin = new Vector2(0f, 1f);
			rt.pivot = new Vector2(0.5f, 1f);
			if (padding != null)
			{
				rt.offsetMin = new Vector2(padding.Value, padding.Value);
				rt.offsetMax = new Vector2(-padding.Value, -padding.Value);
			}
			else
			{
				rt.sizeDelta = default(Vector2);
				rt.anchoredPosition = default(Vector2);
			}
			return rt;
		}

		// Token: 0x060025B6 RID: 9654 RVA: 0x000B9374 File Offset: 0x000B7574
		public static RectTransform ExpandMiddleLeft(this RectTransform rt)
		{
			rt.anchorMax = new Vector2(0f, 0.5f);
			rt.anchorMin = new Vector2(0f, 0.5f);
			rt.pivot = new Vector2(0f, 0.5f);
			return rt;
		}

		// Token: 0x060025B7 RID: 9655 RVA: 0x000B93C1 File Offset: 0x000B75C1
		public static RectTransform SetSizeDelta(this RectTransform rt, float offsetX, float offsetY)
		{
			rt.sizeDelta = new Vector2(offsetX, offsetY);
			return rt;
		}

		// Token: 0x060025B8 RID: 9656 RVA: 0x000B93D1 File Offset: 0x000B75D1
		public static RectTransform SetOffsets(this RectTransform rt, float minX, float maxX, float minY, float maxY)
		{
			rt.offsetMin = new Vector2(minX, minY);
			rt.offsetMax = new Vector2(maxX, maxY);
			return rt;
		}

		// Token: 0x060025B9 RID: 9657 RVA: 0x000B93EF File Offset: 0x000B75EF
		public static RectTransform SetPivot(this RectTransform rt, float pivotX, float pivotY)
		{
			rt.pivot = new Vector2(pivotX, pivotY);
			return rt;
		}

		// Token: 0x060025BA RID: 9658 RVA: 0x000B93FF File Offset: 0x000B75FF
		public static RectTransform SetAnchors(this RectTransform rt, float minX, float maxX, float minY, float maxY)
		{
			rt.anchorMin = new Vector2(minX, minY);
			rt.anchorMax = new Vector2(maxX, maxY);
			return rt;
		}

		// Token: 0x060025BB RID: 9659 RVA: 0x000B9420 File Offset: 0x000B7620
		internal static RectTransform MakeGuides(this RectTransform parent)
		{
			Color color = new Color(0.5f, 0.5f, 0.5f, 0.75f);
			RectTransform rectTransform = parent.CreateRectTransform("Guides", true);
			rectTransform.SetSiblingIndex(0);
			rectTransform.CreateRectTransform("Back", true).gameObject.AddComponent<Image>().color = new Color(0.5f, 0.5f, 0.5f, 0.25f);
			RectTransform rectTransform2 = rectTransform.CreateRectTransform("Left", true);
			rectTransform2.anchorMin = new Vector2(-0.01f, 0f);
			rectTransform2.anchorMax = new Vector2(0f, 1f);
			rectTransform2.gameObject.AddComponent<Image>().color = color;
			RectTransform rectTransform3 = rectTransform.CreateRectTransform("Right", true);
			rectTransform3.anchorMin = new Vector2(1f, 0f);
			rectTransform3.anchorMax = new Vector2(1.01f, 1f);
			rectTransform3.gameObject.AddComponent<Image>().color = color;
			RectTransform rectTransform4 = rectTransform.CreateRectTransform("Top", true);
			rectTransform4.anchorMin = new Vector2(-0.01f, 1f);
			rectTransform4.anchorMax = new Vector2(1.01f, 1.01f);
			rectTransform4.gameObject.AddComponent<Image>().color = color;
			RectTransform rectTransform5 = rectTransform.CreateRectTransform("Bottom", true);
			rectTransform5.anchorMin = new Vector2(-0.01f, -0.01f);
			rectTransform5.anchorMax = new Vector2(1.01f, 0f);
			rectTransform5.gameObject.AddComponent<Image>().color = color;
			rectTransform.CreateRectTransform("Center", true).SetAnchors(0.495f, 0.505f, 0f, 1f).AddImage(color);
			rectTransform.CreateRectTransform("Middle", true).SetAnchors(0f, 1f, 0.495f, 0.505f).AddImage(color);
			return rectTransform;
		}

		// Token: 0x04002846 RID: 10310
		public const int PAD = 10;

		// Token: 0x04002847 RID: 10311
		public const int MARGIN = 6;

		// Token: 0x04002848 RID: 10312
		public const int FONT_SIZE = 12;

		// Token: 0x04002849 RID: 10313
		public const int FONT_SIZE_MIN = 4;

		// Token: 0x0400284A RID: 10314
		public const int FONT_SIZE_MAX = 200;

		// Token: 0x0400284B RID: 10315
		private static List<string> _cachedGraphVisualizationNames;

		// Token: 0x0400284C RID: 10316
		private const int METER_TEXTURE_WIDTH = 512;

		// Token: 0x0400284D RID: 10317
		private static Texture2D _meterTexture;

		// Token: 0x0400284E RID: 10318
		private static Sprite _meterSprite;

		// Token: 0x0400284F RID: 10319
		private const int R = 64;

		// Token: 0x04002850 RID: 10320
		private static Texture2D _circle32Texture;

		// Token: 0x04002851 RID: 10321
		private static Sprite _circle32Sprite;

		// Token: 0x04002852 RID: 10322
		public static Color DARK_GREEN = new Color(0f, 0.5f, 0f, 1f);

		// Token: 0x04002853 RID: 10323
		public static Color DARK_BLUE = new Color(0f, 0f, 0.5f, 1f);

		// Token: 0x04002854 RID: 10324
		public static Color DARK_RED = new Color(0.5f, 0f, 0f, 1f);

		// Token: 0x04002855 RID: 10325
		public const float BTTN_LBL_NORM_HGHT = 0.175f;

		// Token: 0x04002856 RID: 10326
		private const int BTTN_FONT_SIZE_MAX = 100;

		// Token: 0x04002857 RID: 10327
		private const float BTTN_ALPHA = 0.925f;

		// Token: 0x04002858 RID: 10328
		private const float GUIDE_MARGIN = 0.01f;

		// Token: 0x04002859 RID: 10329
		private const float GUIDE_MARGIN_HALF = 0.005f;
	}
}
