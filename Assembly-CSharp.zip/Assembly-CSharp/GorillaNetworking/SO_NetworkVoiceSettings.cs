﻿using System;
using ExitGames.Client.Photon;
using Photon.Voice;
using Photon.Voice.Unity;
using POpusCodec.Enums;
using UnityEngine;

namespace GorillaNetworking
{
	// Token: 0x02000693 RID: 1683
	[CreateAssetMenu(fileName = "VoiceSettings", menuName = "Gorilla Tag/VoiceSettings")]
	public class SO_NetworkVoiceSettings : ScriptableObject
	{
		// Token: 0x04002A3E RID: 10814
		[Header("Voice settings")]
		public bool AutoConnectAndJoin = true;

		// Token: 0x04002A3F RID: 10815
		public bool AutoLeaveAndDisconnect = true;

		// Token: 0x04002A40 RID: 10816
		public bool WorkInOfflineMode = true;

		// Token: 0x04002A41 RID: 10817
		public DebugLevel LogLevel = DebugLevel.ERROR;

		// Token: 0x04002A42 RID: 10818
		public DebugLevel GlobalRecordersLogLevel = DebugLevel.INFO;

		// Token: 0x04002A43 RID: 10819
		public DebugLevel GlobalSpeakersLogLevel = DebugLevel.INFO;

		// Token: 0x04002A44 RID: 10820
		public bool CreateSpeakerIfNotFound;

		// Token: 0x04002A45 RID: 10821
		public int UpdateInterval = 50;

		// Token: 0x04002A46 RID: 10822
		public bool SupportLogger;

		// Token: 0x04002A47 RID: 10823
		public int BackgroundTimeout = 60000;

		// Token: 0x04002A48 RID: 10824
		[Header("Recorder Settings")]
		public bool RecordOnlyWhenEnabled;

		// Token: 0x04002A49 RID: 10825
		public bool RecordOnlyWhenJoined = true;

		// Token: 0x04002A4A RID: 10826
		public bool StopRecordingWhenPaused;

		// Token: 0x04002A4B RID: 10827
		public bool TransmitEnabled = true;

		// Token: 0x04002A4C RID: 10828
		public bool AutoStart = true;

		// Token: 0x04002A4D RID: 10829
		public bool Encrypt;

		// Token: 0x04002A4E RID: 10830
		public byte InterestGroup;

		// Token: 0x04002A4F RID: 10831
		public bool DebugEcho;

		// Token: 0x04002A50 RID: 10832
		public bool ReliableMode;

		// Token: 0x04002A51 RID: 10833
		[Header("Recorder Codec Parameters")]
		public OpusCodec.FrameDuration FrameDuration = OpusCodec.FrameDuration.Frame60ms;

		// Token: 0x04002A52 RID: 10834
		public SamplingRate SamplingRate = SamplingRate.Sampling16000;

		// Token: 0x04002A53 RID: 10835
		[Range(6000f, 510000f)]
		public int Bitrate = 20000;

		// Token: 0x04002A54 RID: 10836
		[Header("Recorder Audio Source Settings")]
		public Recorder.InputSourceType InputSourceType;

		// Token: 0x04002A55 RID: 10837
		public Recorder.MicType MicrophoneType;

		// Token: 0x04002A56 RID: 10838
		public bool UseFallback = true;

		// Token: 0x04002A57 RID: 10839
		public bool Detect = true;

		// Token: 0x04002A58 RID: 10840
		[Range(0f, 1f)]
		public float Threshold = 0.07f;

		// Token: 0x04002A59 RID: 10841
		public int Delay = 500;
	}
}
