﻿using System;

// Token: 0x02000339 RID: 825
public enum GorillaControllerType
{
	// Token: 0x0400156F RID: 5487
	OCULUS_DEFAULT,
	// Token: 0x04001570 RID: 5488
	INDEX
}
