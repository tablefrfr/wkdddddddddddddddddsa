﻿using System;
using System.Collections.Generic;

// Token: 0x020004A7 RID: 1191
public static class ArrayUtils
{
	// Token: 0x06001B48 RID: 6984 RVA: 0x0008B074 File Offset: 0x00089274
	public static T[] Copy<T>(T[] source)
	{
		if (source == null)
		{
			return null;
		}
		if (source.Length == 0)
		{
			return Array.Empty<T>();
		}
		T[] array = new T[source.Length];
		for (int i = 0; i < source.Length; i++)
		{
			array[i] = source[i];
		}
		return array;
	}

	// Token: 0x06001B49 RID: 6985 RVA: 0x0008B0B8 File Offset: 0x000892B8
	public static int IndexOfRef<T>(this List<T> array, T value) where T : class
	{
		if (array == null || array.Count == 0)
		{
			return -1;
		}
		for (int i = 0; i < array.Count; i++)
		{
			if (array[i] == value)
			{
				return i;
			}
		}
		return -1;
	}

	// Token: 0x06001B4A RID: 6986 RVA: 0x0008B0FC File Offset: 0x000892FC
	public static int IndexOfRef<T>(this T[] array, T value) where T : class
	{
		if (array == null || array.Length == 0)
		{
			return -1;
		}
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i] == value)
			{
				return i;
			}
		}
		return -1;
	}
}
