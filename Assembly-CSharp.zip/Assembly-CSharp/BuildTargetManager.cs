﻿using System;
using UnityEngine;

// Token: 0x0200049A RID: 1178
public class BuildTargetManager : MonoBehaviour
{
	// Token: 0x06001B2D RID: 6957 RVA: 0x0008AD17 File Offset: 0x00088F17
	public string GetPath()
	{
		return this.path;
	}

	// Token: 0x04001F08 RID: 7944
	public BuildTargetManager.BuildTowards newBuildTarget;

	// Token: 0x04001F09 RID: 7945
	public bool isBeta;

	// Token: 0x04001F0A RID: 7946
	public bool isQA;

	// Token: 0x04001F0B RID: 7947
	public bool spoofIDs;

	// Token: 0x04001F0C RID: 7948
	public bool spoofChild;

	// Token: 0x04001F0D RID: 7949
	public bool enableAllCosmetics;

	// Token: 0x04001F0E RID: 7950
	public OVRManager ovrManager;

	// Token: 0x04001F0F RID: 7951
	private string path = "Assets/csc.rsp";

	// Token: 0x04001F10 RID: 7952
	public BuildTargetManager.BuildTowards currentBuildTargetDONOTCHANGE;

	// Token: 0x04001F11 RID: 7953
	public GorillaTagger gorillaTagger;

	// Token: 0x04001F12 RID: 7954
	public GameObject[] betaDisableObjects;

	// Token: 0x04001F13 RID: 7955
	public GameObject[] betaEnableObjects;

	// Token: 0x0200049B RID: 1179
	public enum BuildTowards
	{
		// Token: 0x04001F15 RID: 7957
		Steam,
		// Token: 0x04001F16 RID: 7958
		OculusPC,
		// Token: 0x04001F17 RID: 7959
		Quest,
		// Token: 0x04001F18 RID: 7960
		Viveport
	}
}
