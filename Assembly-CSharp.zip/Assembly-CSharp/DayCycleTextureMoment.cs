﻿using System;
using UnityEngine;

// Token: 0x02000094 RID: 148
[Serializable]
public class DayCycleTextureMoment
{
	// Token: 0x04000430 RID: 1072
	public Texture2D sunnyTex;

	// Token: 0x04000431 RID: 1073
	public Texture2D cloudyTex;
}
