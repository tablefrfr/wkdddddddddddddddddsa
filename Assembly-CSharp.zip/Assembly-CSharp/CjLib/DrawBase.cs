﻿using System;
using UnityEngine;

namespace CjLib
{
	// Token: 0x020007D3 RID: 2003
	public abstract class DrawBase : MonoBehaviour
	{
		// Token: 0x06003079 RID: 12409 RVA: 0x000ED63C File Offset: 0x000EB83C
		private void Update()
		{
			if (this.Style != DebugUtil.Style.Wireframe)
			{
				this.Draw(this.ShadededColor, this.Style, this.DepthTest);
			}
			if (this.Style == DebugUtil.Style.Wireframe || this.Wireframe)
			{
				this.Draw(this.WireframeColor, DebugUtil.Style.Wireframe, this.DepthTest);
			}
		}

		// Token: 0x0600307A RID: 12410
		protected abstract void Draw(Color color, DebugUtil.Style style, bool depthTest);

		// Token: 0x040032E7 RID: 13031
		public Color WireframeColor = Color.white;

		// Token: 0x040032E8 RID: 13032
		public Color ShadededColor = Color.gray;

		// Token: 0x040032E9 RID: 13033
		public bool Wireframe;

		// Token: 0x040032EA RID: 13034
		public DebugUtil.Style Style = DebugUtil.Style.FlatShaded;

		// Token: 0x040032EB RID: 13035
		public bool DepthTest = true;
	}
}
