﻿using System;

// Token: 0x020000A6 RID: 166
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public class DevInspectorCyan : DevInspectorColor
{
	// Token: 0x0600031E RID: 798 RVA: 0x00016528 File Offset: 0x00014728
	public DevInspectorCyan() : base("#5ff")
	{
	}
}
