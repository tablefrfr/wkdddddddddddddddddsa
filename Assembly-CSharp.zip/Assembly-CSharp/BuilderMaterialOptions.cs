﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200031A RID: 794
[CreateAssetMenu(fileName = "BuilderMaterialOptions01a", menuName = "Gorilla Tag/Builder/Options", order = 0)]
public class BuilderMaterialOptions : ScriptableObject
{
	// Token: 0x060011D9 RID: 4569 RVA: 0x0005CFC4 File Offset: 0x0005B1C4
	public Material GetMaterialFromType(int materialType)
	{
		if (this.options == null)
		{
			return null;
		}
		foreach (BuilderMaterialOptions.Options options in this.options)
		{
			if (options.materialId.GetHashCode() == materialType)
			{
				return options.material;
			}
		}
		return null;
	}

	// Token: 0x060011DA RID: 4570 RVA: 0x0005D034 File Offset: 0x0005B234
	public Material GetDefaultMaterial()
	{
		if (this.options.Count > 0)
		{
			return this.options[0].material;
		}
		return null;
	}

	// Token: 0x060011DB RID: 4571 RVA: 0x0005D057 File Offset: 0x0005B257
	public int GetDefaultMaterialType()
	{
		if (this.options.Count > 0)
		{
			return this.options[0].materialId.GetHashCode();
		}
		return -1;
	}

	// Token: 0x04001456 RID: 5206
	public List<BuilderMaterialOptions.Options> options;

	// Token: 0x0200031B RID: 795
	[Serializable]
	public class Options
	{
		// Token: 0x04001457 RID: 5207
		public string materialId;

		// Token: 0x04001458 RID: 5208
		public Material material;

		// Token: 0x04001459 RID: 5209
		[NonSerialized]
		public int materialType;
	}
}
