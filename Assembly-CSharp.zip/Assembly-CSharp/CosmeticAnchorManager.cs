﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000290 RID: 656
public class CosmeticAnchorManager : MonoBehaviour
{
	// Token: 0x06000E99 RID: 3737 RVA: 0x0004C5F4 File Offset: 0x0004A7F4
	protected void Awake()
	{
		if (CosmeticAnchorManager.hasInstance && CosmeticAnchorManager.instance != this)
		{
			Object.Destroy(this);
			return;
		}
		CosmeticAnchorManager.SetInstance(this);
	}

	// Token: 0x06000E9A RID: 3738 RVA: 0x0004C617 File Offset: 0x0004A817
	public static void CreateManager()
	{
		CosmeticAnchorManager.SetInstance(new GameObject("CosmeticAnchorManager").AddComponent<CosmeticAnchorManager>());
	}

	// Token: 0x06000E9B RID: 3739 RVA: 0x0004C62D File Offset: 0x0004A82D
	private static void SetInstance(CosmeticAnchorManager manager)
	{
		CosmeticAnchorManager.instance = manager;
		CosmeticAnchorManager.hasInstance = true;
		if (Application.isPlaying)
		{
			Object.DontDestroyOnLoad(manager);
		}
	}

	// Token: 0x06000E9C RID: 3740 RVA: 0x0004C648 File Offset: 0x0004A848
	public static void RegisterCosmeticAnchor(CosmeticAnchors cA)
	{
		if (!CosmeticAnchorManager.hasInstance)
		{
			CosmeticAnchorManager.CreateManager();
		}
		if ((cA.AffectedByHunt() || cA.AffectedByBuilder()) && !CosmeticAnchorManager.allAnchors.Contains(cA))
		{
			CosmeticAnchorManager.allAnchors.Add(cA);
		}
	}

	// Token: 0x06000E9D RID: 3741 RVA: 0x0004C67E File Offset: 0x0004A87E
	public static void UnregisterCosmeticAnchor(CosmeticAnchors cA)
	{
		if (!CosmeticAnchorManager.hasInstance)
		{
			CosmeticAnchorManager.CreateManager();
		}
		if ((cA.AffectedByHunt() || cA.AffectedByBuilder()) && CosmeticAnchorManager.allAnchors.Contains(cA))
		{
			CosmeticAnchorManager.allAnchors.Remove(cA);
		}
	}

	// Token: 0x06000E9E RID: 3742 RVA: 0x0004C6B8 File Offset: 0x0004A8B8
	public void Update()
	{
		for (int i = 0; i < CosmeticAnchorManager.allAnchors.Count; i++)
		{
			CosmeticAnchorManager.allAnchors[i].TryUpdate();
		}
	}

	// Token: 0x04001066 RID: 4198
	public static CosmeticAnchorManager instance;

	// Token: 0x04001067 RID: 4199
	public static bool hasInstance = false;

	// Token: 0x04001068 RID: 4200
	public static List<CosmeticAnchors> allAnchors = new List<CosmeticAnchors>();
}
