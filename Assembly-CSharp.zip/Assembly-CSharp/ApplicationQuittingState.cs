﻿using System;
using UnityEngine;

// Token: 0x0200007A RID: 122
public static class ApplicationQuittingState
{
	// Token: 0x17000033 RID: 51
	// (get) Token: 0x06000294 RID: 660 RVA: 0x000115C4 File Offset: 0x0000F7C4
	// (set) Token: 0x06000295 RID: 661 RVA: 0x000115CB File Offset: 0x0000F7CB
	public static bool IsQuitting { get; private set; }

	// Token: 0x06000296 RID: 662 RVA: 0x000115D3 File Offset: 0x0000F7D3
	[RuntimeInitializeOnLoadMethod]
	private static void Init()
	{
		Application.quitting += ApplicationQuittingState.HandleApplicationQuitting;
	}

	// Token: 0x06000297 RID: 663 RVA: 0x000115E6 File Offset: 0x0000F7E6
	private static void HandleApplicationQuitting()
	{
		ApplicationQuittingState.IsQuitting = true;
	}
}
