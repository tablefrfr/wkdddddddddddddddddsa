﻿using System;
using UnityEngine;

// Token: 0x02000036 RID: 54
public class BuildingColor : MonoBehaviour
{
	// Token: 0x06000106 RID: 262 RVA: 0x00009944 File Offset: 0x00007B44
	private void Start()
	{
		Renderer component = base.GetComponent<Renderer>();
		Color value = new Color(this.Red, this.Green, this.Blue, 1f);
		component.material.SetColor("_Color", value);
	}

	// Token: 0x04000179 RID: 377
	[Range(0f, 178f)]
	public float Red;

	// Token: 0x0400017A RID: 378
	[Range(0f, 178f)]
	public float Green;

	// Token: 0x0400017B RID: 379
	[Range(0f, 178f)]
	public float Blue;
}
