﻿using System;

// Token: 0x020000A2 RID: 162
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public class DevInspectorColor : Attribute
{
	// Token: 0x17000048 RID: 72
	// (get) Token: 0x06000319 RID: 793 RVA: 0x00016504 File Offset: 0x00014704
	public string Color { get; }

	// Token: 0x0600031A RID: 794 RVA: 0x0001650C File Offset: 0x0001470C
	public DevInspectorColor(string color)
	{
		this.Color = color;
	}
}
