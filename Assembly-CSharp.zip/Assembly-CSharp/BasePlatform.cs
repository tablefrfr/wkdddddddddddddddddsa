﻿using System;
using UnityEngine;

// Token: 0x020003BC RID: 956
public class BasePlatform : MonoBehaviour
{
}
