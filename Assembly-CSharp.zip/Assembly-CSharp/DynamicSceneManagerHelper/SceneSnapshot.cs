﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace DynamicSceneManagerHelper
{
	// Token: 0x02000645 RID: 1605
	internal class SceneSnapshot
	{
		// Token: 0x17000447 RID: 1095
		// (get) Token: 0x060025BD RID: 9661 RVA: 0x000B9667 File Offset: 0x000B7867
		public Dictionary<OVRAnchor, SceneSnapshot.Data> Anchors { get; } = new Dictionary<OVRAnchor, SceneSnapshot.Data>();

		// Token: 0x060025BE RID: 9662 RVA: 0x000B966F File Offset: 0x000B786F
		public bool Contains(OVRAnchor anchor)
		{
			return this.Anchors.ContainsKey(anchor);
		}

		// Token: 0x02000646 RID: 1606
		public class Data
		{
			// Token: 0x0400285B RID: 10331
			public List<OVRAnchor> Children;

			// Token: 0x0400285C RID: 10332
			public Rect? Rect;

			// Token: 0x0400285D RID: 10333
			public Bounds? Bounds;
		}
	}
}
