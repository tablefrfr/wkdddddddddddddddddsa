﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020000A0 RID: 160
public class DevConsoleInstance : MonoBehaviour
{
	// Token: 0x06000316 RID: 790 RVA: 0x0000BC47 File Offset: 0x00009E47
	private void OnEnable()
	{
		base.gameObject.SetActive(false);
	}

	// Token: 0x04000478 RID: 1144
	public GorillaDevButton[] buttons;

	// Token: 0x04000479 RID: 1145
	public GameObject[] disableWhileActive;

	// Token: 0x0400047A RID: 1146
	public GameObject[] enableWhileActive;

	// Token: 0x0400047B RID: 1147
	public float maxHeight;

	// Token: 0x0400047C RID: 1148
	public float lineHeight;

	// Token: 0x0400047D RID: 1149
	public int targetLogIndex = -1;

	// Token: 0x0400047E RID: 1150
	public int currentLogIndex;

	// Token: 0x0400047F RID: 1151
	public int expandAmount = 20;

	// Token: 0x04000480 RID: 1152
	public int expandedMessageIndex = -1;

	// Token: 0x04000481 RID: 1153
	public bool canExpand = true;

	// Token: 0x04000482 RID: 1154
	public List<DevConsole.DisplayedLogLine> logLines = new List<DevConsole.DisplayedLogLine>();

	// Token: 0x04000483 RID: 1155
	public HashSet<LogType> selectedLogTypes = new HashSet<LogType>
	{
		LogType.Error,
		LogType.Exception,
		LogType.Log,
		LogType.Warning,
		LogType.Assert
	};

	// Token: 0x04000484 RID: 1156
	[SerializeField]
	private GorillaDevButton[] logTypeButtons;

	// Token: 0x04000485 RID: 1157
	[SerializeField]
	private GorillaDevButton BottomButton;

	// Token: 0x04000486 RID: 1158
	public float lineStartHeight;

	// Token: 0x04000487 RID: 1159
	public float lineStartZ;

	// Token: 0x04000488 RID: 1160
	public float textStartHeight;

	// Token: 0x04000489 RID: 1161
	public float lineStartTextWidth;

	// Token: 0x0400048A RID: 1162
	public double textScale = 0.5;

	// Token: 0x0400048B RID: 1163
	public bool isEnabled = true;

	// Token: 0x0400048C RID: 1164
	[SerializeField]
	private GameObject ConsoleLineExample;
}
