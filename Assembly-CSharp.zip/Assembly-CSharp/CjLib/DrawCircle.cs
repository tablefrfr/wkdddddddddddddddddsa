﻿using System;
using UnityEngine;

namespace CjLib
{
	// Token: 0x020007D5 RID: 2005
	[ExecuteInEditMode]
	public class DrawCircle : DrawBase
	{
		// Token: 0x0600307F RID: 12415 RVA: 0x000ED788 File Offset: 0x000EB988
		private void OnValidate()
		{
			this.Radius = Mathf.Max(0f, this.Radius);
			this.NumSegments = Mathf.Max(0, this.NumSegments);
		}

		// Token: 0x06003080 RID: 12416 RVA: 0x000ED7B2 File Offset: 0x000EB9B2
		protected override void Draw(Color color, DebugUtil.Style style, bool depthTest)
		{
			DebugUtil.DrawCircle(base.transform.position, base.transform.rotation * Vector3.back, this.Radius, this.NumSegments, color, depthTest, style);
		}

		// Token: 0x040032F0 RID: 13040
		public float Radius = 1f;

		// Token: 0x040032F1 RID: 13041
		public int NumSegments = 64;
	}
}
