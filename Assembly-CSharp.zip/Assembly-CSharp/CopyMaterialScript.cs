﻿using System;
using UnityEngine;

// Token: 0x0200046D RID: 1133
public class CopyMaterialScript : MonoBehaviour
{
	// Token: 0x06001A6D RID: 6765 RVA: 0x00087C70 File Offset: 0x00085E70
	private void Start()
	{
		if (Application.platform == RuntimePlatform.Android)
		{
			base.gameObject.SetActive(false);
		}
	}

	// Token: 0x06001A6E RID: 6766 RVA: 0x00087C87 File Offset: 0x00085E87
	private void Update()
	{
		if (this.sourceToCopyMaterialFrom.material != this.mySkinnedMeshRenderer.material)
		{
			this.mySkinnedMeshRenderer.material = this.sourceToCopyMaterialFrom.material;
		}
	}

	// Token: 0x04001E6C RID: 7788
	public SkinnedMeshRenderer sourceToCopyMaterialFrom;

	// Token: 0x04001E6D RID: 7789
	public SkinnedMeshRenderer mySkinnedMeshRenderer;
}
