﻿using System;
using UnityEngine;

// Token: 0x02000429 RID: 1065
[Serializable]
public struct FrameStamp
{
	// Token: 0x170002F5 RID: 757
	// (get) Token: 0x0600189A RID: 6298 RVA: 0x0007F546 File Offset: 0x0007D746
	public int framesElapsed
	{
		get
		{
			return Time.frameCount - this._lastFrame;
		}
	}

	// Token: 0x0600189B RID: 6299 RVA: 0x0007F554 File Offset: 0x0007D754
	public static FrameStamp Now()
	{
		return new FrameStamp
		{
			_lastFrame = Time.frameCount
		};
	}

	// Token: 0x0600189C RID: 6300 RVA: 0x0007F576 File Offset: 0x0007D776
	public override string ToString()
	{
		return string.Format("{0} frames elapsed", this.framesElapsed);
	}

	// Token: 0x0600189D RID: 6301 RVA: 0x0007F58D File Offset: 0x0007D78D
	public override int GetHashCode()
	{
		return StaticHash.Calculate(this._lastFrame);
	}

	// Token: 0x0600189E RID: 6302 RVA: 0x0007F59A File Offset: 0x0007D79A
	public static implicit operator int(FrameStamp fs)
	{
		return fs.framesElapsed;
	}

	// Token: 0x0600189F RID: 6303 RVA: 0x0007F5A4 File Offset: 0x0007D7A4
	public static implicit operator FrameStamp(int framesElapsed)
	{
		return new FrameStamp
		{
			_lastFrame = Time.frameCount - framesElapsed
		};
	}

	// Token: 0x04001C9B RID: 7323
	private int _lastFrame;
}
