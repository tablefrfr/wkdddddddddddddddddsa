﻿using System;
using UnityEngine;

// Token: 0x02000322 RID: 802
public class BuilderPieceCollider : MonoBehaviour
{
	// Token: 0x04001494 RID: 5268
	public BuilderPiece piece;
}
