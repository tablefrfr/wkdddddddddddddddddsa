﻿using System;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;

// Token: 0x02000302 RID: 770
public class GorillaIKHandTarget : MonoBehaviour
{
	// Token: 0x06001192 RID: 4498 RVA: 0x0005C585 File Offset: 0x0005A785
	private void Start()
	{
		this.thisRigidbody = base.gameObject.GetComponent<Rigidbody>();
	}

	// Token: 0x06001193 RID: 4499 RVA: 0x0005C598 File Offset: 0x0005A798
	private void FixedUpdate()
	{
		this.thisRigidbody.MovePosition(this.handToStickTo.transform.position);
		base.transform.rotation = this.handToStickTo.transform.rotation;
	}

	// Token: 0x06001194 RID: 4500 RVA: 0x00003051 File Offset: 0x00001251
	private void OnCollisionEnter(Collision collision)
	{
	}

	// Token: 0x040013EC RID: 5100
	public GameObject handToStickTo;

	// Token: 0x040013ED RID: 5101
	public bool isLeftHand;

	// Token: 0x040013EE RID: 5102
	public float hapticStrength;

	// Token: 0x040013EF RID: 5103
	private Rigidbody thisRigidbody;

	// Token: 0x040013F0 RID: 5104
	private XRController controllerReference;
}
