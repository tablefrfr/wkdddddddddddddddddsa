﻿using System;

// Token: 0x020004D8 RID: 1240
public struct EnterPlayID
{
	// Token: 0x06001C0A RID: 7178 RVA: 0x0008D9C8 File Offset: 0x0008BBC8
	[OnEnterPlay_Run]
	private static void NextID()
	{
		EnterPlayID.currentID++;
	}

	// Token: 0x06001C0B RID: 7179 RVA: 0x0008D9D8 File Offset: 0x0008BBD8
	public static EnterPlayID GetCurrent()
	{
		return new EnterPlayID
		{
			id = EnterPlayID.currentID
		};
	}

	// Token: 0x1700033D RID: 829
	// (get) Token: 0x06001C0C RID: 7180 RVA: 0x0008D9FA File Offset: 0x0008BBFA
	public bool IsCurrent
	{
		get
		{
			return this.id == EnterPlayID.currentID;
		}
	}

	// Token: 0x04001F9D RID: 8093
	private static int currentID = 1;

	// Token: 0x04001F9E RID: 8094
	private int id;
}
