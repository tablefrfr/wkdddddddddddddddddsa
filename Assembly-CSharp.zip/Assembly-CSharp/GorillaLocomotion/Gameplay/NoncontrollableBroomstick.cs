﻿using System;
using Photon.Pun;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005CA RID: 1482
	public class NoncontrollableBroomstick : MonoBehaviourPun, IGorillaGrabable, IPunObservable
	{
		// Token: 0x060022A7 RID: 8871 RVA: 0x000A8B2B File Offset: 0x000A6D2B
		protected virtual void Awake()
		{
			this._view = base.GetComponent<PhotonView>();
			this.progress = this.SplineProgressOffet % 1f;
		}

		// Token: 0x060022A8 RID: 8872 RVA: 0x000A8B4C File Offset: 0x000A6D4C
		protected virtual void Update()
		{
			if (!base.photonView.IsMine && this.progressLerpStartTime + 1f > Time.time)
			{
				this.progress = Mathf.Lerp(this.progressLerpStart, this.progressLerpEnd, (Time.time - this.progressLerpStartTime) / 1f);
			}
			else
			{
				if (this.isHeldByLocalPlayer)
				{
					this.currentSpeedMultiplier = Mathf.MoveTowards(this.currentSpeedMultiplier, this.speedMultiplierWhileHeld, this.acceleration * Time.deltaTime);
				}
				else
				{
					this.currentSpeedMultiplier = Mathf.MoveTowards(this.currentSpeedMultiplier, 1f, this.deceleration * Time.deltaTime);
				}
				if (this.goingForward)
				{
					this.progress += Time.deltaTime * this.currentSpeedMultiplier / this.duration;
					if (this.progress > 1f)
					{
						if (this.mode == SplineWalkerMode.Once)
						{
							this.progress = 1f;
						}
						else if (this.mode == SplineWalkerMode.Loop)
						{
							this.progress %= 1f;
						}
						else
						{
							this.progress = 2f - this.progress;
							this.goingForward = false;
						}
					}
				}
				else
				{
					this.progress -= Time.deltaTime * this.currentSpeedMultiplier / this.duration;
					if (this.progress < 0f)
					{
						this.progress = -this.progress;
						this.goingForward = true;
					}
				}
			}
			Vector3 point = this.spline.GetPoint(this.progress, this.constantVelocity);
			base.transform.position = point;
			if (this.lookForward)
			{
				base.transform.LookAt(base.transform.position + this.spline.GetDirection(this.progress, this.constantVelocity));
			}
		}

		// Token: 0x060022A9 RID: 8873 RVA: 0x000A8D1C File Offset: 0x000A6F1C
		public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
		{
			if (stream.IsWriting)
			{
				stream.SendNext(this.progress + this.currentSpeedMultiplier * 1f / this.duration);
				return;
			}
			this.progressLerpEnd = (float)stream.ReceiveNext();
			if (float.IsNaN(this.progressLerpEnd) || float.IsInfinity(this.progressLerpEnd))
			{
				this.progressLerpEnd = 1f;
			}
			else
			{
				this.progressLerpEnd = Mathf.Abs(this.progressLerpEnd);
				if (this.progressLerpEnd > 1f)
				{
					this.progressLerpEnd = (float)((double)this.progressLerpEnd % 1.0);
				}
			}
			this.progressLerpStart = ((Mathf.Abs(this.progressLerpEnd - this.progress) > Mathf.Abs(this.progressLerpEnd - (this.progress - 1f))) ? (this.progress - 1f) : this.progress);
			this.progressLerpStartTime = Time.time;
		}

		// Token: 0x060022AA RID: 8874 RVA: 0x000A8E16 File Offset: 0x000A7016
		protected float GetProgress()
		{
			return this.progress;
		}

		// Token: 0x060022AB RID: 8875 RVA: 0x000A8E1E File Offset: 0x000A701E
		public float GetCurrentSpeed()
		{
			return this.currentSpeedMultiplier;
		}

		// Token: 0x060022AC RID: 8876 RVA: 0x000A8E26 File Offset: 0x000A7026
		Transform IGorillaGrabable.OnGrabbed(GorillaGrabber g)
		{
			base.photonView.TransferOwnership(PhotonNetwork.LocalPlayer);
			this.isHeldByLocalPlayer = true;
			return base.transform;
		}

		// Token: 0x060022AD RID: 8877 RVA: 0x000A8E45 File Offset: 0x000A7045
		Transform IGorillaGrabable.OnGrabReleased(GorillaGrabber g)
		{
			this.isHeldByLocalPlayer = false;
			return base.transform;
		}

		// Token: 0x0400250C RID: 9484
		public BezierSpline spline;

		// Token: 0x0400250D RID: 9485
		public float duration = 30f;

		// Token: 0x0400250E RID: 9486
		public float speedMultiplierWhileHeld = 2f;

		// Token: 0x0400250F RID: 9487
		private float currentSpeedMultiplier;

		// Token: 0x04002510 RID: 9488
		public float acceleration = 1f;

		// Token: 0x04002511 RID: 9489
		public float deceleration = 1f;

		// Token: 0x04002512 RID: 9490
		private bool isHeldByLocalPlayer;

		// Token: 0x04002513 RID: 9491
		public bool lookForward = true;

		// Token: 0x04002514 RID: 9492
		public SplineWalkerMode mode;

		// Token: 0x04002515 RID: 9493
		[SerializeField]
		private float SplineProgressOffet;

		// Token: 0x04002516 RID: 9494
		private float progress;

		// Token: 0x04002517 RID: 9495
		private float progressLerpStart;

		// Token: 0x04002518 RID: 9496
		private float progressLerpEnd;

		// Token: 0x04002519 RID: 9497
		private const float progressLerpDuration = 1f;

		// Token: 0x0400251A RID: 9498
		private float progressLerpStartTime;

		// Token: 0x0400251B RID: 9499
		private bool goingForward = true;

		// Token: 0x0400251C RID: 9500
		private PhotonView _view;

		// Token: 0x0400251D RID: 9501
		[SerializeField]
		private bool constantVelocity;
	}
}
