﻿using System;

namespace emotitron.Compression
{
	// Token: 0x020007BD RID: 1981
	public enum LiteIntCompressType
	{
		// Token: 0x04003281 RID: 12929
		PackSigned,
		// Token: 0x04003282 RID: 12930
		PackUnsigned,
		// Token: 0x04003283 RID: 12931
		Range
	}
}
