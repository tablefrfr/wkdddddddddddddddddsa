﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Fusion
{
	// Token: 0x02000636 RID: 1590
	public abstract class NetworkSceneManagerBase : Behaviour, INetworkSceneManager
	{
		// Token: 0x17000439 RID: 1081
		// (get) Token: 0x0600255B RID: 9563 RVA: 0x000B7600 File Offset: 0x000B5800
		// (set) Token: 0x0600255C RID: 9564 RVA: 0x000B7608 File Offset: 0x000B5808
		public NetworkRunner Runner { get; private set; }

		// Token: 0x0600255D RID: 9565 RVA: 0x00003051 File Offset: 0x00001251
		protected virtual void OnEnable()
		{
		}

		// Token: 0x0600255E RID: 9566 RVA: 0x00003051 File Offset: 0x00001251
		protected virtual void OnDisable()
		{
		}

		// Token: 0x0600255F RID: 9567 RVA: 0x000B7614 File Offset: 0x000B5814
		protected virtual void LateUpdate()
		{
			if (!this.Runner)
			{
				return;
			}
			if (this.Runner.CurrentScene != this._currentScene)
			{
				this._currentSceneOutdated = true;
			}
			if (!this._currentSceneOutdated || this._runningCoroutine != null)
			{
				return;
			}
			NetworkSceneManagerBase exists;
			if (NetworkSceneManagerBase.s_currentlyLoading.TryGetTarget(out exists))
			{
				if (exists)
				{
					return;
				}
				NetworkSceneManagerBase.s_currentlyLoading.SetTarget(null);
			}
			SceneRef currentScene = this._currentScene;
			this._currentScene = this.Runner.CurrentScene;
			this._currentSceneOutdated = false;
			this._runningCoroutine = this.SwitchSceneWrapper(currentScene, this._currentScene);
			base.StartCoroutine(this._runningCoroutine);
		}

		// Token: 0x06002560 RID: 9568 RVA: 0x000B76C2 File Offset: 0x000B58C2
		public static bool IsScenePathOrNameEqual(Scene scene, string nameOrPath)
		{
			return scene.path == nameOrPath || scene.name == nameOrPath;
		}

		// Token: 0x06002561 RID: 9569 RVA: 0x000B76E2 File Offset: 0x000B58E2
		public static bool TryGetScenePathFromBuildSettings(SceneRef sceneRef, out string path)
		{
			if (sceneRef.IsValid)
			{
				path = SceneUtility.GetScenePathByBuildIndex(sceneRef);
				if (!string.IsNullOrEmpty(path))
				{
					return true;
				}
			}
			path = string.Empty;
			return false;
		}

		// Token: 0x06002562 RID: 9570 RVA: 0x000B770D File Offset: 0x000B590D
		public virtual bool TryGetScenePath(SceneRef sceneRef, out string path)
		{
			return NetworkSceneManagerBase.TryGetScenePathFromBuildSettings(sceneRef, out path);
		}

		// Token: 0x06002563 RID: 9571 RVA: 0x000B7718 File Offset: 0x000B5918
		public virtual bool TryGetSceneRef(string nameOrPath, out SceneRef sceneRef)
		{
			int sceneBuildIndex = FusionUnitySceneManagerUtils.GetSceneBuildIndex(nameOrPath);
			if (sceneBuildIndex >= 0)
			{
				sceneRef = sceneBuildIndex;
				return true;
			}
			sceneRef = default(SceneRef);
			return false;
		}

		// Token: 0x06002564 RID: 9572 RVA: 0x000B7748 File Offset: 0x000B5948
		public bool IsScenePathOrNameEqual(Scene scene, SceneRef sceneRef)
		{
			string nameOrPath;
			return this.TryGetScenePath(sceneRef, out nameOrPath) && NetworkSceneManagerBase.IsScenePathOrNameEqual(scene, nameOrPath);
		}

		// Token: 0x06002565 RID: 9573 RVA: 0x000B776C File Offset: 0x000B596C
		public List<NetworkObject> FindNetworkObjects(Scene scene, bool disable = true, bool addVisibilityNodes = false)
		{
			List<NetworkObject> list = new List<NetworkObject>();
			GameObject[] rootGameObjects = scene.GetRootGameObjects();
			List<NetworkObject> list2 = new List<NetworkObject>();
			foreach (GameObject gameObject in rootGameObjects)
			{
				list.Clear();
				gameObject.GetComponentsInChildren<NetworkObject>(true, list);
				foreach (NetworkObject networkObject in list)
				{
					if (networkObject.Flags.IsSceneObject() && (networkObject.gameObject.activeInHierarchy || networkObject.Flags.IsActivatedByUser()))
					{
						list2.Add(networkObject);
					}
				}
				if (addVisibilityNodes)
				{
					RunnerVisibilityNode.AddVisibilityNodes(gameObject, this.Runner);
				}
			}
			if (disable)
			{
				foreach (NetworkObject networkObject2 in list2)
				{
					networkObject2.gameObject.SetActive(false);
				}
			}
			return list2;
		}

		// Token: 0x06002566 RID: 9574 RVA: 0x000B7878 File Offset: 0x000B5A78
		void INetworkSceneManager.Initialize(NetworkRunner runner)
		{
			this.Initialize(runner);
		}

		// Token: 0x06002567 RID: 9575 RVA: 0x000B7881 File Offset: 0x000B5A81
		void INetworkSceneManager.Shutdown(NetworkRunner runner)
		{
			this.Shutdown(runner);
		}

		// Token: 0x06002568 RID: 9576 RVA: 0x000B788A File Offset: 0x000B5A8A
		bool INetworkSceneManager.IsReady(NetworkRunner runner)
		{
			return this._runningCoroutine == null && !this._currentSceneOutdated && !(runner.CurrentScene != this._currentScene);
		}

		// Token: 0x06002569 RID: 9577 RVA: 0x000B78B6 File Offset: 0x000B5AB6
		protected virtual void Initialize(NetworkRunner runner)
		{
			this.Runner = runner;
		}

		// Token: 0x0600256A RID: 9578 RVA: 0x000B78C0 File Offset: 0x000B5AC0
		protected virtual void Shutdown(NetworkRunner runner)
		{
			try
			{
				if (this._runningCoroutine != null)
				{
					this.LogWarn(string.Format("There is an ongoing scene load ({0}), stopping and disposing coroutine.", this._currentScene));
					base.StopCoroutine(this._runningCoroutine);
					IDisposable disposable = this._runningCoroutine as IDisposable;
					if (disposable != null)
					{
						disposable.Dispose();
					}
				}
			}
			finally
			{
				this.Runner = null;
				this._runningCoroutine = null;
				this._currentScene = SceneRef.None;
				this._currentSceneOutdated = false;
			}
		}

		// Token: 0x0600256B RID: 9579
		protected abstract IEnumerator SwitchScene(SceneRef prevScene, SceneRef newScene, NetworkSceneManagerBase.FinishedLoadingDelegate finished);

		// Token: 0x0600256C RID: 9580 RVA: 0x00003051 File Offset: 0x00001251
		[Conditional("FUSION_NETWORK_SCENE_MANAGER_TRACE")]
		protected void LogTrace(string msg)
		{
		}

		// Token: 0x0600256D RID: 9581 RVA: 0x000B7948 File Offset: 0x000B5B48
		protected void LogError(string msg)
		{
			Log.Error("[NetworkSceneManager] " + ((this != null) ? base.name : "<destroyed>") + ": " + msg);
		}

		// Token: 0x0600256E RID: 9582 RVA: 0x000B7975 File Offset: 0x000B5B75
		protected void LogWarn(string msg)
		{
			Log.Warn("[NetworkSceneManager] " + ((this != null) ? base.name : "<destroyed>") + ": " + msg);
		}

		// Token: 0x0600256F RID: 9583 RVA: 0x000B79A2 File Offset: 0x000B5BA2
		private IEnumerator SwitchSceneWrapper(SceneRef prevScene, SceneRef newScene)
		{
			bool finishCalled = false;
			Dictionary<Guid, NetworkObject> sceneObjects = new Dictionary<Guid, NetworkObject>();
			Exception error = null;
			NetworkSceneManagerBase.FinishedLoadingDelegate finished = delegate(IEnumerable<NetworkObject> objects)
			{
				finishCalled = true;
				foreach (NetworkObject networkObject in objects)
				{
					sceneObjects.Add(networkObject.NetworkGuid, networkObject);
				}
			};
			try
			{
				NetworkSceneManagerBase.s_currentlyLoading.SetTarget(this);
				this.Runner.InvokeSceneLoadStart();
				IEnumerator coro = this.SwitchScene(prevScene, newScene, finished);
				bool next = true;
				while (next)
				{
					try
					{
						next = coro.MoveNext();
					}
					catch (Exception ex)
					{
						error = ex;
						break;
					}
					if (next)
					{
						yield return coro.Current;
					}
				}
				coro = null;
			}
			finally
			{
				NetworkSceneManagerBase.s_currentlyLoading.SetTarget(null);
				this._runningCoroutine = null;
			}
			if (error != null)
			{
				this.LogError(string.Format("Failed to switch scenes: {0}", error));
			}
			else if (!finishCalled)
			{
				this.LogError("Failed to switch scenes: SwitchScene implementation did not invoke finished delegate");
			}
			else
			{
				this.Runner.RegisterSceneObjects(sceneObjects.Values);
				this.Runner.InvokeSceneLoadDone();
			}
			yield break;
			yield break;
		}

		// Token: 0x0400280F RID: 10255
		private static WeakReference<NetworkSceneManagerBase> s_currentlyLoading = new WeakReference<NetworkSceneManagerBase>(null);

		// Token: 0x04002810 RID: 10256
		[InlineHelp]
		[ToggleLeft]
		[MultiPropertyDrawersFix]
		public bool ShowHierarchyWindowOverlay = true;

		// Token: 0x04002811 RID: 10257
		private IEnumerator _runningCoroutine;

		// Token: 0x04002812 RID: 10258
		private bool _currentSceneOutdated;

		// Token: 0x04002813 RID: 10259
		private SceneRef _currentScene;

		// Token: 0x02000637 RID: 1591
		// (Invoke) Token: 0x06002573 RID: 9587
		protected delegate void FinishedLoadingDelegate(IEnumerable<NetworkObject> sceneObjects);
	}
}
