﻿using System;
using System.Collections.Generic;
using System.Reflection;
using Fusion;
using Fusion.StatsInternal;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.UI;

// Token: 0x0200020D RID: 525
[ScriptHelp(BackColor = EditorHeaderBackColor.Olive)]
[ExecuteAlways]
public class FusionStats : Fusion.Behaviour
{
	// Token: 0x06000AA0 RID: 2720 RVA: 0x00038C90 File Offset: 0x00036E90
	internal static FusionStats CreateInternal(NetworkRunner runner = null, FusionStats.DefaultLayouts layout = FusionStats.DefaultLayouts.Left, Simulation.Statistics.NetStatFlags? netStatsMask = null, Simulation.Statistics.SimStatFlags? simStatsMask = null)
	{
		return FusionStats.Create(null, runner, new FusionStats.DefaultLayouts?(layout), new FusionStats.DefaultLayouts?(layout), netStatsMask, simStatsMask);
	}

	// Token: 0x06000AA1 RID: 2721 RVA: 0x00038CA8 File Offset: 0x00036EA8
	public static FusionStats Create(Transform parent = null, NetworkRunner runner = null, FusionStats.DefaultLayouts? screenLayout = null, FusionStats.DefaultLayouts? objectLayout = null, Simulation.Statistics.NetStatFlags? netStatsMask = null, Simulation.Statistics.SimStatFlags? simStatsMask = null)
	{
		GameObject gameObject = new GameObject("FusionStats " + (runner ? runner.name : "null"));
		if (parent)
		{
			gameObject.transform.SetParent(parent);
		}
		FusionStats fusionStats = gameObject.AddComponent<FusionStats>();
		fusionStats.ResetInternal(null, netStatsMask, simStatsMask, objectLayout, screenLayout);
		fusionStats.Runner = runner;
		if (runner != null)
		{
			fusionStats.AutoDestroy = true;
		}
		return fusionStats;
	}

	// Token: 0x06000AA2 RID: 2722 RVA: 0x00038D22 File Offset: 0x00036F22
	[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
	private static void ResetStatics()
	{
		FusionStats._statsForRunnerLookup.Clear();
		FusionStats._activeGuids.Clear();
		FusionStats._newInputSystemFound = null;
	}

	// Token: 0x1700013B RID: 315
	// (get) Token: 0x06000AA3 RID: 2723 RVA: 0x00038D43 File Offset: 0x00036F43
	public static Simulation.Statistics.NetStatFlags DefaultNetStatsMask
	{
		get
		{
			return Simulation.Statistics.NetStatFlags.RoundTripTime | Simulation.Statistics.NetStatFlags.SentPacketSizes | Simulation.Statistics.NetStatFlags.ReceivedPacketSizes;
		}
	}

	// Token: 0x1700013C RID: 316
	// (get) Token: 0x06000AA4 RID: 2724 RVA: 0x00038D46 File Offset: 0x00036F46
	private bool ShowColorControls
	{
		get
		{
			return !Application.isPlaying && this._modifyColors;
		}
	}

	// Token: 0x1700013D RID: 317
	// (get) Token: 0x06000AA5 RID: 2725 RVA: 0x00038D57 File Offset: 0x00036F57
	private bool IsNotPlaying
	{
		get
		{
			return !Application.isPlaying;
		}
	}

	// Token: 0x1700013E RID: 318
	// (get) Token: 0x06000AA6 RID: 2726 RVA: 0x00038D61 File Offset: 0x00036F61
	// (set) Token: 0x06000AA7 RID: 2727 RVA: 0x00038D69 File Offset: 0x00036F69
	public FusionStats.StatCanvasTypes CanvasType
	{
		get
		{
			return this._canvasType;
		}
		set
		{
			this._canvasType = value;
			this.DirtyLayout(2);
		}
	}

	// Token: 0x1700013F RID: 319
	// (get) Token: 0x06000AA8 RID: 2728 RVA: 0x00038D79 File Offset: 0x00036F79
	// (set) Token: 0x06000AA9 RID: 2729 RVA: 0x00038D81 File Offset: 0x00036F81
	public bool ShowButtonLabels
	{
		get
		{
			return this._showButtonLabels;
		}
		set
		{
			this._showButtonLabels = value;
			this.DirtyLayout(1);
		}
	}

	// Token: 0x17000140 RID: 320
	// (get) Token: 0x06000AAA RID: 2730 RVA: 0x00038D91 File Offset: 0x00036F91
	// (set) Token: 0x06000AAB RID: 2731 RVA: 0x00038D99 File Offset: 0x00036F99
	public int MaxHeaderHeight
	{
		get
		{
			return this._maxHeaderHeight;
		}
		set
		{
			this._maxHeaderHeight = value;
			this.DirtyLayout(1);
		}
	}

	// Token: 0x17000141 RID: 321
	// (get) Token: 0x06000AAC RID: 2732 RVA: 0x00038DA9 File Offset: 0x00036FA9
	// (set) Token: 0x06000AAD RID: 2733 RVA: 0x00038DB1 File Offset: 0x00036FB1
	public Rect GameObjectRect
	{
		get
		{
			return this._gameObjectRect;
		}
		set
		{
			this._gameObjectRect = value;
			this.DirtyLayout(1);
		}
	}

	// Token: 0x17000142 RID: 322
	// (get) Token: 0x06000AAE RID: 2734 RVA: 0x00038DC1 File Offset: 0x00036FC1
	// (set) Token: 0x06000AAF RID: 2735 RVA: 0x00038DC9 File Offset: 0x00036FC9
	public Rect OverlayRect
	{
		get
		{
			return this._overlayRect;
		}
		set
		{
			this._overlayRect = value;
			this.DirtyLayout(1);
		}
	}

	// Token: 0x17000143 RID: 323
	// (get) Token: 0x06000AB0 RID: 2736 RVA: 0x00038DD9 File Offset: 0x00036FD9
	// (set) Token: 0x06000AB1 RID: 2737 RVA: 0x00038DE1 File Offset: 0x00036FE1
	public FusionGraph.Layouts DefaultLayout
	{
		get
		{
			return this._defaultLayout;
		}
		set
		{
			this._defaultLayout = value;
			this.DirtyLayout(1);
		}
	}

	// Token: 0x17000144 RID: 324
	// (get) Token: 0x06000AB2 RID: 2738 RVA: 0x00038DF1 File Offset: 0x00036FF1
	// (set) Token: 0x06000AB3 RID: 2739 RVA: 0x00038DF9 File Offset: 0x00036FF9
	public bool NoTextOverlap
	{
		get
		{
			return this._noTextOverlap;
		}
		set
		{
			this._noTextOverlap = value;
			this.DirtyLayout(1);
		}
	}

	// Token: 0x17000145 RID: 325
	// (get) Token: 0x06000AB4 RID: 2740 RVA: 0x00038E09 File Offset: 0x00037009
	// (set) Token: 0x06000AB5 RID: 2741 RVA: 0x00038E11 File Offset: 0x00037011
	public bool NoGraphShader
	{
		get
		{
			return this._noGraphShader;
		}
		set
		{
			this._noGraphShader = value;
			this.DirtyLayout(1);
		}
	}

	// Token: 0x17000146 RID: 326
	// (get) Token: 0x06000AB6 RID: 2742 RVA: 0x00038E21 File Offset: 0x00037021
	// (set) Token: 0x06000AB7 RID: 2743 RVA: 0x00038E29 File Offset: 0x00037029
	public int GraphMaxWidth
	{
		get
		{
			return this._graphMaxWidth;
		}
		set
		{
			this._graphMaxWidth = value;
			this.DirtyLayout(1);
		}
	}

	// Token: 0x17000147 RID: 327
	// (get) Token: 0x06000AB8 RID: 2744 RVA: 0x00038E39 File Offset: 0x00037039
	// (set) Token: 0x06000AB9 RID: 2745 RVA: 0x00038E41 File Offset: 0x00037041
	public bool EnableObjectStats
	{
		get
		{
			return this._enableObjectStats;
		}
		set
		{
			this._enableObjectStats = value;
			this.DirtyLayout(1);
		}
	}

	// Token: 0x17000148 RID: 328
	// (get) Token: 0x06000ABA RID: 2746 RVA: 0x00038E51 File Offset: 0x00037051
	private bool ShowMissingNetObjWarning
	{
		get
		{
			return this._enableObjectStats && this.Object == null;
		}
	}

	// Token: 0x17000149 RID: 329
	// (get) Token: 0x06000ABB RID: 2747 RVA: 0x00038E69 File Offset: 0x00037069
	public NetworkObject Object
	{
		get
		{
			if (this._object == null)
			{
				this._object = base.GetComponentInParent<NetworkObject>();
			}
			return this._object;
		}
	}

	// Token: 0x1700014A RID: 330
	// (get) Token: 0x06000ABC RID: 2748 RVA: 0x00038E8B File Offset: 0x0003708B
	// (set) Token: 0x06000ABD RID: 2749 RVA: 0x00038E93 File Offset: 0x00037093
	public int ObjectTitleHeight
	{
		get
		{
			return this._objectTitleHeight;
		}
		set
		{
			this._objectTitleHeight = value;
			this.DirtyLayout(1);
		}
	}

	// Token: 0x1700014B RID: 331
	// (get) Token: 0x06000ABE RID: 2750 RVA: 0x00038EA3 File Offset: 0x000370A3
	// (set) Token: 0x06000ABF RID: 2751 RVA: 0x00038EAB File Offset: 0x000370AB
	public int ObjectIdsHeight
	{
		get
		{
			return this._objectIdsHeight;
		}
		set
		{
			this._objectIdsHeight = value;
			this.DirtyLayout(1);
		}
	}

	// Token: 0x1700014C RID: 332
	// (get) Token: 0x06000AC0 RID: 2752 RVA: 0x00038EBB File Offset: 0x000370BB
	// (set) Token: 0x06000AC1 RID: 2753 RVA: 0x00038EAB File Offset: 0x000370AB
	public int ObjectMetersHeight
	{
		get
		{
			return this._objectMetersHeight;
		}
		set
		{
			this._objectIdsHeight = value;
			this.DirtyLayout(1);
		}
	}

	// Token: 0x1700014D RID: 333
	// (get) Token: 0x06000AC2 RID: 2754 RVA: 0x00038EC4 File Offset: 0x000370C4
	// (set) Token: 0x06000AC3 RID: 2755 RVA: 0x00038F66 File Offset: 0x00037166
	public NetworkRunner Runner
	{
		get
		{
			if (!Application.isPlaying)
			{
				return null;
			}
			if (this._runner)
			{
				if (!this._runner.IsShutdown)
				{
					return this._runner;
				}
				this.Runner = null;
			}
			if (this.Object)
			{
				NetworkRunner runner = this._object.Runner;
				if (runner && (!this.EnforceSingle || (runner.Mode & this.ConnectTo) != (SimulationModes)0))
				{
					this.Runner = runner;
					return this._runner;
				}
			}
			NetworkRunner networkRunner;
			FusionStatsUtilities.TryFindActiveRunner(this, out networkRunner, new SimulationModes?(this.ConnectTo));
			this.Runner = networkRunner;
			return networkRunner;
		}
		set
		{
			if (this._runner == value)
			{
				return;
			}
			this.DisassociateWithRunner(this._runner);
			this._runner = value;
			this.AssociateWithRunner(value);
			this.UpdateTitle();
		}
	}

	// Token: 0x1700014E RID: 334
	// (get) Token: 0x06000AC4 RID: 2756 RVA: 0x00038F97 File Offset: 0x00037197
	// (set) Token: 0x06000AC5 RID: 2757 RVA: 0x00038F9F File Offset: 0x0003719F
	public Simulation.Statistics.ObjStatFlags IncludedObjectStats
	{
		get
		{
			return this._includedObjStats;
		}
		set
		{
			this._includedObjStats = value;
			this._activeDirty = true;
		}
	}

	// Token: 0x1700014F RID: 335
	// (get) Token: 0x06000AC6 RID: 2758 RVA: 0x00038FAF File Offset: 0x000371AF
	// (set) Token: 0x06000AC7 RID: 2759 RVA: 0x00038FB7 File Offset: 0x000371B7
	public Simulation.Statistics.NetStatFlags IncludedNetStats
	{
		get
		{
			return this._includedNetStats;
		}
		set
		{
			this._includedNetStats = value;
			this._activeDirty = true;
		}
	}

	// Token: 0x17000150 RID: 336
	// (get) Token: 0x06000AC8 RID: 2760 RVA: 0x00038FC7 File Offset: 0x000371C7
	// (set) Token: 0x06000AC9 RID: 2761 RVA: 0x00038FCF File Offset: 0x000371CF
	public Simulation.Statistics.SimStatFlags IncludedSimStats
	{
		get
		{
			return this._includedSimStats;
		}
		set
		{
			this._includedSimStats = value;
			this._activeDirty = true;
		}
	}

	// Token: 0x17000151 RID: 337
	// (get) Token: 0x06000ACA RID: 2762 RVA: 0x00038FDF File Offset: 0x000371DF
	public bool ModifyColors
	{
		get
		{
			return this._modifyColors;
		}
	}

	// Token: 0x17000152 RID: 338
	// (get) Token: 0x06000ACB RID: 2763 RVA: 0x00038FE7 File Offset: 0x000371E7
	public Color FontColor
	{
		get
		{
			return this._fontColor;
		}
	}

	// Token: 0x17000153 RID: 339
	// (get) Token: 0x06000ACC RID: 2764 RVA: 0x00038FEF File Offset: 0x000371EF
	public Color GraphColorGood
	{
		get
		{
			return this._graphColorGood;
		}
	}

	// Token: 0x17000154 RID: 340
	// (get) Token: 0x06000ACD RID: 2765 RVA: 0x00038FF7 File Offset: 0x000371F7
	public Color GraphColorWarn
	{
		get
		{
			return this._graphColorWarn;
		}
	}

	// Token: 0x17000155 RID: 341
	// (get) Token: 0x06000ACE RID: 2766 RVA: 0x00038FFF File Offset: 0x000371FF
	public Color GraphColorBad
	{
		get
		{
			return this._graphColorBad;
		}
	}

	// Token: 0x17000156 RID: 342
	// (get) Token: 0x06000ACF RID: 2767 RVA: 0x00039007 File Offset: 0x00037207
	public Color GraphColorFlag
	{
		get
		{
			return this._graphColorFlag;
		}
	}

	// Token: 0x17000157 RID: 343
	// (get) Token: 0x06000AD0 RID: 2768 RVA: 0x0003900F File Offset: 0x0003720F
	public Color SimDataBackColor
	{
		get
		{
			return this._simDataBackColor;
		}
	}

	// Token: 0x17000158 RID: 344
	// (get) Token: 0x06000AD1 RID: 2769 RVA: 0x00039017 File Offset: 0x00037217
	public Color NetDataBackColor
	{
		get
		{
			return this._netDataBackColor;
		}
	}

	// Token: 0x17000159 RID: 345
	// (get) Token: 0x06000AD2 RID: 2770 RVA: 0x0003901F File Offset: 0x0003721F
	public Color ObjDataBackColor
	{
		get
		{
			return this._objDataBackColor;
		}
	}

	// Token: 0x1700015A RID: 346
	// (get) Token: 0x06000AD3 RID: 2771 RVA: 0x00039027 File Offset: 0x00037227
	public Rect CurrentRect
	{
		get
		{
			if (this._canvasType != FusionStats.StatCanvasTypes.GameObject)
			{
				return this._overlayRect;
			}
			return this._gameObjectRect;
		}
	}

	// Token: 0x06000AD4 RID: 2772 RVA: 0x00039040 File Offset: 0x00037240
	private void UpdateTitle()
	{
		string text = this._runner ? this._runner.name : "Disconnected";
		if (this._titleText)
		{
			this._titleText.text = text;
		}
	}

	// Token: 0x1700015B RID: 347
	// (get) Token: 0x06000AD5 RID: 2773 RVA: 0x00037118 File Offset: 0x00035318
	private Shader Shader
	{
		get
		{
			return Resources.Load<Shader>("FusionGraphShader");
		}
	}

	// Token: 0x06000AD6 RID: 2774 RVA: 0x00039086 File Offset: 0x00037286
	private void DirtyLayout(int minimumRefreshes = 1)
	{
		if (this._layoutDirty < minimumRefreshes)
		{
			this._layoutDirty = minimumRefreshes;
		}
	}

	// Token: 0x06000AD7 RID: 2775 RVA: 0x00039098 File Offset: 0x00037298
	private void ResetInternal(bool? enableObjectStats = null, Simulation.Statistics.NetStatFlags? netStatsMask = null, Simulation.Statistics.SimStatFlags? simStatsMask = null, FusionStats.DefaultLayouts? objectLayout = null, FusionStats.DefaultLayouts? screenLayout = null)
	{
		Canvas componentInChildren = base.GetComponentInChildren<Canvas>();
		if (componentInChildren)
		{
			UnityEngine.Object.DestroyImmediate(componentInChildren.gameObject);
		}
		FusionStatsBillboard fusionStatsBillboard;
		if (!base.TryGetComponent<FusionStatsBillboard>(out fusionStatsBillboard))
		{
			base.gameObject.AddComponent<FusionStatsBillboard>().UpdateLookAt();
		}
		bool flag = base.GetComponentInParent<NetworkObject>();
		if (enableObjectStats.GetValueOrDefault() || (enableObjectStats.GetValueOrDefault(true) && flag))
		{
			this.EnableObjectStats = true;
			this._includedObjStats = Simulation.Statistics.ObjStatFlags.Buffer;
			this._includedSimStats = simStatsMask.GetValueOrDefault();
			this._includedNetStats = netStatsMask.GetValueOrDefault();
			this._canvasType = FusionStats.StatCanvasTypes.GameObject;
			this.EnforceSingle = false;
			this.GraphColumnCount = 1;
		}
		else
		{
			this.GraphColumnCount = 0;
			if (base.transform.parent)
			{
				this._canvasType = FusionStats.StatCanvasTypes.GameObject;
				this.EnforceSingle = false;
			}
			else
			{
				this._canvasType = FusionStats.StatCanvasTypes.Overlay;
				this.EnforceSingle = true;
			}
			this._includedSimStats = simStatsMask.GetValueOrDefault(Simulation.Statistics.SimStatFlags.ForwardSimCount | Simulation.Statistics.SimStatFlags.ResimCount | Simulation.Statistics.SimStatFlags.PacketSize);
			this._includedNetStats = netStatsMask.GetValueOrDefault(Simulation.Statistics.NetStatFlags.RoundTripTime | Simulation.Statistics.NetStatFlags.SentPacketSizes | Simulation.Statistics.NetStatFlags.ReceivedPacketSizes);
		}
		this.ApplyDefaultLayout(objectLayout.GetValueOrDefault(flag ? FusionStats.DefaultLayouts.UpperRight : FusionStats.DefaultLayouts.Full), new FusionStats.StatCanvasTypes?(FusionStats.StatCanvasTypes.GameObject));
		this.ApplyDefaultLayout(screenLayout.GetValueOrDefault(FusionStats.DefaultLayouts.Right), new FusionStats.StatCanvasTypes?(FusionStats.StatCanvasTypes.Overlay));
		this.Guid = System.Guid.NewGuid().ToString().Substring(0, 13);
		this.GenerateGraphs();
	}

	// Token: 0x06000AD8 RID: 2776 RVA: 0x000391E4 File Offset: 0x000373E4
	private void Awake()
	{
		if (this._guidesRT)
		{
			UnityEngine.Object.Destroy(this._guidesRT.gameObject);
		}
		if (Application.isPlaying)
		{
			this._foundViews = new List<IFusionStatsView>();
			base.GetComponentsInChildren<IFusionStatsView>(true, this._foundViews);
		}
		if (this.Guid == "")
		{
			this.Guid = System.Guid.NewGuid().ToString().Substring(0, 13);
		}
		if (this.EnforceSingle && this.Guid != null)
		{
			if (FusionStats._activeGuids.ContainsKey(this.Guid))
			{
				UnityEngine.Object.Destroy(base.gameObject);
				return;
			}
			FusionStats._activeGuids.Add(this.Guid, this);
		}
		if (this.EnforceSingle && base.transform.parent == null && this._canvasType == FusionStats.StatCanvasTypes.Overlay)
		{
			UnityEngine.Object.DontDestroyOnLoad(base.gameObject);
		}
	}

	// Token: 0x06000AD9 RID: 2777 RVA: 0x000392CD File Offset: 0x000374CD
	private void Start()
	{
		if (Application.isPlaying)
		{
			this.Initialize();
			this._activeDirty = true;
			this._layoutDirty = 2;
		}
	}

	// Token: 0x06000ADA RID: 2778 RVA: 0x000392EC File Offset: 0x000374EC
	private void OnDestroy()
	{
		this.DisassociateWithRunner(this._runner);
		FusionStats x;
		if (this.Guid != null && FusionStats._activeGuids.TryGetValue(this.Guid, out x) && x == this)
		{
			FusionStats._activeGuids.Remove(this.Guid);
		}
	}

	// Token: 0x06000ADB RID: 2779 RVA: 0x0003933B File Offset: 0x0003753B
	[BehaviourButtonAction("Destroy Graphs", null, "_canvasRT", ConditionFlags = BehaviourActionAttribute.ActionFlags.ShowAtNotRuntime)]
	private void DestroyGraphs()
	{
		if (this._canvasRT)
		{
			UnityEngine.Object.DestroyImmediate(this._canvasRT.gameObject);
		}
		this._canvasRT = null;
	}

	// Token: 0x1700015C RID: 348
	// (get) Token: 0x06000ADC RID: 2780 RVA: 0x00039364 File Offset: 0x00037564
	public static bool NewInputSystemFound
	{
		get
		{
			if (FusionStats._newInputSystemFound == null)
			{
				Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
				for (int i = 0; i < assemblies.Length; i++)
				{
					Type[] types = assemblies[i].GetTypes();
					for (int j = 0; j < types.Length; j++)
					{
						if (types[j].Namespace == "UnityEngine.InputSystem")
						{
							FusionStats._newInputSystemFound = new bool?(true);
							return true;
						}
					}
				}
				FusionStats._newInputSystemFound = new bool?(false);
				return false;
			}
			return FusionStats._newInputSystemFound.Value;
		}
	}

	// Token: 0x06000ADD RID: 2781 RVA: 0x000393E8 File Offset: 0x000375E8
	private void Initialize()
	{
		if (Application.isPlaying && !FusionStats.NewInputSystemFound && UnityEngine.Object.FindObjectOfType<EventSystem>() == null)
		{
			GameObject gameObject = new GameObject("Event System");
			gameObject.AddComponent<EventSystem>();
			gameObject.AddComponent<StandaloneInputModule>();
			if (Application.isPlaying)
			{
				UnityEngine.Object.DontDestroyOnLoad(gameObject);
			}
		}
		if (!this._canvasRT)
		{
			this.GenerateGraphs();
		}
		if (this._canvasRT)
		{
			Button togglButton = this._togglButton;
			if (togglButton != null)
			{
				togglButton.onClick.RemoveListener(new UnityAction(this.Toggle));
			}
			Button canvsButton = this._canvsButton;
			if (canvsButton != null)
			{
				canvsButton.onClick.RemoveListener(new UnityAction(this.ToggleCanvasType));
			}
			Button clearButton = this._clearButton;
			if (clearButton != null)
			{
				clearButton.onClick.RemoveListener(new UnityAction(this.Clear));
			}
			Button pauseButton = this._pauseButton;
			if (pauseButton != null)
			{
				pauseButton.onClick.RemoveListener(new UnityAction(this.Pause));
			}
			Button closeButton = this._closeButton;
			if (closeButton != null)
			{
				closeButton.onClick.RemoveListener(new UnityAction(this.Close));
			}
			Button titleButton = this._titleButton;
			if (titleButton != null)
			{
				titleButton.onClick.RemoveListener(new UnityAction(this.PingSelectFusionStats));
			}
			Button objctButton = this._objctButton;
			if (objctButton != null)
			{
				objctButton.onClick.RemoveListener(new UnityAction(this.PingSelectObject));
			}
			Button togglButton2 = this._togglButton;
			if (togglButton2 != null)
			{
				togglButton2.onClick.AddListener(new UnityAction(this.Toggle));
			}
			Button canvsButton2 = this._canvsButton;
			if (canvsButton2 != null)
			{
				canvsButton2.onClick.AddListener(new UnityAction(this.ToggleCanvasType));
			}
			Button clearButton2 = this._clearButton;
			if (clearButton2 != null)
			{
				clearButton2.onClick.AddListener(new UnityAction(this.Clear));
			}
			Button pauseButton2 = this._pauseButton;
			if (pauseButton2 != null)
			{
				pauseButton2.onClick.AddListener(new UnityAction(this.Pause));
			}
			Button closeButton2 = this._closeButton;
			if (closeButton2 != null)
			{
				closeButton2.onClick.AddListener(new UnityAction(this.Close));
			}
			Button titleButton2 = this._titleButton;
			if (titleButton2 != null)
			{
				titleButton2.onClick.AddListener(new UnityAction(this.PingSelectFusionStats));
			}
			Button objctButton2 = this._objctButton;
			if (objctButton2 != null)
			{
				objctButton2.onClick.AddListener(new UnityAction(this.PingSelectObject));
			}
			base.GetComponentsInChildren<IFusionStatsView>(true, this._foundViews);
			foreach (IFusionStatsView fusionStatsView in this._foundViews)
			{
				fusionStatsView.Initialize();
			}
			this._layoutDirty = 1;
		}
	}

	// Token: 0x1700015D RID: 349
	// (get) Token: 0x06000ADE RID: 2782 RVA: 0x0003968C File Offset: 0x0003788C
	private bool _graphsAreMissing
	{
		get
		{
			return this._canvasRT == null;
		}
	}

	// Token: 0x06000ADF RID: 2783 RVA: 0x0003969C File Offset: 0x0003789C
	[BehaviourButtonAction("Generate Graphs", null, "_graphsAreMissing", ConditionFlags = BehaviourActionAttribute.ActionFlags.ShowAtNotRuntime)]
	private void GenerateGraphs()
	{
		Transform component = base.gameObject.GetComponent<Transform>();
		this._canvasRT = component.CreateRectTransform("Stats Canvas", false);
		this._canvas = this._canvasRT.gameObject.AddComponent<Canvas>();
		this._canvas.renderMode = RenderMode.ScreenSpaceOverlay;
		if (this.Runner && this.Runner.IsRunning)
		{
			RunnerVisibilityNode.AddVisibilityNodes(this._canvasRT.gameObject, this.Runner);
		}
		CanvasScaler canvasScaler = this._canvasRT.gameObject.AddComponent<CanvasScaler>();
		canvasScaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
		canvasScaler.referenceResolution = new Vector2(1080f, 1080f);
		canvasScaler.matchWidthOrHeight = 0.4f;
		this._canvasRT.gameObject.AddComponent<GraphicRaycaster>();
		this._rootPanelRT = this._canvasRT.CreateRectTransform("Root Panel", false);
		this._headerRT = this._rootPanelRT.CreateRectTransform("Header Panel", false).AddCircleSprite(this.PanelColor);
		this._titleRT = this._headerRT.CreateRectTransform("Runner Title", false).SetAnchors(0f, 1f, 0.75f, 1f).SetOffsets(6f, -6f, 0f, -6f);
		this._titleButton = this._titleRT.gameObject.AddComponent<Button>();
		this._titleText = this._titleRT.AddText(this._runner ? this._runner.name : "Disconnected", TextAnchor.UpperCenter, this._fontColor);
		this._titleText.raycastTarget = true;
		this._buttonsRT = this._headerRT.CreateRectTransform("Buttons", false).SetAnchors(0f, 1f, 0f, 0.75f).SetOffsets(6f, -6f, 6f, 0f);
		HorizontalLayoutGroup horizontalLayoutGroup = this._buttonsRT.gameObject.AddComponent<HorizontalLayoutGroup>();
		horizontalLayoutGroup.childControlHeight = true;
		horizontalLayoutGroup.childControlWidth = true;
		horizontalLayoutGroup.spacing = 6f;
		this._buttonsRT.MakeButton(ref this._togglButton, "▼", "HIDE", out this._togglIcon, out this._togglLabel, new UnityAction(this.Toggle));
		this._buttonsRT.MakeButton(ref this._canvsButton, "ﬦ", "CANVAS", out this._canvsIcon, out this._canvsLabel, new UnityAction(this.ToggleCanvasType));
		this._buttonsRT.MakeButton(ref this._pauseButton, "װ", "PAUSE", out this._pauseIcon, out this._pauseLabel, new UnityAction(this.Pause));
		this._buttonsRT.MakeButton(ref this._clearButton, "ᴓ", "CLEAR", out this._clearIcon, out this._clearLabel, new UnityAction(this.Clear));
		this._buttonsRT.MakeButton(ref this._closeButton, "x", "CLOSE", out this._closeIcon, out this._closeLabel, new UnityAction(this.Close));
		this._togglIcon.rectTransform.anchorMax = new Vector2(1f, 0.85f);
		this._statsPanelRT = this._rootPanelRT.CreateRectTransform("Stats Panel", false).AddCircleSprite(this.PanelColor);
		this._objectTitlePanelRT = this._statsPanelRT.CreateRectTransform("Object Name Panel", false).ExpandTopAnchor(new float?((float)6)).AddCircleSprite(this._objDataBackColor);
		this._objctButton = this._objectTitlePanelRT.gameObject.AddComponent<Button>();
		RectTransform rt = this._objectTitlePanelRT.CreateRectTransform("Object Name", false).SetAnchors(0f, 1f, 0.15f, 0.85f).SetOffsets(10f, -10f, 0f, 0f);
		this._objectNameText = rt.AddText("Object Name", TextAnchor.MiddleCenter, this._fontColor);
		this._objectNameText.alignByGeometry = false;
		this._objectNameText.raycastTarget = false;
		this._objectIdsGroupRT = FusionStatsObjectIds.Create(this._statsPanelRT, this);
		this._objectMetersPanelRT = this._statsPanelRT.CreateRectTransform("Object Meters Layout", false).ExpandTopAnchor(new float?((float)6)).AddVerticalLayoutGroup(6f, null, null, null, null);
		FusionStatsMeterBar.Create(this._objectMetersPanelRT, this, Simulation.Statistics.StatSourceTypes.NetworkObject, 0, 15f, 30f);
		FusionStatsMeterBar.Create(this._objectMetersPanelRT, this, Simulation.Statistics.StatSourceTypes.NetworkObject, 1, 3f, 6f);
		this._graphsLayoutRT = this._statsPanelRT.CreateRectTransform("Graphs Layout", false).ExpandAnchor(null).SetOffsets(6f, 0f, 0f, 0f);
		this._graphGridLayoutGroup = this._graphsLayoutRT.AddGridlLayoutGroup(6f, null, null, null, null);
		this._objGraphs = new FusionGraph[2];
		for (int i = 0; i < 2; i++)
		{
			if (this.InitializeAllGraphs || (1 << i & (int)this._includedObjStats) != 0)
			{
				this.CreateGraph(Simulation.Statistics.StatSourceTypes.NetworkObject, i, this._graphsLayoutRT);
			}
		}
		this._netGraphs = new FusionGraph[3];
		for (int j = 0; j < 3; j++)
		{
			if (this.InitializeAllGraphs || (1 << j & (int)this._includedNetStats) != 0)
			{
				this.CreateGraph(Simulation.Statistics.StatSourceTypes.NetConnection, j, this._graphsLayoutRT);
			}
		}
		this._simGraphs = new FusionGraph[16];
		for (int k = 0; k < 16; k++)
		{
			if (this.InitializeAllGraphs || (1 << k & (int)this._includedSimStats) != 0)
			{
				this.CreateGraph(Simulation.Statistics.StatSourceTypes.Simulation, k, this._graphsLayoutRT);
			}
		}
		this._activeDirty = true;
		this._layoutDirty = 2;
	}

	// Token: 0x06000AE0 RID: 2784 RVA: 0x00039C90 File Offset: 0x00037E90
	private void AssociateWithRunner(NetworkRunner runner)
	{
		if (runner != null)
		{
			List<FusionStats> list;
			if (!FusionStats._statsForRunnerLookup.TryGetValue(runner, out list))
			{
				FusionStats._statsForRunnerLookup.Add(runner, new List<FusionStats>
				{
					this
				});
				return;
			}
			list.Add(this);
		}
	}

	// Token: 0x06000AE1 RID: 2785 RVA: 0x00039CD4 File Offset: 0x00037ED4
	private void DisassociateWithRunner(NetworkRunner runner)
	{
		List<FusionStats> list;
		if (runner != null && FusionStats._statsForRunnerLookup.TryGetValue(runner, out list) && list.Contains(this))
		{
			list.Remove(this);
		}
	}

	// Token: 0x06000AE2 RID: 2786 RVA: 0x00039D0C File Offset: 0x00037F0C
	private void Pause()
	{
		if (this._runner && this._runner.Simulation != null)
		{
			this._paused = !this._paused;
			string text = this._paused ? "►" : "װ";
			string text2 = this._paused ? "PLAY" : "PAUSE";
			this._pauseIcon.text = text;
			this._pauseLabel.text = text2;
			List<FusionStats> list;
			if (FusionStats._statsForRunnerLookup.TryGetValue(this._runner, out list))
			{
				bool flag = false;
				using (List<FusionStats>.Enumerator enumerator = list.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						if (!enumerator.Current._paused)
						{
							flag = true;
							break;
						}
					}
				}
				this._runner.Simulation.Stats.Pause(!flag);
			}
		}
	}

	// Token: 0x06000AE3 RID: 2787 RVA: 0x00039E00 File Offset: 0x00038000
	private void Toggle()
	{
		this._hidden = !this._hidden;
		this._togglIcon.text = (this._hidden ? "▲" : "▼");
		this._togglLabel.text = (this._hidden ? "SHOW" : "HIDE");
		this._statsPanelRT.gameObject.SetActive(!this._hidden);
		for (int i = 0; i < this._simGraphs.Length; i++)
		{
			if (this._simGraphs[i])
			{
				this._simGraphs[i].gameObject.SetActive(!this._hidden && (1 << i & (int)this._includedSimStats) != 0);
			}
		}
		for (int j = 0; j < this._objGraphs.Length; j++)
		{
			if (this._objGraphs[j])
			{
				this._objGraphs[j].gameObject.SetActive(!this._hidden && (1 << j & (int)this._includedObjStats) != 0);
			}
		}
		for (int k = 0; k < this._netGraphs.Length; k++)
		{
			if (this._netGraphs[k])
			{
				this._netGraphs[k].gameObject.SetActive(!this._hidden && (1 << k & (int)this._includedNetStats) != 0);
			}
		}
	}

	// Token: 0x06000AE4 RID: 2788 RVA: 0x00039F60 File Offset: 0x00038160
	private void Clear()
	{
		if (this._runner && this._runner.Simulation != null)
		{
			this._runner.Simulation.Stats.Clear();
		}
		for (int i = 0; i < this._simGraphs.Length; i++)
		{
			if (this._simGraphs[i])
			{
				this._simGraphs[i].Clear();
			}
		}
		for (int j = 0; j < this._objGraphs.Length; j++)
		{
			if (this._objGraphs[j])
			{
				this._objGraphs[j].Clear();
			}
		}
		for (int k = 0; k < this._netGraphs.Length; k++)
		{
			if (this._netGraphs[k])
			{
				this._netGraphs[k].Clear();
			}
		}
	}

	// Token: 0x06000AE5 RID: 2789 RVA: 0x0003A029 File Offset: 0x00038229
	private void ToggleCanvasType()
	{
		this._canvasType = ((this._canvasType == FusionStats.StatCanvasTypes.GameObject) ? FusionStats.StatCanvasTypes.Overlay : FusionStats.StatCanvasTypes.GameObject);
		this._layoutDirty = 3;
		this.CalculateLayout();
	}

	// Token: 0x06000AE6 RID: 2790 RVA: 0x0001657F File Offset: 0x0001477F
	private void Close()
	{
		UnityEngine.Object.Destroy(base.gameObject);
	}

	// Token: 0x06000AE7 RID: 2791 RVA: 0x00003051 File Offset: 0x00001251
	private void PingSelectObject()
	{
	}

	// Token: 0x06000AE8 RID: 2792 RVA: 0x00003051 File Offset: 0x00001251
	private void PingSelectFusionStats()
	{
	}

	// Token: 0x06000AE9 RID: 2793 RVA: 0x0003A04C File Offset: 0x0003824C
	private void LateUpdate()
	{
		NetworkRunner runner = this.Runner;
		bool flag = runner == null;
		if (this.AutoDestroy && flag)
		{
			UnityEngine.Object.Destroy(base.gameObject);
			return;
		}
		if (this._activeDirty)
		{
			this.ReapplyEnabled();
		}
		if (this._layoutDirty > 0)
		{
			this.CalculateLayout();
		}
		if (!Application.isPlaying)
		{
			return;
		}
		if (flag || runner.IsShutdown)
		{
			return;
		}
		if (this._paused)
		{
			return;
		}
		if (this.RedrawInterval > 0f)
		{
			double timeAsDouble = Time.timeAsDouble;
			if (timeAsDouble > this._delayDrawUntil)
			{
				this._currentDrawTime = timeAsDouble;
				while (this._delayDrawUntil <= timeAsDouble)
				{
					this._delayDrawUntil += (double)this.RedrawInterval;
				}
			}
			if (timeAsDouble != this._currentDrawTime)
			{
				return;
			}
		}
		if (this.EnableObjectStats)
		{
			this.RefreshObjectValues();
		}
		foreach (IFusionStatsView fusionStatsView in this._foundViews)
		{
			if (fusionStatsView != null && fusionStatsView.isActiveAndEnabled)
			{
				fusionStatsView.Refresh();
			}
		}
	}

	// Token: 0x06000AEA RID: 2794 RVA: 0x0003A168 File Offset: 0x00038368
	private void RefreshObjectValues()
	{
		NetworkObject @object = this.Object;
		if (@object == null)
		{
			return;
		}
		string name = @object.name;
		if (this._previousObjectTitle != name)
		{
			this._objectNameText.text = name;
			this._previousObjectTitle = name;
		}
	}

	// Token: 0x06000AEB RID: 2795 RVA: 0x0003A1B0 File Offset: 0x000383B0
	public FusionGraph CreateGraph(Simulation.Statistics.StatSourceTypes type, int statId, RectTransform parentRT)
	{
		FusionGraph fusionGraph = FusionGraph.Create(this, type, statId, parentRT);
		if (type == Simulation.Statistics.StatSourceTypes.Simulation)
		{
			this._simGraphs[statId] = fusionGraph;
			if ((this._includedSimStats & (Simulation.Statistics.SimStatFlags)(1 << statId)) == (Simulation.Statistics.SimStatFlags)0)
			{
				fusionGraph.gameObject.SetActive(false);
			}
		}
		else if (type == Simulation.Statistics.StatSourceTypes.NetworkObject)
		{
			this._objGraphs[statId] = fusionGraph;
			if ((this._includedObjStats & (Simulation.Statistics.ObjStatFlags)(1 << statId)) == (Simulation.Statistics.ObjStatFlags)0)
			{
				fusionGraph.gameObject.SetActive(false);
			}
		}
		else
		{
			this._netGraphs[statId] = fusionGraph;
			if ((this._includedNetStats & (Simulation.Statistics.NetStatFlags)(1 << statId)) == (Simulation.Statistics.NetStatFlags)0)
			{
				fusionGraph.gameObject.SetActive(false);
			}
		}
		return fusionGraph;
	}

	// Token: 0x06000AEC RID: 2796 RVA: 0x0003A240 File Offset: 0x00038440
	private void ReapplyEnabled()
	{
		this._activeDirty = false;
		if (this._simGraphs == null || this._simGraphs.Length < 0)
		{
			return;
		}
		if (this._graphsLayoutRT == null)
		{
			return;
		}
		int i = 0;
		while (i < this._simGraphs.Length)
		{
			FusionGraph fusionGraph = this._simGraphs[i];
			bool flag = (1 << i & (int)this._includedSimStats) != 0;
			if (!(fusionGraph == null))
			{
				goto IL_6C;
			}
			if (flag)
			{
				fusionGraph = this.CreateGraph(Simulation.Statistics.StatSourceTypes.Simulation, i, this._graphsLayoutRT);
				this._simGraphs[i] = fusionGraph;
				goto IL_6C;
			}
			IL_78:
			i++;
			continue;
			IL_6C:
			fusionGraph.gameObject.SetActive(flag);
			goto IL_78;
		}
		int j = 0;
		while (j < this._objGraphs.Length)
		{
			FusionGraph fusionGraph2 = this._objGraphs[j];
			bool flag2 = this._enableObjectStats && (1 << j & (int)this._includedObjStats) != 0;
			if (!(fusionGraph2 == null))
			{
				goto IL_DA;
			}
			if (flag2)
			{
				fusionGraph2 = this.CreateGraph(Simulation.Statistics.StatSourceTypes.NetworkObject, j, this._graphsLayoutRT);
				this._objGraphs[j] = fusionGraph2;
				goto IL_DA;
			}
			IL_F8:
			j++;
			continue;
			IL_DA:
			if (this._objGraphs[j] != null)
			{
				fusionGraph2.gameObject.SetActive(flag2);
				goto IL_F8;
			}
			goto IL_F8;
		}
		int k = 0;
		while (k < this._netGraphs.Length)
		{
			FusionGraph fusionGraph3 = this._netGraphs[k];
			bool flag3 = (1 << k & (int)this._includedNetStats) != 0;
			if (!(fusionGraph3 == null))
			{
				goto IL_154;
			}
			if (flag3)
			{
				fusionGraph3 = this.CreateGraph(Simulation.Statistics.StatSourceTypes.NetConnection, k, this._graphsLayoutRT);
				this._netGraphs[k] = fusionGraph3;
				goto IL_154;
			}
			IL_173:
			k++;
			continue;
			IL_154:
			if (this._netGraphs[k] != null)
			{
				fusionGraph3.gameObject.SetActive(flag3);
				goto IL_173;
			}
			goto IL_173;
		}
	}

	// Token: 0x06000AED RID: 2797 RVA: 0x0003A3D4 File Offset: 0x000385D4
	private void CalculateLayout()
	{
		if (this._rootPanelRT == null || this._graphsLayoutRT == null)
		{
			return;
		}
		if (this._foundGraphs == null)
		{
			this._foundGraphs = new List<FusionGraph>(this._graphsLayoutRT.GetComponentsInChildren<FusionGraph>(false));
		}
		else
		{
			base.GetComponentsInChildren<FusionGraph>(false, this._foundGraphs);
		}
		float time = Time.time;
		if (this._lastLayoutUpdate < time)
		{
			this._layoutDirty--;
			this._lastLayoutUpdate = time;
		}
		if (this._layoutDirty <= 0)
		{
			bool enabled = this._canvas.enabled;
		}
		if (this._rootPanelRT)
		{
			float num = Math.Min((float)this._maxHeaderHeight, this._rootPanelRT.rect.width / 4f);
			if (this._canvasType == FusionStats.StatCanvasTypes.GameObject)
			{
				this._canvas.renderMode = RenderMode.WorldSpace;
				float num2 = this.CanvasScale / 1080f;
				this._canvasRT.localScale = new Vector3(num2, num2, num2);
				this._canvasRT.sizeDelta = new Vector2(1024f, 1024f);
				this._canvasRT.localPosition = new Vector3(0f, 0f, this.CanvasDistance);
				if (!this._canvasRT.GetComponent<FusionStatsBillboard>())
				{
					this._canvasRT.localRotation = default(Quaternion);
				}
			}
			else
			{
				this._canvas.renderMode = RenderMode.ScreenSpaceOverlay;
			}
			this._objectTitlePanelRT.gameObject.SetActive(this._enableObjectStats);
			this._objectIdsGroupRT.gameObject.SetActive(this._enableObjectStats);
			this._objectMetersPanelRT.gameObject.SetActive(this._enableObjectStats);
			Vector2 vector;
			if (this._showButtonLabels)
			{
				vector = new Vector2(0f, 0.0875f);
			}
			else
			{
				vector = new Vector2(0f, 0f);
			}
			this._togglIcon.rectTransform.anchorMin = vector + new Vector2(0f, 0.15f);
			this._canvsIcon.rectTransform.anchorMin = vector;
			this._clearIcon.rectTransform.anchorMin = vector;
			this._pauseIcon.rectTransform.anchorMin = vector;
			this._closeIcon.rectTransform.anchorMin = vector;
			this._togglLabel.gameObject.SetActive(this._showButtonLabels);
			this._canvsLabel.gameObject.SetActive(this._showButtonLabels);
			this._clearLabel.gameObject.SetActive(this._showButtonLabels);
			this._pauseLabel.gameObject.SetActive(this._showButtonLabels);
			this._closeLabel.gameObject.SetActive(this._showButtonLabels);
			Rect currentRect = this.CurrentRect;
			this._rootPanelRT.anchorMax = new Vector2(currentRect.xMax, currentRect.yMax);
			this._rootPanelRT.anchorMin = new Vector2(currentRect.xMin, currentRect.yMin);
			this._rootPanelRT.sizeDelta = new Vector2(0f, 0f);
			this._rootPanelRT.pivot = new Vector2(0.5f, 0.5f);
			this._rootPanelRT.anchoredPosition3D = default(Vector3);
			this._headerRT.anchorMin = new Vector2(0f, 1f);
			this._headerRT.anchorMax = new Vector2(1f, 1f);
			this._headerRT.pivot = new Vector2(0.5f, 1f);
			this._headerRT.anchoredPosition3D = default(Vector3);
			this._headerRT.sizeDelta = new Vector2(0f, num);
			this._objectTitlePanelRT.offsetMax = new Vector2(-6f, -6f);
			this._objectTitlePanelRT.offsetMin = new Vector2(6f, (float)(-(float)this.ObjectTitleHeight));
			this._objectIdsGroupRT.offsetMax = new Vector2(-6f, (float)(-(float)(this.ObjectTitleHeight + 6)));
			this._objectIdsGroupRT.offsetMin = new Vector2(6f, (float)(-(float)(this.ObjectTitleHeight + this.ObjectIdsHeight)));
			this._objectMetersPanelRT.offsetMax = new Vector2(-6f, (float)(-(float)(this.ObjectTitleHeight + this.ObjectIdsHeight + 6)));
			this._objectMetersPanelRT.offsetMin = new Vector2(6f, (float)(-(float)(this.ObjectTitleHeight + this.ObjectIdsHeight + this.ObjectMetersHeight)));
			this._objectTitlePanelRT.gameObject.SetActive(this.EnableObjectStats && this.ObjectTitleHeight > 0);
			this._objectIdsGroupRT.gameObject.SetActive(this.EnableObjectStats && this.ObjectIdsHeight > 0);
			this._objectMetersPanelRT.gameObject.SetActive(this.EnableObjectStats && this.ObjectMetersHeight > 0);
			this._statsPanelRT.ExpandAnchor(null).SetOffsets(0f, 0f, 0f, -num);
			if (this._enableObjectStats && this._statsPanelRT.rect.height < (float)(this.ObjectTitleHeight + this.ObjectIdsHeight + this.ObjectMetersHeight))
			{
				this._statsPanelRT.offsetMin = new Vector2(0f, this._statsPanelRT.rect.height - (float)(this.ObjectTitleHeight + this.ObjectIdsHeight + this.ObjectMetersHeight + 6));
			}
			int num3 = (this.GraphColumnCount > 0) ? this.GraphColumnCount : ((int)(this._graphsLayoutRT.rect.width / (float)(this._graphMaxWidth + 6)));
			if (num3 < 1)
			{
				num3 = 1;
			}
			int num4 = (int)Math.Ceiling((double)this._foundGraphs.Count / (double)num3);
			if (num4 < 1)
			{
				num4 = 1;
			}
			if (num4 == 1)
			{
				num3 = this._foundGraphs.Count;
			}
			this._graphGridLayoutGroup.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
			this._graphGridLayoutGroup.constraintCount = num3;
			float x = this._graphsLayoutRT.rect.width / (float)num3 - 6f;
			float y = this._graphsLayoutRT.rect.height / (float)num4 - 6f;
			this._graphGridLayoutGroup.cellSize = new Vector2(x, y);
			this._graphsLayoutRT.offsetMax = new Vector2(0f, (float)(this._enableObjectStats ? (-(float)(this.ObjectTitleHeight + this.ObjectIdsHeight + this.ObjectMetersHeight + 6)) : -6));
			if (this._foundViews == null)
			{
				this._foundViews = new List<IFusionStatsView>(base.GetComponentsInChildren<IFusionStatsView>(false));
			}
			else
			{
				base.GetComponentsInChildren<IFusionStatsView>(false, this._foundViews);
			}
			if (this._objGraphs != null)
			{
				foreach (FusionGraph fusionGraph in this._objGraphs)
				{
					if (fusionGraph)
					{
						fusionGraph.gameObject.SetActive((this._includedObjStats & (Simulation.Statistics.ObjStatFlags)(1 << fusionGraph.StatId)) != (Simulation.Statistics.ObjStatFlags)0 && this._enableObjectStats);
					}
				}
			}
			for (int j = 0; j < this._foundViews.Count; j++)
			{
				IFusionStatsView fusionStatsView = this._foundViews[j];
				if (fusionStatsView != null && fusionStatsView.isActiveAndEnabled)
				{
					fusionStatsView.CalculateLayout();
					fusionStatsView.transform.localRotation = default(Quaternion);
					fusionStatsView.transform.localScale = new Vector3(1f, 1f, 1f);
				}
			}
		}
	}

	// Token: 0x06000AEE RID: 2798 RVA: 0x0003AB74 File Offset: 0x00038D74
	private void ApplyDefaultLayout(FusionStats.DefaultLayouts defaults, FusionStats.StatCanvasTypes? applyForCanvasType = null)
	{
		bool flag = applyForCanvasType == null || applyForCanvasType.Value == FusionStats.StatCanvasTypes.GameObject;
		bool flag2 = applyForCanvasType == null || applyForCanvasType.Value == FusionStats.StatCanvasTypes.Overlay;
		if (defaults == FusionStats.DefaultLayouts.Custom)
		{
			return;
		}
		bool flag3 = Screen.height > Screen.width;
		Rect rect;
		Rect overlayRect;
		switch (defaults)
		{
		case FusionStats.DefaultLayouts.Left:
			rect = Rect.MinMaxRect(0f, 0f, 0.3f, 1f);
			overlayRect = rect;
			break;
		case FusionStats.DefaultLayouts.Right:
			rect = Rect.MinMaxRect(0.7f, 0f, 1f, 1f);
			overlayRect = rect;
			break;
		case FusionStats.DefaultLayouts.UpperLeft:
			rect = Rect.MinMaxRect(0f, 0.5f, 0.3f, 1f);
			overlayRect = (flag3 ? Rect.MinMaxRect(0f, 0.7f, 0.3f, 1f) : rect);
			break;
		case FusionStats.DefaultLayouts.UpperRight:
			rect = Rect.MinMaxRect(0.7f, 0.5f, 1f, 1f);
			overlayRect = (flag3 ? Rect.MinMaxRect(0.7f, 0.7f, 1f, 1f) : rect);
			break;
		case FusionStats.DefaultLayouts.Full:
			rect = Rect.MinMaxRect(0f, 0f, 1f, 1f);
			overlayRect = rect;
			break;
		default:
			rect = Rect.MinMaxRect(0f, 0.5f, 0.3f, 1f);
			overlayRect = rect;
			break;
		}
		if (flag)
		{
			this.GameObjectRect = rect;
		}
		if (flag2)
		{
			this.OverlayRect = overlayRect;
		}
		this._layoutDirty++;
	}

	// Token: 0x04000BDD RID: 3037
	private static Dictionary<NetworkRunner, List<FusionStats>> _statsForRunnerLookup = new Dictionary<NetworkRunner, List<FusionStats>>();

	// Token: 0x04000BDE RID: 3038
	private static Dictionary<string, FusionStats> _activeGuids = new Dictionary<string, FusionStats>();

	// Token: 0x04000BDF RID: 3039
	public const Simulation.Statistics.SimStatFlags DefaultSimStatsMask = Simulation.Statistics.SimStatFlags.ForwardSimCount | Simulation.Statistics.SimStatFlags.ResimCount | Simulation.Statistics.SimStatFlags.PacketSize;

	// Token: 0x04000BE0 RID: 3040
	private const int SCREEN_SCALE_W = 1080;

	// Token: 0x04000BE1 RID: 3041
	private const int SCREEN_SCALE_H = 1080;

	// Token: 0x04000BE2 RID: 3042
	private const float TEXT_MARGIN = 0.25f;

	// Token: 0x04000BE3 RID: 3043
	private const float TITLE_HEIGHT = 20f;

	// Token: 0x04000BE4 RID: 3044
	private const int MARGIN = 6;

	// Token: 0x04000BE5 RID: 3045
	private const int PAD = 10;

	// Token: 0x04000BE6 RID: 3046
	private const string PLAY_TEXT = "PLAY";

	// Token: 0x04000BE7 RID: 3047
	private const string PAUS_TEXT = "PAUSE";

	// Token: 0x04000BE8 RID: 3048
	private const string SHOW_TEXT = "SHOW";

	// Token: 0x04000BE9 RID: 3049
	private const string HIDE_TEXT = "HIDE";

	// Token: 0x04000BEA RID: 3050
	private const string CLER_TEXT = "CLEAR";

	// Token: 0x04000BEB RID: 3051
	private const string CNVS_TEXT = "CANVAS";

	// Token: 0x04000BEC RID: 3052
	private const string CLSE_TEXT = "CLOSE";

	// Token: 0x04000BED RID: 3053
	private const string PLAY_ICON = "►";

	// Token: 0x04000BEE RID: 3054
	private const string PAUS_ICON = "װ";

	// Token: 0x04000BEF RID: 3055
	private const string HIDE_ICON = "▼";

	// Token: 0x04000BF0 RID: 3056
	private const string SHOW_ICON = "▲";

	// Token: 0x04000BF1 RID: 3057
	private const string CLER_ICON = "ᴓ";

	// Token: 0x04000BF2 RID: 3058
	private const string CNVS_ICON = "ﬦ";

	// Token: 0x04000BF3 RID: 3059
	private const string CLSE_ICON = "x";

	// Token: 0x04000BF4 RID: 3060
	[InlineHelp]
	[Unit(Units.Seconds, 1.0, 0.0, DecimalPlaces = 2)]
	[MultiPropertyDrawersFix]
	public float RedrawInterval = 0.1f;

	// Token: 0x04000BF5 RID: 3061
	[Header("Layout")]
	[InlineHelp]
	[SerializeField]
	private FusionStats.StatCanvasTypes _canvasType;

	// Token: 0x04000BF6 RID: 3062
	[InlineHelp]
	[SerializeField]
	private bool _showButtonLabels = true;

	// Token: 0x04000BF7 RID: 3063
	[InlineHelp]
	[SerializeField]
	[Range(0f, 200f)]
	[MultiPropertyDrawersFix]
	private int _maxHeaderHeight = 70;

	// Token: 0x04000BF8 RID: 3064
	[InlineHelp]
	[DrawIf("_canvasType", 1.0, Hide = true)]
	[Range(0f, 20f)]
	[MultiPropertyDrawersFix]
	public float CanvasScale = 5f;

	// Token: 0x04000BF9 RID: 3065
	[InlineHelp]
	[DrawIf("_canvasType", 1.0, Hide = true)]
	[Range(-10f, 10f)]
	[MultiPropertyDrawersFix]
	public float CanvasDistance;

	// Token: 0x04000BFA RID: 3066
	[InlineHelp]
	[SerializeField]
	[DrawIf("CanvasType", 1.0, Hide = true)]
	[NormalizedRect(true, 1f)]
	[MultiPropertyDrawersFix]
	private Rect _gameObjectRect = new Rect(0f, 0f, 0.3f, 1f);

	// Token: 0x04000BFB RID: 3067
	[InlineHelp]
	[SerializeField]
	[DrawIf("CanvasType", 0.0, Hide = true)]
	[NormalizedRect(true, 0f)]
	[MultiPropertyDrawersFix]
	private Rect _overlayRect = new Rect(0f, 0f, 0.3f, 1f);

	// Token: 0x04000BFC RID: 3068
	[Header("Fusion Graphs Layout")]
	[InlineHelp]
	[SerializeField]
	private FusionGraph.Layouts _defaultLayout;

	// Token: 0x04000BFD RID: 3069
	[InlineHelp]
	[SerializeField]
	private bool _noTextOverlap;

	// Token: 0x04000BFE RID: 3070
	[InlineHelp]
	[SerializeField]
	private bool _noGraphShader;

	// Token: 0x04000BFF RID: 3071
	[InlineHelp]
	[Range(0f, 16f)]
	[MultiPropertyDrawersFix]
	public int GraphColumnCount = 1;

	// Token: 0x04000C00 RID: 3072
	[InlineHelp]
	[SerializeField]
	[DrawIf("GraphColumnCount", 0.0)]
	[Range(30f, 1080f)]
	[MultiPropertyDrawersFix]
	private int _graphMaxWidth = 270;

	// Token: 0x04000C01 RID: 3073
	[Header("Network Object Stats")]
	[InlineHelp]
	[SerializeField]
	[WarnIf("ShowMissingNetObjWarning", "No NetworkObject found on this GameObject, nor parent. Object stats will be unavailable.")]
	private bool _enableObjectStats;

	// Token: 0x04000C02 RID: 3074
	[InlineHelp]
	[SerializeField]
	[DrawIf("EnableObjectStats")]
	private NetworkObject _object;

	// Token: 0x04000C03 RID: 3075
	[InlineHelp]
	[SerializeField]
	[DrawIf("EnableObjectStats")]
	[Range(0f, 200f)]
	[MultiPropertyDrawersFix]
	private int _objectTitleHeight = 48;

	// Token: 0x04000C04 RID: 3076
	[InlineHelp]
	[SerializeField]
	[DrawIf("EnableObjectStats")]
	[Range(0f, 200f)]
	[MultiPropertyDrawersFix]
	private int _objectIdsHeight = 60;

	// Token: 0x04000C05 RID: 3077
	[InlineHelp]
	[SerializeField]
	[DrawIf("EnableObjectStats")]
	[Range(0f, 200f)]
	[MultiPropertyDrawersFix]
	private int _objectMetersHeight = 90;

	// Token: 0x04000C06 RID: 3078
	[Header("Data")]
	[SerializeField]
	[InlineHelp]
	[EditorDisabled(false)]
	[MultiPropertyDrawersFix]
	private NetworkRunner _runner;

	// Token: 0x04000C07 RID: 3079
	[InlineHelp]
	public bool InitializeAllGraphs;

	// Token: 0x04000C08 RID: 3080
	[InlineHelp]
	[VersaMask(false, null)]
	[MultiPropertyDrawersFix]
	public SimulationModes ConnectTo = SimulationModes.Client;

	// Token: 0x04000C09 RID: 3081
	[InlineHelp]
	[SerializeField]
	[VersaMask(false, null)]
	[DrawIf("EnableObjectStats")]
	[MultiPropertyDrawersFix]
	private Simulation.Statistics.ObjStatFlags _includedObjStats;

	// Token: 0x04000C0A RID: 3082
	[InlineHelp]
	[SerializeField]
	[VersaMask(false, null)]
	[MultiPropertyDrawersFix]
	private Simulation.Statistics.NetStatFlags _includedNetStats;

	// Token: 0x04000C0B RID: 3083
	[InlineHelp]
	[SerializeField]
	[VersaMask(false, null)]
	[MultiPropertyDrawersFix]
	private Simulation.Statistics.SimStatFlags _includedSimStats;

	// Token: 0x04000C0C RID: 3084
	[Header("Life-Cycle")]
	[InlineHelp]
	[SerializeField]
	public bool AutoDestroy;

	// Token: 0x04000C0D RID: 3085
	[InlineHelp]
	[SerializeField]
	public bool EnforceSingle = true;

	// Token: 0x04000C0E RID: 3086
	[InlineHelp]
	[DrawIf("EnforceSingle")]
	[SerializeField]
	public string Guid;

	// Token: 0x04000C0F RID: 3087
	[Header("Customization")]
	[InlineHelp]
	[SerializeField]
	[DrawIf("IsNotPlaying", Hide = true)]
	[MultiPropertyDrawersFix]
	private bool _modifyColors;

	// Token: 0x04000C10 RID: 3088
	[InlineHelp]
	[SerializeField]
	[DrawIf("ShowColorControls", Hide = true)]
	private Color _graphColorGood = new Color(0.1f, 0.5f, 0.1f, 0.9f);

	// Token: 0x04000C11 RID: 3089
	[InlineHelp]
	[SerializeField]
	[DrawIf("ShowColorControls", Hide = true)]
	private Color _graphColorWarn = new Color(0.75f, 0.75f, 0.2f, 0.9f);

	// Token: 0x04000C12 RID: 3090
	[InlineHelp]
	[SerializeField]
	[DrawIf("ShowColorControls", Hide = true)]
	private Color _graphColorBad = new Color(0.9f, 0.2f, 0.2f, 0.9f);

	// Token: 0x04000C13 RID: 3091
	[InlineHelp]
	[SerializeField]
	[DrawIf("ShowColorControls", Hide = true)]
	private Color _graphColorFlag = new Color(0.8f, 0.75f, 0f, 1f);

	// Token: 0x04000C14 RID: 3092
	[InlineHelp]
	[SerializeField]
	[DrawIf("ShowColorControls", Hide = true)]
	private Color _fontColor = new Color(1f, 1f, 1f, 1f);

	// Token: 0x04000C15 RID: 3093
	[InlineHelp]
	[SerializeField]
	[DrawIf("ShowColorControls", Hide = true)]
	private Color PanelColor = new Color(0.3f, 0.3f, 0.3f, 1f);

	// Token: 0x04000C16 RID: 3094
	[InlineHelp]
	[SerializeField]
	[DrawIf("ShowColorControls", Hide = true)]
	private Color _simDataBackColor = new Color(0.1f, 0.08f, 0.08f, 1f);

	// Token: 0x04000C17 RID: 3095
	[InlineHelp]
	[SerializeField]
	[DrawIf("ShowColorControls", Hide = true)]
	private Color _netDataBackColor = new Color(0.15f, 0.14f, 0.09f, 1f);

	// Token: 0x04000C18 RID: 3096
	[InlineHelp]
	[SerializeField]
	[DrawIf("ShowColorControls", Hide = true)]
	private Color _objDataBackColor = new Color(0f, 0.2f, 0.4f, 1f);

	// Token: 0x04000C19 RID: 3097
	[SerializeField]
	[HideInInspector]
	private FusionGraph[] _simGraphs;

	// Token: 0x04000C1A RID: 3098
	[SerializeField]
	[HideInInspector]
	private FusionGraph[] _objGraphs;

	// Token: 0x04000C1B RID: 3099
	[SerializeField]
	[HideInInspector]
	private FusionGraph[] _netGraphs;

	// Token: 0x04000C1C RID: 3100
	[NonSerialized]
	private List<IFusionStatsView> _foundViews;

	// Token: 0x04000C1D RID: 3101
	[NonSerialized]
	private List<FusionGraph> _foundGraphs;

	// Token: 0x04000C1E RID: 3102
	[SerializeField]
	[HideInInspector]
	private Text _titleText;

	// Token: 0x04000C1F RID: 3103
	[SerializeField]
	[HideInInspector]
	private Text _clearIcon;

	// Token: 0x04000C20 RID: 3104
	[SerializeField]
	[HideInInspector]
	private Text _pauseIcon;

	// Token: 0x04000C21 RID: 3105
	[SerializeField]
	[HideInInspector]
	private Text _togglIcon;

	// Token: 0x04000C22 RID: 3106
	[SerializeField]
	[HideInInspector]
	private Text _closeIcon;

	// Token: 0x04000C23 RID: 3107
	[SerializeField]
	[HideInInspector]
	private Text _canvsIcon;

	// Token: 0x04000C24 RID: 3108
	[SerializeField]
	[HideInInspector]
	private Text _clearLabel;

	// Token: 0x04000C25 RID: 3109
	[SerializeField]
	[HideInInspector]
	private Text _pauseLabel;

	// Token: 0x04000C26 RID: 3110
	[SerializeField]
	[HideInInspector]
	private Text _togglLabel;

	// Token: 0x04000C27 RID: 3111
	[SerializeField]
	[HideInInspector]
	private Text _closeLabel;

	// Token: 0x04000C28 RID: 3112
	[SerializeField]
	[HideInInspector]
	private Text _canvsLabel;

	// Token: 0x04000C29 RID: 3113
	[SerializeField]
	[HideInInspector]
	private Text _objectNameText;

	// Token: 0x04000C2A RID: 3114
	[SerializeField]
	[HideInInspector]
	private GridLayoutGroup _graphGridLayoutGroup;

	// Token: 0x04000C2B RID: 3115
	[SerializeField]
	[HideInInspector]
	private Canvas _canvas;

	// Token: 0x04000C2C RID: 3116
	[SerializeField]
	[HideInInspector]
	private RectTransform _canvasRT;

	// Token: 0x04000C2D RID: 3117
	[SerializeField]
	[HideInInspector]
	private RectTransform _rootPanelRT;

	// Token: 0x04000C2E RID: 3118
	[SerializeField]
	[HideInInspector]
	private RectTransform _guidesRT;

	// Token: 0x04000C2F RID: 3119
	[SerializeField]
	[HideInInspector]
	private RectTransform _headerRT;

	// Token: 0x04000C30 RID: 3120
	[SerializeField]
	[HideInInspector]
	private RectTransform _statsPanelRT;

	// Token: 0x04000C31 RID: 3121
	[SerializeField]
	[HideInInspector]
	private RectTransform _graphsLayoutRT;

	// Token: 0x04000C32 RID: 3122
	[SerializeField]
	[HideInInspector]
	private RectTransform _titleRT;

	// Token: 0x04000C33 RID: 3123
	[SerializeField]
	[HideInInspector]
	private RectTransform _buttonsRT;

	// Token: 0x04000C34 RID: 3124
	[SerializeField]
	[HideInInspector]
	private RectTransform _objectTitlePanelRT;

	// Token: 0x04000C35 RID: 3125
	[SerializeField]
	[HideInInspector]
	private RectTransform _objectIdsGroupRT;

	// Token: 0x04000C36 RID: 3126
	[SerializeField]
	[HideInInspector]
	private RectTransform _objectMetersPanelRT;

	// Token: 0x04000C37 RID: 3127
	[SerializeField]
	[HideInInspector]
	private RectTransform _clientIdPanelRT;

	// Token: 0x04000C38 RID: 3128
	[SerializeField]
	[HideInInspector]
	private RectTransform _authorityPanelRT;

	// Token: 0x04000C39 RID: 3129
	[SerializeField]
	[HideInInspector]
	private Button _titleButton;

	// Token: 0x04000C3A RID: 3130
	[SerializeField]
	[HideInInspector]
	private Button _objctButton;

	// Token: 0x04000C3B RID: 3131
	[SerializeField]
	[HideInInspector]
	private Button _clearButton;

	// Token: 0x04000C3C RID: 3132
	[SerializeField]
	[HideInInspector]
	private Button _togglButton;

	// Token: 0x04000C3D RID: 3133
	[SerializeField]
	[HideInInspector]
	private Button _pauseButton;

	// Token: 0x04000C3E RID: 3134
	[SerializeField]
	[HideInInspector]
	private Button _closeButton;

	// Token: 0x04000C3F RID: 3135
	[SerializeField]
	[HideInInspector]
	private Button _canvsButton;

	// Token: 0x04000C40 RID: 3136
	private Font _font;

	// Token: 0x04000C41 RID: 3137
	private bool _hidden;

	// Token: 0x04000C42 RID: 3138
	private bool _paused;

	// Token: 0x04000C43 RID: 3139
	private int _layoutDirty;

	// Token: 0x04000C44 RID: 3140
	private bool _activeDirty;

	// Token: 0x04000C45 RID: 3141
	private double _currentDrawTime;

	// Token: 0x04000C46 RID: 3142
	private double _delayDrawUntil;

	// Token: 0x04000C47 RID: 3143
	private static bool? _newInputSystemFound;

	// Token: 0x04000C48 RID: 3144
	private string _previousObjectTitle;

	// Token: 0x04000C49 RID: 3145
	private float _lastLayoutUpdate;

	// Token: 0x0200020E RID: 526
	public enum StatCanvasTypes
	{
		// Token: 0x04000C4B RID: 3147
		Overlay,
		// Token: 0x04000C4C RID: 3148
		GameObject
	}

	// Token: 0x0200020F RID: 527
	public enum DefaultLayouts
	{
		// Token: 0x04000C4E RID: 3150
		Custom,
		// Token: 0x04000C4F RID: 3151
		Left,
		// Token: 0x04000C50 RID: 3152
		Right,
		// Token: 0x04000C51 RID: 3153
		UpperLeft,
		// Token: 0x04000C52 RID: 3154
		UpperRight,
		// Token: 0x04000C53 RID: 3155
		Full
	}
}
