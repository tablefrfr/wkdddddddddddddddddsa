﻿using System;

// Token: 0x020000A7 RID: 167
public class ComponentMember
{
	// Token: 0x17000049 RID: 73
	// (get) Token: 0x0600031F RID: 799 RVA: 0x00016535 File Offset: 0x00014735
	public string Name { get; }

	// Token: 0x1700004A RID: 74
	// (get) Token: 0x06000320 RID: 800 RVA: 0x0001653D File Offset: 0x0001473D
	public string Value
	{
		get
		{
			return this.getValue();
		}
	}

	// Token: 0x1700004B RID: 75
	// (get) Token: 0x06000321 RID: 801 RVA: 0x0001654A File Offset: 0x0001474A
	public bool IsStarred { get; }

	// Token: 0x1700004C RID: 76
	// (get) Token: 0x06000322 RID: 802 RVA: 0x00016552 File Offset: 0x00014752
	public string Color { get; }

	// Token: 0x06000323 RID: 803 RVA: 0x0001655A File Offset: 0x0001475A
	public ComponentMember(string name, Func<string> getValue, bool isStarred, string color)
	{
		this.Name = name;
		this.getValue = getValue;
		this.IsStarred = isStarred;
		this.Color = color;
	}

	// Token: 0x04000496 RID: 1174
	private Func<string> getValue;

	// Token: 0x04000497 RID: 1175
	public string computedPrefix;

	// Token: 0x04000498 RID: 1176
	public string computedSuffix;
}
