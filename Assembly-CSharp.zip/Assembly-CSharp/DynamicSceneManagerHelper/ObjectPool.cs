﻿using System;

namespace DynamicSceneManagerHelper
{
	// Token: 0x0200064C RID: 1612
	internal static class ObjectPool
	{
	}
}
