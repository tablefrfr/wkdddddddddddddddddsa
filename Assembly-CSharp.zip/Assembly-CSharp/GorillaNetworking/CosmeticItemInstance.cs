﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace GorillaNetworking
{
	// Token: 0x02000695 RID: 1685
	public class CosmeticItemInstance
	{
		// Token: 0x06002796 RID: 10134 RVA: 0x000C07BC File Offset: 0x000BE9BC
		private void EnableItem(GameObject obj, bool enable)
		{
			CosmeticAnchors component = obj.GetComponent<CosmeticAnchors>();
			if (component && !enable)
			{
				component.EnableAnchor(false);
			}
			obj.SetActive(enable);
			if (component && enable)
			{
				component.EnableAnchor(true);
			}
		}

		// Token: 0x06002797 RID: 10135 RVA: 0x000C07FC File Offset: 0x000BE9FC
		public void DisableItem(CosmeticsController.CosmeticSlots cosmeticSlot)
		{
			bool flag = CosmeticsController.CosmeticSet.IsSlotLeftHanded(cosmeticSlot);
			bool flag2 = CosmeticsController.CosmeticSet.IsSlotRightHanded(cosmeticSlot);
			foreach (GameObject obj in this.objects)
			{
				this.EnableItem(obj, false);
			}
			if (flag)
			{
				foreach (GameObject obj2 in this.leftObjects)
				{
					this.EnableItem(obj2, false);
				}
			}
			if (flag2)
			{
				foreach (GameObject obj3 in this.rightObjects)
				{
					this.EnableItem(obj3, false);
				}
			}
		}

		// Token: 0x06002798 RID: 10136 RVA: 0x000C08F0 File Offset: 0x000BEAF0
		public void EnableItem(CosmeticsController.CosmeticSlots cosmeticSlot)
		{
			bool flag = CosmeticsController.CosmeticSet.IsSlotLeftHanded(cosmeticSlot);
			bool flag2 = CosmeticsController.CosmeticSet.IsSlotRightHanded(cosmeticSlot);
			foreach (GameObject gameObject in this.objects)
			{
				this.EnableItem(gameObject, true);
				if (cosmeticSlot == CosmeticsController.CosmeticSlots.Badge)
				{
					GorillaTagger.Instance.offlineVRRig.GetComponent<VRRigAnchorOverrides>().CurrentBadgeTransform = gameObject.transform;
				}
			}
			if (flag)
			{
				foreach (GameObject obj in this.leftObjects)
				{
					this.EnableItem(obj, true);
				}
			}
			if (flag2)
			{
				foreach (GameObject obj2 in this.rightObjects)
				{
					this.EnableItem(obj2, true);
				}
			}
		}

		// Token: 0x04002A5D RID: 10845
		public List<GameObject> leftObjects = new List<GameObject>();

		// Token: 0x04002A5E RID: 10846
		public List<GameObject> rightObjects = new List<GameObject>();

		// Token: 0x04002A5F RID: 10847
		public List<GameObject> objects = new List<GameObject>();
	}
}
