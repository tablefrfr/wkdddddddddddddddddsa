﻿using System;
using UnityEngine;

// Token: 0x0200004D RID: 77
public class CornOnCobCosmetic : MonoBehaviour
{
	// Token: 0x06000184 RID: 388 RVA: 0x0000C568 File Offset: 0x0000A768
	protected void Awake()
	{
		this.emissionModule = this.particleSys.emission;
		this.maxBurstProbability = ((this.emissionModule.burstCount > 0) ? this.emissionModule.GetBurst(0).probability : 0.2f);
	}

	// Token: 0x06000185 RID: 389 RVA: 0x0000C5B8 File Offset: 0x0000A7B8
	protected void LateUpdate()
	{
		for (int i = 0; i < this.emissionModule.burstCount; i++)
		{
			ParticleSystem.Burst burst = this.emissionModule.GetBurst(i);
			burst.probability = this.maxBurstProbability * this.particleEmissionCurve.Evaluate(this.thermalReceiver.celsius);
			this.emissionModule.SetBurst(i, burst);
		}
		int particleCount = this.particleSys.particleCount;
		if (particleCount > this.previousParticleCount)
		{
			this.soundBankPlayer.Play(null, null);
		}
		this.previousParticleCount = particleCount;
	}

	// Token: 0x0400021B RID: 539
	[Tooltip("The corn will start popping based on the temperature from this ThermalReceiver.")]
	public ThermalReceiver thermalReceiver;

	// Token: 0x0400021C RID: 540
	[Tooltip("The particle system that will be emitted when the heat source is hot enough.")]
	public ParticleSystem particleSys;

	// Token: 0x0400021D RID: 541
	[Tooltip("The curve that determines how many particles will be emitted based on the heat source's temperature.\n\nThe x-axis is the heat source's temperature and the y-axis is the number of particles to emit.")]
	public AnimationCurve particleEmissionCurve;

	// Token: 0x0400021E RID: 542
	public SoundBankPlayer soundBankPlayer;

	// Token: 0x0400021F RID: 543
	private ParticleSystem.EmissionModule emissionModule;

	// Token: 0x04000220 RID: 544
	private float maxBurstProbability;

	// Token: 0x04000221 RID: 545
	private int previousParticleCount;
}
