﻿using System;
using System.Collections.Generic;
using PlayFab;
using Unity.Collections;
using UnityEngine;
using UnityEngine.Serialization;
using WebSocketSharp;

namespace GorillaNetworking.Store
{
	// Token: 0x020006FA RID: 1786
	[Serializable]
	public class StoreBundle
	{
		// Token: 0x170004E7 RID: 1255
		// (get) Token: 0x06002A41 RID: 10817 RVA: 0x000CF7E0 File Offset: 0x000CD9E0
		public string playfabBundleID
		{
			get
			{
				return this._storeBundleDataReference.playfabBundleID;
			}
		}

		// Token: 0x170004E8 RID: 1256
		// (get) Token: 0x06002A42 RID: 10818 RVA: 0x000CF7ED File Offset: 0x000CD9ED
		public string bundleSKU
		{
			get
			{
				return this._storeBundleDataReference.bundleSKU;
			}
		}

		// Token: 0x170004E9 RID: 1257
		// (get) Token: 0x06002A43 RID: 10819 RVA: 0x000CF7FA File Offset: 0x000CD9FA
		public Sprite bundleImage
		{
			get
			{
				return this._storeBundleDataReference.bundleImage;
			}
		}

		// Token: 0x170004EA RID: 1258
		// (get) Token: 0x06002A44 RID: 10820 RVA: 0x000CF808 File Offset: 0x000CDA08
		public string bundleName
		{
			get
			{
				if (this._bundleName.IsNullOrEmpty())
				{
					int num = CosmeticsController.instance.allCosmetics.FindIndex((CosmeticsController.CosmeticItem x) => this.playfabBundleID == x.itemName);
					if (num > 0)
					{
						if (!CosmeticsController.instance.allCosmetics[num].overrideDisplayName.IsNullOrEmpty())
						{
							this._bundleName = CosmeticsController.instance.allCosmetics[num].overrideDisplayName;
						}
						else
						{
							this._bundleName = CosmeticsController.instance.allCosmetics[num].displayName;
						}
					}
					else
					{
						this._bundleName = "NULL_BUNDLE_NAME";
					}
				}
				return this._bundleName;
			}
		}

		// Token: 0x170004EB RID: 1259
		// (get) Token: 0x06002A45 RID: 10821 RVA: 0x000CF8B4 File Offset: 0x000CDAB4
		public string bundleDescriptionText
		{
			get
			{
				return this._storeBundleDataReference.bundleDescriptionText;
			}
		}

		// Token: 0x06002A46 RID: 10822 RVA: 0x000CF8C4 File Offset: 0x000CDAC4
		public StoreBundle()
		{
			this.isOwned = false;
			this.bundleStands = new List<BundleStand>();
		}

		// Token: 0x06002A47 RID: 10823 RVA: 0x000CF918 File Offset: 0x000CDB18
		public StoreBundle(StoreBundleData data)
		{
			this.isOwned = false;
			this.bundleStands = new List<BundleStand>();
			this._storeBundleDataReference = data;
		}

		// Token: 0x06002A48 RID: 10824 RVA: 0x00003051 File Offset: 0x00001251
		public void UpdateBundleData()
		{
		}

		// Token: 0x06002A49 RID: 10825 RVA: 0x000CF970 File Offset: 0x000CDB70
		public void InitializebundleStands()
		{
			foreach (BundleStand bundleStand in this.bundleStands)
			{
				bundleStand.UpdateDescriptionText(this.bundleDescriptionText);
				bundleStand.InitializeEventListeners();
			}
		}

		// Token: 0x06002A4A RID: 10826 RVA: 0x00003051 File Offset: 0x00001251
		public void UpdatePriceFromTitleData()
		{
		}

		// Token: 0x06002A4B RID: 10827 RVA: 0x000CF9CC File Offset: 0x000CDBCC
		public void FailedToUpdatePrice(PlayFabError error)
		{
			this.price = "$--.--";
			this.UpdatePurchaseButtonText();
			Debug.LogError(string.Format("Error getting price title data: {0}", error));
		}

		// Token: 0x06002A4C RID: 10828 RVA: 0x000CF9F0 File Offset: 0x000CDBF0
		public void UpdatePurchaseButtonText()
		{
			this.purchaseButtonText = string.Format(this.purchaseButtonStringFormat, this.bundleName, this.price);
			foreach (BundleStand bundleStand in this.bundleStands)
			{
				bundleStand.UpdatePurchaseButtonText(this.purchaseButtonText);
			}
		}

		// Token: 0x06002A4D RID: 10829 RVA: 0x000CFA64 File Offset: 0x000CDC64
		public void ValidateBundleData()
		{
			if (this._storeBundleDataReference == null)
			{
				Debug.LogError("StoreBundleData is null");
				foreach (BundleStand bundleStand in this.bundleStands)
				{
					if (bundleStand == null)
					{
						Debug.LogError("BundleStand is null");
					}
					else if (bundleStand._bundleDataReference != null)
					{
						this._storeBundleDataReference = bundleStand._bundleDataReference;
						Debug.LogError("BundleStand StoreBundleData is not equal to StoreBundle StoreBundleData");
					}
				}
			}
			if (this._storeBundleDataReference == null)
			{
				Debug.LogError("StoreBundleData is null");
				return;
			}
			this.UpdateBundleData();
			if (this._storeBundleDataReference.playfabBundleID.IsNullOrEmpty())
			{
				Debug.LogError("playfabBundleID is null");
			}
			if (this._storeBundleDataReference.bundleSKU.IsNullOrEmpty())
			{
				Debug.LogError("bundleSKU is null");
			}
			if (this._storeBundleDataReference.bundleImage == null)
			{
				Debug.LogError("bundleImage is null");
			}
			if (this._storeBundleDataReference.bundleDescriptionText.IsNullOrEmpty())
			{
				Debug.LogError("bundleDescriptionText is null");
			}
		}

		// Token: 0x04002D4A RID: 11594
		[NonSerialized]
		public string purchaseButtonStringFormat = "THE {0}\n{1}";

		// Token: 0x04002D4B RID: 11595
		[SerializeField]
		public List<BundleStand> bundleStands;

		// Token: 0x04002D4C RID: 11596
		public bool isOwned;

		// Token: 0x04002D4D RID: 11597
		[NonSerialized]
		public string price = "";

		// Token: 0x04002D4E RID: 11598
		private string _bundleName = "";

		// Token: 0x04002D4F RID: 11599
		public string purchaseButtonText = "";

		// Token: 0x04002D50 RID: 11600
		[FormerlySerializedAs("storeBundleDataReference")]
		[SerializeField]
		[ReadOnly]
		private StoreBundleData _storeBundleDataReference;
	}
}
