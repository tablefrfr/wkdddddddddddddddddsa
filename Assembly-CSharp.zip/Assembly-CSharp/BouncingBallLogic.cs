﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x020001C7 RID: 455
public class BouncingBallLogic : MonoBehaviour
{
	// Token: 0x06000965 RID: 2405 RVA: 0x00031372 File Offset: 0x0002F572
	private void OnCollisionEnter()
	{
		this.audioSource.PlayOneShot(this.bounce);
	}

	// Token: 0x06000966 RID: 2406 RVA: 0x00031385 File Offset: 0x0002F585
	private void Start()
	{
		this.audioSource = base.GetComponent<AudioSource>();
		this.audioSource.PlayOneShot(this.loadball);
		this.centerEyeCamera = OVRManager.instance.GetComponentInChildren<OVRCameraRig>().centerEyeAnchor;
	}

	// Token: 0x06000967 RID: 2407 RVA: 0x000313BC File Offset: 0x0002F5BC
	private void Update()
	{
		if (!this.isReleased)
		{
			return;
		}
		this.UpdateVisibility();
		this.timer += Time.deltaTime;
		if (!this.isReadyForDestroy && this.timer >= this.TTL)
		{
			this.isReadyForDestroy = true;
			float length = this.pop.length;
			this.audioSource.PlayOneShot(this.pop);
			base.StartCoroutine(this.PlayPopCallback(length));
		}
	}

	// Token: 0x06000968 RID: 2408 RVA: 0x00031434 File Offset: 0x0002F634
	private void UpdateVisibility()
	{
		Vector3 direction = this.centerEyeCamera.position - base.transform.position;
		RaycastHit raycastHit;
		if (Physics.Raycast(new Ray(base.transform.position, direction), out raycastHit, direction.magnitude))
		{
			if (raycastHit.collider.gameObject != base.gameObject)
			{
				this.SetVisible(false);
				return;
			}
		}
		else
		{
			this.SetVisible(true);
		}
	}

	// Token: 0x06000969 RID: 2409 RVA: 0x000314A8 File Offset: 0x0002F6A8
	private void SetVisible(bool setVisible)
	{
		if (this.isVisible && !setVisible)
		{
			base.GetComponent<MeshRenderer>().material = this.hiddenMat;
			this.isVisible = false;
		}
		if (!this.isVisible && setVisible)
		{
			base.GetComponent<MeshRenderer>().material = this.visibleMat;
			this.isVisible = true;
		}
	}

	// Token: 0x0600096A RID: 2410 RVA: 0x000314FD File Offset: 0x0002F6FD
	public void Release(Vector3 pos, Vector3 vel, Vector3 angVel)
	{
		this.isReleased = true;
		base.transform.position = pos;
		base.GetComponent<Rigidbody>().isKinematic = false;
		base.GetComponent<Rigidbody>().velocity = vel;
		base.GetComponent<Rigidbody>().angularVelocity = angVel;
	}

	// Token: 0x0600096B RID: 2411 RVA: 0x00031536 File Offset: 0x0002F736
	private IEnumerator PlayPopCallback(float clipLength)
	{
		yield return new WaitForSeconds(clipLength);
		Object.Destroy(base.gameObject);
		yield break;
	}

	// Token: 0x04000A62 RID: 2658
	[SerializeField]
	private float TTL = 5f;

	// Token: 0x04000A63 RID: 2659
	[SerializeField]
	private AudioClip pop;

	// Token: 0x04000A64 RID: 2660
	[SerializeField]
	private AudioClip bounce;

	// Token: 0x04000A65 RID: 2661
	[SerializeField]
	private AudioClip loadball;

	// Token: 0x04000A66 RID: 2662
	[SerializeField]
	private Material visibleMat;

	// Token: 0x04000A67 RID: 2663
	[SerializeField]
	private Material hiddenMat;

	// Token: 0x04000A68 RID: 2664
	private AudioSource audioSource;

	// Token: 0x04000A69 RID: 2665
	private Transform centerEyeCamera;

	// Token: 0x04000A6A RID: 2666
	private bool isVisible = true;

	// Token: 0x04000A6B RID: 2667
	private float timer;

	// Token: 0x04000A6C RID: 2668
	private bool isReleased;

	// Token: 0x04000A6D RID: 2669
	private bool isReadyForDestroy;
}
