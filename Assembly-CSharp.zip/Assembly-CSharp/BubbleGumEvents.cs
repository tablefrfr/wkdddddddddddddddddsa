﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x020002DC RID: 732
public class BubbleGumEvents : MonoBehaviour
{
	// Token: 0x060010D3 RID: 4307 RVA: 0x00059341 File Offset: 0x00057541
	private void OnEnable()
	{
		this._edible.onBiteWorld.AddListener(new UnityAction<VRRig, int>(this.OnBiteWorld));
		this._edible.onBiteView.AddListener(new UnityAction<VRRig, int>(this.OnBiteView));
	}

	// Token: 0x060010D4 RID: 4308 RVA: 0x0005937B File Offset: 0x0005757B
	private void OnDisable()
	{
		this._edible.onBiteWorld.RemoveListener(new UnityAction<VRRig, int>(this.OnBiteWorld));
		this._edible.onBiteView.RemoveListener(new UnityAction<VRRig, int>(this.OnBiteView));
	}

	// Token: 0x060010D5 RID: 4309 RVA: 0x000593B5 File Offset: 0x000575B5
	public void OnBiteView(VRRig rig, int nextState)
	{
		this.OnBite(rig, nextState, true);
	}

	// Token: 0x060010D6 RID: 4310 RVA: 0x000593C0 File Offset: 0x000575C0
	public void OnBiteWorld(VRRig rig, int nextState)
	{
		this.OnBite(rig, nextState, false);
	}

	// Token: 0x060010D7 RID: 4311 RVA: 0x000593CC File Offset: 0x000575CC
	public void OnBite(VRRig rig, int nextState, bool isViewRig)
	{
		GorillaTagger instance = GorillaTagger.Instance;
		GameObject gameObject = null;
		if (isViewRig && instance != null)
		{
			gameObject = instance.gameObject;
		}
		else if (!isViewRig)
		{
			gameObject = rig.gameObject;
		}
		if (!BubbleGumEvents.gTargetCache.TryGetValue(gameObject, out this._bubble))
		{
			this._bubble = gameObject.GetComponentsInChildren<GumBubble>(true).FirstOrDefault((GumBubble g) => g.transform.parent.name == "$gum");
			if (isViewRig)
			{
				this._bubble.audioSource = instance.offlineVRRig.tagSound;
				this._bubble.targetScale = Vector3.one * 1.36f;
			}
			else
			{
				this._bubble.audioSource = rig.tagSound;
				this._bubble.targetScale = Vector3.one * 2f;
			}
			BubbleGumEvents.gTargetCache.Add(gameObject, this._bubble);
		}
		GumBubble bubble = this._bubble;
		if (bubble != null)
		{
			bubble.transform.parent.gameObject.SetActive(true);
		}
		GumBubble bubble2 = this._bubble;
		if (bubble2 == null)
		{
			return;
		}
		bubble2.InflateDelayed();
	}

	// Token: 0x04001301 RID: 4865
	[SerializeField]
	private EdibleHoldable _edible;

	// Token: 0x04001302 RID: 4866
	[SerializeField]
	private GumBubble _bubble;

	// Token: 0x04001303 RID: 4867
	private static Dictionary<GameObject, GumBubble> gTargetCache = new Dictionary<GameObject, GumBubble>(16);

	// Token: 0x020002DD RID: 733
	public enum EdibleState
	{
		// Token: 0x04001305 RID: 4869
		A = 1,
		// Token: 0x04001306 RID: 4870
		B,
		// Token: 0x04001307 RID: 4871
		C = 4,
		// Token: 0x04001308 RID: 4872
		D = 8
	}
}
