﻿using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005CC RID: 1484
	public class RopeSwingManager : MonoBehaviourPun
	{
		// Token: 0x1700040E RID: 1038
		// (get) Token: 0x060022BF RID: 8895 RVA: 0x000A9533 File Offset: 0x000A7733
		// (set) Token: 0x060022C0 RID: 8896 RVA: 0x000A953A File Offset: 0x000A773A
		public static RopeSwingManager instance { get; private set; }

		// Token: 0x060022C1 RID: 8897 RVA: 0x000A9544 File Offset: 0x000A7744
		private void Awake()
		{
			if (RopeSwingManager.instance != null && RopeSwingManager.instance != this)
			{
				GTDev.LogWarning("Instance of RopeSwingManager already exists. Destroying.", null);
				Object.Destroy(this);
				return;
			}
			if (RopeSwingManager.instance == null)
			{
				RopeSwingManager.instance = this;
			}
		}

		// Token: 0x060022C2 RID: 8898 RVA: 0x000A9590 File Offset: 0x000A7790
		private void RegisterInstance(GorillaRopeSwing t)
		{
			this.ropes.Add(t.ropeId, t);
		}

		// Token: 0x060022C3 RID: 8899 RVA: 0x000A95A4 File Offset: 0x000A77A4
		private void UnregisterInstance(GorillaRopeSwing t)
		{
			this.ropes.Remove(t.ropeId);
		}

		// Token: 0x060022C4 RID: 8900 RVA: 0x000A95B8 File Offset: 0x000A77B8
		public static void Register(GorillaRopeSwing t)
		{
			RopeSwingManager.instance.RegisterInstance(t);
		}

		// Token: 0x060022C5 RID: 8901 RVA: 0x000A95C5 File Offset: 0x000A77C5
		public static void Unregister(GorillaRopeSwing t)
		{
			RopeSwingManager.instance.UnregisterInstance(t);
		}

		// Token: 0x060022C6 RID: 8902 RVA: 0x000A95D4 File Offset: 0x000A77D4
		public void SendSetVelocity_RPC(int ropeId, int boneIndex, Vector3 velocity, bool wholeRope)
		{
			if (PhotonNetwork.InRoom)
			{
				base.photonView.RPC("SetVelocity", RpcTarget.All, new object[]
				{
					ropeId,
					boneIndex,
					velocity,
					wholeRope
				});
				return;
			}
			this.SetVelocity(ropeId, boneIndex, velocity, wholeRope, default(PhotonMessageInfo));
		}

		// Token: 0x060022C7 RID: 8903 RVA: 0x000A963C File Offset: 0x000A783C
		public GorillaRopeSwing GetRope(int ropeId)
		{
			GorillaRopeSwing result;
			this.ropes.TryGetValue(ropeId, out result);
			return result;
		}

		// Token: 0x060022C8 RID: 8904 RVA: 0x000A965C File Offset: 0x000A785C
		[PunRPC]
		public void SetVelocity(int ropeId, int boneIndex, Vector3 velocity, bool wholeRope, PhotonMessageInfo info)
		{
			if (info.Sender != null)
			{
				GorillaNot.IncrementRPCCall(info, "SetVelocity");
			}
			GorillaRopeSwing rope = this.GetRope(ropeId);
			if (rope != null)
			{
				rope.SetVelocity(boneIndex, velocity, wholeRope, info);
			}
		}

		// Token: 0x04002530 RID: 9520
		private Dictionary<int, GorillaRopeSwing> ropes = new Dictionary<int, GorillaRopeSwing>();
	}
}
