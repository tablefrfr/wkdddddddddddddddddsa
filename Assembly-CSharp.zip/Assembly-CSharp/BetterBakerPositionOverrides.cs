﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020004B0 RID: 1200
public class BetterBakerPositionOverrides : MonoBehaviour
{
	// Token: 0x04001F4D RID: 8013
	public List<BetterBakerPositionOverrides.OverridePosition> overridePositions;

	// Token: 0x020004B1 RID: 1201
	[Serializable]
	public struct OverridePosition
	{
		// Token: 0x04001F4E RID: 8014
		public GameObject go;

		// Token: 0x04001F4F RID: 8015
		public Transform bakingTransform;

		// Token: 0x04001F50 RID: 8016
		public Transform gameTransform;
	}
}
