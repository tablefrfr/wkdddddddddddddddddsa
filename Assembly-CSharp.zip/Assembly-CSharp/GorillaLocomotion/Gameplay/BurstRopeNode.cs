﻿using System;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005C0 RID: 1472
	public struct BurstRopeNode
	{
		// Token: 0x040024CA RID: 9418
		public Vector3 lastPos;

		// Token: 0x040024CB RID: 9419
		public Vector3 curPos;
	}
}
