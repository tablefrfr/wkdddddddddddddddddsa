﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace BoingKit
{
	// Token: 0x020007FA RID: 2042
	public static class BoingManager
	{
		// Token: 0x1700055C RID: 1372
		// (get) Token: 0x0600318E RID: 12686 RVA: 0x000F7AC4 File Offset: 0x000F5CC4
		public static IEnumerable<BoingBehavior> Behaviors
		{
			get
			{
				return BoingManager.s_behaviorMap.Values;
			}
		}

		// Token: 0x1700055D RID: 1373
		// (get) Token: 0x0600318F RID: 12687 RVA: 0x000F7AD0 File Offset: 0x000F5CD0
		public static IEnumerable<BoingReactor> Reactors
		{
			get
			{
				return BoingManager.s_reactorMap.Values;
			}
		}

		// Token: 0x1700055E RID: 1374
		// (get) Token: 0x06003190 RID: 12688 RVA: 0x000F7ADC File Offset: 0x000F5CDC
		public static IEnumerable<BoingEffector> Effectors
		{
			get
			{
				return BoingManager.s_effectorMap.Values;
			}
		}

		// Token: 0x1700055F RID: 1375
		// (get) Token: 0x06003191 RID: 12689 RVA: 0x000F7AE8 File Offset: 0x000F5CE8
		public static IEnumerable<BoingReactorField> ReactorFields
		{
			get
			{
				return BoingManager.s_fieldMap.Values;
			}
		}

		// Token: 0x17000560 RID: 1376
		// (get) Token: 0x06003192 RID: 12690 RVA: 0x000F7AF4 File Offset: 0x000F5CF4
		public static IEnumerable<BoingReactorFieldCPUSampler> ReactorFieldCPUSamlers
		{
			get
			{
				return BoingManager.s_cpuSamplerMap.Values;
			}
		}

		// Token: 0x17000561 RID: 1377
		// (get) Token: 0x06003193 RID: 12691 RVA: 0x000F7B00 File Offset: 0x000F5D00
		public static IEnumerable<BoingReactorFieldGPUSampler> ReactorFieldGPUSampler
		{
			get
			{
				return BoingManager.s_gpuSamplerMap.Values;
			}
		}

		// Token: 0x17000562 RID: 1378
		// (get) Token: 0x06003194 RID: 12692 RVA: 0x000F7B0C File Offset: 0x000F5D0C
		public static float DeltaTime
		{
			get
			{
				return BoingManager.s_deltaTime;
			}
		}

		// Token: 0x17000563 RID: 1379
		// (get) Token: 0x06003195 RID: 12693 RVA: 0x000F7B13 File Offset: 0x000F5D13
		public static float FixedDeltaTime
		{
			get
			{
				return Time.fixedDeltaTime;
			}
		}

		// Token: 0x17000564 RID: 1380
		// (get) Token: 0x06003196 RID: 12694 RVA: 0x000F7B1A File Offset: 0x000F5D1A
		internal static int NumBehaviors
		{
			get
			{
				return BoingManager.s_behaviorMap.Count;
			}
		}

		// Token: 0x17000565 RID: 1381
		// (get) Token: 0x06003197 RID: 12695 RVA: 0x000F7B26 File Offset: 0x000F5D26
		internal static int NumEffectors
		{
			get
			{
				return BoingManager.s_effectorMap.Count;
			}
		}

		// Token: 0x17000566 RID: 1382
		// (get) Token: 0x06003198 RID: 12696 RVA: 0x000F7B32 File Offset: 0x000F5D32
		internal static int NumReactors
		{
			get
			{
				return BoingManager.s_reactorMap.Count;
			}
		}

		// Token: 0x17000567 RID: 1383
		// (get) Token: 0x06003199 RID: 12697 RVA: 0x000F7B3E File Offset: 0x000F5D3E
		internal static int NumFields
		{
			get
			{
				return BoingManager.s_fieldMap.Count;
			}
		}

		// Token: 0x17000568 RID: 1384
		// (get) Token: 0x0600319A RID: 12698 RVA: 0x000F7B4A File Offset: 0x000F5D4A
		internal static int NumCPUFieldSamplers
		{
			get
			{
				return BoingManager.s_cpuSamplerMap.Count;
			}
		}

		// Token: 0x17000569 RID: 1385
		// (get) Token: 0x0600319B RID: 12699 RVA: 0x000F7B56 File Offset: 0x000F5D56
		internal static int NumGPUFieldSamplers
		{
			get
			{
				return BoingManager.s_gpuSamplerMap.Count;
			}
		}

		// Token: 0x0600319C RID: 12700 RVA: 0x000F7B64 File Offset: 0x000F5D64
		private static void ValidateManager()
		{
			if (BoingManager.s_managerGo != null)
			{
				return;
			}
			BoingManager.s_managerGo = new GameObject("Boing Kit manager (don't delete)");
			BoingManager.s_managerGo.AddComponent<BoingManagerPreUpdatePump>();
			BoingManager.s_managerGo.AddComponent<BoingManagerPostUpdatePump>();
			Object.DontDestroyOnLoad(BoingManager.s_managerGo);
			BoingManager.s_managerGo.AddComponent<SphereCollider>().enabled = false;
		}

		// Token: 0x1700056A RID: 1386
		// (get) Token: 0x0600319D RID: 12701 RVA: 0x000F7BBE File Offset: 0x000F5DBE
		internal static SphereCollider SharedSphereCollider
		{
			get
			{
				if (BoingManager.s_managerGo == null)
				{
					return null;
				}
				return BoingManager.s_managerGo.GetComponent<SphereCollider>();
			}
		}

		// Token: 0x0600319E RID: 12702 RVA: 0x000F7BD9 File Offset: 0x000F5DD9
		internal static void Register(BoingBehavior behavior)
		{
			BoingManager.PreRegisterBehavior();
			BoingManager.s_behaviorMap.Add(behavior.GetInstanceID(), behavior);
			if (BoingManager.OnBehaviorRegister != null)
			{
				BoingManager.OnBehaviorRegister(behavior);
			}
		}

		// Token: 0x0600319F RID: 12703 RVA: 0x000F7C03 File Offset: 0x000F5E03
		internal static void Unregister(BoingBehavior behavior)
		{
			if (BoingManager.OnBehaviorUnregister != null)
			{
				BoingManager.OnBehaviorUnregister(behavior);
			}
			BoingManager.s_behaviorMap.Remove(behavior.GetInstanceID());
			BoingManager.PostUnregisterBehavior();
		}

		// Token: 0x060031A0 RID: 12704 RVA: 0x000F7C2D File Offset: 0x000F5E2D
		internal static void Register(BoingEffector effector)
		{
			BoingManager.PreRegisterEffectorReactor();
			BoingManager.s_effectorMap.Add(effector.GetInstanceID(), effector);
			if (BoingManager.OnEffectorRegister != null)
			{
				BoingManager.OnEffectorRegister(effector);
			}
		}

		// Token: 0x060031A1 RID: 12705 RVA: 0x000F7C57 File Offset: 0x000F5E57
		internal static void Unregister(BoingEffector effector)
		{
			if (BoingManager.OnEffectorUnregister != null)
			{
				BoingManager.OnEffectorUnregister(effector);
			}
			BoingManager.s_effectorMap.Remove(effector.GetInstanceID());
			BoingManager.PostUnregisterEffectorReactor();
		}

		// Token: 0x060031A2 RID: 12706 RVA: 0x000F7C81 File Offset: 0x000F5E81
		internal static void Register(BoingReactor reactor)
		{
			BoingManager.PreRegisterEffectorReactor();
			BoingManager.s_reactorMap.Add(reactor.GetInstanceID(), reactor);
			if (BoingManager.OnReactorRegister != null)
			{
				BoingManager.OnReactorRegister(reactor);
			}
		}

		// Token: 0x060031A3 RID: 12707 RVA: 0x000F7CAB File Offset: 0x000F5EAB
		internal static void Unregister(BoingReactor reactor)
		{
			if (BoingManager.OnReactorUnregister != null)
			{
				BoingManager.OnReactorUnregister(reactor);
			}
			BoingManager.s_reactorMap.Remove(reactor.GetInstanceID());
			BoingManager.PostUnregisterEffectorReactor();
		}

		// Token: 0x060031A4 RID: 12708 RVA: 0x000F7CD5 File Offset: 0x000F5ED5
		internal static void Register(BoingReactorField field)
		{
			BoingManager.PreRegisterEffectorReactor();
			BoingManager.s_fieldMap.Add(field.GetInstanceID(), field);
			if (BoingManager.OnReactorFieldRegister != null)
			{
				BoingManager.OnReactorFieldRegister(field);
			}
		}

		// Token: 0x060031A5 RID: 12709 RVA: 0x000F7CFF File Offset: 0x000F5EFF
		internal static void Unregister(BoingReactorField field)
		{
			if (BoingManager.OnReactorFieldUnregister != null)
			{
				BoingManager.OnReactorFieldUnregister(field);
			}
			BoingManager.s_fieldMap.Remove(field.GetInstanceID());
			BoingManager.PostUnregisterEffectorReactor();
		}

		// Token: 0x060031A6 RID: 12710 RVA: 0x000F7D29 File Offset: 0x000F5F29
		internal static void Register(BoingReactorFieldCPUSampler sampler)
		{
			BoingManager.PreRegisterEffectorReactor();
			BoingManager.s_cpuSamplerMap.Add(sampler.GetInstanceID(), sampler);
			if (BoingManager.OnReactorFieldCPUSamplerRegister != null)
			{
				BoingManager.OnReactorFieldCPUSamplerUnregister(sampler);
			}
		}

		// Token: 0x060031A7 RID: 12711 RVA: 0x000F7D53 File Offset: 0x000F5F53
		internal static void Unregister(BoingReactorFieldCPUSampler sampler)
		{
			if (BoingManager.OnReactorFieldCPUSamplerUnregister != null)
			{
				BoingManager.OnReactorFieldCPUSamplerUnregister(sampler);
			}
			BoingManager.s_cpuSamplerMap.Remove(sampler.GetInstanceID());
			BoingManager.PostUnregisterEffectorReactor();
		}

		// Token: 0x060031A8 RID: 12712 RVA: 0x000F7D7D File Offset: 0x000F5F7D
		internal static void Register(BoingReactorFieldGPUSampler sampler)
		{
			BoingManager.PreRegisterEffectorReactor();
			BoingManager.s_gpuSamplerMap.Add(sampler.GetInstanceID(), sampler);
			if (BoingManager.OnReactorFieldGPUSamplerRegister != null)
			{
				BoingManager.OnReactorFieldGPUSamplerRegister(sampler);
			}
		}

		// Token: 0x060031A9 RID: 12713 RVA: 0x000F7DA7 File Offset: 0x000F5FA7
		internal static void Unregister(BoingReactorFieldGPUSampler sampler)
		{
			if (BoingManager.OnFieldGPUSamplerUnregister != null)
			{
				BoingManager.OnFieldGPUSamplerUnregister(sampler);
			}
			BoingManager.s_gpuSamplerMap.Remove(sampler.GetInstanceID());
			BoingManager.PostUnregisterEffectorReactor();
		}

		// Token: 0x060031AA RID: 12714 RVA: 0x000F7DD1 File Offset: 0x000F5FD1
		internal static void Register(BoingBones bones)
		{
			BoingManager.PreRegisterBones();
			BoingManager.s_bonesMap.Add(bones.GetInstanceID(), bones);
			if (BoingManager.OnBonesRegister != null)
			{
				BoingManager.OnBonesRegister(bones);
			}
		}

		// Token: 0x060031AB RID: 12715 RVA: 0x000F7DFB File Offset: 0x000F5FFB
		internal static void Unregister(BoingBones bones)
		{
			if (BoingManager.OnBonesUnregister != null)
			{
				BoingManager.OnBonesUnregister(bones);
			}
			BoingManager.s_bonesMap.Remove(bones.GetInstanceID());
			BoingManager.PostUnregisterBones();
		}

		// Token: 0x060031AC RID: 12716 RVA: 0x000F7E25 File Offset: 0x000F6025
		private static void PreRegisterBehavior()
		{
			BoingManager.ValidateManager();
		}

		// Token: 0x060031AD RID: 12717 RVA: 0x000F7E2C File Offset: 0x000F602C
		private static void PostUnregisterBehavior()
		{
			if (BoingManager.s_behaviorMap.Count > 0)
			{
				return;
			}
			BoingWorkAsynchronous.PostUnregisterBehaviorCleanUp();
		}

		// Token: 0x060031AE RID: 12718 RVA: 0x000F7E44 File Offset: 0x000F6044
		private static void PreRegisterEffectorReactor()
		{
			BoingManager.ValidateManager();
			if (BoingManager.s_effectorParamsBuffer == null)
			{
				BoingManager.s_effectorParamsList = new List<BoingEffector.Params>(BoingManager.kEffectorParamsIncrement);
				BoingManager.s_effectorParamsBuffer = new ComputeBuffer(BoingManager.s_effectorParamsList.Capacity, BoingEffector.Params.Stride);
			}
			if (BoingManager.s_effectorMap.Count >= BoingManager.s_effectorParamsList.Capacity)
			{
				BoingManager.s_effectorParamsList.Capacity += BoingManager.kEffectorParamsIncrement;
				BoingManager.s_effectorParamsBuffer.Dispose();
				BoingManager.s_effectorParamsBuffer = new ComputeBuffer(BoingManager.s_effectorParamsList.Capacity, BoingEffector.Params.Stride);
			}
		}

		// Token: 0x060031AF RID: 12719 RVA: 0x000F7ED4 File Offset: 0x000F60D4
		private static void PostUnregisterEffectorReactor()
		{
			if (BoingManager.s_effectorMap.Count > 0 || BoingManager.s_reactorMap.Count > 0 || BoingManager.s_fieldMap.Count > 0 || BoingManager.s_cpuSamplerMap.Count > 0 || BoingManager.s_gpuSamplerMap.Count > 0)
			{
				return;
			}
			BoingManager.s_effectorParamsList = null;
			BoingManager.s_effectorParamsBuffer.Dispose();
			BoingManager.s_effectorParamsBuffer = null;
			BoingWorkAsynchronous.PostUnregisterEffectorReactorCleanUp();
		}

		// Token: 0x060031B0 RID: 12720 RVA: 0x000F7E25 File Offset: 0x000F6025
		private static void PreRegisterBones()
		{
			BoingManager.ValidateManager();
		}

		// Token: 0x060031B1 RID: 12721 RVA: 0x00003051 File Offset: 0x00001251
		private static void PostUnregisterBones()
		{
		}

		// Token: 0x060031B2 RID: 12722 RVA: 0x000F7F3E File Offset: 0x000F613E
		internal static void Execute(BoingManager.UpdateMode updateMode)
		{
			if (updateMode == BoingManager.UpdateMode.EarlyUpdate)
			{
				BoingManager.s_deltaTime = Time.deltaTime;
			}
			BoingManager.RefreshEffectorParams();
			BoingManager.ExecuteBones(updateMode);
			BoingManager.ExecuteBehaviors(updateMode);
			BoingManager.ExecuteReactors(updateMode);
		}

		// Token: 0x060031B3 RID: 12723 RVA: 0x000F7F68 File Offset: 0x000F6168
		internal static void ExecuteBehaviors(BoingManager.UpdateMode updateMode)
		{
			if (BoingManager.s_behaviorMap.Count == 0)
			{
				return;
			}
			foreach (KeyValuePair<int, BoingBehavior> keyValuePair in BoingManager.s_behaviorMap)
			{
				BoingBehavior value = keyValuePair.Value;
				if (!value.InitRebooted)
				{
					value.Reboot();
					value.InitRebooted = true;
				}
			}
			if (BoingManager.UseAsynchronousJobs)
			{
				BoingWorkAsynchronous.ExecuteBehaviors(BoingManager.s_behaviorMap, updateMode);
				return;
			}
			BoingWorkSynchronous.ExecuteBehaviors(BoingManager.s_behaviorMap, updateMode);
		}

		// Token: 0x060031B4 RID: 12724 RVA: 0x000F7FFC File Offset: 0x000F61FC
		internal static void PullBehaviorResults(BoingManager.UpdateMode updateMode)
		{
			foreach (KeyValuePair<int, BoingBehavior> keyValuePair in BoingManager.s_behaviorMap)
			{
				if (keyValuePair.Value.UpdateMode == updateMode)
				{
					keyValuePair.Value.PullResults();
				}
			}
		}

		// Token: 0x060031B5 RID: 12725 RVA: 0x000F8064 File Offset: 0x000F6264
		internal static void RestoreBehaviors()
		{
			foreach (KeyValuePair<int, BoingBehavior> keyValuePair in BoingManager.s_behaviorMap)
			{
				keyValuePair.Value.Restore();
			}
		}

		// Token: 0x060031B6 RID: 12726 RVA: 0x000F80BC File Offset: 0x000F62BC
		internal static void RefreshEffectorParams()
		{
			if (BoingManager.s_effectorParamsList == null)
			{
				return;
			}
			BoingManager.s_effectorParamsIndexMap.Clear();
			BoingManager.s_effectorParamsList.Clear();
			foreach (KeyValuePair<int, BoingEffector> keyValuePair in BoingManager.s_effectorMap)
			{
				BoingEffector value = keyValuePair.Value;
				BoingManager.s_effectorParamsIndexMap.Add(value.GetInstanceID(), BoingManager.s_effectorParamsList.Count);
				BoingManager.s_effectorParamsList.Add(new BoingEffector.Params(value));
			}
			if (BoingManager.s_aEffectorParams == null || BoingManager.s_aEffectorParams.Length != BoingManager.s_effectorParamsList.Count)
			{
				BoingManager.s_aEffectorParams = BoingManager.s_effectorParamsList.ToArray();
				return;
			}
			BoingManager.s_effectorParamsList.CopyTo(BoingManager.s_aEffectorParams);
		}

		// Token: 0x060031B7 RID: 12727 RVA: 0x000F8190 File Offset: 0x000F6390
		internal static void ExecuteReactors(BoingManager.UpdateMode updateMode)
		{
			if (BoingManager.s_effectorMap.Count == 0 && BoingManager.s_reactorMap.Count == 0 && BoingManager.s_fieldMap.Count == 0 && BoingManager.s_cpuSamplerMap.Count == 0)
			{
				return;
			}
			foreach (KeyValuePair<int, BoingReactor> keyValuePair in BoingManager.s_reactorMap)
			{
				BoingReactor value = keyValuePair.Value;
				if (!value.InitRebooted)
				{
					value.Reboot();
					value.InitRebooted = true;
				}
			}
			if (BoingManager.UseAsynchronousJobs)
			{
				BoingWorkAsynchronous.ExecuteReactors(BoingManager.s_effectorMap, BoingManager.s_reactorMap, BoingManager.s_fieldMap, BoingManager.s_cpuSamplerMap, updateMode);
				return;
			}
			BoingWorkSynchronous.ExecuteReactors(BoingManager.s_aEffectorParams, BoingManager.s_reactorMap, BoingManager.s_fieldMap, BoingManager.s_cpuSamplerMap, updateMode);
		}

		// Token: 0x060031B8 RID: 12728 RVA: 0x000F8268 File Offset: 0x000F6468
		internal static void PullReactorResults(BoingManager.UpdateMode updateMode)
		{
			foreach (KeyValuePair<int, BoingReactor> keyValuePair in BoingManager.s_reactorMap)
			{
				if (keyValuePair.Value.UpdateMode == updateMode)
				{
					keyValuePair.Value.PullResults();
				}
			}
			foreach (KeyValuePair<int, BoingReactorFieldCPUSampler> keyValuePair2 in BoingManager.s_cpuSamplerMap)
			{
				if (keyValuePair2.Value.UpdateMode == updateMode)
				{
					keyValuePair2.Value.SampleFromField();
				}
			}
		}

		// Token: 0x060031B9 RID: 12729 RVA: 0x000F8324 File Offset: 0x000F6524
		internal static void RestoreReactors()
		{
			foreach (KeyValuePair<int, BoingReactor> keyValuePair in BoingManager.s_reactorMap)
			{
				keyValuePair.Value.Restore();
			}
			foreach (KeyValuePair<int, BoingReactorFieldCPUSampler> keyValuePair2 in BoingManager.s_cpuSamplerMap)
			{
				keyValuePair2.Value.Restore();
			}
		}

		// Token: 0x060031BA RID: 12730 RVA: 0x000F83C4 File Offset: 0x000F65C4
		internal static void DispatchReactorFieldCompute()
		{
			if (BoingManager.s_effectorParamsBuffer == null)
			{
				return;
			}
			BoingManager.s_effectorParamsBuffer.SetData(BoingManager.s_aEffectorParams);
			float deltaTime = Time.deltaTime;
			foreach (KeyValuePair<int, BoingReactorField> keyValuePair in BoingManager.s_fieldMap)
			{
				BoingReactorField value = keyValuePair.Value;
				if (value.HardwareMode == BoingReactorField.HardwareModeEnum.GPU)
				{
					value.ExecuteGpu(deltaTime, BoingManager.s_effectorParamsBuffer, BoingManager.s_effectorParamsIndexMap);
				}
			}
		}

		// Token: 0x060031BB RID: 12731 RVA: 0x000F8450 File Offset: 0x000F6650
		internal static void ExecuteBones(BoingManager.UpdateMode updateMode)
		{
			if (BoingManager.s_bonesMap.Count == 0)
			{
				return;
			}
			foreach (KeyValuePair<int, BoingBones> keyValuePair in BoingManager.s_bonesMap)
			{
				BoingBones value = keyValuePair.Value;
				if (!value.InitRebooted)
				{
					value.Reboot();
					value.InitRebooted = true;
				}
			}
			if (BoingManager.UseAsynchronousJobs)
			{
				BoingWorkAsynchronous.ExecuteBones(BoingManager.s_aEffectorParams, BoingManager.s_bonesMap, updateMode);
				return;
			}
			BoingWorkSynchronous.ExecuteBones(BoingManager.s_aEffectorParams, BoingManager.s_bonesMap, updateMode);
		}

		// Token: 0x060031BC RID: 12732 RVA: 0x000F84F0 File Offset: 0x000F66F0
		internal static void PullBonesResults(BoingManager.UpdateMode updateMode)
		{
			if (BoingManager.s_bonesMap.Count == 0)
			{
				return;
			}
			if (BoingManager.UseAsynchronousJobs)
			{
				BoingWorkAsynchronous.PullBonesResults(BoingManager.s_aEffectorParams, BoingManager.s_bonesMap, updateMode);
				return;
			}
			BoingWorkSynchronous.PullBonesResults(BoingManager.s_aEffectorParams, BoingManager.s_bonesMap, updateMode);
		}

		// Token: 0x060031BD RID: 12733 RVA: 0x000F8528 File Offset: 0x000F6728
		internal static void RestoreBones()
		{
			foreach (KeyValuePair<int, BoingBones> keyValuePair in BoingManager.s_bonesMap)
			{
				keyValuePair.Value.Restore();
			}
		}

		// Token: 0x04003424 RID: 13348
		public static BoingManager.BehaviorRegisterDelegate OnBehaviorRegister;

		// Token: 0x04003425 RID: 13349
		public static BoingManager.BehaviorUnregisterDelegate OnBehaviorUnregister;

		// Token: 0x04003426 RID: 13350
		public static BoingManager.EffectorRegisterDelegate OnEffectorRegister;

		// Token: 0x04003427 RID: 13351
		public static BoingManager.EffectorUnregisterDelegate OnEffectorUnregister;

		// Token: 0x04003428 RID: 13352
		public static BoingManager.ReactorRegisterDelegate OnReactorRegister;

		// Token: 0x04003429 RID: 13353
		public static BoingManager.ReactorUnregisterDelegate OnReactorUnregister;

		// Token: 0x0400342A RID: 13354
		public static BoingManager.ReactorFieldRegisterDelegate OnReactorFieldRegister;

		// Token: 0x0400342B RID: 13355
		public static BoingManager.ReactorFieldUnregisterDelegate OnReactorFieldUnregister;

		// Token: 0x0400342C RID: 13356
		public static BoingManager.ReactorFieldCPUSamplerRegisterDelegate OnReactorFieldCPUSamplerRegister;

		// Token: 0x0400342D RID: 13357
		public static BoingManager.ReactorFieldCPUSamplerUnregisterDelegate OnReactorFieldCPUSamplerUnregister;

		// Token: 0x0400342E RID: 13358
		public static BoingManager.ReactorFieldGPUSamplerRegisterDelegate OnReactorFieldGPUSamplerRegister;

		// Token: 0x0400342F RID: 13359
		public static BoingManager.ReactorFieldGPUSamplerUnregisterDelegate OnFieldGPUSamplerUnregister;

		// Token: 0x04003430 RID: 13360
		public static BoingManager.BonesRegisterDelegate OnBonesRegister;

		// Token: 0x04003431 RID: 13361
		public static BoingManager.BonesUnregisterDelegate OnBonesUnregister;

		// Token: 0x04003432 RID: 13362
		private static float s_deltaTime = 0f;

		// Token: 0x04003433 RID: 13363
		private static Dictionary<int, BoingBehavior> s_behaviorMap = new Dictionary<int, BoingBehavior>();

		// Token: 0x04003434 RID: 13364
		private static Dictionary<int, BoingEffector> s_effectorMap = new Dictionary<int, BoingEffector>();

		// Token: 0x04003435 RID: 13365
		private static Dictionary<int, BoingReactor> s_reactorMap = new Dictionary<int, BoingReactor>();

		// Token: 0x04003436 RID: 13366
		private static Dictionary<int, BoingReactorField> s_fieldMap = new Dictionary<int, BoingReactorField>();

		// Token: 0x04003437 RID: 13367
		private static Dictionary<int, BoingReactorFieldCPUSampler> s_cpuSamplerMap = new Dictionary<int, BoingReactorFieldCPUSampler>();

		// Token: 0x04003438 RID: 13368
		private static Dictionary<int, BoingReactorFieldGPUSampler> s_gpuSamplerMap = new Dictionary<int, BoingReactorFieldGPUSampler>();

		// Token: 0x04003439 RID: 13369
		private static Dictionary<int, BoingBones> s_bonesMap = new Dictionary<int, BoingBones>();

		// Token: 0x0400343A RID: 13370
		private static readonly int kEffectorParamsIncrement = 16;

		// Token: 0x0400343B RID: 13371
		private static List<BoingEffector.Params> s_effectorParamsList = new List<BoingEffector.Params>(BoingManager.kEffectorParamsIncrement);

		// Token: 0x0400343C RID: 13372
		private static BoingEffector.Params[] s_aEffectorParams;

		// Token: 0x0400343D RID: 13373
		private static ComputeBuffer s_effectorParamsBuffer;

		// Token: 0x0400343E RID: 13374
		private static Dictionary<int, int> s_effectorParamsIndexMap = new Dictionary<int, int>();

		// Token: 0x0400343F RID: 13375
		internal static readonly bool UseAsynchronousJobs = true;

		// Token: 0x04003440 RID: 13376
		internal static GameObject s_managerGo;

		// Token: 0x020007FB RID: 2043
		public enum UpdateMode
		{
			// Token: 0x04003442 RID: 13378
			FixedUpdate,
			// Token: 0x04003443 RID: 13379
			EarlyUpdate,
			// Token: 0x04003444 RID: 13380
			LateUpdate
		}

		// Token: 0x020007FC RID: 2044
		public enum TranslationLockSpace
		{
			// Token: 0x04003446 RID: 13382
			Global,
			// Token: 0x04003447 RID: 13383
			Local
		}

		// Token: 0x020007FD RID: 2045
		// (Invoke) Token: 0x060031C0 RID: 12736
		public delegate void BehaviorRegisterDelegate(BoingBehavior behavior);

		// Token: 0x020007FE RID: 2046
		// (Invoke) Token: 0x060031C4 RID: 12740
		public delegate void BehaviorUnregisterDelegate(BoingBehavior behavior);

		// Token: 0x020007FF RID: 2047
		// (Invoke) Token: 0x060031C8 RID: 12744
		public delegate void EffectorRegisterDelegate(BoingEffector effector);

		// Token: 0x02000800 RID: 2048
		// (Invoke) Token: 0x060031CC RID: 12748
		public delegate void EffectorUnregisterDelegate(BoingEffector effector);

		// Token: 0x02000801 RID: 2049
		// (Invoke) Token: 0x060031D0 RID: 12752
		public delegate void ReactorRegisterDelegate(BoingReactor reactor);

		// Token: 0x02000802 RID: 2050
		// (Invoke) Token: 0x060031D4 RID: 12756
		public delegate void ReactorUnregisterDelegate(BoingReactor reactor);

		// Token: 0x02000803 RID: 2051
		// (Invoke) Token: 0x060031D8 RID: 12760
		public delegate void ReactorFieldRegisterDelegate(BoingReactorField field);

		// Token: 0x02000804 RID: 2052
		// (Invoke) Token: 0x060031DC RID: 12764
		public delegate void ReactorFieldUnregisterDelegate(BoingReactorField field);

		// Token: 0x02000805 RID: 2053
		// (Invoke) Token: 0x060031E0 RID: 12768
		public delegate void ReactorFieldCPUSamplerRegisterDelegate(BoingReactorFieldCPUSampler sampler);

		// Token: 0x02000806 RID: 2054
		// (Invoke) Token: 0x060031E4 RID: 12772
		public delegate void ReactorFieldCPUSamplerUnregisterDelegate(BoingReactorFieldCPUSampler sampler);

		// Token: 0x02000807 RID: 2055
		// (Invoke) Token: 0x060031E8 RID: 12776
		public delegate void ReactorFieldGPUSamplerRegisterDelegate(BoingReactorFieldGPUSampler sampler);

		// Token: 0x02000808 RID: 2056
		// (Invoke) Token: 0x060031EC RID: 12780
		public delegate void ReactorFieldGPUSamplerUnregisterDelegate(BoingReactorFieldGPUSampler sampler);

		// Token: 0x02000809 RID: 2057
		// (Invoke) Token: 0x060031F0 RID: 12784
		public delegate void BonesRegisterDelegate(BoingBones bones);

		// Token: 0x0200080A RID: 2058
		// (Invoke) Token: 0x060031F4 RID: 12788
		public delegate void BonesUnregisterDelegate(BoingBones bones);
	}
}
