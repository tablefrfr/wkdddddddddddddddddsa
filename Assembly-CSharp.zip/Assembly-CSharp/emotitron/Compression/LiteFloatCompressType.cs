﻿using System;

namespace emotitron.Compression
{
	// Token: 0x020007BB RID: 1979
	public enum LiteFloatCompressType
	{
		// Token: 0x0400326C RID: 12908
		Bits2 = 2,
		// Token: 0x0400326D RID: 12909
		Bits3,
		// Token: 0x0400326E RID: 12910
		Bits4,
		// Token: 0x0400326F RID: 12911
		Bits5,
		// Token: 0x04003270 RID: 12912
		Bits6,
		// Token: 0x04003271 RID: 12913
		Bits7,
		// Token: 0x04003272 RID: 12914
		Bits8,
		// Token: 0x04003273 RID: 12915
		Bits9,
		// Token: 0x04003274 RID: 12916
		Bits10,
		// Token: 0x04003275 RID: 12917
		Bits12 = 12,
		// Token: 0x04003276 RID: 12918
		Bits14 = 14,
		// Token: 0x04003277 RID: 12919
		Half16 = 16,
		// Token: 0x04003278 RID: 12920
		Full32 = 32
	}
}
