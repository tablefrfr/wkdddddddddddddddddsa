﻿using System;
using System.Collections;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200033B RID: 827
public class ChestHeartbeat : MonoBehaviour
{
	// Token: 0x06001290 RID: 4752 RVA: 0x00062FBC File Offset: 0x000611BC
	public void Update()
	{
		if (PhotonNetwork.InRoom)
		{
			if ((PhotonNetwork.ServerTimestamp > this.lastShot + this.millisMin || Mathf.Abs(PhotonNetwork.ServerTimestamp - this.lastShot) > 10000) && PhotonNetwork.ServerTimestamp % 1500 <= 10)
			{
				this.lastShot = PhotonNetwork.ServerTimestamp;
				this.audioSource.PlayOneShot(this.audioSource.clip);
				base.StartCoroutine(this.HeartBeat());
				return;
			}
		}
		else if ((Time.time * 1000f > (float)(this.lastShot + this.millisMin) || Mathf.Abs(Time.time * 1000f - (float)this.lastShot) > 10000f) && Time.time * 1000f % 1500f <= 10f)
		{
			this.lastShot = PhotonNetwork.ServerTimestamp;
			this.audioSource.PlayOneShot(this.audioSource.clip);
			base.StartCoroutine(this.HeartBeat());
		}
	}

	// Token: 0x06001291 RID: 4753 RVA: 0x000630C0 File Offset: 0x000612C0
	private IEnumerator HeartBeat()
	{
		float startTime = Time.time;
		while (Time.time < startTime + this.endtime)
		{
			if (Time.time < startTime + this.minTime)
			{
				this.deltaTime = Time.time - startTime;
				this.scaleTransform.localScale = Vector3.Lerp(Vector3.one, Vector3.one * this.heartMinSize, this.deltaTime / this.minTime);
			}
			else if (Time.time < startTime + this.maxTime)
			{
				this.deltaTime = Time.time - startTime - this.minTime;
				this.scaleTransform.localScale = Vector3.Lerp(Vector3.one * this.heartMinSize, Vector3.one * this.heartMaxSize, this.deltaTime / (this.maxTime - this.minTime));
			}
			else if (Time.time < startTime + this.endtime)
			{
				this.deltaTime = Time.time - startTime - this.maxTime;
				this.scaleTransform.localScale = Vector3.Lerp(Vector3.one * this.heartMaxSize, Vector3.one, this.deltaTime / (this.endtime - this.maxTime));
			}
			yield return new WaitForFixedUpdate();
		}
		yield break;
	}

	// Token: 0x04001595 RID: 5525
	public int millisToWait;

	// Token: 0x04001596 RID: 5526
	public int millisMin = 300;

	// Token: 0x04001597 RID: 5527
	public int lastShot;

	// Token: 0x04001598 RID: 5528
	public AudioSource audioSource;

	// Token: 0x04001599 RID: 5529
	public Transform scaleTransform;

	// Token: 0x0400159A RID: 5530
	private float deltaTime;

	// Token: 0x0400159B RID: 5531
	private float heartMinSize = 0.9f;

	// Token: 0x0400159C RID: 5532
	private float heartMaxSize = 1.2f;

	// Token: 0x0400159D RID: 5533
	private float minTime = 0.05f;

	// Token: 0x0400159E RID: 5534
	private float maxTime = 0.1f;

	// Token: 0x0400159F RID: 5535
	private float endtime = 0.25f;

	// Token: 0x040015A0 RID: 5536
	private float currentTime;
}
