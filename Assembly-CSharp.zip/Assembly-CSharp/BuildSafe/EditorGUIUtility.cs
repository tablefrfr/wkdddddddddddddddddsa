﻿using System;
using System.Diagnostics;
using UnityEngine;

namespace BuildSafe
{
	// Token: 0x02000622 RID: 1570
	public static class EditorGUIUtility
	{
		// Token: 0x06002511 RID: 9489 RVA: 0x00003051 File Offset: 0x00001251
		[Conditional("UNITY_EDITOR")]
		public static void PingObject(Object obj)
		{
		}
	}
}
