﻿using System;
using UnityEngine;

// Token: 0x0200040D RID: 1037
public class GorillaEnemySpawner : MonoBehaviour
{
}
