﻿using System;
using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005C1 RID: 1473
	[BurstCompile]
	public struct SolveRopeJob : IJob
	{
		// Token: 0x0600226E RID: 8814 RVA: 0x000A77B4 File Offset: 0x000A59B4
		public void Execute()
		{
			this.Simulate();
			for (int i = 0; i < 20; i++)
			{
				this.ApplyConstraint();
			}
		}

		// Token: 0x0600226F RID: 8815 RVA: 0x000A77DC File Offset: 0x000A59DC
		private void Simulate()
		{
			for (int i = 0; i < this.nodes.Length; i++)
			{
				BurstRopeNode burstRopeNode = this.nodes[i];
				Vector3 b = burstRopeNode.curPos - burstRopeNode.lastPos;
				burstRopeNode.lastPos = burstRopeNode.curPos;
				Vector3 vector = burstRopeNode.curPos + b;
				vector += this.gravity * this.fixedDeltaTime;
				burstRopeNode.curPos = vector;
				this.nodes[i] = burstRopeNode;
			}
		}

		// Token: 0x06002270 RID: 8816 RVA: 0x000A7868 File Offset: 0x000A5A68
		private void ApplyConstraint()
		{
			BurstRopeNode value = this.nodes[0];
			value.curPos = this.rootPos;
			this.nodes[0] = value;
			for (int i = 0; i < this.nodes.Length - 1; i++)
			{
				BurstRopeNode burstRopeNode = this.nodes[i];
				BurstRopeNode burstRopeNode2 = this.nodes[i + 1];
				float magnitude = (burstRopeNode.curPos - burstRopeNode2.curPos).magnitude;
				float d = Mathf.Abs(magnitude - this.nodeDistance);
				Vector3 a = Vector3.zero;
				if (magnitude > this.nodeDistance)
				{
					a = (burstRopeNode.curPos - burstRopeNode2.curPos).normalized;
				}
				else if (magnitude < this.nodeDistance)
				{
					a = (burstRopeNode2.curPos - burstRopeNode.curPos).normalized;
				}
				Vector3 a2 = a * d;
				burstRopeNode.curPos -= a2 * 0.5f;
				burstRopeNode2.curPos += a2 * 0.5f;
				this.nodes[i] = burstRopeNode;
				this.nodes[i + 1] = burstRopeNode2;
			}
		}

		// Token: 0x040024CC RID: 9420
		[ReadOnly]
		public float fixedDeltaTime;

		// Token: 0x040024CD RID: 9421
		[WriteOnly]
		public NativeArray<BurstRopeNode> nodes;

		// Token: 0x040024CE RID: 9422
		[ReadOnly]
		public Vector3 gravity;

		// Token: 0x040024CF RID: 9423
		[ReadOnly]
		public Vector3 rootPos;

		// Token: 0x040024D0 RID: 9424
		[ReadOnly]
		public float nodeDistance;
	}
}
