﻿using System;
using UnityEngine;

// Token: 0x02000374 RID: 884
public class GorillaHasUITransformFollow : MonoBehaviour
{
	// Token: 0x06001438 RID: 5176 RVA: 0x00069A74 File Offset: 0x00067C74
	private void Awake()
	{
		GorillaUITransformFollow[] array = this.transformFollowers;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].gameObject.SetActive(base.gameObject.activeSelf);
		}
	}

	// Token: 0x06001439 RID: 5177 RVA: 0x00069AB0 File Offset: 0x00067CB0
	private void OnDestroy()
	{
		GorillaUITransformFollow[] array = this.transformFollowers;
		for (int i = 0; i < array.Length; i++)
		{
			Object.Destroy(array[i].gameObject);
		}
	}

	// Token: 0x0600143A RID: 5178 RVA: 0x00069AE0 File Offset: 0x00067CE0
	private void OnEnable()
	{
		GorillaUITransformFollow[] array = this.transformFollowers;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].gameObject.SetActive(true);
		}
	}

	// Token: 0x0600143B RID: 5179 RVA: 0x00069B10 File Offset: 0x00067D10
	private void OnDisable()
	{
		GorillaUITransformFollow[] array = this.transformFollowers;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].gameObject.SetActive(false);
		}
	}

	// Token: 0x04001702 RID: 5890
	public GorillaUITransformFollow[] transformFollowers;
}
