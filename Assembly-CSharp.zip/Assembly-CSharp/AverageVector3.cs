﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020004A9 RID: 1193
public class AverageVector3
{
	// Token: 0x06001B4E RID: 6990 RVA: 0x0008B1E1 File Offset: 0x000893E1
	public AverageVector3(float averagingWindow = 0.1f)
	{
		this.timeWindow = averagingWindow;
	}

	// Token: 0x06001B4F RID: 6991 RVA: 0x0008B208 File Offset: 0x00089408
	public void AddSample(Vector3 sample, float time)
	{
		this.samples.Add(new AverageVector3.Sample
		{
			timeStamp = time,
			value = sample
		});
		this.RefreshSamples();
	}

	// Token: 0x06001B50 RID: 6992 RVA: 0x0008B240 File Offset: 0x00089440
	public Vector3 GetAverage()
	{
		this.RefreshSamples();
		Vector3 a = Vector3.zero;
		for (int i = 0; i < this.samples.Count; i++)
		{
			a += this.samples[i].value;
		}
		return a / (float)this.samples.Count;
	}

	// Token: 0x06001B51 RID: 6993 RVA: 0x0008B29B File Offset: 0x0008949B
	public void Clear()
	{
		this.samples.Clear();
	}

	// Token: 0x06001B52 RID: 6994 RVA: 0x0008B2A8 File Offset: 0x000894A8
	private void RefreshSamples()
	{
		float num = Time.time - this.timeWindow;
		for (int i = this.samples.Count - 1; i >= 0; i--)
		{
			if (this.samples[i].timeStamp < num)
			{
				this.samples.RemoveAt(i);
			}
		}
	}

	// Token: 0x04001F3D RID: 7997
	private List<AverageVector3.Sample> samples = new List<AverageVector3.Sample>();

	// Token: 0x04001F3E RID: 7998
	private float timeWindow = 0.1f;

	// Token: 0x020004AA RID: 1194
	public struct Sample
	{
		// Token: 0x04001F3F RID: 7999
		public float timeStamp;

		// Token: 0x04001F40 RID: 8000
		public Vector3 value;
	}
}
