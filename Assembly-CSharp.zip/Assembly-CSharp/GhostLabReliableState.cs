﻿using System;
using Photon.Pun;
using Photon.Realtime;

// Token: 0x0200003F RID: 63
public class GhostLabReliableState : MonoBehaviourPunCallbacks, IInRoomCallbacks, IPunObservable, IOnPhotonViewOwnerChange, IPhotonViewCallback
{
	// Token: 0x0600012C RID: 300 RVA: 0x0000A1A9 File Offset: 0x000083A9
	private void Awake()
	{
		this.singleDoorOpen = new bool[this.singleDoorCount];
	}

	// Token: 0x0600012D RID: 301 RVA: 0x0000A1BC File Offset: 0x000083BC
	public void OnOwnerChange(Player newOwner, Player previousOwner)
	{
		Player localPlayer = PhotonNetwork.LocalPlayer;
	}

	// Token: 0x0600012E RID: 302 RVA: 0x0000A1C8 File Offset: 0x000083C8
	public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
		if (!base.photonView.IsMine && info.Sender != PhotonNetwork.MasterClient)
		{
			return;
		}
		if (stream.IsWriting)
		{
			stream.SendNext(this.doorState);
			for (int i = 0; i < this.singleDoorOpen.Length; i++)
			{
				stream.SendNext(this.singleDoorOpen[i]);
			}
			return;
		}
		this.doorState = (GhostLab.EntranceDoorsState)stream.ReceiveNext();
		for (int j = 0; j < this.singleDoorOpen.Length; j++)
		{
			this.singleDoorOpen[j] = (bool)stream.ReceiveNext();
		}
	}

	// Token: 0x0600012F RID: 303 RVA: 0x0000A268 File Offset: 0x00008468
	public void UpdateEntranceDoorsState(GhostLab.EntranceDoorsState newState)
	{
		if (!NetworkSystem.Instance.InRoom || NetworkSystem.Instance.IsMasterClient)
		{
			this.doorState = newState;
			return;
		}
		if (NetworkSystem.Instance.InRoom && !NetworkSystem.Instance.IsMasterClient)
		{
			base.photonView.RPC("RemoteEntranceDoorState", RpcTarget.MasterClient, new object[]
			{
				newState
			});
		}
	}

	// Token: 0x06000130 RID: 304 RVA: 0x0000A2D0 File Offset: 0x000084D0
	public void UpdateSingleDoorState(int singleDoorIndex)
	{
		if (!NetworkSystem.Instance.InRoom || NetworkSystem.Instance.IsMasterClient)
		{
			this.singleDoorOpen[singleDoorIndex] = !this.singleDoorOpen[singleDoorIndex];
			return;
		}
		if (NetworkSystem.Instance.InRoom && !NetworkSystem.Instance.IsMasterClient)
		{
			base.photonView.RPC("RemoteSingleDoorState", RpcTarget.MasterClient, new object[]
			{
				singleDoorIndex
			});
		}
	}

	// Token: 0x06000131 RID: 305 RVA: 0x0000A341 File Offset: 0x00008541
	[PunRPC]
	public void RemoteEntranceDoorState(GhostLab.EntranceDoorsState newState, PhotonMessageInfo info)
	{
		GorillaNot.IncrementRPCCall(info, "RemoteEntranceDoorState");
		if (!base.photonView.IsMine)
		{
			return;
		}
		this.doorState = newState;
	}

	// Token: 0x06000132 RID: 306 RVA: 0x0000A363 File Offset: 0x00008563
	[PunRPC]
	public void RemoteSingleDoorState(int doorIndex, PhotonMessageInfo info)
	{
		GorillaNot.IncrementRPCCall(info, "RemoteSingleDoorState");
		if (!base.photonView.IsMine)
		{
			return;
		}
		if (doorIndex >= this.singleDoorCount)
		{
			return;
		}
		this.singleDoorOpen[doorIndex] = !this.singleDoorOpen[doorIndex];
	}

	// Token: 0x040001A1 RID: 417
	public GhostLab.EntranceDoorsState doorState;

	// Token: 0x040001A2 RID: 418
	public int singleDoorCount;

	// Token: 0x040001A3 RID: 419
	public bool[] singleDoorOpen;
}
