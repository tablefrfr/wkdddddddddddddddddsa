﻿using System;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005C2 RID: 1474
	public class GorillaRopeSegment : MonoBehaviour
	{
		// Token: 0x040024D1 RID: 9425
		public GorillaRopeSwing swing;

		// Token: 0x040024D2 RID: 9426
		public int boneIndex;
	}
}
