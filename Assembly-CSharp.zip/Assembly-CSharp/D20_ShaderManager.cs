﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000073 RID: 115
public class D20_ShaderManager : MonoBehaviour
{
	// Token: 0x06000281 RID: 641 RVA: 0x00011258 File Offset: 0x0000F458
	private void Start()
	{
		this.rb = base.GetComponent<Rigidbody>();
		this.lastPosition = base.transform.position;
		Renderer component = base.GetComponent<Renderer>();
		this.material = component.material;
		this.material.SetVector("_Velocity", this.velocity);
		base.StartCoroutine(this.UpdateVelocityCoroutine());
	}

	// Token: 0x06000282 RID: 642 RVA: 0x000112BD File Offset: 0x0000F4BD
	private IEnumerator UpdateVelocityCoroutine()
	{
		for (;;)
		{
			Vector3 position = base.transform.position;
			this.velocity = (position - this.lastPosition) / this.updateInterval;
			this.lastPosition = position;
			this.material.SetVector("_Velocity", this.velocity);
			yield return new WaitForSeconds(this.updateInterval);
		}
		yield break;
	}

	// Token: 0x04000370 RID: 880
	private Rigidbody rb;

	// Token: 0x04000371 RID: 881
	private Vector3 lastPosition;

	// Token: 0x04000372 RID: 882
	public float updateInterval = 0.1f;

	// Token: 0x04000373 RID: 883
	public Vector3 velocity;

	// Token: 0x04000374 RID: 884
	private Material material;
}
