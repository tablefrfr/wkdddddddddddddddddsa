﻿using System;
using UnityEngine;

// Token: 0x02000316 RID: 790
public class BlinkingLightManager : MonoBehaviour
{
}
