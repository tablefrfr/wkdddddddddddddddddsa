﻿using System;

// Token: 0x02000280 RID: 640
[Serializable]
internal struct BundleData
{
	// Token: 0x04001004 RID: 4100
	public string skuName;

	// Token: 0x04001005 RID: 4101
	public string playFabItemName;

	// Token: 0x04001006 RID: 4102
	public int shinyRocks;

	// Token: 0x04001007 RID: 4103
	public int majorVersion;

	// Token: 0x04001008 RID: 4104
	public int minorVersion;

	// Token: 0x04001009 RID: 4105
	public int minorVersion2;

	// Token: 0x0400100A RID: 4106
	public bool isActive;
}
