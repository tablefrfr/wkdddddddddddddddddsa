﻿using System;
using UnityEngine;

// Token: 0x0200035C RID: 860
public class GorillaBallWall : MonoBehaviour
{
	// Token: 0x06001385 RID: 4997 RVA: 0x00067022 File Offset: 0x00065222
	private void Awake()
	{
		if (GorillaBallWall.instance == null)
		{
			GorillaBallWall.instance = this;
			return;
		}
		if (GorillaBallWall.instance != this)
		{
			Object.Destroy(base.gameObject);
		}
	}

	// Token: 0x06001386 RID: 4998 RVA: 0x00003051 File Offset: 0x00001251
	private void Update()
	{
	}

	// Token: 0x0400165A RID: 5722
	[OnEnterPlay_SetNull]
	public static volatile GorillaBallWall instance;
}
