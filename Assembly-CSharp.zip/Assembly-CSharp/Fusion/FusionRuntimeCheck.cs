﻿using System;
using UnityEngine;

namespace Fusion
{
	// Token: 0x02000633 RID: 1587
	internal static class FusionRuntimeCheck
	{
		// Token: 0x0600254E RID: 9550 RVA: 0x000B713E File Offset: 0x000B533E
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
		private static void RuntimeCheck()
		{
			RuntimeUnityFlagsSetup.Check_ENABLE_MONO();
			RuntimeUnityFlagsSetup.Check_NET_STANDARD_2_0();
			RuntimeUnityFlagsSetup.Check_UNITY_2019_4_OR_NEWER();
		}
	}
}
