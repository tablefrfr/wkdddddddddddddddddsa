﻿using System;
using GorillaLocomotion.Climbing;
using Unity.Mathematics;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005C6 RID: 1478
	public class GorillaZipline : MonoBehaviour
	{
		// Token: 0x1700040C RID: 1036
		// (get) Token: 0x06002298 RID: 8856 RVA: 0x000A8502 File Offset: 0x000A6702
		// (set) Token: 0x06002299 RID: 8857 RVA: 0x000A850A File Offset: 0x000A670A
		public float currentSpeed { get; private set; }

		// Token: 0x0600229A RID: 8858 RVA: 0x000A8514 File Offset: 0x000A6714
		private void FindTFromDistance(ref float t, float distance, int steps = 1000)
		{
			float num = distance / (float)steps;
			Vector3 b = this.spline.GetPointLocal(t);
			float num2 = 0f;
			for (int i = 0; i < 1000; i++)
			{
				t += num;
				if (t >= 1f || t <= 0f)
				{
					break;
				}
				Vector3 pointLocal = this.spline.GetPointLocal(t);
				num2 += Vector3.Distance(pointLocal, b);
				if (num2 >= Mathf.Abs(distance))
				{
					break;
				}
				b = pointLocal;
			}
		}

		// Token: 0x0600229B RID: 8859 RVA: 0x000A8588 File Offset: 0x000A6788
		private float FindSlideHelperSpot(Vector3 grabPoint)
		{
			int i = 0;
			int num = 200;
			float num2 = 0.001f;
			float num3 = 1f / (float)num;
			float3 y = base.transform.InverseTransformPoint(grabPoint);
			float result = 0f;
			float num4 = float.PositiveInfinity;
			while (i < num)
			{
				float num5 = math.distancesq(this.spline.GetPointLocal(num2), y);
				if (num5 < num4)
				{
					num4 = num5;
					result = num2;
				}
				num2 += num3;
				i++;
			}
			return result;
		}

		// Token: 0x0600229C RID: 8860 RVA: 0x000A8604 File Offset: 0x000A6804
		private void Start()
		{
			this.spline = base.GetComponent<BezierSpline>();
			GorillaClimbable gorillaClimbable = this.slideHelper;
			gorillaClimbable.onBeforeClimb = (Action<GorillaHandClimber, GorillaClimbableRef>)Delegate.Combine(gorillaClimbable.onBeforeClimb, new Action<GorillaHandClimber, GorillaClimbableRef>(this.OnBeforeClimb));
		}

		// Token: 0x0600229D RID: 8861 RVA: 0x000A8639 File Offset: 0x000A6839
		private void OnDestroy()
		{
			GorillaClimbable gorillaClimbable = this.slideHelper;
			gorillaClimbable.onBeforeClimb = (Action<GorillaHandClimber, GorillaClimbableRef>)Delegate.Remove(gorillaClimbable.onBeforeClimb, new Action<GorillaHandClimber, GorillaClimbableRef>(this.OnBeforeClimb));
		}

		// Token: 0x0600229E RID: 8862 RVA: 0x000A8662 File Offset: 0x000A6862
		public Vector3 GetCurrentDirection()
		{
			return this.spline.GetDirection(this.currentT);
		}

		// Token: 0x0600229F RID: 8863 RVA: 0x000A8678 File Offset: 0x000A6878
		private void OnBeforeClimb(GorillaHandClimber hand, GorillaClimbableRef climbRef)
		{
			bool flag = this.currentClimber == null;
			this.currentClimber = hand;
			if (climbRef)
			{
				this.climbOffsetHelper.SetParent(climbRef.transform);
				this.climbOffsetHelper.position = hand.transform.position;
				this.climbOffsetHelper.localPosition = new Vector3(0f, 0f, this.climbOffsetHelper.localPosition.z);
			}
			this.currentT = this.FindSlideHelperSpot(this.climbOffsetHelper.position);
			this.slideHelper.transform.localPosition = this.spline.GetPointLocal(this.currentT);
			if (flag)
			{
				Vector3 currentVelocity = Player.Instance.currentVelocity;
				float num = Vector3.Dot(currentVelocity.normalized, this.spline.GetDirection(this.currentT));
				this.currentSpeed = currentVelocity.magnitude * num * this.currentInheritVelocityMulti;
			}
		}

		// Token: 0x060022A0 RID: 8864 RVA: 0x000A876C File Offset: 0x000A696C
		private void Update()
		{
			if (this.currentClimber)
			{
				Vector3 direction = this.spline.GetDirection(this.currentT);
				float num = Physics.gravity.y * direction.y * this.settings.gravityMulti;
				this.currentSpeed = Mathf.MoveTowards(this.currentSpeed, this.settings.maxSpeed, num * Time.deltaTime);
				float num2 = MathUtils.Linear(this.currentSpeed, 0f, this.settings.maxFrictionSpeed, this.settings.friction, this.settings.maxFriction);
				this.currentSpeed = Mathf.MoveTowards(this.currentSpeed, 0f, num2 * Time.deltaTime);
				this.currentSpeed = Mathf.Min(this.currentSpeed, this.settings.maxSpeed);
				this.currentSpeed = Mathf.Max(this.currentSpeed, -this.settings.maxSpeed);
				float value = Mathf.Abs(this.currentSpeed);
				this.FindTFromDistance(ref this.currentT, this.currentSpeed * Time.deltaTime, 1000);
				this.slideHelper.transform.localPosition = this.spline.GetPointLocal(this.currentT);
				if (!this.audioSlide.gameObject.activeSelf)
				{
					this.audioSlide.gameObject.SetActive(true);
				}
				this.audioSlide.volume = MathUtils.Linear(value, 0f, this.settings.maxSpeed, this.settings.minSlideVolume, this.settings.maxSlideVolume);
				this.audioSlide.pitch = MathUtils.Linear(value, 0f, this.settings.maxSpeed, this.settings.minSlidePitch, this.settings.maxSlidePitch);
				if (!this.audioSlide.isPlaying)
				{
					this.audioSlide.Play();
				}
				float num3 = MathUtils.Linear(value, 0f, this.settings.maxSpeed, -0.1f, 0.75f);
				if (num3 > 0f)
				{
					GorillaTagger.Instance.DoVibration(this.currentClimber.xrNode, num3, Time.deltaTime);
				}
				if (!this.spline.Loop)
				{
					if (this.currentT >= 1f || this.currentT <= 0f)
					{
						this.currentClimber.ForceStopClimbing(false, true);
					}
				}
				else if (this.currentT >= 1f)
				{
					this.currentT = 0f;
				}
				else if (this.currentT <= 0f)
				{
					this.currentT = 1f;
				}
				if (!this.slideHelper.isBeingClimbed)
				{
					this.Stop();
				}
			}
			if (this.currentInheritVelocityMulti < 1f)
			{
				this.currentInheritVelocityMulti += Time.deltaTime * 0.2f;
				this.currentInheritVelocityMulti = Mathf.Min(this.currentInheritVelocityMulti, 1f);
			}
		}

		// Token: 0x060022A1 RID: 8865 RVA: 0x000A8A5A File Offset: 0x000A6C5A
		private void Stop()
		{
			this.currentClimber = null;
			this.audioSlide.Stop();
			this.audioSlide.gameObject.SetActive(false);
			this.currentInheritVelocityMulti = 0.55f;
			this.currentSpeed = 0f;
		}

		// Token: 0x040024F3 RID: 9459
		[SerializeField]
		private Transform segmentsRoot;

		// Token: 0x040024F4 RID: 9460
		[SerializeField]
		private GameObject segmentPrefab;

		// Token: 0x040024F5 RID: 9461
		[SerializeField]
		private GorillaClimbable slideHelper;

		// Token: 0x040024F6 RID: 9462
		[SerializeField]
		private AudioSource audioSlide;

		// Token: 0x040024F7 RID: 9463
		private BezierSpline spline;

		// Token: 0x040024F8 RID: 9464
		[SerializeField]
		private Transform climbOffsetHelper;

		// Token: 0x040024F9 RID: 9465
		[SerializeField]
		private GorillaZiplineSettings settings;

		// Token: 0x040024FB RID: 9467
		[SerializeField]
		private float ziplineDistance = 15f;

		// Token: 0x040024FC RID: 9468
		[SerializeField]
		private float segmentDistance = 0.9f;

		// Token: 0x040024FD RID: 9469
		private GorillaHandClimber currentClimber;

		// Token: 0x040024FE RID: 9470
		private float currentT;

		// Token: 0x040024FF RID: 9471
		private const float inheritVelocityRechargeRate = 0.2f;

		// Token: 0x04002500 RID: 9472
		private const float inheritVelocityValueOnRelease = 0.55f;

		// Token: 0x04002501 RID: 9473
		private float currentInheritVelocityMulti = 1f;
	}
}
