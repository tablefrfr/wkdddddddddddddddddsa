﻿using System;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x02000314 RID: 788
public class AutomaticAdjustIPD : MonoBehaviour
{
	// Token: 0x060011C7 RID: 4551 RVA: 0x0005CD90 File Offset: 0x0005AF90
	private void Update()
	{
		if (!this.headset.isValid)
		{
			this.headset = InputDevices.GetDeviceAtXRNode(XRNode.Head);
		}
		if (this.headset.isValid && this.headset.TryGetFeatureValue(CommonUsages.leftEyePosition, out this.leftEyePosition) && this.headset.TryGetFeatureValue(CommonUsages.rightEyePosition, out this.rightEyePosition))
		{
			this.currentIPD = (this.rightEyePosition - this.leftEyePosition).magnitude;
			if (Mathf.Abs(this.lastIPD - this.currentIPD) < 0.01f)
			{
				return;
			}
			this.lastIPD = this.currentIPD;
			for (int i = 0; i < this.adjustXScaleObjects.Length; i++)
			{
				Transform transform = this.adjustXScaleObjects[i];
				if (!transform)
				{
					return;
				}
				transform.localScale = new Vector3(Mathf.LerpUnclamped(1f, 1.12f, (this.currentIPD - 0.058f) / 0.0050000027f), 1f, 1f);
			}
		}
	}

	// Token: 0x04001447 RID: 5191
	public InputDevice headset;

	// Token: 0x04001448 RID: 5192
	public float currentIPD;

	// Token: 0x04001449 RID: 5193
	public Vector3 leftEyePosition;

	// Token: 0x0400144A RID: 5194
	public Vector3 rightEyePosition;

	// Token: 0x0400144B RID: 5195
	public bool testOverride;

	// Token: 0x0400144C RID: 5196
	public Transform[] adjustXScaleObjects;

	// Token: 0x0400144D RID: 5197
	public float sizeAt58mm = 1f;

	// Token: 0x0400144E RID: 5198
	public float sizeAt63mm = 1.12f;

	// Token: 0x0400144F RID: 5199
	public float lastIPD;
}
