﻿using System;
using System.Collections.Generic;
using GorillaTagScripts;
using UnityEngine;

// Token: 0x0200032E RID: 814
public class BuilderShelf : MonoBehaviour
{
	// Token: 0x06001245 RID: 4677 RVA: 0x000616E0 File Offset: 0x0005F8E0
	public void BuildItems(BuilderTable table)
	{
		int num = 0;
		this.count = 0;
		for (int i = 0; i < this.buildPieceSpawns.Count; i++)
		{
			this.count += this.buildPieceSpawns[i].count;
		}
		for (int j = 0; j < this.buildPieceSpawns.Count; j++)
		{
			BuilderShelf.BuildPieceSpawn buildPieceSpawn = this.buildPieceSpawns[j];
			if (buildPieceSpawn != null && buildPieceSpawn.count != 0)
			{
				int staticHash = buildPieceSpawn.buildPiecePrefab.name.GetStaticHash();
				int materialType = string.IsNullOrEmpty(buildPieceSpawn.materialID) ? -1 : buildPieceSpawn.materialID.GetHashCode();
				int num2 = 0;
				while (num2 < buildPieceSpawn.count && num < this.count)
				{
					Vector3 position;
					Quaternion rotation;
					this.GetSpawnLocation(num, buildPieceSpawn, out position, out rotation);
					int pieceId = table.CreatePieceId();
					table.CreatePiece(staticHash, pieceId, position, rotation, materialType);
					num++;
					num2++;
				}
			}
		}
	}

	// Token: 0x06001246 RID: 4678 RVA: 0x000617DC File Offset: 0x0005F9DC
	public void GetSpawnLocation(int slot, BuilderShelf.BuildPieceSpawn spawn, out Vector3 spawnPosition, out Quaternion spawnRotation)
	{
		if (this.center == null)
		{
			this.center = base.transform;
		}
		spawnRotation = this.center.rotation * Quaternion.Euler(spawn.rotationOffset);
		float d = (float)slot * this.separation - (float)(this.count - 1) * this.separation / 2f;
		spawnPosition = this.center.position + this.center.rotation * (spawn.localAxis * d + spawn.positionOffset);
	}

	// Token: 0x04001512 RID: 5394
	private int count;

	// Token: 0x04001513 RID: 5395
	public float separation;

	// Token: 0x04001514 RID: 5396
	public Transform center;

	// Token: 0x04001515 RID: 5397
	public Material overrideMaterial;

	// Token: 0x04001516 RID: 5398
	public List<BuilderShelf.BuildPieceSpawn> buildPieceSpawns;

	// Token: 0x0200032F RID: 815
	[Serializable]
	public class BuildPieceSpawn
	{
		// Token: 0x04001517 RID: 5399
		public GameObject buildPiecePrefab;

		// Token: 0x04001518 RID: 5400
		public string materialID;

		// Token: 0x04001519 RID: 5401
		public int count = 1;

		// Token: 0x0400151A RID: 5402
		public Vector3 localAxis = Vector3.right;

		// Token: 0x0400151B RID: 5403
		public Vector3 positionOffset;

		// Token: 0x0400151C RID: 5404
		public Vector3 rotationOffset;

		// Token: 0x0400151D RID: 5405
		[Tooltip("Optional Editor Visual")]
		public Mesh previewMesh;
	}
}
