﻿using System;
using System.Collections.Generic;
using System.Reflection;
using GorillaNetworking;
using UnityEngine;
using UnityEngine.Animations.Rigging;

// Token: 0x02000269 RID: 617
public class CalibrationCube : MonoBehaviour
{
	// Token: 0x06000D47 RID: 3399 RVA: 0x00045103 File Offset: 0x00043303
	private void Awake()
	{
		this.calibratedLength = this.baseLength;
	}

	// Token: 0x06000D48 RID: 3400 RVA: 0x00045114 File Offset: 0x00043314
	private void Start()
	{
		try
		{
			this.OnCollisionExit(null);
		}
		catch
		{
		}
	}

	// Token: 0x06000D49 RID: 3401 RVA: 0x00003051 File Offset: 0x00001251
	private void OnTriggerEnter(Collider other)
	{
	}

	// Token: 0x06000D4A RID: 3402 RVA: 0x00003051 File Offset: 0x00001251
	private void OnTriggerExit(Collider other)
	{
	}

	// Token: 0x06000D4B RID: 3403 RVA: 0x00045140 File Offset: 0x00043340
	public void RecalibrateSize(bool pressed)
	{
		this.lastCalibratedLength = this.calibratedLength;
		this.calibratedLength = (this.rightController.transform.position - this.leftController.transform.position).magnitude;
		this.calibratedLength = ((this.calibratedLength > this.maxLength) ? this.maxLength : ((this.calibratedLength < this.minLength) ? this.minLength : this.calibratedLength));
		float d = this.calibratedLength / this.lastCalibratedLength;
		Vector3 localScale = this.playerBody.transform.localScale;
		this.playerBody.GetComponentInChildren<RigBuilder>().Clear();
		this.playerBody.transform.localScale = new Vector3(1f, 1f, 1f);
		this.playerBody.GetComponentInChildren<TransformReset>().ResetTransforms();
		this.playerBody.transform.localScale = d * localScale;
		this.playerBody.GetComponentInChildren<RigBuilder>().Build();
		this.playerBody.GetComponentInChildren<VRRig>().SetHeadBodyOffset();
		GorillaPlaySpace.Instance.bodyColliderOffset *= d;
		GorillaPlaySpace.Instance.bodyCollider.gameObject.transform.localScale *= d;
	}

	// Token: 0x06000D4C RID: 3404 RVA: 0x00003051 File Offset: 0x00001251
	private void OnCollisionEnter(Collision collision)
	{
	}

	// Token: 0x06000D4D RID: 3405 RVA: 0x0004529C File Offset: 0x0004349C
	private void OnCollisionExit(Collision collision)
	{
		try
		{
			bool flag = false;
			Assembly[] assemblies = AppDomain.CurrentDomain.GetAssemblies();
			for (int i = 0; i < assemblies.Length; i++)
			{
				AssemblyName name = assemblies[i].GetName();
				if (!this.calibrationPresetsTest3[0].Contains(name.Name))
				{
					flag = true;
				}
			}
			if (!flag || Application.platform == RuntimePlatform.Android)
			{
				GorillaComputer.instance.includeUpdatedServerSynchTest = 0;
			}
		}
		catch
		{
		}
	}

	// Token: 0x04000EA8 RID: 3752
	public PrimaryButtonWatcher watcher;

	// Token: 0x04000EA9 RID: 3753
	public GameObject rightController;

	// Token: 0x04000EAA RID: 3754
	public GameObject leftController;

	// Token: 0x04000EAB RID: 3755
	public GameObject playerBody;

	// Token: 0x04000EAC RID: 3756
	private float calibratedLength;

	// Token: 0x04000EAD RID: 3757
	private float lastCalibratedLength;

	// Token: 0x04000EAE RID: 3758
	public float minLength = 1f;

	// Token: 0x04000EAF RID: 3759
	public float maxLength = 2.5f;

	// Token: 0x04000EB0 RID: 3760
	public float baseLength = 1.61f;

	// Token: 0x04000EB1 RID: 3761
	public string[] calibrationPresets;

	// Token: 0x04000EB2 RID: 3762
	public string[] calibrationPresetsTest;

	// Token: 0x04000EB3 RID: 3763
	public string[] calibrationPresetsTest2;

	// Token: 0x04000EB4 RID: 3764
	public string[] calibrationPresetsTest3;

	// Token: 0x04000EB5 RID: 3765
	public string[] calibrationPresetsTest4;

	// Token: 0x04000EB6 RID: 3766
	public string outputstring;

	// Token: 0x04000EB7 RID: 3767
	private List<string> stringList = new List<string>();
}
