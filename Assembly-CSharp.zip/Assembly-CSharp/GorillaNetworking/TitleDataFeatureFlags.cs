﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using PlayFab;
using UnityEngine;

namespace GorillaNetworking
{
	// Token: 0x020006D6 RID: 1750
	public class TitleDataFeatureFlags
	{
		// Token: 0x170004CB RID: 1227
		// (get) Token: 0x06002954 RID: 10580 RVA: 0x000CB61E File Offset: 0x000C981E
		// (set) Token: 0x06002955 RID: 10581 RVA: 0x000CB626 File Offset: 0x000C9826
		public bool ready { get; private set; }

		// Token: 0x06002956 RID: 10582 RVA: 0x000CB62F File Offset: 0x000C982F
		public void FetchFeatureFlags()
		{
			PlayFabTitleDataCache.Instance.GetTitleData(this.TitleDataKey, delegate(string json)
			{
				FeatureFlagListData featureFlagListData = JsonUtility.FromJson<FeatureFlagListData>(json);
				foreach (FeatureFlagData featureFlagData in featureFlagListData.flags)
				{
					if (featureFlagData.valueType == "percent")
					{
						this.flagValueByName.AddOrUpdate(featureFlagData.name, featureFlagData.value);
					}
				}
				Debug.Log(string.Format("GorillaServer: Fetched flags ({0})", featureFlagListData));
				this.ready = true;
			}, delegate(PlayFabError e)
			{
				Debug.LogError("Error fetching rollout feature flags: " + e.ErrorMessage);
				this.ready = false;
			});
		}

		// Token: 0x06002957 RID: 10583 RVA: 0x000CB65C File Offset: 0x000C985C
		public bool IsEnabledForUser(string flagName, string userId)
		{
			Debug.Log(string.Concat(new string[]
			{
				"GorillaServer: Checking flag ",
				flagName,
				" for ",
				userId,
				"\nFlag values:\n",
				JsonConvert.SerializeObject(this.flagValueByName),
				"\n\nDefaults:\n",
				JsonConvert.SerializeObject(this.defaults)
			}));
			int num;
			if (!this.ready || !this.flagValueByName.TryGetValue(flagName, out num))
			{
				Debug.Log("GorillaServer: Returning default");
				bool flag;
				return this.defaults.TryGetValue(flagName, out flag) && flag;
			}
			Debug.Log(string.Format("GorillaServer: Rollout % is {0}", num));
			if (num <= 0)
			{
				Debug.Log("GorillaServer: " + flagName + " is off (<=0%).");
				return false;
			}
			if (num >= 100)
			{
				Debug.Log("GorillaServer: " + flagName + " is on (>=100%).");
				return true;
			}
			int num2 = new Random(userId.GetHashCode()).Next(0, 100);
			Debug.Log(string.Format("GorillaServer: Partial rollout, seed = {0} flag value = {1}", num2, num2 <= num));
			return num2 <= num;
		}

		// Token: 0x04002C62 RID: 11362
		public string TitleDataKey = "DeployFeatureFlags";

		// Token: 0x04002C64 RID: 11364
		public Dictionary<string, bool> defaults = new Dictionary<string, bool>
		{
			{
				"2024-05-ReturnCurrentVersionV2",
				false
			},
			{
				"2024-05-ReturnMyOculusHashV2",
				false
			},
			{
				"2024-05-TryDistributeCurrencyV2",
				false
			},
			{
				"2024-05-AddOrRemoveDLCOwnershipV2",
				false
			},
			{
				"2024-05-BroadcastMyRoomV2",
				false
			},
			{
				"2024-06-CosmeticsAuthenticationV2",
				false
			}
		};

		// Token: 0x04002C65 RID: 11365
		private Dictionary<string, int> flagValueByName = new Dictionary<string, int>();
	}
}
