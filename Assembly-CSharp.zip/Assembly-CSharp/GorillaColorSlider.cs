﻿using System;
using UnityEngine;

// Token: 0x020003F6 RID: 1014
public class GorillaColorSlider : MonoBehaviour
{
	// Token: 0x06001798 RID: 6040 RVA: 0x0007921D File Offset: 0x0007741D
	private void Start()
	{
		if (!this.setRandomly)
		{
			this.startingLocation = base.transform.position;
		}
	}

	// Token: 0x06001799 RID: 6041 RVA: 0x00079238 File Offset: 0x00077438
	public void SetPosition(float speed)
	{
		float num = this.startingLocation.x - this.zRange / 2f;
		float num2 = this.startingLocation.x + this.zRange / 2f;
		float x = (speed - this.minValue) * (num2 - num) / (this.maxValue - this.minValue) + num;
		base.transform.position = new Vector3(x, this.startingLocation.y, this.startingLocation.z);
		this.valueImReporting = this.InterpolateValue(base.transform.position.x);
	}

	// Token: 0x0600179A RID: 6042 RVA: 0x000792D8 File Offset: 0x000774D8
	public float InterpolateValue(float value)
	{
		float num = this.startingLocation.x - this.zRange / 2f;
		float num2 = this.startingLocation.x + this.zRange / 2f;
		return (value - num) / (num2 - num) * (this.maxValue - this.minValue) + this.minValue;
	}

	// Token: 0x0600179B RID: 6043 RVA: 0x00079334 File Offset: 0x00077534
	public void OnSliderRelease()
	{
		if (this.zRange != 0f && (base.transform.position - this.startingLocation).magnitude > this.zRange / 2f)
		{
			if (base.transform.position.x > this.startingLocation.x)
			{
				base.transform.position = new Vector3(this.startingLocation.x + this.zRange / 2f, this.startingLocation.y, this.startingLocation.z);
			}
			else
			{
				base.transform.position = new Vector3(this.startingLocation.x - this.zRange / 2f, this.startingLocation.y, this.startingLocation.z);
			}
		}
		this.valueImReporting = this.InterpolateValue(base.transform.position.x);
	}

	// Token: 0x04001B06 RID: 6918
	public bool setRandomly;

	// Token: 0x04001B07 RID: 6919
	public float zRange;

	// Token: 0x04001B08 RID: 6920
	public float maxValue;

	// Token: 0x04001B09 RID: 6921
	public float minValue;

	// Token: 0x04001B0A RID: 6922
	public Vector3 startingLocation;

	// Token: 0x04001B0B RID: 6923
	public int valueIndex;

	// Token: 0x04001B0C RID: 6924
	public float valueImReporting;

	// Token: 0x04001B0D RID: 6925
	public GorillaTriggerBox gorilla;

	// Token: 0x04001B0E RID: 6926
	private float startingZ;
}
