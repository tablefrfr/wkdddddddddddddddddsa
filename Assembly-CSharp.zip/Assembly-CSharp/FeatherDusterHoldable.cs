﻿using System;
using UnityEngine;

// Token: 0x0200005F RID: 95
public class FeatherDusterHoldable : MonoBehaviour
{
	// Token: 0x060001E6 RID: 486 RVA: 0x0000E063 File Offset: 0x0000C263
	protected void Awake()
	{
		this.timeSinceLastSound = this.soundCooldown;
		this.emissionModule = this.particleFx.emission;
		this.initialRateOverTime = this.emissionModule.rateOverTimeMultiplier;
	}

	// Token: 0x060001E7 RID: 487 RVA: 0x0000E093 File Offset: 0x0000C293
	protected void OnEnable()
	{
		this.lastWorldPos = base.transform.position;
		this.emissionModule.rateOverTimeMultiplier = 0f;
	}

	// Token: 0x060001E8 RID: 488 RVA: 0x0000E0B8 File Offset: 0x0000C2B8
	protected void Update()
	{
		this.timeSinceLastSound += Time.deltaTime;
		Transform transform = base.transform;
		Vector3 position = transform.position;
		float num = (position - this.lastWorldPos).magnitude / Time.deltaTime;
		this.emissionModule.rateOverTimeMultiplier = 0f;
		if (num >= this.collideMinSpeed && Physics.OverlapSphereNonAlloc(position, this.overlapSphereRadius * transform.localScale.x, this.colliderResult, this.collisionLayer) > 0)
		{
			this.emissionModule.rateOverTimeMultiplier = this.initialRateOverTime;
			if (this.timeSinceLastSound >= this.soundCooldown)
			{
				this.soundBankPlayer.Play(null, null);
				this.timeSinceLastSound = 0f;
			}
		}
		this.lastWorldPos = position;
	}

	// Token: 0x04000298 RID: 664
	public LayerMask collisionLayer;

	// Token: 0x04000299 RID: 665
	public float overlapSphereRadius = 0.08f;

	// Token: 0x0400029A RID: 666
	[Tooltip("Collision is not tested until this speed requirement is met.")]
	private float collideMinSpeed = 1f;

	// Token: 0x0400029B RID: 667
	public ParticleSystem particleFx;

	// Token: 0x0400029C RID: 668
	public SoundBankPlayer soundBankPlayer;

	// Token: 0x0400029D RID: 669
	private float soundCooldown = 0.8f;

	// Token: 0x0400029E RID: 670
	private ParticleSystem.EmissionModule emissionModule;

	// Token: 0x0400029F RID: 671
	private float initialRateOverTime;

	// Token: 0x040002A0 RID: 672
	private float timeSinceLastSound;

	// Token: 0x040002A1 RID: 673
	private Vector3 lastWorldPos;

	// Token: 0x040002A2 RID: 674
	private Collider[] colliderResult = new Collider[1];
}
