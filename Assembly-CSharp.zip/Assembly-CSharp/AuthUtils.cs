﻿using System;
using System.Collections.Generic;
using Fusion.Photon.Realtime;
using Photon.Realtime;

// Token: 0x02000127 RID: 295
public static class AuthUtils
{
	// Token: 0x060005BF RID: 1471 RVA: 0x00020F44 File Offset: 0x0001F144
	public static Fusion.Photon.Realtime.AuthenticationValues ToAuthValues_F(this Dictionary<string, string> authDict)
	{
		if (authDict == null)
		{
			return null;
		}
		string userId;
		bool flag = authDict.TryGetValue("deviceId", out userId);
		Fusion.Photon.Realtime.AuthenticationValues authenticationValues = null;
		if (flag)
		{
			authenticationValues = new Fusion.Photon.Realtime.AuthenticationValues(userId);
		}
		else
		{
			authenticationValues = new Fusion.Photon.Realtime.AuthenticationValues();
		}
		authenticationValues.AuthType = Fusion.Photon.Realtime.CustomAuthenticationType.Custom;
		string value;
		if (authDict.TryGetValue("username", out value))
		{
			authenticationValues.AddAuthParameter("username", value);
		}
		string value2;
		if (authDict.TryGetValue("token", out value2))
		{
			authenticationValues.AddAuthParameter("token", value2);
		}
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		foreach (KeyValuePair<string, string> keyValuePair in authDict)
		{
			if (keyValuePair.Key != "username" && keyValuePair.Key != "token")
			{
				dictionary.Add(keyValuePair.Key, keyValuePair.Value);
			}
		}
		authenticationValues.SetAuthPostData(dictionary);
		return authenticationValues;
	}

	// Token: 0x060005C0 RID: 1472 RVA: 0x0002103C File Offset: 0x0001F23C
	public static Photon.Realtime.AuthenticationValues ToAuthValues_P(this Dictionary<string, string> authDict)
	{
		if (authDict == null)
		{
			return null;
		}
		string userId;
		bool flag = authDict.TryGetValue("deviceId", out userId);
		Photon.Realtime.AuthenticationValues authenticationValues = null;
		if (flag)
		{
			authenticationValues = new Photon.Realtime.AuthenticationValues(userId);
		}
		else
		{
			authenticationValues = new Photon.Realtime.AuthenticationValues();
		}
		authenticationValues.AuthType = Photon.Realtime.CustomAuthenticationType.Custom;
		string value;
		if (authDict.TryGetValue("username", out value))
		{
			authenticationValues.AddAuthParameter("username", value);
		}
		string value2;
		if (authDict.TryGetValue("token", out value2))
		{
			authenticationValues.AddAuthParameter("token", value2);
		}
		Dictionary<string, object> dictionary = new Dictionary<string, object>();
		foreach (KeyValuePair<string, string> keyValuePair in authDict)
		{
			if (keyValuePair.Key != "username" && keyValuePair.Key != "token")
			{
				dictionary.Add(keyValuePair.Key, keyValuePair.Value);
			}
		}
		authenticationValues.SetAuthPostData(dictionary);
		return authenticationValues;
	}
}
