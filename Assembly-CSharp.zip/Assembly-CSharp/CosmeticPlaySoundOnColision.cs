﻿using System;
using System.Collections;
using System.Collections.Generic;
using GorillaLocomotion;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x02000021 RID: 33
public class CosmeticPlaySoundOnColision : MonoBehaviour
{
	// Token: 0x06000066 RID: 102 RVA: 0x000048E0 File Offset: 0x00002AE0
	private void Awake()
	{
		this.transferrableObject = base.GetComponentInParent<TransferrableObject>();
		this.soundLookup = new Dictionary<int, int>();
		this.audioSource = base.GetComponent<AudioSource>();
		for (int i = 0; i < this.soundIdRemappings.Length; i++)
		{
			this.soundLookup.Add(this.soundIdRemappings[i].SoundIn, this.soundIdRemappings[i].SoundOut);
		}
	}

	// Token: 0x06000067 RID: 103 RVA: 0x00004948 File Offset: 0x00002B48
	private void OnTriggerEnter(Collider other)
	{
		GorillaSurfaceOverride gorillaSurfaceOverride;
		if (this.speed >= this.minSpeed && other.TryGetComponent<GorillaSurfaceOverride>(out gorillaSurfaceOverride))
		{
			int soundIndex;
			if (this.soundLookup.TryGetValue(gorillaSurfaceOverride.overrideIndex, out soundIndex))
			{
				this.playSound(soundIndex, this.invokeEventOnOverideSound);
				return;
			}
			this.playSound(this.defaultSound, this.invokeEventOnDefaultSound);
		}
	}

	// Token: 0x06000068 RID: 104 RVA: 0x000049A4 File Offset: 0x00002BA4
	private void playSound(int soundIndex, bool invokeEvent)
	{
		if (soundIndex > -1 && soundIndex < Player.Instance.materialData.Count)
		{
			if (this.audioSource.isPlaying)
			{
				this.audioSource.Stop();
				if (this.invokeEventsOnAllClients || this.transferrableObject.IsMyItem())
				{
					this.OnStopPlayback.Invoke();
				}
				if (this.crWaitForStopPlayback != null)
				{
					base.StopCoroutine(this.crWaitForStopPlayback);
					this.crWaitForStopPlayback = null;
				}
			}
			this.audioSource.clip = Player.Instance.materialData[soundIndex].audio;
			this.audioSource.Play();
			if (invokeEvent && (this.invokeEventsOnAllClients || this.transferrableObject.IsMyItem()))
			{
				this.OnStartPlayback.Invoke();
				this.crWaitForStopPlayback = base.StartCoroutine(this.waitForStopPlayback());
			}
		}
	}

	// Token: 0x06000069 RID: 105 RVA: 0x00004A80 File Offset: 0x00002C80
	private IEnumerator waitForStopPlayback()
	{
		while (this.audioSource.isPlaying)
		{
			yield return null;
		}
		if (this.invokeEventsOnAllClients || this.transferrableObject.IsMyItem())
		{
			this.OnStopPlayback.Invoke();
		}
		this.crWaitForStopPlayback = null;
		yield break;
	}

	// Token: 0x0600006A RID: 106 RVA: 0x00004A8F File Offset: 0x00002C8F
	private void FixedUpdate()
	{
		this.speed = Vector3.Distance(base.transform.position, this.previousFramePosition) * Time.fixedDeltaTime * 100f;
		this.previousFramePosition = base.transform.position;
	}

	// Token: 0x0400009A RID: 154
	[GorillaSoundLookup]
	[SerializeField]
	private int defaultSound = 1;

	// Token: 0x0400009B RID: 155
	[SerializeField]
	private SoundIdRemapping[] soundIdRemappings;

	// Token: 0x0400009C RID: 156
	[SerializeField]
	private UnityEvent OnStartPlayback;

	// Token: 0x0400009D RID: 157
	[SerializeField]
	private UnityEvent OnStopPlayback;

	// Token: 0x0400009E RID: 158
	[SerializeField]
	private float minSpeed = 0.1f;

	// Token: 0x0400009F RID: 159
	private TransferrableObject transferrableObject;

	// Token: 0x040000A0 RID: 160
	private Dictionary<int, int> soundLookup;

	// Token: 0x040000A1 RID: 161
	private AudioSource audioSource;

	// Token: 0x040000A2 RID: 162
	private Coroutine crWaitForStopPlayback;

	// Token: 0x040000A3 RID: 163
	private float speed;

	// Token: 0x040000A4 RID: 164
	private Vector3 previousFramePosition;

	// Token: 0x040000A5 RID: 165
	[SerializeField]
	private bool invokeEventsOnAllClients;

	// Token: 0x040000A6 RID: 166
	[SerializeField]
	private bool invokeEventOnOverideSound = true;

	// Token: 0x040000A7 RID: 167
	[SerializeField]
	private bool invokeEventOnDefaultSound;
}
