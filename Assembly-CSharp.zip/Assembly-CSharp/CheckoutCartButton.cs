﻿using System;
using GorillaNetworking;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200027C RID: 636
public class CheckoutCartButton : GorillaPressableButton
{
	// Token: 0x06000E1E RID: 3614 RVA: 0x0004A4AB File Offset: 0x000486AB
	public override void Start()
	{
		this.currentCosmeticItem = CosmeticsController.instance.nullItem;
	}

	// Token: 0x06000E1F RID: 3615 RVA: 0x0004A4C0 File Offset: 0x000486C0
	public override void UpdateColor()
	{
		if (this.currentCosmeticItem.itemName == "null")
		{
			this.button.material = this.unpressedMaterial;
			this.buttonText.text = this.noCosmeticText;
			return;
		}
		if (this.isOn)
		{
			this.button.material = this.pressedMaterial;
			this.buttonText.text = this.onText;
			return;
		}
		this.button.material = this.unpressedMaterial;
		this.buttonText.text = this.offText;
	}

	// Token: 0x06000E20 RID: 3616 RVA: 0x0004A554 File Offset: 0x00048754
	public override void ButtonActivationWithHand(bool isLeftHand)
	{
		base.ButtonActivation();
		CosmeticsController.instance.PressCheckoutCartButton(this, isLeftHand);
	}

	// Token: 0x04000FFB RID: 4091
	public CosmeticsController.CosmeticItem currentCosmeticItem;

	// Token: 0x04000FFC RID: 4092
	public Image currentImage;

	// Token: 0x04000FFD RID: 4093
	public MeshRenderer button;

	// Token: 0x04000FFE RID: 4094
	public Material blank;

	// Token: 0x04000FFF RID: 4095
	public string noCosmeticText;

	// Token: 0x04001000 RID: 4096
	public Text buttonText;
}
