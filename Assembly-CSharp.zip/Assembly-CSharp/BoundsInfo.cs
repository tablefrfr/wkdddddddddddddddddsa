﻿using System;
using MathGeoLib;
using UnityEngine;

// Token: 0x02000538 RID: 1336
[Serializable]
public struct BoundsInfo
{
	// Token: 0x17000369 RID: 873
	// (get) Token: 0x06001DEE RID: 7662 RVA: 0x00094AC3 File Offset: 0x00092CC3
	public Vector3 sizeComputed
	{
		get
		{
			return Vector3.Scale(this.size, this.scale) * this.inflate;
		}
	}

	// Token: 0x1700036A RID: 874
	// (get) Token: 0x06001DEF RID: 7663 RVA: 0x00094AE1 File Offset: 0x00092CE1
	public Vector3 sizeComputedAA
	{
		get
		{
			return Vector3.Scale(this.sizeAA, this.scaleAA) * this.inflateAA;
		}
	}

	// Token: 0x06001DF0 RID: 7664 RVA: 0x00094B00 File Offset: 0x00092D00
	public static BoundsInfo ComputeBounds(Vector3[] vertices)
	{
		if (vertices.Length == 0)
		{
			return default(BoundsInfo);
		}
		OrientedBoundingBox orientedBoundingBox = OrientedBoundingBox.BruteEnclosing(vertices);
		Vector4 column = orientedBoundingBox.Axis1;
		Vector4 column2 = orientedBoundingBox.Axis2;
		Vector4 column3 = orientedBoundingBox.Axis3;
		Vector4 column4 = new Vector4(0f, 0f, 0f, 1f);
		BoundsInfo result = default(BoundsInfo);
		result.center = orientedBoundingBox.Center;
		result.size = orientedBoundingBox.Extent * 2f;
		result.rotation = new Matrix4x4(column, column2, column3, column4).rotation;
		result.scale = Vector3.one;
		result.inflate = 1f;
		Bounds bounds = GeometryUtility.CalculateBounds(vertices, Matrix4x4.identity);
		result.centerAA = bounds.center;
		result.sizeAA = bounds.size;
		result.scaleAA = Vector3.one;
		result.inflateAA = 1f;
		return result;
	}

	// Token: 0x06001DF1 RID: 7665 RVA: 0x00094C04 File Offset: 0x00092E04
	public static BoxCollider CreateBoxCollider(BoundsInfo bounds)
	{
		int hashCode = bounds.center.QuantizedId128().GetHashCode();
		int hashCode2 = bounds.size.QuantizedId128().GetHashCode();
		int hashCode3 = bounds.rotation.QuantizedId128().GetHashCode();
		int num = StaticHash.Combine(hashCode, hashCode2, hashCode3);
		Transform transform = new GameObject(string.Format("BoxCollider_{0:X8}", num)).transform;
		transform.position = bounds.center;
		transform.rotation = bounds.rotation;
		BoxCollider boxCollider = transform.gameObject.AddComponent<BoxCollider>();
		boxCollider.size = bounds.sizeComputed;
		return boxCollider;
	}

	// Token: 0x06001DF2 RID: 7666 RVA: 0x00094CB0 File Offset: 0x00092EB0
	public static BoxCollider CreateBoxColliderAA(BoundsInfo bounds)
	{
		int hashCode = bounds.center.QuantizedId128().GetHashCode();
		int hashCode2 = bounds.size.QuantizedId128().GetHashCode();
		int num = StaticHash.Combine(hashCode, hashCode2);
		Transform transform = new GameObject(string.Format("BoxCollider_{0:X8}", num)).transform;
		transform.position = bounds.centerAA;
		BoxCollider boxCollider = transform.gameObject.AddComponent<BoxCollider>();
		boxCollider.size = bounds.sizeComputedAA;
		return boxCollider;
	}

	// Token: 0x04002148 RID: 8520
	public Vector3 center;

	// Token: 0x04002149 RID: 8521
	public Vector3 size;

	// Token: 0x0400214A RID: 8522
	public Quaternion rotation;

	// Token: 0x0400214B RID: 8523
	public Vector3 scale;

	// Token: 0x0400214C RID: 8524
	public float inflate;

	// Token: 0x0400214D RID: 8525
	[Space]
	public Vector3 centerAA;

	// Token: 0x0400214E RID: 8526
	public Vector3 sizeAA;

	// Token: 0x0400214F RID: 8527
	public Vector3 scaleAA;

	// Token: 0x04002150 RID: 8528
	public float inflateAA;
}
