﻿using System;
using UnityEngine;

namespace GorillaLocomotion.Swimming
{
	// Token: 0x020005BA RID: 1466
	public class WaterSplashOverride : MonoBehaviour
	{
		// Token: 0x0400249E RID: 9374
		public bool suppressWaterEffects;

		// Token: 0x0400249F RID: 9375
		public bool playBigSplash;

		// Token: 0x040024A0 RID: 9376
		public bool playDrippingEffect = true;

		// Token: 0x040024A1 RID: 9377
		public bool scaleByPlayersScale;

		// Token: 0x040024A2 RID: 9378
		public bool overrideBoundingRadius;

		// Token: 0x040024A3 RID: 9379
		public float boundingRadiusOverride = 1f;
	}
}
