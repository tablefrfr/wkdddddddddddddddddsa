﻿using System;
using Fusion.Internal;

namespace Fusion.CodeGen
{
	// Token: 0x02000845 RID: 2117
	[Serializable]
	internal class UnityValueSurrogate@ReaderWriter@Fusion_NetworkString : UnityValueSurrogate<NetworkString<_16>, ReaderWriter@Fusion_NetworkString>
	{
		// Token: 0x1700057A RID: 1402
		// (get) Token: 0x06003322 RID: 13090 RVA: 0x00100490 File Offset: 0x000FE690
		// (set) Token: 0x06003323 RID: 13091 RVA: 0x00100498 File Offset: 0x000FE698
		public override NetworkString<_16> DataProperty
		{
			get
			{
				return this.Data;
			}
			set
			{
				this.Data = value;
			}
		}

		// Token: 0x04003581 RID: 13697
		public NetworkString<_16> Data;
	}
}
