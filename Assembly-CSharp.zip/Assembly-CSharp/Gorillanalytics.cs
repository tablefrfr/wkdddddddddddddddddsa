﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using GorillaLocomotion;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using PlayFab;
using UnityEngine;

// Token: 0x02000388 RID: 904
public class Gorillanalytics : MonoBehaviour
{
	// Token: 0x0600149A RID: 5274 RVA: 0x0006C937 File Offset: 0x0006AB37
	private IEnumerator Start()
	{
		PlayFabTitleDataCache.Instance.GetTitleData("GorillanalyticsChance", delegate(string s)
		{
			double num;
			if (double.TryParse(s, out num))
			{
				this.oneOverChance = num;
			}
		}, delegate(PlayFabError e)
		{
		});
		for (;;)
		{
			yield return new WaitForSeconds(this.interval);
			if ((double)Random.Range(0f, 1f) < 1.0 / this.oneOverChance && PlayFabClientAPI.IsClientLoggedIn())
			{
				this.UploadGorillanalytics();
			}
		}
		yield break;
	}

	// Token: 0x0600149B RID: 5275 RVA: 0x0006C948 File Offset: 0x0006AB48
	private void UploadGorillanalytics()
	{
		try
		{
			string map;
			string mode;
			string queue;
			this.GetMapModeQueue(out map, out mode, out queue);
			Vector3 position = GorillaLocomotion.Player.Instance.headCollider.transform.position;
			Vector3 currentVelocity = GorillaLocomotion.Player.Instance.currentVelocity;
			this.uploadData.version = NetworkSystemConfig.AppVersion;
			this.uploadData.upload_chance = this.oneOverChance;
			this.uploadData.map = map;
			this.uploadData.mode = mode;
			this.uploadData.queue = queue;
			this.uploadData.player_count = (int)(PhotonNetwork.InRoom ? PhotonNetwork.CurrentRoom.PlayerCount : 0);
			this.uploadData.pos_x = position.x;
			this.uploadData.pos_y = position.y;
			this.uploadData.pos_z = position.z;
			this.uploadData.vel_x = currentVelocity.x;
			this.uploadData.vel_y = currentVelocity.y;
			this.uploadData.vel_z = currentVelocity.z;
			this.uploadData.cosmetics_owned = string.Join(";", from c in CosmeticsController.instance.unlockedCosmetics
			select c.itemName);
			this.uploadData.cosmetics_worn = string.Join(";", from c in CosmeticsController.instance.currentWornSet.items
			select c.itemName);
			GorillaServer.Instance.UploadGorillanalytics(this.uploadData);
		}
		catch (Exception message)
		{
			Debug.LogError(message);
		}
	}

	// Token: 0x0600149C RID: 5276 RVA: 0x0006CB18 File Offset: 0x0006AD18
	private void GetMapModeQueue(out string map, out string mode, out string queue)
	{
		if (!PhotonNetwork.InRoom)
		{
			map = "none";
			mode = "none";
			queue = "none";
			return;
		}
		object obj = null;
		Room currentRoom = PhotonNetwork.CurrentRoom;
		if (currentRoom != null)
		{
			currentRoom.CustomProperties.TryGetValue("gameMode", out obj);
		}
		string gameMode = ((obj != null) ? obj.ToString() : null) ?? "";
		map = (this.maps.FirstOrDefault((string s) => gameMode.Contains(s)) ?? "unknown");
		mode = (this.modes.FirstOrDefault((string s) => gameMode.Contains(s)) ?? "unknown");
		queue = (this.queues.FirstOrDefault((string s) => gameMode.Contains(s)) ?? "unknown");
	}

	// Token: 0x0400178B RID: 6027
	public float interval = 60f;

	// Token: 0x0400178C RID: 6028
	public double oneOverChance = 4320.0;

	// Token: 0x0400178D RID: 6029
	public PhotonNetworkController photonNetworkController;

	// Token: 0x0400178E RID: 6030
	public List<string> maps;

	// Token: 0x0400178F RID: 6031
	public List<string> modes;

	// Token: 0x04001790 RID: 6032
	public List<string> queues;

	// Token: 0x04001791 RID: 6033
	private readonly Gorillanalytics.UploadData uploadData = new Gorillanalytics.UploadData();

	// Token: 0x02000389 RID: 905
	private class UploadData
	{
		// Token: 0x04001792 RID: 6034
		public string version;

		// Token: 0x04001793 RID: 6035
		public double upload_chance;

		// Token: 0x04001794 RID: 6036
		public string map;

		// Token: 0x04001795 RID: 6037
		public string mode;

		// Token: 0x04001796 RID: 6038
		public string queue;

		// Token: 0x04001797 RID: 6039
		public int player_count;

		// Token: 0x04001798 RID: 6040
		public float pos_x;

		// Token: 0x04001799 RID: 6041
		public float pos_y;

		// Token: 0x0400179A RID: 6042
		public float pos_z;

		// Token: 0x0400179B RID: 6043
		public float vel_x;

		// Token: 0x0400179C RID: 6044
		public float vel_y;

		// Token: 0x0400179D RID: 6045
		public float vel_z;

		// Token: 0x0400179E RID: 6046
		public string cosmetics_owned;

		// Token: 0x0400179F RID: 6047
		public string cosmetics_worn;
	}
}
