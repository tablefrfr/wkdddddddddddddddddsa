﻿using System;

// Token: 0x02000477 RID: 1143
[Serializable]
public class CooldownType : CallLimitType<CallLimiterWithCooldown>
{
}
