﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000375 RID: 885
[Obsolete("This class is obsolete and will be removed in a future version. (MattO 2024-02-26) It doesn't appear to be used anywhere.")]
public class GorillaHatButton : MonoBehaviour
{
	// Token: 0x0600143D RID: 5181 RVA: 0x00069B40 File Offset: 0x00067D40
	public void Update()
	{
		if (this.testPress)
		{
			this.testPress = false;
			if (this.touchTime + this.debounceTime < Time.time)
			{
				this.touchTime = Time.time;
				this.isOn = !this.isOn;
				this.buttonParent.PressButton(this.isOn, this.buttonType, this.cosmeticName);
			}
		}
	}

	// Token: 0x0600143E RID: 5182 RVA: 0x00069BA8 File Offset: 0x00067DA8
	private void OnTriggerEnter(Collider collider)
	{
		if (this.touchTime + this.debounceTime < Time.time && collider.GetComponentInParent<GorillaTriggerColliderHandIndicator>() != null)
		{
			this.touchTime = Time.time;
			GorillaTriggerColliderHandIndicator component = collider.GetComponent<GorillaTriggerColliderHandIndicator>();
			this.isOn = !this.isOn;
			this.buttonParent.PressButton(this.isOn, this.buttonType, this.cosmeticName);
			if (component != null)
			{
				GorillaTagger.Instance.StartVibration(component.isLeftHand, GorillaTagger.Instance.tapHapticStrength / 2f, GorillaTagger.Instance.tapHapticDuration);
			}
		}
	}

	// Token: 0x0600143F RID: 5183 RVA: 0x00069C48 File Offset: 0x00067E48
	public void UpdateColor()
	{
		if (this.isOn)
		{
			base.GetComponent<MeshRenderer>().material = this.onMaterial;
			this.myText.text = this.onText;
			return;
		}
		base.GetComponent<MeshRenderer>().material = this.offMaterial;
		this.myText.text = this.offText;
	}

	// Token: 0x04001703 RID: 5891
	public GorillaHatButtonParent buttonParent;

	// Token: 0x04001704 RID: 5892
	public GorillaHatButton.HatButtonType buttonType;

	// Token: 0x04001705 RID: 5893
	public bool isOn;

	// Token: 0x04001706 RID: 5894
	public Material offMaterial;

	// Token: 0x04001707 RID: 5895
	public Material onMaterial;

	// Token: 0x04001708 RID: 5896
	public string offText;

	// Token: 0x04001709 RID: 5897
	public string onText;

	// Token: 0x0400170A RID: 5898
	public Text myText;

	// Token: 0x0400170B RID: 5899
	public float debounceTime = 0.25f;

	// Token: 0x0400170C RID: 5900
	public float touchTime;

	// Token: 0x0400170D RID: 5901
	public string cosmeticName;

	// Token: 0x0400170E RID: 5902
	public bool testPress;

	// Token: 0x02000376 RID: 886
	public enum HatButtonType
	{
		// Token: 0x04001710 RID: 5904
		Hat,
		// Token: 0x04001711 RID: 5905
		Face,
		// Token: 0x04001712 RID: 5906
		Badge
	}
}
