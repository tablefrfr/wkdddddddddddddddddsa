﻿using System;
using UnityEngine;

// Token: 0x02000467 RID: 1127
public class GliderWindVolume : MonoBehaviour
{
	// Token: 0x17000314 RID: 788
	// (get) Token: 0x06001A39 RID: 6713 RVA: 0x0008734B File Offset: 0x0008554B
	public Vector3 WindDirection
	{
		get
		{
			return base.transform.TransformDirection(this.localWindDirection);
		}
	}

	// Token: 0x06001A3A RID: 6714 RVA: 0x00087360 File Offset: 0x00085560
	public Vector3 GetAccelFromVelocity(Vector3 velocity)
	{
		Vector3 windDirection = this.WindDirection;
		float time = Mathf.Clamp(Vector3.Dot(velocity, windDirection), -this.maxSpeed, this.maxSpeed) / this.maxSpeed;
		float d = this.speedVsAccelCurve.Evaluate(time) * this.maxAccel;
		return windDirection * d;
	}

	// Token: 0x04001E4F RID: 7759
	[SerializeField]
	private float maxSpeed = 30f;

	// Token: 0x04001E50 RID: 7760
	[SerializeField]
	private float maxAccel = 15f;

	// Token: 0x04001E51 RID: 7761
	[SerializeField]
	private AnimationCurve speedVsAccelCurve = AnimationCurve.Linear(0f, 1f, 1f, 0f);

	// Token: 0x04001E52 RID: 7762
	[SerializeField]
	private Vector3 localWindDirection = Vector3.up;
}
