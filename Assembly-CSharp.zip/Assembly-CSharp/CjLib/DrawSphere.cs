﻿using System;
using UnityEngine;

namespace CjLib
{
	// Token: 0x020007D7 RID: 2007
	[ExecuteInEditMode]
	public class DrawSphere : DrawBase
	{
		// Token: 0x06003085 RID: 12421 RVA: 0x000ED85B File Offset: 0x000EBA5B
		private void OnValidate()
		{
			this.Radius = Mathf.Max(0f, this.Radius);
			this.NumSegments = Mathf.Max(0, this.NumSegments);
		}

		// Token: 0x06003086 RID: 12422 RVA: 0x000ED888 File Offset: 0x000EBA88
		protected override void Draw(Color color, DebugUtil.Style style, bool depthTest)
		{
			Quaternion rhs = QuaternionUtil.AxisAngle(Vector3.forward, this.StartAngle * MathUtil.Deg2Rad);
			DebugUtil.DrawArc(base.transform.position, base.transform.rotation * rhs * Vector3.right, base.transform.rotation * Vector3.forward, this.ArcAngle * MathUtil.Deg2Rad, this.Radius, this.NumSegments, color, depthTest);
		}

		// Token: 0x040032F3 RID: 13043
		public float Radius = 1f;

		// Token: 0x040032F4 RID: 13044
		public int NumSegments = 64;

		// Token: 0x040032F5 RID: 13045
		public float StartAngle;

		// Token: 0x040032F6 RID: 13046
		public float ArcAngle = 60f;
	}
}
