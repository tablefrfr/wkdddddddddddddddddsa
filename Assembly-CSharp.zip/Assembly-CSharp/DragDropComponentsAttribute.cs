﻿using System;

// Token: 0x02000424 RID: 1060
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
public class DragDropComponentsAttribute : Attribute
{
}
