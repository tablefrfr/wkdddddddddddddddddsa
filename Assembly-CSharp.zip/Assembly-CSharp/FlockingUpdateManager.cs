﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000344 RID: 836
public class FlockingUpdateManager : MonoBehaviour
{
	// Token: 0x060012BA RID: 4794 RVA: 0x00063DA0 File Offset: 0x00061FA0
	protected void Awake()
	{
		if (FlockingUpdateManager.hasInstance && FlockingUpdateManager.instance != null && FlockingUpdateManager.instance != this)
		{
			Object.Destroy(this);
			return;
		}
		FlockingUpdateManager.SetInstance(this);
	}

	// Token: 0x060012BB RID: 4795 RVA: 0x00063DD0 File Offset: 0x00061FD0
	public static void CreateManager()
	{
		FlockingUpdateManager.SetInstance(new GameObject("FlockingUpdateManager").AddComponent<FlockingUpdateManager>());
	}

	// Token: 0x060012BC RID: 4796 RVA: 0x00063DE6 File Offset: 0x00061FE6
	private static void SetInstance(FlockingUpdateManager manager)
	{
		FlockingUpdateManager.instance = manager;
		FlockingUpdateManager.hasInstance = true;
		if (Application.isPlaying)
		{
			Object.DontDestroyOnLoad(manager);
		}
	}

	// Token: 0x060012BD RID: 4797 RVA: 0x00063E01 File Offset: 0x00062001
	public static void RegisterFlocking(Flocking flocking)
	{
		if (!FlockingUpdateManager.hasInstance)
		{
			FlockingUpdateManager.CreateManager();
		}
		if (!FlockingUpdateManager.allFlockings.Contains(flocking))
		{
			FlockingUpdateManager.allFlockings.Add(flocking);
		}
	}

	// Token: 0x060012BE RID: 4798 RVA: 0x00063E27 File Offset: 0x00062027
	public static void UnregisterFlocking(Flocking flocking)
	{
		if (!FlockingUpdateManager.hasInstance)
		{
			FlockingUpdateManager.CreateManager();
		}
		if (FlockingUpdateManager.allFlockings.Contains(flocking))
		{
			FlockingUpdateManager.allFlockings.Remove(flocking);
		}
	}

	// Token: 0x060012BF RID: 4799 RVA: 0x00063E50 File Offset: 0x00062050
	public void Update()
	{
		for (int i = 0; i < FlockingUpdateManager.allFlockings.Count; i++)
		{
			FlockingUpdateManager.allFlockings[i].InvokeUpdate();
		}
	}

	// Token: 0x040015DE RID: 5598
	public static FlockingUpdateManager instance;

	// Token: 0x040015DF RID: 5599
	public static bool hasInstance = false;

	// Token: 0x040015E0 RID: 5600
	public static List<Flocking> allFlockings = new List<Flocking>();
}
