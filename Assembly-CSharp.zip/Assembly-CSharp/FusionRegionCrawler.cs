﻿using System;
using System.Collections;
using System.Collections.Generic;
using Fusion;
using Fusion.Photon.Realtime;
using Fusion.Sockets;
using UnityEngine;

// Token: 0x0200010D RID: 269
public class FusionRegionCrawler : MonoBehaviour, INetworkRunnerCallbacks
{
	// Token: 0x17000079 RID: 121
	// (get) Token: 0x06000516 RID: 1302 RVA: 0x0001DCB8 File Offset: 0x0001BEB8
	public int PlayerCountGlobal
	{
		get
		{
			return this.globalPlayerCount;
		}
	}

	// Token: 0x06000517 RID: 1303 RVA: 0x0001DCC0 File Offset: 0x0001BEC0
	public void Start()
	{
		this.regionRunner = base.gameObject.AddComponent<NetworkRunner>();
		this.regionRunner.AddCallbacks(new INetworkRunnerCallbacks[]
		{
			this
		});
		base.StartCoroutine(this.OccasionalUpdate());
	}

	// Token: 0x06000518 RID: 1304 RVA: 0x0001DCF5 File Offset: 0x0001BEF5
	public IEnumerator OccasionalUpdate()
	{
		while (this.refreshPlayerCountAutomatically)
		{
			yield return this.UpdatePlayerCount();
			yield return new WaitForSeconds(this.UpdateFrequency);
		}
		yield break;
	}

	// Token: 0x06000519 RID: 1305 RVA: 0x0001DD04 File Offset: 0x0001BF04
	public IEnumerator UpdatePlayerCount()
	{
		int tempGlobalPlayerCount = 0;
		StartGameArgs startGameArgs = default(StartGameArgs);
		foreach (string fixedRegion in NetworkSystem.Instance.regionNames)
		{
			startGameArgs.CustomPhotonAppSettings = new AppSettings();
			startGameArgs.CustomPhotonAppSettings.FixedRegion = fixedRegion;
			this.waitingForSessionListUpdate = true;
			this.regionRunner.JoinSessionLobby(SessionLobby.ClientServer, startGameArgs.CustomPhotonAppSettings.FixedRegion, null, null, new bool?(false));
			while (this.waitingForSessionListUpdate)
			{
				yield return new WaitForEndOfFrame();
			}
			foreach (SessionInfo sessionInfo in this.sessionInfoCache)
			{
				tempGlobalPlayerCount += sessionInfo.PlayerCount;
			}
			tempGlobalPlayerCount += this.tempSessionPlayerCount;
		}
		string[] array = null;
		this.globalPlayerCount = tempGlobalPlayerCount;
		FusionRegionCrawler.PlayerCountUpdated onPlayerCountUpdated = this.OnPlayerCountUpdated;
		if (onPlayerCountUpdated != null)
		{
			onPlayerCountUpdated(this.globalPlayerCount);
		}
		yield break;
	}

	// Token: 0x0600051A RID: 1306 RVA: 0x0001DD13 File Offset: 0x0001BF13
	public void OnSessionListUpdated(NetworkRunner runner, List<SessionInfo> sessionList)
	{
		if (this.waitingForSessionListUpdate)
		{
			this.sessionInfoCache = sessionList;
			this.waitingForSessionListUpdate = false;
		}
	}

	// Token: 0x0600051B RID: 1307 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnPlayerJoined(NetworkRunner runner, PlayerRef player)
	{
	}

	// Token: 0x0600051C RID: 1308 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnPlayerLeft(NetworkRunner runner, PlayerRef player)
	{
	}

	// Token: 0x0600051D RID: 1309 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnInput(NetworkRunner runner, NetworkInput input)
	{
	}

	// Token: 0x0600051E RID: 1310 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnInputMissing(NetworkRunner runner, PlayerRef player, NetworkInput input)
	{
	}

	// Token: 0x0600051F RID: 1311 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnShutdown(NetworkRunner runner, ShutdownReason shutdownReason)
	{
	}

	// Token: 0x06000520 RID: 1312 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnConnectedToServer(NetworkRunner runner)
	{
	}

	// Token: 0x06000521 RID: 1313 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnDisconnectedFromServer(NetworkRunner runner)
	{
	}

	// Token: 0x06000522 RID: 1314 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnConnectRequest(NetworkRunner runner, NetworkRunnerCallbackArgs.ConnectRequest request, byte[] token)
	{
	}

	// Token: 0x06000523 RID: 1315 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnConnectFailed(NetworkRunner runner, NetAddress remoteAddress, NetConnectFailedReason reason)
	{
	}

	// Token: 0x06000524 RID: 1316 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnUserSimulationMessage(NetworkRunner runner, SimulationMessagePtr message)
	{
	}

	// Token: 0x06000525 RID: 1317 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnSessionListUpdated(NetworkRunner runner, List<SessionInfo> sessionList)
	{
	}

	// Token: 0x06000526 RID: 1318 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnCustomAuthenticationResponse(NetworkRunner runner, Dictionary<string, object> data)
	{
	}

	// Token: 0x06000527 RID: 1319 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnHostMigration(NetworkRunner runner, HostMigrationToken hostMigrationToken)
	{
	}

	// Token: 0x06000528 RID: 1320 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnReliableDataReceived(NetworkRunner runner, PlayerRef player, ArraySegment<byte> data)
	{
	}

	// Token: 0x06000529 RID: 1321 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnSceneLoadDone(NetworkRunner runner)
	{
	}

	// Token: 0x0600052A RID: 1322 RVA: 0x00003051 File Offset: 0x00001251
	void INetworkRunnerCallbacks.OnSceneLoadStart(NetworkRunner runner)
	{
	}

	// Token: 0x04000689 RID: 1673
	public FusionRegionCrawler.PlayerCountUpdated OnPlayerCountUpdated;

	// Token: 0x0400068A RID: 1674
	private NetworkRunner regionRunner;

	// Token: 0x0400068B RID: 1675
	private List<SessionInfo> sessionInfoCache;

	// Token: 0x0400068C RID: 1676
	private bool waitingForSessionListUpdate;

	// Token: 0x0400068D RID: 1677
	private int globalPlayerCount;

	// Token: 0x0400068E RID: 1678
	private float UpdateFrequency = 10f;

	// Token: 0x0400068F RID: 1679
	private bool refreshPlayerCountAutomatically = true;

	// Token: 0x04000690 RID: 1680
	private int tempSessionPlayerCount;

	// Token: 0x0200010E RID: 270
	// (Invoke) Token: 0x0600052D RID: 1325
	public delegate void PlayerCountUpdated(int playerCount);
}
