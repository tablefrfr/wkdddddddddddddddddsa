﻿using System;

namespace GorillaNetworking
{
	// Token: 0x020006D5 RID: 1749
	[Serializable]
	internal class FeatureFlagListData
	{
		// Token: 0x04002C61 RID: 11361
		public FeatureFlagData[] flags;
	}
}
