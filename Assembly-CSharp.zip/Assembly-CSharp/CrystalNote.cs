﻿using System;

// Token: 0x02000362 RID: 866
public enum CrystalNote
{
	// Token: 0x0400168D RID: 5773
	C,
	// Token: 0x0400168E RID: 5774
	D,
	// Token: 0x0400168F RID: 5775
	E,
	// Token: 0x04001690 RID: 5776
	F,
	// Token: 0x04001691 RID: 5777
	G,
	// Token: 0x04001692 RID: 5778
	A,
	// Token: 0x04001693 RID: 5779
	B
}
