﻿using System;

// Token: 0x0200009E RID: 158
public enum ConsoleMode
{
	// Token: 0x04000463 RID: 1123
	Console,
	// Token: 0x04000464 RID: 1124
	Inspector,
	// Token: 0x04000465 RID: 1125
	ComponentInspector
}
