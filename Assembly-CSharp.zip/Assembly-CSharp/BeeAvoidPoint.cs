﻿using System;
using UnityEngine;

// Token: 0x0200006E RID: 110
public class BeeAvoidPoint : MonoBehaviour
{
	// Token: 0x06000231 RID: 561 RVA: 0x0001082F File Offset: 0x0000EA2F
	private void Start()
	{
		BeeSwarmManager.RegisterAvoidPoint(base.gameObject);
		FlockingManager.RegisterAvoidPoint(base.gameObject);
	}

	// Token: 0x06000232 RID: 562 RVA: 0x00010847 File Offset: 0x0000EA47
	private void OnDestroy()
	{
		BeeSwarmManager.UnregisterAvoidPoint(base.gameObject);
		FlockingManager.UnregisterAvoidPoint(base.gameObject);
	}
}
