﻿using System;
using GorillaNetworking;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000284 RID: 644
public class CosmeticStand : GorillaPressableButton
{
	// Token: 0x06000E32 RID: 3634 RVA: 0x0004AA04 File Offset: 0x00048C04
	public void InitializeCosmetic()
	{
		this.thisCosmeticItem = CosmeticsController.instance.allCosmetics.Find((CosmeticsController.CosmeticItem x) => this.thisCosmeticName == x.displayName || this.thisCosmeticName == x.overrideDisplayName || this.thisCosmeticName == x.itemName);
		this.slotPriceText.text = this.thisCosmeticItem.itemCategory.ToString().ToUpper() + " " + this.thisCosmeticItem.cost.ToString();
	}

	// Token: 0x06000E33 RID: 3635 RVA: 0x0004AA74 File Offset: 0x00048C74
	public override void ButtonActivation()
	{
		base.ButtonActivation();
		CosmeticsController.instance.PressCosmeticStandButton(this);
	}

	// Token: 0x0400101B RID: 4123
	public CosmeticsController.CosmeticItem thisCosmeticItem;

	// Token: 0x0400101C RID: 4124
	public string thisCosmeticName;

	// Token: 0x0400101D RID: 4125
	public HeadModel thisHeadModel;

	// Token: 0x0400101E RID: 4126
	public Text slotPriceText;

	// Token: 0x0400101F RID: 4127
	public Text addToCartText;

	// Token: 0x04001020 RID: 4128
	[Tooltip("If this is true then this cosmetic stand should have already been updated when the 'Update Cosmetic Stands' button was pressed in the CosmeticsController inspector.")]
	public bool skipMe;
}
