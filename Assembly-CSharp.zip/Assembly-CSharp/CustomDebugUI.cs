﻿using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200019E RID: 414
public class CustomDebugUI : MonoBehaviour
{
	// Token: 0x06000888 RID: 2184 RVA: 0x0002B2EA File Offset: 0x000294EA
	private void Awake()
	{
		CustomDebugUI.instance = this;
	}

	// Token: 0x06000889 RID: 2185 RVA: 0x0002B2F4 File Offset: 0x000294F4
	public RectTransform AddTextField(string label, int targetCanvas = 0)
	{
		RectTransform component = Object.Instantiate<RectTransform>(this.textPrefab).GetComponent<RectTransform>();
		component.GetComponentInChildren<InputField>().text = label;
		DebugUIBuilder obj = DebugUIBuilder.instance;
		typeof(DebugUIBuilder).GetMethod("AddRect", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(obj, new object[]
		{
			component,
			targetCanvas
		});
		return component;
	}

	// Token: 0x0600088A RID: 2186 RVA: 0x0002B358 File Offset: 0x00029558
	public void RemoveFromCanvas(RectTransform element, int targetCanvas = 0)
	{
		DebugUIBuilder obj = DebugUIBuilder.instance;
		FieldInfo field = typeof(DebugUIBuilder).GetField("insertedElements", BindingFlags.Instance | BindingFlags.NonPublic);
		MethodInfo method = typeof(DebugUIBuilder).GetMethod("Relayout", BindingFlags.Instance | BindingFlags.NonPublic);
		List<RectTransform>[] array = (List<RectTransform>[])field.GetValue(obj);
		if (targetCanvas > -1 && targetCanvas < array.Length - 1)
		{
			array[targetCanvas].Remove(element);
			element.SetParent(null);
			method.Invoke(obj, new object[0]);
		}
	}

	// Token: 0x04000981 RID: 2433
	[SerializeField]
	private RectTransform textPrefab;

	// Token: 0x04000982 RID: 2434
	public static CustomDebugUI instance;

	// Token: 0x04000983 RID: 2435
	private const BindingFlags privateFlags = BindingFlags.Instance | BindingFlags.NonPublic;
}
