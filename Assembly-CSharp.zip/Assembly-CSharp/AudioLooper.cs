﻿using System;
using UnityEngine;

// Token: 0x020004A8 RID: 1192
[RequireComponent(typeof(AudioSource))]
public class AudioLooper : MonoBehaviour
{
	// Token: 0x06001B4B RID: 6987 RVA: 0x0008B137 File Offset: 0x00089337
	protected virtual void Awake()
	{
		this.audioSource = base.GetComponent<AudioSource>();
	}

	// Token: 0x06001B4C RID: 6988 RVA: 0x0008B148 File Offset: 0x00089348
	private void Update()
	{
		if (!this.audioSource.isPlaying)
		{
			if (this.audioSource.clip == this.loopClip && this.interjectionClips.Length != 0 && Random.value < this.interjectionLikelyhood)
			{
				this.audioSource.clip = this.interjectionClips[Random.Range(0, this.interjectionClips.Length)];
			}
			else
			{
				this.audioSource.clip = this.loopClip;
			}
			this.audioSource.Play();
		}
	}

	// Token: 0x04001F39 RID: 7993
	private AudioSource audioSource;

	// Token: 0x04001F3A RID: 7994
	[SerializeField]
	private AudioClip loopClip;

	// Token: 0x04001F3B RID: 7995
	[SerializeField]
	private AudioClip[] interjectionClips;

	// Token: 0x04001F3C RID: 7996
	[SerializeField]
	private float interjectionLikelyhood = 0.5f;
}
