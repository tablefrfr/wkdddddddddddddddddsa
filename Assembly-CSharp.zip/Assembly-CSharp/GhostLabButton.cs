﻿using System;
using UnityEngine;

// Token: 0x0200003E RID: 62
public class GhostLabButton : GorillaPressableButton, IBuildValidation
{
	// Token: 0x06000129 RID: 297 RVA: 0x0000A164 File Offset: 0x00008364
	public bool BuildValidationCheck()
	{
		if (this.ghostLab == null)
		{
			Debug.LogError("ghostlab is missing", this);
			return false;
		}
		return true;
	}

	// Token: 0x0600012A RID: 298 RVA: 0x0000A182 File Offset: 0x00008382
	public override void ButtonActivation()
	{
		base.ButtonActivation();
		this.ghostLab.DoorButtonPress(this.buttonIndex, this.forSingleDoor);
	}

	// Token: 0x0400019E RID: 414
	public GhostLab ghostLab;

	// Token: 0x0400019F RID: 415
	public int buttonIndex;

	// Token: 0x040001A0 RID: 416
	public bool forSingleDoor;
}
