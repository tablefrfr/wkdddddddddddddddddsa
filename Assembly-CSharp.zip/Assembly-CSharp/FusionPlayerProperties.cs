﻿using System;
using System.Runtime.InteropServices;
using Fusion;
using Fusion.CodeGen;
using UnityEngine;
using UnityEngine.Scripting;

// Token: 0x0200010A RID: 266
[NetworkBehaviourWeaved(3862)]
public class FusionPlayerProperties : NetworkBehaviour
{
	// Token: 0x17000075 RID: 117
	// (get) Token: 0x06000500 RID: 1280 RVA: 0x0001D7E8 File Offset: 0x0001B9E8
	[Networked(OnChanged = "AttributesChanged")]
	[Capacity(10)]
	[NetworkedWeaved(0, 3862)]
	private NetworkDictionary<PlayerRef, FusionPlayerProperties.PlayerInfo> netPlayerAttributes
	{
		get
		{
			if (this.Ptr == null)
			{
				throw new InvalidOperationException("Error when accessing FusionPlayerProperties.netPlayerAttributes. Networked properties can only be accessed when Spawned() has been called.");
			}
			return new NetworkDictionary<PlayerRef, FusionPlayerProperties.PlayerInfo>(this.Ptr + 0, 17, ReaderWriter@Fusion_PlayerRef.GetInstance(), ReaderWriter@FusionPlayerProperties__PlayerInfo.GetInstance());
		}
	}

	// Token: 0x17000076 RID: 118
	// (get) Token: 0x06000501 RID: 1281 RVA: 0x0001D82C File Offset: 0x0001BA2C
	public FusionPlayerProperties.PlayerInfo PlayerProperties
	{
		get
		{
			return this.netPlayerAttributes[this.Runner.LocalPlayer];
		}
	}

	// Token: 0x06000502 RID: 1282 RVA: 0x0001D852 File Offset: 0x0001BA52
	[Preserve]
	public static void AttributesChanged(Changed<FusionPlayerProperties> changed)
	{
		changed.Behaviour.OnAttributesChanged();
	}

	// Token: 0x06000503 RID: 1283 RVA: 0x0001D860 File Offset: 0x0001BA60
	private void OnAttributesChanged()
	{
		FusionPlayerProperties.PlayerAttributeOnChanged playerAttributeOnChanged = this.playerAttributeOnChanged;
		if (playerAttributeOnChanged == null)
		{
			return;
		}
		playerAttributeOnChanged();
	}

	// Token: 0x06000504 RID: 1284 RVA: 0x0001D874 File Offset: 0x0001BA74
	[Rpc(RpcSources.All, RpcTargets.All, InvokeLocal = true, TickAligned = true)]
	public unsafe void RPC_UpdatePlayerAttributes(FusionPlayerProperties.PlayerInfo newInfo, RpcInfo info = default(RpcInfo))
	{
		if (!this.InvokeRpc)
		{
			NetworkBehaviourUtils.ThrowIfBehaviourNotInitialized(this);
			if (this.Runner.Stage != SimulationStages.Resimulate)
			{
				int localAuthorityMask = this.Object.GetLocalAuthorityMask();
				if ((localAuthorityMask & 7) == 0)
				{
					NetworkBehaviourUtils.NotifyLocalSimulationNotAllowedToSendRpc("System.Void FusionPlayerProperties::RPC_UpdatePlayerAttributes(FusionPlayerProperties/PlayerInfo,Fusion.RpcInfo)", this.Object, 7);
				}
				else
				{
					if (this.Runner.HasAnyActiveConnections())
					{
						int num = 8;
						num += 896;
						SimulationMessage* ptr = SimulationMessage.Allocate(this.Runner.Simulation, num);
						byte* data = SimulationMessage.GetData(ptr);
						int num2 = RpcHeader.Write(RpcHeader.Create(this.Object.Id, this.ObjectIndex, 1), data);
						*(FusionPlayerProperties.PlayerInfo*)(data + num2) = newInfo;
						num2 += 896;
						ptr->Offset = num2 * 8;
						this.Runner.SendRpc(ptr);
					}
					if ((localAuthorityMask & 7) != 0)
					{
						info = RpcInfo.FromLocal(this.Runner, RpcChannel.Reliable, RpcHostMode.SourceIsServer);
						goto IL_12;
					}
				}
			}
			return;
		}
		this.InvokeRpc = false;
		IL_12:
		Debug.Log("Update Player attributes triggered");
		PlayerRef source = info.Source;
		if (this.netPlayerAttributes.ContainsKey(source))
		{
			Debug.Log("Current nickname is " + this.netPlayerAttributes[source].NickName.ToString());
			Debug.Log("Sent nickname is " + newInfo.NickName.ToString());
			if (this.netPlayerAttributes[source].Equals(newInfo))
			{
				Debug.Log("Info is already correct for this user. Shouldnt have received an RPC in this case.");
				return;
			}
		}
		this.netPlayerAttributes.Set(source, newInfo);
	}

	// Token: 0x06000505 RID: 1285 RVA: 0x0001DA71 File Offset: 0x0001BC71
	public override void Spawned()
	{
		Debug.Log("Player props SPAWNED!");
		if (this.Runner.Mode == SimulationModes.Client)
		{
			Debug.Log("SET Player Properties manager!");
		}
	}

	// Token: 0x06000506 RID: 1286 RVA: 0x0001DA98 File Offset: 0x0001BC98
	public string GetDisplayName(PlayerRef player)
	{
		return this.netPlayerAttributes[player].NickName.Value;
	}

	// Token: 0x06000507 RID: 1287 RVA: 0x0001DAC4 File Offset: 0x0001BCC4
	public string GetLocalDisplayName()
	{
		return this.netPlayerAttributes[this.Runner.LocalPlayer].NickName.Value;
	}

	// Token: 0x06000508 RID: 1288 RVA: 0x0001DAFC File Offset: 0x0001BCFC
	public bool GetProperty(PlayerRef player, string propertyName, out string propertyValue)
	{
		NetworkString<_32> networkString;
		if (this.netPlayerAttributes[player].properties.TryGet(propertyName, out networkString))
		{
			propertyValue = networkString.Value;
			return true;
		}
		propertyValue = null;
		return false;
	}

	// Token: 0x06000509 RID: 1289 RVA: 0x0001DB44 File Offset: 0x0001BD44
	public bool PlayerHasEntry(PlayerRef player)
	{
		return this.netPlayerAttributes.ContainsKey(player);
	}

	// Token: 0x0600050A RID: 1290 RVA: 0x0001DB60 File Offset: 0x0001BD60
	public void RemovePlayerEntry(PlayerRef player)
	{
		if (this.Object.HasStateAuthority)
		{
			string value = this.netPlayerAttributes[player].NickName.Value;
			this.netPlayerAttributes.Remove(player);
			Debug.Log("Removed " + value + "player properties as they just left.");
		}
	}

	// Token: 0x0600050C RID: 1292 RVA: 0x0001DBC7 File Offset: 0x0001BDC7
	public override void CopyBackingFieldsToState(bool A_1)
	{
		NetworkBehaviourUtils.InitializeNetworkDictionary<SerializableDictionary<PlayerRef, FusionPlayerProperties.PlayerInfo>, PlayerRef, FusionPlayerProperties.PlayerInfo>(this.netPlayerAttributes, this._netPlayerAttributes, "netPlayerAttributes");
	}

	// Token: 0x0600050D RID: 1293 RVA: 0x0001DBDF File Offset: 0x0001BDDF
	public override void CopyStateToBackingFields()
	{
		NetworkBehaviourUtils.CopyFromNetworkDictionary<SerializableDictionary<PlayerRef, FusionPlayerProperties.PlayerInfo>, PlayerRef, FusionPlayerProperties.PlayerInfo>(this.netPlayerAttributes, ref this._netPlayerAttributes);
	}

	// Token: 0x0600050E RID: 1294 RVA: 0x0001DBF4 File Offset: 0x0001BDF4
	[NetworkRpcWeavedInvoker(1, 7, 7)]
	[Preserve]
	protected unsafe static void RPC_UpdatePlayerAttributes@Invoker(NetworkBehaviour behaviour, SimulationMessage* message)
	{
		byte* data = SimulationMessage.GetData(message);
		int num = RpcHeader.ReadSize(data) + 3 & -4;
		FusionPlayerProperties.PlayerInfo playerInfo = *(FusionPlayerProperties.PlayerInfo*)(data + num);
		num += 896;
		FusionPlayerProperties.PlayerInfo newInfo = playerInfo;
		RpcInfo info = RpcInfo.FromMessage(behaviour.Runner, message, RpcHostMode.SourceIsServer);
		behaviour.InvokeRpc = true;
		((FusionPlayerProperties)behaviour).RPC_UpdatePlayerAttributes(newInfo, info);
	}

	// Token: 0x04000682 RID: 1666
	public FusionPlayerProperties.PlayerAttributeOnChanged playerAttributeOnChanged;

	// Token: 0x04000683 RID: 1667
	static Changed<FusionPlayerProperties> $IL2CPP_CHANGED;

	// Token: 0x04000684 RID: 1668
	static ChangedDelegate<FusionPlayerProperties> $IL2CPP_CHANGED_DELEGATE;

	// Token: 0x04000685 RID: 1669
	static NetworkBehaviourCallbacks<FusionPlayerProperties> $IL2CPP_NETWORK_BEHAVIOUR_CALLBACKS;

	// Token: 0x04000686 RID: 1670
	[DefaultForProperty("netPlayerAttributes", 0, 3862)]
	private SerializableDictionary<PlayerRef, FusionPlayerProperties.PlayerInfo> _netPlayerAttributes;

	// Token: 0x0200010B RID: 267
	[NetworkStructWeaved(224)]
	[StructLayout(LayoutKind.Explicit, Size = 896)]
	public struct PlayerInfo : INetworkStruct
	{
		// Token: 0x17000077 RID: 119
		// (get) Token: 0x0600050F RID: 1295 RVA: 0x0001DC6B File Offset: 0x0001BE6B
		// (set) Token: 0x06000510 RID: 1296 RVA: 0x0001DC7D File Offset: 0x0001BE7D
		[Networked]
		public unsafe NetworkString<_16> NickName
		{
			readonly get
			{
				return *(NetworkString<_16>*)Native.ReferenceToPointer<FixedStorage@17>(ref this._NickName);
			}
			set
			{
				*(NetworkString<_16>*)Native.ReferenceToPointer<FixedStorage@17>(ref this._NickName) = value;
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x06000511 RID: 1297 RVA: 0x0001DC90 File Offset: 0x0001BE90
		[Networked]
		public unsafe NetworkDictionary<NetworkString<_32>, NetworkString<_32>> properties
		{
			get
			{
				return new NetworkDictionary<NetworkString<_32>, NetworkString<_32>>((int*)Native.ReferenceToPointer<FixedStorage@207>(ref this._properties), 3, ReaderWriter@Fusion_NetworkString.GetInstance(), ReaderWriter@Fusion_NetworkString.GetInstance());
			}
		}

		// Token: 0x04000687 RID: 1671
		[FixedBufferProperty(typeof(NetworkString<_16>), typeof(UnityValueSurrogate@ReaderWriter@Fusion_NetworkString), 0, order = -2147483647)]
		[SerializeField]
		[FieldOffset(0)]
		private FixedStorage@17 _NickName;

		// Token: 0x04000688 RID: 1672
		[FixedBufferProperty(typeof(NetworkDictionary<NetworkString<_32>, NetworkString<_32>>), typeof(UnityDictionarySurrogate@ReaderWriter@Fusion_NetworkString`1<Fusion__32>@ReaderWriter@Fusion_NetworkString), 3, order = -2147483647)]
		[SerializeField]
		[FieldOffset(68)]
		private FixedStorage@207 _properties;
	}

	// Token: 0x0200010C RID: 268
	// (Invoke) Token: 0x06000513 RID: 1299
	public delegate void PlayerAttributeOnChanged();
}
