﻿using System;
using System.Diagnostics;
using UnityEngine;

namespace BuildSafe
{
	// Token: 0x02000624 RID: 1572
	internal static class EditorOnlyScripts
	{
		// Token: 0x06002513 RID: 9491 RVA: 0x00003051 File Offset: 0x00001251
		[Conditional("UNITY_EDITOR")]
		public static void Cleanup(GameObject[] rootObjects, bool force = false)
		{
		}
	}
}
