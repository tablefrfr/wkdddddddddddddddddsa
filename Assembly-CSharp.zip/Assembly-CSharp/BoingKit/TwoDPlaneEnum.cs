﻿using System;

namespace BoingKit
{
	// Token: 0x02000826 RID: 2086
	public enum TwoDPlaneEnum
	{
		// Token: 0x04003523 RID: 13603
		XY,
		// Token: 0x04003524 RID: 13604
		XZ,
		// Token: 0x04003525 RID: 13605
		YZ
	}
}
