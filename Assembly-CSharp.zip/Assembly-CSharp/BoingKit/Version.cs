﻿using System;

namespace BoingKit
{
	// Token: 0x020007F9 RID: 2041
	public struct Version : IEquatable<Version>
	{
		// Token: 0x17000559 RID: 1369
		// (get) Token: 0x06003182 RID: 12674 RVA: 0x000F78F0 File Offset: 0x000F5AF0
		public readonly int MajorVersion { get; }

		// Token: 0x1700055A RID: 1370
		// (get) Token: 0x06003183 RID: 12675 RVA: 0x000F78F8 File Offset: 0x000F5AF8
		public readonly int MinorVersion { get; }

		// Token: 0x1700055B RID: 1371
		// (get) Token: 0x06003184 RID: 12676 RVA: 0x000F7900 File Offset: 0x000F5B00
		public readonly int Revision { get; }

		// Token: 0x06003185 RID: 12677 RVA: 0x000F7908 File Offset: 0x000F5B08
		public override string ToString()
		{
			return string.Concat(new string[]
			{
				this.MajorVersion.ToString(),
				".",
				this.MinorVersion.ToString(),
				".",
				this.Revision.ToString()
			});
		}

		// Token: 0x06003186 RID: 12678 RVA: 0x000F7963 File Offset: 0x000F5B63
		public bool IsValid()
		{
			return this.MajorVersion >= 0 && this.MinorVersion >= 0 && this.Revision >= 0;
		}

		// Token: 0x06003187 RID: 12679 RVA: 0x000F7985 File Offset: 0x000F5B85
		public Version(int majorVersion = -1, int minorVersion = -1, int revision = -1)
		{
			this.MajorVersion = majorVersion;
			this.MinorVersion = minorVersion;
			this.Revision = revision;
		}

		// Token: 0x06003188 RID: 12680 RVA: 0x000F799C File Offset: 0x000F5B9C
		public static bool operator ==(Version lhs, Version rhs)
		{
			return lhs.IsValid() && rhs.IsValid() && (lhs.MajorVersion == rhs.MajorVersion && lhs.MinorVersion == rhs.MinorVersion) && lhs.Revision == rhs.Revision;
		}

		// Token: 0x06003189 RID: 12681 RVA: 0x000F79F1 File Offset: 0x000F5BF1
		public static bool operator !=(Version lhs, Version rhs)
		{
			return !(lhs == rhs);
		}

		// Token: 0x0600318A RID: 12682 RVA: 0x000F79FD File Offset: 0x000F5BFD
		public override bool Equals(object obj)
		{
			return obj is Version && this.Equals((Version)obj);
		}

		// Token: 0x0600318B RID: 12683 RVA: 0x000F7A15 File Offset: 0x000F5C15
		public bool Equals(Version other)
		{
			return this.MajorVersion == other.MajorVersion && this.MinorVersion == other.MinorVersion && this.Revision == other.Revision;
		}

		// Token: 0x0600318C RID: 12684 RVA: 0x000F7A48 File Offset: 0x000F5C48
		public override int GetHashCode()
		{
			return ((366299368 * -1521134295 + this.MajorVersion.GetHashCode()) * -1521134295 + this.MinorVersion.GetHashCode()) * -1521134295 + this.Revision.GetHashCode();
		}

		// Token: 0x0400341E RID: 13342
		public static readonly Version Invalid = new Version(-1, -1, -1);

		// Token: 0x0400341F RID: 13343
		public static readonly Version FirstTracked = new Version(1, 2, 33);

		// Token: 0x04003420 RID: 13344
		public static readonly Version LastUntracked = new Version(1, 2, 32);
	}
}
