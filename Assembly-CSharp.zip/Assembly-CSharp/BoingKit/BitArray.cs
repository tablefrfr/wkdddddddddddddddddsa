﻿using System;

namespace BoingKit
{
	// Token: 0x02000829 RID: 2089
	public struct BitArray
	{
		// Token: 0x17000577 RID: 1399
		// (get) Token: 0x060032A9 RID: 12969 RVA: 0x000FE500 File Offset: 0x000FC700
		public int[] Blocks
		{
			get
			{
				return this.m_aBlock;
			}
		}

		// Token: 0x060032AA RID: 12970 RVA: 0x000FE508 File Offset: 0x000FC708
		private static int GetBlockIndex(int index)
		{
			return index / 4;
		}

		// Token: 0x060032AB RID: 12971 RVA: 0x000FE50D File Offset: 0x000FC70D
		private static int GetSubIndex(int index)
		{
			return index % 4;
		}

		// Token: 0x060032AC RID: 12972 RVA: 0x000FE514 File Offset: 0x000FC714
		private static void SetBit(int index, bool value, int[] blocks)
		{
			int blockIndex = BitArray.GetBlockIndex(index);
			int subIndex = BitArray.GetSubIndex(index);
			if (value)
			{
				blocks[blockIndex] |= 1 << subIndex;
				return;
			}
			blocks[blockIndex] &= ~(1 << subIndex);
		}

		// Token: 0x060032AD RID: 12973 RVA: 0x000FE556 File Offset: 0x000FC756
		private static bool IsBitSet(int index, int[] blocks)
		{
			return (blocks[BitArray.GetBlockIndex(index)] & 1 << BitArray.GetSubIndex(index)) != 0;
		}

		// Token: 0x060032AE RID: 12974 RVA: 0x000FE570 File Offset: 0x000FC770
		public BitArray(int capacity)
		{
			int num = (capacity + 4 - 1) / 4;
			this.m_aBlock = new int[num];
			this.Clear();
		}

		// Token: 0x060032AF RID: 12975 RVA: 0x000FE598 File Offset: 0x000FC798
		public void Resize(int capacity)
		{
			int num = (capacity + 4 - 1) / 4;
			if (num <= this.m_aBlock.Length)
			{
				return;
			}
			int[] array = new int[num];
			int i = 0;
			int num2 = this.m_aBlock.Length;
			while (i < num2)
			{
				array[i] = this.m_aBlock[i];
				i++;
			}
			this.m_aBlock = array;
		}

		// Token: 0x060032B0 RID: 12976 RVA: 0x000FE5E7 File Offset: 0x000FC7E7
		public void Clear()
		{
			this.SetAllBits(false);
		}

		// Token: 0x060032B1 RID: 12977 RVA: 0x000FE5F0 File Offset: 0x000FC7F0
		public void SetAllBits(bool value)
		{
			int num = value ? -1 : 1;
			int i = 0;
			int num2 = this.m_aBlock.Length;
			while (i < num2)
			{
				this.m_aBlock[i] = num;
				i++;
			}
		}

		// Token: 0x060032B2 RID: 12978 RVA: 0x000FE623 File Offset: 0x000FC823
		public void SetBit(int index, bool value)
		{
			BitArray.SetBit(index, value, this.m_aBlock);
		}

		// Token: 0x060032B3 RID: 12979 RVA: 0x000FE632 File Offset: 0x000FC832
		public bool IsBitSet(int index)
		{
			return BitArray.IsBitSet(index, this.m_aBlock);
		}

		// Token: 0x04003529 RID: 13609
		private int[] m_aBlock;
	}
}
