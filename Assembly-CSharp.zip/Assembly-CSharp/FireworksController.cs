﻿using System;
using System.Linq;
using UnityEngine;
using UnityEngine.Serialization;

// Token: 0x02000511 RID: 1297
public class FireworksController : MonoBehaviour
{
	// Token: 0x06001D3A RID: 7482 RVA: 0x00091D96 File Offset: 0x0008FF96
	private void Awake()
	{
		this._launchOrder = this.fireworks.ToArray<Firework>();
		this._rnd = new SRand(this.seed);
	}

	// Token: 0x06001D3B RID: 7483 RVA: 0x00091DBC File Offset: 0x0008FFBC
	public void LaunchVolley()
	{
		if (!Application.isPlaying)
		{
			return;
		}
		this._rnd.Shuffle<Firework>(this._launchOrder);
		for (int i = 0; i < this._launchOrder.Length; i++)
		{
			MonoBehaviour monoBehaviour = this._launchOrder[i];
			float time = this._rnd.NextFloat() * this.roundLength;
			monoBehaviour.Invoke("Launch", time);
		}
	}

	// Token: 0x06001D3C RID: 7484 RVA: 0x00091E20 File Offset: 0x00090020
	public void LaunchVolleyRound()
	{
		int num = 0;
		while ((long)num < (long)((ulong)this.roundNumVolleys))
		{
			float time = this._rnd.NextFloat() * this.roundLength;
			base.Invoke("LaunchVolley", time);
			num++;
		}
		if (this._fireworksEvent)
		{
			base.Invoke("LaunchVolleyRound", this.roundLength);
		}
	}

	// Token: 0x06001D3D RID: 7485 RVA: 0x00091E84 File Offset: 0x00090084
	public void Launch(Firework fw)
	{
		if (!fw)
		{
			return;
		}
		Vector3 position = fw.origin.position;
		Vector3 position2 = fw.target.position;
		AudioSource sourceOrigin = fw.sourceOrigin;
		int num = this._rnd.NextInt(this.bursts.Length);
		AudioClip audioClip = this.whistles[this._rnd.NextInt(this.whistles.Length)];
		AudioClip audioClip2 = this.bursts[num];
		while (this._lastWhistle == audioClip)
		{
			audioClip = this.whistles[this._rnd.NextInt(this.whistles.Length)];
		}
		while (this._lastBurst == audioClip2)
		{
			num = this._rnd.NextInt(this.bursts.Length);
			audioClip2 = this.bursts[num];
		}
		this._lastWhistle = audioClip;
		this._lastBurst = audioClip2;
		int num2 = this._rnd.NextInt(fw.explosions.Length);
		ParticleSystem particleSystem = fw.explosions[num2];
		if (fw.doTrail)
		{
			ParticleSystem trail = fw.trail;
			trail.startColor = fw.colorOrigin;
			trail.subEmitters.GetSubEmitterSystem(0).colorOverLifetime.color = new ParticleSystem.MinMaxGradient(fw.colorOrigin, fw.colorTarget);
			trail.Stop();
			trail.Play();
		}
		sourceOrigin.pitch = this._rnd.NextFloat(0.92f, 1f);
		fw.doTrailAudio = this._rnd.NextBool();
		FireworksController.ExplosionEvent ev = new FireworksController.ExplosionEvent
		{
			firework = fw,
			timeSince = TimeSince.Now(),
			burstIndex = num,
			explosionIndex = num2,
			delay = (double)(fw.doTrail ? audioClip.length : 0f),
			active = true
		};
		if (fw.doExplosion)
		{
			this.PostExplosionEvent(ev);
		}
		if (fw.doTrailAudio && this._timeSinceLastWhistle > this.minWhistleDelay)
		{
			this._timeSinceLastWhistle = TimeSince.Now();
			sourceOrigin.PlayOneShot(audioClip, this._rnd.NextFloat(this.whistleVolumeMin, this.whistleVolumeMax));
		}
		particleSystem.Stop();
		particleSystem.transform.position = position2;
	}

	// Token: 0x06001D3E RID: 7486 RVA: 0x000920B4 File Offset: 0x000902B4
	private void PostExplosionEvent(FireworksController.ExplosionEvent ev)
	{
		for (int i = 0; i < this._explosionQueue.Length; i++)
		{
			if (!this._explosionQueue[i].active)
			{
				this._explosionQueue[i] = ev;
				return;
			}
		}
	}

	// Token: 0x06001D3F RID: 7487 RVA: 0x000920F5 File Offset: 0x000902F5
	private void Update()
	{
		this.ProcessEvents();
	}

	// Token: 0x06001D40 RID: 7488 RVA: 0x00092100 File Offset: 0x00090300
	private void ProcessEvents()
	{
		if (this._explosionQueue == null || this._explosionQueue.Length == 0)
		{
			return;
		}
		for (int i = 0; i < this._explosionQueue.Length; i++)
		{
			FireworksController.ExplosionEvent explosionEvent = this._explosionQueue[i];
			if (explosionEvent.active && explosionEvent.timeSince >= explosionEvent.delay)
			{
				this.DoExplosion(explosionEvent);
				this._explosionQueue[i] = default(FireworksController.ExplosionEvent);
			}
		}
	}

	// Token: 0x06001D41 RID: 7489 RVA: 0x00092174 File Offset: 0x00090374
	private void DoExplosion(FireworksController.ExplosionEvent ev)
	{
		Firework firework = ev.firework;
		ParticleSystem particleSystem = firework.explosions[ev.explosionIndex];
		ParticleSystem.MinMaxGradient color = new ParticleSystem.MinMaxGradient(firework.colorOrigin, firework.colorTarget);
		ParticleSystem.ColorOverLifetimeModule colorOverLifetime = particleSystem.colorOverLifetime;
		ParticleSystem.ColorOverLifetimeModule colorOverLifetime2 = particleSystem.subEmitters.GetSubEmitterSystem(0).colorOverLifetime;
		colorOverLifetime.color = color;
		colorOverLifetime2.color = color;
		ParticleSystem particleSystem2 = firework.explosions[ev.explosionIndex];
		particleSystem2.Stop();
		particleSystem2.Play();
		firework.sourceTarget.PlayOneShot(this.bursts[ev.burstIndex]);
	}

	// Token: 0x06001D42 RID: 7490 RVA: 0x00092204 File Offset: 0x00090404
	public void RenderGizmo(Firework fw, Color c)
	{
		if (!fw)
		{
			return;
		}
		if (!fw.origin || !fw.target)
		{
			return;
		}
		Gizmos.color = c;
		Vector3 position = fw.origin.position;
		Vector3 position2 = fw.target.position;
		Gizmos.DrawLine(position, position2);
		Gizmos.DrawWireCube(position, Vector3.one * 0.5f);
		Gizmos.DrawWireCube(position2, Vector3.one * 0.5f);
	}

	// Token: 0x04002042 RID: 8258
	public Firework[] fireworks;

	// Token: 0x04002043 RID: 8259
	public AudioClip[] whistles;

	// Token: 0x04002044 RID: 8260
	public AudioClip[] bursts;

	// Token: 0x04002045 RID: 8261
	[Space]
	[Range(0f, 1f)]
	public float whistleVolumeMin = 0.1f;

	// Token: 0x04002046 RID: 8262
	[Range(0f, 1f)]
	public float whistleVolumeMax = 0.15f;

	// Token: 0x04002047 RID: 8263
	public float minWhistleDelay = 1f;

	// Token: 0x04002048 RID: 8264
	[Space]
	[NonSerialized]
	private AudioClip _lastWhistle;

	// Token: 0x04002049 RID: 8265
	[NonSerialized]
	private AudioClip _lastBurst;

	// Token: 0x0400204A RID: 8266
	[NonSerialized]
	private Firework[] _launchOrder;

	// Token: 0x0400204B RID: 8267
	[NonSerialized]
	private SRand _rnd;

	// Token: 0x0400204C RID: 8268
	[NonSerialized]
	private FireworksController.ExplosionEvent[] _explosionQueue = new FireworksController.ExplosionEvent[8];

	// Token: 0x0400204D RID: 8269
	[NonSerialized]
	private TimeSince _timeSinceLastWhistle = 10f;

	// Token: 0x0400204E RID: 8270
	[Space]
	public string seed = "Fireworks.Summer23";

	// Token: 0x0400204F RID: 8271
	[Space]
	public uint roundNumVolleys = 6U;

	// Token: 0x04002050 RID: 8272
	public uint roundLength = 6U;

	// Token: 0x04002051 RID: 8273
	[FormerlySerializedAs("_timeOfDayEvent")]
	[FormerlySerializedAs("_timeOfDay")]
	[Space]
	[SerializeField]
	private TimeOfDayEvent _fireworksEvent;

	// Token: 0x02000512 RID: 1298
	[Serializable]
	public struct ExplosionEvent
	{
		// Token: 0x04002052 RID: 8274
		public TimeSince timeSince;

		// Token: 0x04002053 RID: 8275
		public double delay;

		// Token: 0x04002054 RID: 8276
		public int explosionIndex;

		// Token: 0x04002055 RID: 8277
		public int burstIndex;

		// Token: 0x04002056 RID: 8278
		public bool active;

		// Token: 0x04002057 RID: 8279
		public Firework firework;
	}
}
