﻿using System;

namespace emotitron.Compression
{
	// Token: 0x020007BA RID: 1978
	[Serializable]
	public abstract class LiteCrusher<T> : LiteCrusher where T : struct
	{
		// Token: 0x06002FCF RID: 12239
		public abstract ulong Encode(T val);

		// Token: 0x06002FD0 RID: 12240
		public abstract T Decode(uint val);

		// Token: 0x06002FD1 RID: 12241
		public abstract ulong WriteValue(T val, byte[] buffer, ref int bitposition);

		// Token: 0x06002FD2 RID: 12242
		public abstract void WriteCValue(uint val, byte[] buffer, ref int bitposition);

		// Token: 0x06002FD3 RID: 12243
		public abstract T ReadValue(byte[] buffer, ref int bitposition);
	}
}
