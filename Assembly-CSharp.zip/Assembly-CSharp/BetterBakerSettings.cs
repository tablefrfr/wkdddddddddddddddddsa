﻿using System;
using UnityEngine;

// Token: 0x020004B2 RID: 1202
public class BetterBakerSettings : MonoBehaviour
{
	// Token: 0x04001F51 RID: 8017
	[SerializeField]
	public GameObject[] lightMapMaps = new GameObject[9];

	// Token: 0x020004B3 RID: 1203
	[Serializable]
	public struct LightMapMap
	{
		// Token: 0x04001F52 RID: 8018
		[SerializeField]
		public string timeOfDayName;

		// Token: 0x04001F53 RID: 8019
		[SerializeField]
		public GameObject sceneLightObject;
	}
}
