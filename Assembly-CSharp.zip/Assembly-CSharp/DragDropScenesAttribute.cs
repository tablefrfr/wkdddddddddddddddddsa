﻿using System;

// Token: 0x0200050A RID: 1290
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
public class DragDropScenesAttribute : Attribute
{
}
