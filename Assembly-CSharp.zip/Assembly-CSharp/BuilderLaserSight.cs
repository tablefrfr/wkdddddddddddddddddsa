﻿using System;
using UnityEngine;

// Token: 0x02000319 RID: 793
public class BuilderLaserSight : MonoBehaviour
{
	// Token: 0x060011D5 RID: 4565 RVA: 0x0005CF47 File Offset: 0x0005B147
	public void Awake()
	{
		if (this.lineRenderer == null)
		{
			this.lineRenderer = base.GetComponentInChildren<LineRenderer>();
		}
		if (this.lineRenderer != null)
		{
			this.lineRenderer.enabled = false;
		}
	}

	// Token: 0x060011D6 RID: 4566 RVA: 0x0005CF7D File Offset: 0x0005B17D
	public void SetPoints(Vector3 start, Vector3 end)
	{
		this.lineRenderer.positionCount = 2;
		this.lineRenderer.SetPosition(0, start);
		this.lineRenderer.SetPosition(1, end);
	}

	// Token: 0x060011D7 RID: 4567 RVA: 0x0005CFA5 File Offset: 0x0005B1A5
	public void Show(bool show)
	{
		if (this.lineRenderer != null)
		{
			this.lineRenderer.enabled = show;
		}
	}

	// Token: 0x04001455 RID: 5205
	public LineRenderer lineRenderer;
}
