﻿using System;
using UnityEngine;

// Token: 0x02000311 RID: 785
public class AddCollidersToParticleSystemTriggers : MonoBehaviour
{
	// Token: 0x060011BA RID: 4538 RVA: 0x0005CB10 File Offset: 0x0005AD10
	private void Update()
	{
		this.count = 0;
		while (this.count < 6)
		{
			this.index++;
			if (this.index >= this.collidersToAdd.Length)
			{
				if (BetterDayNightManager.instance.collidersToAddToWeatherSystems.Count >= this.index - this.collidersToAdd.Length)
				{
					this.index = 0;
				}
				else
				{
					this.particleSystemToUpdate.trigger.SetCollider(this.count, BetterDayNightManager.instance.collidersToAddToWeatherSystems[this.index - this.collidersToAdd.Length]);
				}
			}
			if (this.index < this.collidersToAdd.Length)
			{
				this.particleSystemToUpdate.trigger.SetCollider(this.count, this.collidersToAdd[this.index]);
			}
			this.count++;
		}
	}

	// Token: 0x0400143E RID: 5182
	public Collider[] collidersToAdd;

	// Token: 0x0400143F RID: 5183
	public ParticleSystem particleSystemToUpdate;

	// Token: 0x04001440 RID: 5184
	private int count;

	// Token: 0x04001441 RID: 5185
	private int index;
}
