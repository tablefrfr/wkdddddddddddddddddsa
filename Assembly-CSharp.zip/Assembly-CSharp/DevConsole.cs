﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000096 RID: 150
public class DevConsole : MonoBehaviour, IDebugObject
{
	// Token: 0x17000044 RID: 68
	// (get) Token: 0x06000301 RID: 769 RVA: 0x00015FBB File Offset: 0x000141BB
	public static DevConsole instance
	{
		get
		{
			if (DevConsole._instance == null)
			{
				DevConsole._instance = Object.FindObjectOfType<DevConsole>();
			}
			return DevConsole._instance;
		}
	}

	// Token: 0x17000045 RID: 69
	// (get) Token: 0x06000302 RID: 770 RVA: 0x00015FD9 File Offset: 0x000141D9
	public static List<DevConsole.LogEntry> logEntries
	{
		get
		{
			return DevConsole.instance._logEntries;
		}
	}

	// Token: 0x06000303 RID: 771 RVA: 0x00015FE8 File Offset: 0x000141E8
	public void OnDestroyDebugObject()
	{
		Debug.Log("Destroying debug instances now");
		foreach (DevConsoleInstance devConsoleInstance in this.instances)
		{
			Object.DestroyImmediate(devConsoleInstance.gameObject);
		}
	}

	// Token: 0x06000304 RID: 772 RVA: 0x0000BC47 File Offset: 0x00009E47
	private void OnEnable()
	{
		base.gameObject.SetActive(false);
	}

	// Token: 0x04000432 RID: 1074
	private static DevConsole _instance;

	// Token: 0x04000433 RID: 1075
	[SerializeField]
	private AudioClip errorSound;

	// Token: 0x04000434 RID: 1076
	[SerializeField]
	private AudioSource audioSource;

	// Token: 0x04000435 RID: 1077
	[SerializeField]
	private float maxHeight;

	// Token: 0x04000436 RID: 1078
	public static readonly string[] tracebackScrubbing = new string[]
	{
		"ExitGames.Client.Photon",
		"Photon.Realtime.LoadBalancingClient",
		"Photon.Pun.PhotonHandler"
	};

	// Token: 0x04000437 RID: 1079
	private const int kLogEntriesCapacityIncrementAmount = 1024;

	// Token: 0x04000438 RID: 1080
	[SerializeReference]
	[SerializeField]
	private readonly List<DevConsole.LogEntry> _logEntries = new List<DevConsole.LogEntry>(1024);

	// Token: 0x04000439 RID: 1081
	public int targetLogIndex = -1;

	// Token: 0x0400043A RID: 1082
	public int currentLogIndex;

	// Token: 0x0400043B RID: 1083
	public bool isMuted;

	// Token: 0x0400043C RID: 1084
	public float currentZoomLevel = 1f;

	// Token: 0x0400043D RID: 1085
	public List<GameObject> disableWhileActive;

	// Token: 0x0400043E RID: 1086
	public List<GameObject> enableWhileActive;

	// Token: 0x0400043F RID: 1087
	public int expandAmount = 20;

	// Token: 0x04000440 RID: 1088
	public int expandedMessageIndex = -1;

	// Token: 0x04000441 RID: 1089
	public bool canExpand = true;

	// Token: 0x04000442 RID: 1090
	public List<DevConsole.DisplayedLogLine> logLines = new List<DevConsole.DisplayedLogLine>();

	// Token: 0x04000443 RID: 1091
	public float lineStartHeight;

	// Token: 0x04000444 RID: 1092
	public float textStartHeight;

	// Token: 0x04000445 RID: 1093
	public float lineStartTextWidth;

	// Token: 0x04000446 RID: 1094
	public double textScale = 0.5;

	// Token: 0x04000447 RID: 1095
	public List<DevConsoleInstance> instances;

	// Token: 0x02000097 RID: 151
	[Serializable]
	public class LogEntry
	{
		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000307 RID: 775 RVA: 0x000160D2 File Offset: 0x000142D2
		public string Message
		{
			get
			{
				if (this.repeatCount > 1)
				{
					return string.Format("({0}) {1}", this.repeatCount, this._Message);
				}
				return this._Message;
			}
		}

		// Token: 0x06000308 RID: 776 RVA: 0x00016100 File Offset: 0x00014300
		public LogEntry(string message, LogType type, string trace)
		{
			this._Message = message;
			this.Type = type;
			this.Trace = trace;
			StringBuilder stringBuilder = new StringBuilder();
			string[] array = trace.Split("\n".ToCharArray(), StringSplitOptions.None);
			for (int i = 0; i < array.Length; i++)
			{
				string line = array[i];
				if (!DevConsole.tracebackScrubbing.Any((string scrubString) => line.Contains(scrubString)))
				{
					stringBuilder.AppendLine(line);
				}
			}
			this.Trace = stringBuilder.ToString();
			DevConsole.LogEntry.TotalIndex++;
			this.index = DevConsole.LogEntry.TotalIndex;
		}

		// Token: 0x04000448 RID: 1096
		private static int TotalIndex;

		// Token: 0x04000449 RID: 1097
		[SerializeReference]
		[SerializeField]
		public readonly string _Message;

		// Token: 0x0400044A RID: 1098
		[SerializeField]
		[SerializeReference]
		public readonly LogType Type;

		// Token: 0x0400044B RID: 1099
		public readonly string Trace;

		// Token: 0x0400044C RID: 1100
		public bool forwarded;

		// Token: 0x0400044D RID: 1101
		public int repeatCount = 1;

		// Token: 0x0400044E RID: 1102
		public bool filtered;

		// Token: 0x0400044F RID: 1103
		public int index;
	}

	// Token: 0x02000099 RID: 153
	[Serializable]
	public class DisplayedLogLine
	{
		// Token: 0x17000047 RID: 71
		// (get) Token: 0x0600030B RID: 779 RVA: 0x000161BA File Offset: 0x000143BA
		// (set) Token: 0x0600030C RID: 780 RVA: 0x000161C2 File Offset: 0x000143C2
		public Type data { get; set; }

		// Token: 0x0600030D RID: 781 RVA: 0x000161CC File Offset: 0x000143CC
		public DisplayedLogLine(GameObject obj)
		{
			this.lineText = obj.GetComponentInChildren<Text>();
			this.buttons = obj.GetComponentsInChildren<GorillaDevButton>();
			this.transform = obj.GetComponent<RectTransform>();
			this.backdrop = obj.GetComponentInChildren<SpriteRenderer>();
			foreach (GorillaDevButton gorillaDevButton in this.buttons)
			{
				if (gorillaDevButton.Type == DevButtonType.LineExpand)
				{
					this.maximizeButton = gorillaDevButton;
				}
				if (gorillaDevButton.Type == DevButtonType.LineForward)
				{
					this.forwardButton = gorillaDevButton;
				}
			}
		}

		// Token: 0x04000451 RID: 1105
		public GorillaDevButton[] buttons;

		// Token: 0x04000452 RID: 1106
		public Text lineText;

		// Token: 0x04000453 RID: 1107
		public RectTransform transform;

		// Token: 0x04000454 RID: 1108
		public int targetMessage;

		// Token: 0x04000455 RID: 1109
		public GorillaDevButton maximizeButton;

		// Token: 0x04000456 RID: 1110
		public GorillaDevButton forwardButton;

		// Token: 0x04000457 RID: 1111
		public SpriteRenderer backdrop;

		// Token: 0x04000458 RID: 1112
		private bool expanded;

		// Token: 0x04000459 RID: 1113
		public DevInspector inspector;
	}

	// Token: 0x0200009A RID: 154
	[Serializable]
	public class MessagePayload
	{
		// Token: 0x0600030E RID: 782 RVA: 0x00016248 File Offset: 0x00014448
		public static List<DevConsole.MessagePayload> GeneratePayloads(string username, List<DevConsole.LogEntry> entries)
		{
			List<DevConsole.MessagePayload> list = new List<DevConsole.MessagePayload>();
			List<DevConsole.MessagePayload.Block> list2 = new List<DevConsole.MessagePayload.Block>();
			entries.Sort((DevConsole.LogEntry e1, DevConsole.LogEntry e2) => e1.index.CompareTo(e2.index));
			string text = "";
			text += "```";
			list2.Add(new DevConsole.MessagePayload.Block("User `" + username + "` Forwarded some errors"));
			foreach (DevConsole.LogEntry logEntry in entries)
			{
				string[] array = logEntry.Trace.Split("\n".ToCharArray());
				string text2 = "";
				foreach (string str in array)
				{
					text2 = text2 + "    " + str + "\n";
				}
				string text3 = string.Format("({0}) {1}\n{2}\n", logEntry.Type, logEntry.Message, text2);
				if (text.Length + text3.Length > 3000)
				{
					text += "```";
					list2.Add(new DevConsole.MessagePayload.Block(text));
					list.Add(new DevConsole.MessagePayload
					{
						blocks = list2.ToArray()
					});
					list2 = new List<DevConsole.MessagePayload.Block>();
					text = "```";
				}
				text += string.Format("({0}) {1}\n{2}\n", logEntry.Type, logEntry.Message, text2);
			}
			text += "```";
			list2.Add(new DevConsole.MessagePayload.Block(text));
			list.Add(new DevConsole.MessagePayload
			{
				blocks = list2.ToArray()
			});
			return list;
		}

		// Token: 0x0400045B RID: 1115
		public DevConsole.MessagePayload.Block[] blocks;

		// Token: 0x0200009B RID: 155
		[Serializable]
		public class Block
		{
			// Token: 0x06000310 RID: 784 RVA: 0x00016418 File Offset: 0x00014618
			public Block(string markdownText)
			{
				this.text = new DevConsole.MessagePayload.TextBlock
				{
					text = markdownText,
					type = "mrkdwn"
				};
				this.type = "section";
			}

			// Token: 0x0400045C RID: 1116
			public string type;

			// Token: 0x0400045D RID: 1117
			public DevConsole.MessagePayload.TextBlock text;
		}

		// Token: 0x0200009C RID: 156
		[Serializable]
		public class TextBlock
		{
			// Token: 0x0400045E RID: 1118
			public string type;

			// Token: 0x0400045F RID: 1119
			public string text;
		}
	}
}
