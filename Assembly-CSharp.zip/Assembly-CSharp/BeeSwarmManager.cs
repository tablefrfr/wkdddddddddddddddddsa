﻿using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000070 RID: 112
public class BeeSwarmManager : MonoBehaviourPun
{
	// Token: 0x17000015 RID: 21
	// (get) Token: 0x06000236 RID: 566 RVA: 0x00010872 File Offset: 0x0000EA72
	// (set) Token: 0x06000237 RID: 567 RVA: 0x0001087A File Offset: 0x0000EA7A
	public BeePerchPoint BeeHive { get; private set; }

	// Token: 0x17000016 RID: 22
	// (get) Token: 0x06000238 RID: 568 RVA: 0x00010883 File Offset: 0x0000EA83
	// (set) Token: 0x06000239 RID: 569 RVA: 0x0001088B File Offset: 0x0000EA8B
	public float BeeSpeed { get; private set; }

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x0600023A RID: 570 RVA: 0x00010894 File Offset: 0x0000EA94
	// (set) Token: 0x0600023B RID: 571 RVA: 0x0001089C File Offset: 0x0000EA9C
	public float BeeMaxTravelTime { get; private set; }

	// Token: 0x17000018 RID: 24
	// (get) Token: 0x0600023C RID: 572 RVA: 0x000108A5 File Offset: 0x0000EAA5
	// (set) Token: 0x0600023D RID: 573 RVA: 0x000108AD File Offset: 0x0000EAAD
	public float BeeAcceleration { get; private set; }

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x0600023E RID: 574 RVA: 0x000108B6 File Offset: 0x0000EAB6
	// (set) Token: 0x0600023F RID: 575 RVA: 0x000108BE File Offset: 0x0000EABE
	public float BeeJitterStrength { get; private set; }

	// Token: 0x1700001A RID: 26
	// (get) Token: 0x06000240 RID: 576 RVA: 0x000108C7 File Offset: 0x0000EAC7
	// (set) Token: 0x06000241 RID: 577 RVA: 0x000108CF File Offset: 0x0000EACF
	public float BeeJitterDamping { get; private set; }

	// Token: 0x1700001B RID: 27
	// (get) Token: 0x06000242 RID: 578 RVA: 0x000108D8 File Offset: 0x0000EAD8
	// (set) Token: 0x06000243 RID: 579 RVA: 0x000108E0 File Offset: 0x0000EAE0
	public float BeeMaxJitterRadius { get; private set; }

	// Token: 0x1700001C RID: 28
	// (get) Token: 0x06000244 RID: 580 RVA: 0x000108E9 File Offset: 0x0000EAE9
	// (set) Token: 0x06000245 RID: 581 RVA: 0x000108F1 File Offset: 0x0000EAF1
	public float BeeNearDestinationRadius { get; private set; }

	// Token: 0x1700001D RID: 29
	// (get) Token: 0x06000246 RID: 582 RVA: 0x000108FA File Offset: 0x0000EAFA
	// (set) Token: 0x06000247 RID: 583 RVA: 0x00010902 File Offset: 0x0000EB02
	public float AvoidPointRadius { get; private set; }

	// Token: 0x1700001E RID: 30
	// (get) Token: 0x06000248 RID: 584 RVA: 0x0001090B File Offset: 0x0000EB0B
	// (set) Token: 0x06000249 RID: 585 RVA: 0x00010913 File Offset: 0x0000EB13
	public float BeeMinFlowerDuration { get; private set; }

	// Token: 0x1700001F RID: 31
	// (get) Token: 0x0600024A RID: 586 RVA: 0x0001091C File Offset: 0x0000EB1C
	// (set) Token: 0x0600024B RID: 587 RVA: 0x00010924 File Offset: 0x0000EB24
	public float BeeMaxFlowerDuration { get; private set; }

	// Token: 0x17000020 RID: 32
	// (get) Token: 0x0600024C RID: 588 RVA: 0x0001092D File Offset: 0x0000EB2D
	// (set) Token: 0x0600024D RID: 589 RVA: 0x00010935 File Offset: 0x0000EB35
	public float GeneralBuzzRange { get; private set; }

	// Token: 0x0600024E RID: 590 RVA: 0x00010940 File Offset: 0x0000EB40
	private void Awake()
	{
		this.bees = new List<AnimatedBee>(this.numBees);
		for (int i = 0; i < this.numBees; i++)
		{
			AnimatedBee item = default(AnimatedBee);
			item.InitVisual(this.beePrefab, this);
			this.bees.Add(item);
		}
		this.playerCamera = Camera.main.transform;
	}

	// Token: 0x0600024F RID: 591 RVA: 0x000109A4 File Offset: 0x0000EBA4
	private void Start()
	{
		foreach (XSceneRef xsceneRef in this.flowerSections)
		{
			GameObject gameObject;
			if (xsceneRef.TryResolve(out gameObject))
			{
				foreach (BeePerchPoint item in gameObject.GetComponentsInChildren<BeePerchPoint>())
				{
					this.allPerchPoints.Add(item);
				}
			}
		}
		this.OnSeedChange();
		RandomTimedSeedManager.instance.AddCallbackOnSeedChanged(new Action(this.OnSeedChange));
	}

	// Token: 0x06000250 RID: 592 RVA: 0x00010A24 File Offset: 0x0000EC24
	private void OnDestroy()
	{
		RandomTimedSeedManager.instance.RemoveCallbackOnSeedChanged(new Action(this.OnSeedChange));
	}

	// Token: 0x06000251 RID: 593 RVA: 0x00010A3C File Offset: 0x0000EC3C
	private void Update()
	{
		Vector3 position = this.playerCamera.transform.position;
		Vector3 position2 = Vector3.zero;
		Vector3 a = Vector3.zero;
		float num = 1f / (float)this.bees.Count;
		float num2 = float.PositiveInfinity;
		float num3 = this.GeneralBuzzRange * this.GeneralBuzzRange;
		int num4 = 0;
		for (int i = 0; i < this.bees.Count; i++)
		{
			AnimatedBee animatedBee = this.bees[i];
			animatedBee.UpdateVisual(RandomTimedSeedManager.instance.currentSyncTime, this);
			Vector3 position3 = animatedBee.visual.transform.position;
			float sqrMagnitude = (position3 - position).sqrMagnitude;
			if (sqrMagnitude < num2)
			{
				position2 = position3;
				num2 = sqrMagnitude;
			}
			if (sqrMagnitude < num3)
			{
				a += position3;
				num4++;
			}
			this.bees[i] = animatedBee;
		}
		this.nearbyBeeBuzz.transform.position = position2;
		if (num4 > 0)
		{
			this.generalBeeBuzz.transform.position = a / (float)num4;
			this.generalBeeBuzz.enabled = true;
			return;
		}
		this.generalBeeBuzz.enabled = false;
	}

	// Token: 0x06000252 RID: 594 RVA: 0x00010B6C File Offset: 0x0000ED6C
	private void OnSeedChange()
	{
		SRand srand = new SRand(RandomTimedSeedManager.instance.seed);
		List<BeePerchPoint> pickBuffer = new List<BeePerchPoint>(this.allPerchPoints.Count);
		List<BeePerchPoint> list = new List<BeePerchPoint>(this.loopSizePerBee);
		List<float> list2 = new List<float>(this.loopSizePerBee);
		for (int i = 0; i < this.bees.Count; i++)
		{
			AnimatedBee value = this.bees[i];
			list = new List<BeePerchPoint>(this.loopSizePerBee);
			list2 = new List<float>(this.loopSizePerBee);
			this.PickPoints(this.loopSizePerBee, pickBuffer, this.allPerchPoints, ref srand, list);
			for (int j = 0; j < list.Count; j++)
			{
				list2.Add(srand.NextFloat(this.BeeMinFlowerDuration, this.BeeMaxFlowerDuration));
			}
			value.InitRoute(list, list2, this);
			value.InitRouteTimestamps();
			this.bees[i] = value;
		}
	}

	// Token: 0x06000253 RID: 595 RVA: 0x00010C60 File Offset: 0x0000EE60
	private void PickPoints(int n, List<BeePerchPoint> pickBuffer, List<BeePerchPoint> allPerchPoints, ref SRand rand, List<BeePerchPoint> resultBuffer)
	{
		resultBuffer.Add(this.BeeHive);
		n--;
		int num = 100;
		while (pickBuffer.Count < n && num-- > 0)
		{
			n -= pickBuffer.Count;
			resultBuffer.AddRange(pickBuffer);
			pickBuffer.Clear();
			pickBuffer.AddRange(allPerchPoints);
			rand.Shuffle<BeePerchPoint>(pickBuffer);
		}
		resultBuffer.AddRange(pickBuffer.GetRange(pickBuffer.Count - n, n));
		pickBuffer.RemoveRange(pickBuffer.Count - n, n);
	}

	// Token: 0x06000254 RID: 596 RVA: 0x00010CE1 File Offset: 0x0000EEE1
	public static void RegisterAvoidPoint(GameObject obj)
	{
		BeeSwarmManager.avoidPoints.Add(obj);
	}

	// Token: 0x06000255 RID: 597 RVA: 0x00010CEE File Offset: 0x0000EEEE
	public static void UnregisterAvoidPoint(GameObject obj)
	{
		BeeSwarmManager.avoidPoints.Remove(obj);
	}

	// Token: 0x0400033E RID: 830
	[SerializeField]
	private XSceneRef[] flowerSections;

	// Token: 0x0400033F RID: 831
	[SerializeField]
	private int loopSizePerBee;

	// Token: 0x04000340 RID: 832
	[SerializeField]
	private int numBees;

	// Token: 0x04000341 RID: 833
	[SerializeField]
	private MeshRenderer beePrefab;

	// Token: 0x04000342 RID: 834
	[SerializeField]
	private AudioSource nearbyBeeBuzz;

	// Token: 0x04000343 RID: 835
	[SerializeField]
	private AudioSource generalBeeBuzz;

	// Token: 0x04000344 RID: 836
	private GameObject[] flowerSectionsResolved;

	// Token: 0x04000351 RID: 849
	private List<AnimatedBee> bees;

	// Token: 0x04000352 RID: 850
	private Transform playerCamera;

	// Token: 0x04000353 RID: 851
	private List<BeePerchPoint> allPerchPoints = new List<BeePerchPoint>();

	// Token: 0x04000354 RID: 852
	public static readonly List<GameObject> avoidPoints = new List<GameObject>();
}
