﻿using System;
using UnityEngine;

// Token: 0x020001A9 RID: 425
public class AugmentedObject : MonoBehaviour
{
	// Token: 0x060008C7 RID: 2247 RVA: 0x0002CE70 File Offset: 0x0002B070
	private void Start()
	{
		if (base.GetComponent<GrabObject>())
		{
			GrabObject component = base.GetComponent<GrabObject>();
			component.GrabbedObjectDelegate = (GrabObject.GrabbedObject)Delegate.Combine(component.GrabbedObjectDelegate, new GrabObject.GrabbedObject(this.Grab));
			GrabObject component2 = base.GetComponent<GrabObject>();
			component2.ReleasedObjectDelegate = (GrabObject.ReleasedObject)Delegate.Combine(component2.ReleasedObjectDelegate, new GrabObject.ReleasedObject(this.Release));
		}
	}

	// Token: 0x060008C8 RID: 2248 RVA: 0x0002CED8 File Offset: 0x0002B0D8
	private void Update()
	{
		if (this.controllerHand != OVRInput.Controller.None && OVRInput.GetUp(OVRInput.Button.One, this.controllerHand))
		{
			this.ToggleShadowType();
		}
		if (this.shadow)
		{
			if (this.groundShadow)
			{
				this.shadow.transform.position = new Vector3(base.transform.position.x, 0f, base.transform.position.z);
				return;
			}
			this.shadow.transform.localPosition = Vector3.zero;
		}
	}

	// Token: 0x060008C9 RID: 2249 RVA: 0x0002CF66 File Offset: 0x0002B166
	public void Grab(OVRInput.Controller grabHand)
	{
		this.controllerHand = grabHand;
	}

	// Token: 0x060008CA RID: 2250 RVA: 0x0002CF6F File Offset: 0x0002B16F
	public void Release()
	{
		this.controllerHand = OVRInput.Controller.None;
	}

	// Token: 0x060008CB RID: 2251 RVA: 0x0002CF78 File Offset: 0x0002B178
	private void ToggleShadowType()
	{
		this.groundShadow = !this.groundShadow;
	}

	// Token: 0x040009B6 RID: 2486
	public OVRInput.Controller controllerHand;

	// Token: 0x040009B7 RID: 2487
	public Transform shadow;

	// Token: 0x040009B8 RID: 2488
	private bool groundShadow;
}
