﻿using System;
using System.IO;
using UnityEngine;

namespace GorillaNetworking.Store
{
	// Token: 0x020006FC RID: 1788
	[Serializable]
	public class StoreItem
	{
		// Token: 0x06002A51 RID: 10833 RVA: 0x000CFC28 File Offset: 0x000CDE28
		public static void SerializeItemsAsJSON(StoreItem[] items)
		{
			string text = "";
			foreach (StoreItem obj in items)
			{
				text = text + JsonUtility.ToJson(obj) + ";";
			}
			Debug.LogError(text);
			File.WriteAllText(Application.dataPath + "/Resources/StoreItems/FeaturedStoreItemsList.json", text);
		}

		// Token: 0x06002A52 RID: 10834 RVA: 0x000CFC7C File Offset: 0x000CDE7C
		public static void ConvertCosmeticItemToSToreItem(CosmeticsController.CosmeticItem cosmeticItem, ref StoreItem storeItem)
		{
			storeItem.itemName = cosmeticItem.itemName;
			storeItem.itemCategory = (int)cosmeticItem.itemCategory;
			storeItem.itemPictureResourceString = cosmeticItem.itemPictureResourceString;
			storeItem.displayName = cosmeticItem.displayName;
			storeItem.overrideDisplayName = cosmeticItem.overrideDisplayName;
			storeItem.bundledItems = cosmeticItem.bundledItems;
			storeItem.canTryOn = cosmeticItem.canTryOn;
			storeItem.bothHandsHoldable = cosmeticItem.bothHandsHoldable;
			storeItem.AssetBundleName = "";
			storeItem.bUsesMeshAtlas = cosmeticItem.bUsesMeshAtlas;
			storeItem.MeshResourceName = cosmeticItem.meshResourceString;
			storeItem.MeshAtlasResourceName = cosmeticItem.meshAtlasResourceString;
			storeItem.MaterialResrouceName = cosmeticItem.materialResourceString;
		}

		// Token: 0x04002D55 RID: 11605
		public string itemName = "";

		// Token: 0x04002D56 RID: 11606
		public int itemCategory;

		// Token: 0x04002D57 RID: 11607
		public string itemPictureResourceString = "";

		// Token: 0x04002D58 RID: 11608
		public string displayName = "";

		// Token: 0x04002D59 RID: 11609
		public string overrideDisplayName = "";

		// Token: 0x04002D5A RID: 11610
		public string[] bundledItems = new string[0];

		// Token: 0x04002D5B RID: 11611
		public bool canTryOn;

		// Token: 0x04002D5C RID: 11612
		public bool bothHandsHoldable;

		// Token: 0x04002D5D RID: 11613
		public string AssetBundleName = "";

		// Token: 0x04002D5E RID: 11614
		public bool bUsesMeshAtlas;

		// Token: 0x04002D5F RID: 11615
		public string MeshAtlasResourceName = "";

		// Token: 0x04002D60 RID: 11616
		public string MeshResourceName = "";

		// Token: 0x04002D61 RID: 11617
		public string MaterialResrouceName = "";

		// Token: 0x04002D62 RID: 11618
		public Vector3 translationOffset = Vector3.zero;

		// Token: 0x04002D63 RID: 11619
		public Vector3 rotationOffset = Vector3.zero;

		// Token: 0x04002D64 RID: 11620
		public Vector3 scale = Vector3.one;
	}
}
