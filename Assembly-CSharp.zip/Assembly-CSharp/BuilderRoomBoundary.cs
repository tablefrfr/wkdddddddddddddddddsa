﻿using System;
using UnityEngine;

// Token: 0x0200032D RID: 813
public class BuilderRoomBoundary : GorillaTriggerBox
{
	// Token: 0x06001240 RID: 4672 RVA: 0x000615B6 File Offset: 0x0005F7B6
	private void Awake()
	{
		this.enableOnEnterTrigger.OnEnter += this.OnEnteredBoundary;
		this.disableOnExitTrigger.OnExit += this.OnExitedBoundary;
	}

	// Token: 0x06001241 RID: 4673 RVA: 0x000615E6 File Offset: 0x0005F7E6
	private void OnDestroy()
	{
		this.enableOnEnterTrigger.OnEnter -= this.OnEnteredBoundary;
		this.disableOnExitTrigger.OnExit -= this.OnExitedBoundary;
	}

	// Token: 0x06001242 RID: 4674 RVA: 0x00061618 File Offset: 0x0005F818
	public void OnEnteredBoundary(Collider other)
	{
		if (other.attachedRigidbody == null)
		{
			return;
		}
		if (!ZoneManagement.instance.IsZoneActive(GTZone.attic))
		{
			return;
		}
		this.rigRef = other.attachedRigidbody.gameObject.GetComponent<VRRig>();
		if (this.rigRef == null || !this.rigRef.isOfflineVRRig)
		{
			return;
		}
		this.rigRef.EnableBuilderResizeWatch(true);
	}

	// Token: 0x06001243 RID: 4675 RVA: 0x00061684 File Offset: 0x0005F884
	public void OnExitedBoundary(Collider other)
	{
		if (other.attachedRigidbody == null)
		{
			return;
		}
		this.rigRef = other.attachedRigidbody.gameObject.GetComponent<VRRig>();
		if (this.rigRef == null || !this.rigRef.isOfflineVRRig)
		{
			return;
		}
		this.rigRef.EnableBuilderResizeWatch(false);
	}

	// Token: 0x0400150F RID: 5391
	[SerializeField]
	private SizeChangerTrigger enableOnEnterTrigger;

	// Token: 0x04001510 RID: 5392
	[SerializeField]
	private SizeChangerTrigger disableOnExitTrigger;

	// Token: 0x04001511 RID: 5393
	private VRRig rigRef;
}
