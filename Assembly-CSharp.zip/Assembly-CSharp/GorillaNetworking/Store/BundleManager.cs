﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using GorillaExtensions;
using Sirenix.OdinInspector;
using UnityEngine;
using UnityEngine.Serialization;
using WebSocketSharp;

namespace GorillaNetworking.Store
{
	// Token: 0x020006EF RID: 1775
	public class BundleManager : MonoBehaviour
	{
		// Token: 0x060029ED RID: 10733 RVA: 0x000CE4B8 File Offset: 0x000CC6B8
		private IEnumerable GetStoreBundles()
		{
			List<StoreBundleData> list = new List<StoreBundleData>();
			list.Add(this.nullBundleData);
			list.AddRange(this._bundleScriptableObjects);
			return list;
		}

		// Token: 0x060029EE RID: 10734 RVA: 0x000CE4D7 File Offset: 0x000CC6D7
		public void Awake()
		{
			if (BundleManager.instance == null)
			{
				BundleManager.instance = this;
				return;
			}
			if (BundleManager.instance != this)
			{
				Object.Destroy(base.gameObject);
				return;
			}
		}

		// Token: 0x060029EF RID: 10735 RVA: 0x000CE50C File Offset: 0x000CC70C
		private void Start()
		{
			this.GenerateBundleDictionaries();
			this.Initialize();
		}

		// Token: 0x060029F0 RID: 10736 RVA: 0x000CE51C File Offset: 0x000CC71C
		private void Initialize()
		{
			foreach (StoreBundle storeBundle in this._storeBundles)
			{
				storeBundle.InitializebundleStands();
			}
			if (CosmeticsController.instance.v2_isCosmeticPlayFabCatalogDataLoaded)
			{
				this.GetTitleDataForBundles();
				return;
			}
			CosmeticsController cosmeticsController = CosmeticsController.instance;
			cosmeticsController.V2_OnGetCosmeticsPlayFabCatalogData_PostSuccess = (Action)Delegate.Combine(cosmeticsController.V2_OnGetCosmeticsPlayFabCatalogData_PostSuccess, new Action(this.GetTitleDataForBundles));
		}

		// Token: 0x060029F1 RID: 10737 RVA: 0x000CE5AC File Offset: 0x000CC7AC
		private void ValidateBundleData()
		{
			foreach (StoreBundle storeBundle in this._storeBundles)
			{
				storeBundle.ValidateBundleData();
			}
		}

		// Token: 0x060029F2 RID: 10738 RVA: 0x000CE5FC File Offset: 0x000CC7FC
		private void SpawnBundleStands()
		{
			foreach (StoreBundle storeBundle in this._storeBundles)
			{
				foreach (BundleStand bundleStand in storeBundle.bundleStands)
				{
					if (bundleStand != null)
					{
						Object.DestroyImmediate(bundleStand.gameObject);
					}
				}
			}
			this._spawnedBundleStands.Clear();
			this.storeBundlesById.Clear();
			this.storeBundlesBySKU.Clear();
			this._storeBundles.Clear();
			this._bundleScriptableObjects.Clear();
			BundleStand[] array = Object.FindObjectsOfType<BundleStand>();
			for (int i = 0; i < array.Length; i++)
			{
				Object.DestroyImmediate(array[i].gameObject);
			}
			for (int j = 0; j < this.BundleStands.Count; j++)
			{
				if (this.BundleStands[j].spawnLocation == null)
				{
					Debug.LogError("No spawn location set for Bundle Stand " + j.ToString());
				}
				else if (this.BundleStands[j].bundleStand == null)
				{
					Debug.LogError("No Bundle Stand set for Bundle Stand " + j.ToString());
				}
			}
			this.GenerateAllStoreBundleReferences();
			if (!this._bundleScriptableObjects.Contains(this.tryOnBundleButton1))
			{
				this.tryOnBundleButton1 = this.nullBundleData;
			}
			if (!this._bundleScriptableObjects.Contains(this.tryOnBundleButton2))
			{
				this.tryOnBundleButton2 = this.nullBundleData;
			}
			if (!this._bundleScriptableObjects.Contains(this.tryOnBundleButton3))
			{
				this.tryOnBundleButton3 = this.nullBundleData;
			}
			if (!this._bundleScriptableObjects.Contains(this.tryOnBundleButton4))
			{
				this.tryOnBundleButton4 = this.nullBundleData;
			}
			if (!this._bundleScriptableObjects.Contains(this.tryOnBundleButton5))
			{
				this.tryOnBundleButton4 = this.nullBundleData;
			}
		}

		// Token: 0x060029F3 RID: 10739 RVA: 0x000CE810 File Offset: 0x000CCA10
		public void ClearEverything()
		{
			foreach (StoreBundle storeBundle in this._storeBundles)
			{
				foreach (BundleStand bundleStand in storeBundle.bundleStands)
				{
					if (bundleStand != null)
					{
						Object.DestroyImmediate(bundleStand.gameObject);
					}
				}
			}
			this._spawnedBundleStands.Clear();
			this.storeBundlesById.Clear();
			this.storeBundlesBySKU.Clear();
			this._storeBundles.Clear();
			this._bundleScriptableObjects.Clear();
			this.tryOnBundleButton1 = this.nullBundleData;
			this.tryOnBundleButton2 = this.nullBundleData;
			this.tryOnBundleButton3 = this.nullBundleData;
			this.tryOnBundleButton4 = this.nullBundleData;
			this.tryOnBundleButton5 = this.nullBundleData;
			BundleStand[] array = Object.FindObjectsOfType<BundleStand>();
			for (int i = 0; i < array.Length; i++)
			{
				Object.DestroyImmediate(array[i].gameObject);
			}
		}

		// Token: 0x060029F4 RID: 10740 RVA: 0x00003051 File Offset: 0x00001251
		public void GenerateAllStoreBundleReferences()
		{
		}

		// Token: 0x060029F5 RID: 10741 RVA: 0x000CE944 File Offset: 0x000CCB44
		private void AddNewBundleStand(BundleStand bundleStand)
		{
			foreach (StoreBundle storeBundle in this._storeBundles)
			{
				if (storeBundle.playfabBundleID == bundleStand._bundleDataReference.playfabBundleID)
				{
					storeBundle.bundleStands.Add(bundleStand);
					return;
				}
			}
			StoreBundle storeBundle2 = new StoreBundle(bundleStand._bundleDataReference);
			storeBundle2.bundleStands.Add(bundleStand);
			this._storeBundles.Add(storeBundle2);
		}

		// Token: 0x060029F6 RID: 10742 RVA: 0x000CE9DC File Offset: 0x000CCBDC
		public void GenerateBundleDictionaries()
		{
			this.storeBundlesById.Clear();
			this.storeBundlesBySKU.Clear();
			foreach (StoreBundle storeBundle in this._storeBundles)
			{
				this.storeBundlesById.Add(storeBundle.playfabBundleID, storeBundle);
				this.storeBundlesBySKU.Add(storeBundle.bundleSKU, storeBundle);
			}
		}

		// Token: 0x060029F7 RID: 10743 RVA: 0x000CEA64 File Offset: 0x000CCC64
		public void GetTitleDataForBundles()
		{
			foreach (StoreBundle storeBundle in this._storeBundles)
			{
				storeBundle.UpdatePriceFromTitleData();
			}
			this.storeBundlesBySKU.Keys.ToArray<string>();
			foreach (StoreBundle storeBundle2 in this._storeBundles)
			{
				if (storeBundle2.price.IsNullOrEmpty())
				{
					storeBundle2.price = "$--.--";
					storeBundle2.UpdatePurchaseButtonText();
				}
			}
		}

		// Token: 0x060029F8 RID: 10744 RVA: 0x000CEB20 File Offset: 0x000CCD20
		public void BundlePurchaseButtonPressed(string playFabItemName)
		{
			CosmeticsController.instance.PurchaseBundle(this.storeBundlesById[playFabItemName]);
		}

		// Token: 0x060029F9 RID: 10745 RVA: 0x000CEB3C File Offset: 0x000CCD3C
		public void FixBundles()
		{
			this._storeBundles.Clear();
			BundleStand[] array = Object.FindObjectsOfType<BundleStand>();
			for (int i = 0; i < array.Length; i++)
			{
				BundleStand bundle = array[i];
				if (this._spawnedBundleStands.Any((SpawnedBundle x) => x.spawnLocationPath == bundle.transform.parent.gameObject.GetPath(3)))
				{
					Object.DestroyImmediate(this._spawnedBundleStands.First((SpawnedBundle x) => x.spawnLocationPath == bundle.transform.parent.gameObject.GetPath(3)).bundleStand.gameObject);
					this._spawnedBundleStands.First((SpawnedBundle x) => x.spawnLocationPath == bundle.transform.parent.gameObject.GetPath(3)).bundleStand = bundle;
				}
				else
				{
					this._spawnedBundleStands.Add(new SpawnedBundle
					{
						spawnLocationPath = bundle.transform.parent.gameObject.GetPath(3),
						bundleStand = bundle
					});
				}
			}
			this.GenerateAllStoreBundleReferences();
		}

		// Token: 0x060029FA RID: 10746 RVA: 0x000CEC23 File Offset: 0x000CCE23
		public StoreBundleData[] GetTryOnButtons()
		{
			return new StoreBundleData[]
			{
				this.tryOnBundleButton1,
				this.tryOnBundleButton2,
				this.tryOnBundleButton3,
				this.tryOnBundleButton4,
				this.tryOnBundleButton5
			};
		}

		// Token: 0x060029FB RID: 10747 RVA: 0x000CEC58 File Offset: 0x000CCE58
		public void NotifyBundleOfErrorByPlayFabID(string ItemId)
		{
			StoreBundle storeBundle;
			if (this.storeBundlesById.TryGetValue(ItemId, out storeBundle))
			{
				foreach (BundleStand bundleStand in storeBundle.bundleStands)
				{
					bundleStand.ErrorHappened();
				}
			}
		}

		// Token: 0x060029FC RID: 10748 RVA: 0x000CECB8 File Offset: 0x000CCEB8
		public void NotifyBundleOfErrorBySKU(string ItemSKU)
		{
			StoreBundle storeBundle;
			if (this.storeBundlesBySKU.TryGetValue(ItemSKU, out storeBundle))
			{
				foreach (BundleStand bundleStand in storeBundle.bundleStands)
				{
					bundleStand.ErrorHappened();
				}
			}
		}

		// Token: 0x060029FD RID: 10749 RVA: 0x000CED18 File Offset: 0x000CCF18
		public void MarkBundleOwnedByPlayFabID(string ItemId)
		{
			if (this.storeBundlesById.ContainsKey(ItemId))
			{
				this.storeBundlesById[ItemId].isOwned = true;
				foreach (BundleStand bundleStand in this.storeBundlesById[ItemId].bundleStands)
				{
					bundleStand.NotifyAlreadyOwn();
				}
			}
		}

		// Token: 0x060029FE RID: 10750 RVA: 0x000CED94 File Offset: 0x000CCF94
		public void MarkBundleOwnedBySKU(string SKU)
		{
			if (this.storeBundlesBySKU.ContainsKey(SKU))
			{
				this.storeBundlesBySKU[SKU].isOwned = true;
				foreach (BundleStand bundleStand in this.storeBundlesBySKU[SKU].bundleStands)
				{
					bundleStand.NotifyAlreadyOwn();
				}
			}
		}

		// Token: 0x060029FF RID: 10751 RVA: 0x000CEE10 File Offset: 0x000CD010
		public void CheckIfBundlesOwned()
		{
			foreach (StoreBundle storeBundle in this.storeBundlesById.Values)
			{
				if (storeBundle.isOwned)
				{
					foreach (BundleStand bundleStand in storeBundle.bundleStands)
					{
						bundleStand.NotifyAlreadyOwn();
					}
				}
			}
		}

		// Token: 0x06002A00 RID: 10752 RVA: 0x000CEEA8 File Offset: 0x000CD0A8
		public void PressTryOnBundleButton(TryOnBundleButton pressedTryOnBundleButton, bool isLeftHand)
		{
			if (this._tryOnBundlesStand.IsNotNull())
			{
				this._tryOnBundlesStand.PressTryOnBundleButton(pressedTryOnBundleButton, isLeftHand);
			}
		}

		// Token: 0x06002A01 RID: 10753 RVA: 0x000CEEC4 File Offset: 0x000CD0C4
		public void PressPurchaseTryOnBundleButton()
		{
			this._tryOnBundlesStand.PurchaseButtonPressed();
		}

		// Token: 0x06002A02 RID: 10754 RVA: 0x000CEED4 File Offset: 0x000CD0D4
		public void UpdateBundlePrice(string productSku, string productFormattedPrice)
		{
			if (this.storeBundlesBySKU.ContainsKey(productSku))
			{
				this.storeBundlesBySKU[productSku].price = productFormattedPrice;
				this.storeBundlesBySKU[productSku].UpdatePurchaseButtonText();
				return;
			}
			Debug.LogWarning("Bundle with SKU " + productSku + " not found in storeBundlesBySKU");
		}

		// Token: 0x04002D1A RID: 11546
		public static volatile BundleManager instance;

		// Token: 0x04002D1B RID: 11547
		[FormerlySerializedAs("_TryOnBundlesStand")]
		public TryOnBundlesStand _tryOnBundlesStand;

		// Token: 0x04002D1C RID: 11548
		[SerializeField]
		private StoreBundleData nullBundleData;

		// Token: 0x04002D1D RID: 11549
		private List<StoreBundleData> _bundleScriptableObjects = new List<StoreBundleData>();

		// Token: 0x04002D1E RID: 11550
		[SerializeField]
		private List<StoreBundle> _storeBundles = new List<StoreBundle>();

		// Token: 0x04002D1F RID: 11551
		[FormerlySerializedAs("_SpawnedBundleStands")]
		[SerializeField]
		private List<SpawnedBundle> _spawnedBundleStands = new List<SpawnedBundle>();

		// Token: 0x04002D20 RID: 11552
		public Dictionary<string, StoreBundle> storeBundlesById = new Dictionary<string, StoreBundle>();

		// Token: 0x04002D21 RID: 11553
		public Dictionary<string, StoreBundle> storeBundlesBySKU = new Dictionary<string, StoreBundle>();

		// Token: 0x04002D22 RID: 11554
		[Header("Enable Advanced Search window in your settings to easily see all bundle prefabs")]
		[SerializeField]
		private List<BundleManager.BundleStandSpawn> BundleStands = new List<BundleManager.BundleStandSpawn>();

		// Token: 0x04002D23 RID: 11555
		[SerializeField]
		private StoreBundleData tryOnBundleButton1;

		// Token: 0x04002D24 RID: 11556
		[SerializeField]
		private StoreBundleData tryOnBundleButton2;

		// Token: 0x04002D25 RID: 11557
		[SerializeField]
		private StoreBundleData tryOnBundleButton3;

		// Token: 0x04002D26 RID: 11558
		[SerializeField]
		private StoreBundleData tryOnBundleButton4;

		// Token: 0x04002D27 RID: 11559
		[SerializeField]
		private StoreBundleData tryOnBundleButton5;

		// Token: 0x020006F0 RID: 1776
		[Serializable]
		public class BundleStandSpawn
		{
			// Token: 0x06002A04 RID: 10756 RVA: 0x000CEF7D File Offset: 0x000CD17D
			private static IEnumerable GetEndCapSpawnPoints()
			{
				return from x in Object.FindObjectsOfType<EndCapSpawnPoint>()
				select new ValueDropdownItem(string.Concat(new string[]
				{
					x.transform.parent.parent.name,
					"/",
					x.transform.parent.name,
					"/",
					x.name
				}), x);
			}

			// Token: 0x04002D28 RID: 11560
			public EndCapSpawnPoint spawnLocation;

			// Token: 0x04002D29 RID: 11561
			public BundleStand bundleStand;
		}
	}
}
