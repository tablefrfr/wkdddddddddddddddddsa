﻿using System;
using GorillaTag;
using Photon.Pun;
using UnityEngine;
using UnityEngine.Serialization;

// Token: 0x02000297 RID: 663
public class GeodeItem : TransferrableObject
{
	// Token: 0x06000ECB RID: 3787 RVA: 0x0004D84A File Offset: 0x0004BA4A
	public override void OnSpawn()
	{
		base.OnSpawn();
		this.hasEffectsGameObject = (this.effectsGameObject != null);
		this.effectsHaveBeenPlayed = false;
	}

	// Token: 0x06000ECC RID: 3788 RVA: 0x0004D86B File Offset: 0x0004BA6B
	protected override void Start()
	{
		base.Start();
		this.itemState = TransferrableObject.ItemStates.State0;
		this.prevItemState = TransferrableObject.ItemStates.State0;
		this.InitToDefault();
	}

	// Token: 0x06000ECD RID: 3789 RVA: 0x0004D887 File Offset: 0x0004BA87
	public override void ResetToDefaultState()
	{
		base.ResetToDefaultState();
		this.InitToDefault();
		this.itemState = TransferrableObject.ItemStates.State0;
	}

	// Token: 0x06000ECE RID: 3790 RVA: 0x0004D89C File Offset: 0x0004BA9C
	public override bool OnRelease(DropZone zoneReleased, GameObject releasingHand)
	{
		return base.OnRelease(zoneReleased, releasingHand) && this.itemState != TransferrableObject.ItemStates.State0 && !base.InHand();
	}

	// Token: 0x06000ECF RID: 3791 RVA: 0x0004D8C0 File Offset: 0x0004BAC0
	private void InitToDefault()
	{
		this.cooldownRemaining = 0f;
		this.effectsHaveBeenPlayed = false;
		if (this.hasEffectsGameObject)
		{
			this.effectsGameObject.SetActive(false);
		}
		this.geodeFullMesh.SetActive(true);
		for (int i = 0; i < this.geodeCrackedMeshes.Length; i++)
		{
			this.geodeCrackedMeshes[i].SetActive(false);
		}
		this.hitLastFrame = false;
	}

	// Token: 0x06000ED0 RID: 3792 RVA: 0x0004D928 File Offset: 0x0004BB28
	protected override void LateUpdateLocal()
	{
		base.LateUpdateLocal();
		if (this.itemState == TransferrableObject.ItemStates.State1)
		{
			this.cooldownRemaining -= Time.deltaTime;
			if (this.cooldownRemaining <= 0f)
			{
				this.itemState = TransferrableObject.ItemStates.State0;
				this.OnItemStateChanged();
			}
			return;
		}
		if (this.velocityEstimator.linearVelocity.magnitude < this.minHitVelocity)
		{
			return;
		}
		if (base.InHand())
		{
			int num = Physics.SphereCastNonAlloc(this.geodeFullMesh.transform.position, this.sphereRayRadius * Mathf.Abs(this.geodeFullMesh.transform.lossyScale.x), this.geodeFullMesh.transform.TransformDirection(Vector3.forward), this.collidersHit, this.rayCastMaxDistance, this.collisionLayerMask, QueryTriggerInteraction.Collide);
			this.hitLastFrame = (num > 0);
		}
		if (!this.hitLastFrame)
		{
			return;
		}
		if (!GorillaParent.hasInstance)
		{
			return;
		}
		this.itemState = TransferrableObject.ItemStates.State1;
		this.cooldownRemaining = this.cooldown;
		this.index = this.RandomPickCrackedGeode();
	}

	// Token: 0x06000ED1 RID: 3793 RVA: 0x0004DA33 File Offset: 0x0004BC33
	protected override void LateUpdateShared()
	{
		base.LateUpdateShared();
		this.currentItemState = this.itemState;
		if (this.currentItemState != this.prevItemState)
		{
			this.OnItemStateChanged();
		}
		this.prevItemState = this.currentItemState;
	}

	// Token: 0x06000ED2 RID: 3794 RVA: 0x0004DA68 File Offset: 0x0004BC68
	private void OnItemStateChanged()
	{
		if (this.itemState == TransferrableObject.ItemStates.State0)
		{
			this.InitToDefault();
			return;
		}
		this.geodeFullMesh.SetActive(false);
		for (int i = 0; i < this.geodeCrackedMeshes.Length; i++)
		{
			this.geodeCrackedMeshes[i].SetActive(i == this.index);
		}
		if (PhotonNetwork.InRoom && GorillaGameManager.instance != null && !this.effectsHaveBeenPlayed)
		{
			GorillaGameManager.instance.FindVRRigForPlayer(PhotonNetwork.LocalPlayer).RPC("PlayGeodeEffect", RpcTarget.All, new object[]
			{
				this.geodeFullMesh.transform.position
			});
			this.effectsHaveBeenPlayed = true;
		}
		if (!PhotonNetwork.InRoom && !this.effectsHaveBeenPlayed)
		{
			if (this.audioSource)
			{
				this.audioSource.Play();
			}
			this.effectsHaveBeenPlayed = true;
		}
	}

	// Token: 0x06000ED3 RID: 3795 RVA: 0x0004DB43 File Offset: 0x0004BD43
	private int RandomPickCrackedGeode()
	{
		return Random.Range(0, this.geodeCrackedMeshes.Length);
	}

	// Token: 0x040010B0 RID: 4272
	[Tooltip("This GameObject will activate when the geode hits the ground with enough force.")]
	public GameObject effectsGameObject;

	// Token: 0x040010B1 RID: 4273
	public LayerMask collisionLayerMask;

	// Token: 0x040010B2 RID: 4274
	[Tooltip("Used to calculate velocity of the geode.")]
	public GorillaVelocityEstimator velocityEstimator;

	// Token: 0x040010B3 RID: 4275
	public float cooldown = 5f;

	// Token: 0x040010B4 RID: 4276
	[Tooltip("The velocity of the geode must be greater than this value to activate the effect.")]
	public float minHitVelocity = 0.2f;

	// Token: 0x040010B5 RID: 4277
	[Tooltip("Geode's full mesh before cracking")]
	public GameObject geodeFullMesh;

	// Token: 0x040010B6 RID: 4278
	[Tooltip("Geode's cracked open half different meshes, picked randomly")]
	public GameObject[] geodeCrackedMeshes;

	// Token: 0x040010B7 RID: 4279
	[Tooltip("The distance between te geode and the layer mask to detect whether it hits it")]
	public float rayCastMaxDistance = 0.2f;

	// Token: 0x040010B8 RID: 4280
	[FormerlySerializedAs("collisionRadius")]
	public float sphereRayRadius = 0.05f;

	// Token: 0x040010B9 RID: 4281
	[DebugReadout]
	private float cooldownRemaining;

	// Token: 0x040010BA RID: 4282
	[DebugReadout]
	private bool hitLastFrame;

	// Token: 0x040010BB RID: 4283
	[SerializeField]
	private AudioSource audioSource;

	// Token: 0x040010BC RID: 4284
	private bool hasEffectsGameObject;

	// Token: 0x040010BD RID: 4285
	private bool effectsHaveBeenPlayed;

	// Token: 0x040010BE RID: 4286
	private RaycastHit hit;

	// Token: 0x040010BF RID: 4287
	private RaycastHit[] collidersHit = new RaycastHit[20];

	// Token: 0x040010C0 RID: 4288
	private TransferrableObject.ItemStates currentItemState;

	// Token: 0x040010C1 RID: 4289
	private TransferrableObject.ItemStates prevItemState;

	// Token: 0x040010C2 RID: 4290
	private int index;
}
