﻿using System;
using GorillaTag;
using Photon.Pun;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x02000065 RID: 101
public class FingerTorch : MonoBehaviour, ISpawnable
{
	// Token: 0x17000013 RID: 19
	// (get) Token: 0x060001FC RID: 508 RVA: 0x0000E7C5 File Offset: 0x0000C9C5
	// (set) Token: 0x060001FD RID: 509 RVA: 0x0000E7CD File Offset: 0x0000C9CD
	bool ISpawnable.IsSpawned { get; set; }

	// Token: 0x060001FE RID: 510 RVA: 0x0000E7D6 File Offset: 0x0000C9D6
	void ISpawnable.OnSpawn()
	{
		this.myRig = base.GetComponentInParent<VRRig>(true);
		if (!this.myRig)
		{
			base.gameObject.SetActive(false);
		}
	}

	// Token: 0x060001FF RID: 511 RVA: 0x00003051 File Offset: 0x00001251
	void ISpawnable.OnDespawn()
	{
	}

	// Token: 0x06000200 RID: 512 RVA: 0x0000E800 File Offset: 0x0000CA00
	protected void OnEnable()
	{
		int num = this.attachedToLeftHand ? 1 : 2;
		this.stateBitIndex = VRRig.WearablePackedStatesBitWriteInfos[num].index;
		this.OnExtendStateChanged(false);
	}

	// Token: 0x06000201 RID: 513 RVA: 0x00003051 File Offset: 0x00001251
	protected void OnDisable()
	{
	}

	// Token: 0x06000202 RID: 514 RVA: 0x0000E838 File Offset: 0x0000CA38
	private void UpdateLocal()
	{
		int node = this.attachedToLeftHand ? 4 : 5;
		bool flag = ControllerInputPoller.GripFloat((XRNode)node) > 0.25f;
		bool flag2 = ControllerInputPoller.PrimaryButtonPress((XRNode)node);
		bool flag3 = ControllerInputPoller.SecondaryButtonPress((XRNode)node);
		bool flag4 = flag && (flag2 || flag3);
		this.networkedExtended = flag4;
		if (PhotonNetwork.InRoom && this.myRig)
		{
			this.myRig.WearablePackedStates = GTBitOps.WriteBit(this.myRig.WearablePackedStates, this.stateBitIndex, this.networkedExtended);
		}
	}

	// Token: 0x06000203 RID: 515 RVA: 0x0000E8B8 File Offset: 0x0000CAB8
	private void UpdateShared()
	{
		if (this.extended != this.networkedExtended)
		{
			this.extended = this.networkedExtended;
			this.OnExtendStateChanged(true);
			this.particleFX.SetActive(this.extended);
		}
	}

	// Token: 0x06000204 RID: 516 RVA: 0x0000E8EC File Offset: 0x0000CAEC
	private void UpdateReplicated()
	{
		if (this.myRig != null && !this.myRig.isOfflineVRRig)
		{
			this.networkedExtended = GTBitOps.ReadBit(this.myRig.WearablePackedStates, this.stateBitIndex);
		}
	}

	// Token: 0x06000205 RID: 517 RVA: 0x0000E925 File Offset: 0x0000CB25
	public bool IsMyItem()
	{
		return this.myRig != null && this.myRig.isOfflineVRRig;
	}

	// Token: 0x06000206 RID: 518 RVA: 0x0000E942 File Offset: 0x0000CB42
	protected void LateUpdate()
	{
		if (this.IsMyItem())
		{
			this.UpdateLocal();
		}
		else
		{
			this.UpdateReplicated();
		}
		this.UpdateShared();
	}

	// Token: 0x06000207 RID: 519 RVA: 0x0000E960 File Offset: 0x0000CB60
	private void OnExtendStateChanged(bool playAudio)
	{
		this.audioSource.clip = (this.extended ? this.extendAudioClip : this.retractAudioClip);
		if (playAudio)
		{
			this.audioSource.Play();
		}
		if (this.IsMyItem() && GorillaTagger.Instance)
		{
			GorillaTagger.Instance.StartVibration(this.attachedToLeftHand, this.extended ? this.extendVibrationDuration : this.retractVibrationDuration, this.extended ? this.extendVibrationStrength : this.retractVibrationStrength);
		}
	}

	// Token: 0x040002C1 RID: 705
	[Header("Wearable Settings")]
	public bool attachedToLeftHand = true;

	// Token: 0x040002C2 RID: 706
	[Header("Bones")]
	public Transform pinkyRingBone;

	// Token: 0x040002C3 RID: 707
	public Transform thumbRingBone;

	// Token: 0x040002C4 RID: 708
	[Header("Audio")]
	public AudioSource audioSource;

	// Token: 0x040002C5 RID: 709
	public AudioClip extendAudioClip;

	// Token: 0x040002C6 RID: 710
	public AudioClip retractAudioClip;

	// Token: 0x040002C7 RID: 711
	[Header("Vibration")]
	public float extendVibrationDuration = 0.05f;

	// Token: 0x040002C8 RID: 712
	public float extendVibrationStrength = 0.2f;

	// Token: 0x040002C9 RID: 713
	public float retractVibrationDuration = 0.05f;

	// Token: 0x040002CA RID: 714
	public float retractVibrationStrength = 0.2f;

	// Token: 0x040002CB RID: 715
	[Header("Particle FX")]
	public GameObject particleFX;

	// Token: 0x040002CC RID: 716
	private bool networkedExtended;

	// Token: 0x040002CD RID: 717
	private bool extended;

	// Token: 0x040002CE RID: 718
	private bool fullyRetracted;

	// Token: 0x040002CF RID: 719
	private float retractExtendTime;

	// Token: 0x040002D0 RID: 720
	private InputDevice inputDevice;

	// Token: 0x040002D1 RID: 721
	private VRRig myRig;

	// Token: 0x040002D2 RID: 722
	private int stateBitIndex;
}
