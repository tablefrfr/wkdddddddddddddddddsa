﻿using System;
using GorillaExtensions;
using GorillaNetworking;
using GorillaTag;
using UnityEngine;

// Token: 0x02000291 RID: 657
public class CosmeticAnchors : MonoBehaviour, ISpawnable
{
	// Token: 0x170001B3 RID: 435
	// (get) Token: 0x06000EA1 RID: 3745 RVA: 0x0004C6FC File Offset: 0x0004A8FC
	// (set) Token: 0x06000EA2 RID: 3746 RVA: 0x0004C704 File Offset: 0x0004A904
	bool ISpawnable.IsSpawned { get; set; }

	// Token: 0x06000EA3 RID: 3747 RVA: 0x0004C710 File Offset: 0x0004A910
	void ISpawnable.OnSpawn()
	{
		this.anchorEnabled = false;
		this.vrRig = base.GetComponentInParent<VRRig>(true);
		if (!this.vrRig)
		{
			Debug.LogError("CosmeticAnchors.OnSpawn: Disabling! Could not find VRRig in parent! Path: " + base.transform.GetPathQ(), this);
			base.enabled = false;
			return;
		}
		this.anchorOverrides = this.vrRig.gameObject.GetComponent<VRRigAnchorOverrides>();
		this.AssignAnchorToPath(ref this.nameAnchor, this.nameAnchor_path);
		this.AssignAnchorToPath(ref this.leftArmAnchor, this.leftArmAnchor_path);
		this.AssignAnchorToPath(ref this.rightArmAnchor, this.rightArmAnchor_path);
		this.AssignAnchorToPath(ref this.chestAnchor, this.chestAnchor_path);
		this.AssignAnchorToPath(ref this.huntComputerAnchor, this.huntComputerAnchor_path);
		this.AssignAnchorToPath(ref this.badgeAnchor, this.badgeAnchor_path);
		this.AssignAnchorToPath(ref this.builderWatchAnchor, this.builderWatchAnchor_path);
		this.AssignAnchorToPath(ref this.friendshipBraceletLeftOverride, this.friendshipBraceletLeftOverride_path);
		this.AssignAnchorToPath(ref this.friendshipBraceletRightOverride, this.friendshipBraceletRightOverride_path);
	}

	// Token: 0x06000EA4 RID: 3748 RVA: 0x00003051 File Offset: 0x00001251
	void ISpawnable.OnDespawn()
	{
	}

	// Token: 0x06000EA5 RID: 3749 RVA: 0x0004C81C File Offset: 0x0004AA1C
	private void AssignAnchorToPath(ref GameObject anchorGObjRef, string path)
	{
		if (string.IsNullOrEmpty(path))
		{
			return;
		}
		Transform transform;
		if (!base.transform.TryFindByPath(path, out transform, false))
		{
			this.vrRig = base.GetComponentInParent<VRRig>(true);
			if (this.vrRig && this.vrRig.isOfflineVRRig)
			{
				Debug.LogError("CosmeticAnchors: Could not find path: \"" + path + "\".\nPath to this component: " + base.transform.GetPathQ(), this);
			}
			return;
		}
		anchorGObjRef = transform.gameObject;
	}

	// Token: 0x06000EA6 RID: 3750 RVA: 0x0004C894 File Offset: 0x0004AA94
	private void OnEnable()
	{
		if (this.huntComputerAnchor || this.builderWatchAnchor)
		{
			CosmeticAnchorManager.RegisterCosmeticAnchor(this);
		}
	}

	// Token: 0x06000EA7 RID: 3751 RVA: 0x0004C8B6 File Offset: 0x0004AAB6
	private void OnDisable()
	{
		if (this.huntComputerAnchor || this.builderWatchAnchor)
		{
			CosmeticAnchorManager.UnregisterCosmeticAnchor(this);
		}
	}

	// Token: 0x06000EA8 RID: 3752 RVA: 0x0004C8D8 File Offset: 0x0004AAD8
	public void TryUpdate()
	{
		if (this.anchorEnabled && this.huntComputerAnchor && !GorillaTagger.Instance.offlineVRRig.huntComputer.activeSelf && this.anchorOverrides.HuntComputer.parent != this.anchorOverrides.HuntDefaultAnchor)
		{
			this.anchorOverrides.HuntComputer.parent = this.anchorOverrides.HuntDefaultAnchor;
			return;
		}
		if (this.anchorEnabled && this.huntComputerAnchor && GorillaTagger.Instance.offlineVRRig.huntComputer.activeSelf && this.anchorOverrides.HuntComputer.parent == this.anchorOverrides.HuntDefaultAnchor)
		{
			this.SetHuntComputerAnchor(this.anchorEnabled);
		}
		if (this.anchorEnabled && this.builderWatchAnchor && !GorillaTagger.Instance.offlineVRRig.builderResizeWatch.activeSelf && this.anchorOverrides.BuilderWatch.parent != this.anchorOverrides.BuilderWatchAnchor)
		{
			this.anchorOverrides.BuilderWatch.parent = this.anchorOverrides.BuilderWatchAnchor;
			return;
		}
		if (this.anchorEnabled && this.builderWatchAnchor && GorillaTagger.Instance.offlineVRRig.builderResizeWatch.activeSelf && this.anchorOverrides.BuilderWatch.parent == this.anchorOverrides.BuilderWatchAnchor)
		{
			this.SetBuilderWatchAnchor(this.anchorEnabled);
		}
	}

	// Token: 0x06000EA9 RID: 3753 RVA: 0x0004CA6C File Offset: 0x0004AC6C
	public void EnableAnchor(bool enable)
	{
		this.anchorEnabled = enable;
		if (this.anchorOverrides == null)
		{
			return;
		}
		if (this.leftArmAnchor)
		{
			this.anchorOverrides.OverrideAnchor(TransferrableObject.PositionState.OnLeftArm, enable ? this.leftArmAnchor.transform : null);
		}
		if (this.rightArmAnchor)
		{
			this.anchorOverrides.OverrideAnchor(TransferrableObject.PositionState.OnRightArm, enable ? this.rightArmAnchor.transform : null);
		}
		if (this.chestAnchor)
		{
			this.anchorOverrides.OverrideAnchor(TransferrableObject.PositionState.OnChest, enable ? this.chestAnchor.transform : this.anchorOverrides.chestDefaultTransform);
		}
		this.anchorOverrides.UpdateNameAnchor(enable ? this.nameAnchor : null, this.slot);
		this.anchorOverrides.UpdateBadgeAnchor(enable ? this.badgeAnchor : null, this.slot);
		if (this.huntComputerAnchor)
		{
			this.SetHuntComputerAnchor(enable);
		}
		if (this.builderWatchAnchor)
		{
			this.SetBuilderWatchAnchor(enable);
		}
		this.SetCustomAnchor(this.anchorOverrides.friendshipBraceletLeftAnchor, enable, this.friendshipBraceletLeftOverride, this.anchorOverrides.friendshipBraceletLeftDefaultAnchor);
		this.SetCustomAnchor(this.anchorOverrides.friendshipBraceletRightAnchor, enable, this.friendshipBraceletRightOverride, this.anchorOverrides.friendshipBraceletRightDefaultAnchor);
	}

	// Token: 0x06000EAA RID: 3754 RVA: 0x0004CBC0 File Offset: 0x0004ADC0
	private void SetHuntComputerAnchor(bool enable)
	{
		Transform huntComputer = this.anchorOverrides.HuntComputer;
		if (!GorillaTagger.Instance.offlineVRRig.huntComputer.activeSelf || !enable)
		{
			huntComputer.parent = this.anchorOverrides.HuntDefaultAnchor;
		}
		else
		{
			huntComputer.parent = this.huntComputerAnchor.transform;
		}
		huntComputer.transform.localPosition = Vector3.zero;
		huntComputer.transform.localRotation = Quaternion.identity;
	}

	// Token: 0x06000EAB RID: 3755 RVA: 0x0004CC38 File Offset: 0x0004AE38
	private void SetBuilderWatchAnchor(bool enable)
	{
		Transform builderWatch = this.anchorOverrides.BuilderWatch;
		if (!GorillaTagger.Instance.offlineVRRig.builderResizeWatch.activeSelf || !enable)
		{
			builderWatch.parent = this.anchorOverrides.BuilderWatchAnchor;
		}
		else
		{
			builderWatch.parent = this.builderWatchAnchor.transform;
		}
		builderWatch.transform.localPosition = Vector3.zero;
		builderWatch.transform.localRotation = Quaternion.identity;
	}

	// Token: 0x06000EAC RID: 3756 RVA: 0x0004CCB0 File Offset: 0x0004AEB0
	private void SetCustomAnchor(Transform target, bool enable, GameObject overrideAnchor, Transform defaultAnchor)
	{
		Transform transform = (enable && overrideAnchor != null) ? overrideAnchor.transform : defaultAnchor;
		if (target != null && target.parent != transform)
		{
			target.parent = transform;
			target.transform.localPosition = Vector3.zero;
			target.transform.localRotation = Quaternion.identity;
			target.transform.localScale = Vector3.one;
		}
	}

	// Token: 0x06000EAD RID: 3757 RVA: 0x0004CD24 File Offset: 0x0004AF24
	public Transform GetPositionAnchor(TransferrableObject.PositionState pos)
	{
		if (pos != TransferrableObject.PositionState.OnLeftArm)
		{
			if (pos != TransferrableObject.PositionState.OnRightArm)
			{
				if (pos != TransferrableObject.PositionState.OnChest)
				{
					return null;
				}
				if (!this.chestAnchor)
				{
					return null;
				}
				return this.chestAnchor.transform;
			}
			else
			{
				if (!this.rightArmAnchor)
				{
					return null;
				}
				return this.rightArmAnchor.transform;
			}
		}
		else
		{
			if (!this.leftArmAnchor)
			{
				return null;
			}
			return this.leftArmAnchor.transform;
		}
	}

	// Token: 0x06000EAE RID: 3758 RVA: 0x0004CD92 File Offset: 0x0004AF92
	public Transform GetNameAnchor()
	{
		if (!this.nameAnchor)
		{
			return null;
		}
		return this.nameAnchor.transform;
	}

	// Token: 0x06000EAF RID: 3759 RVA: 0x0004CDAE File Offset: 0x0004AFAE
	public bool AffectedByHunt()
	{
		return this.huntComputerAnchor != null;
	}

	// Token: 0x06000EB0 RID: 3760 RVA: 0x0004CDBC File Offset: 0x0004AFBC
	public bool AffectedByBuilder()
	{
		return this.builderWatchAnchor != null;
	}

	// Token: 0x04001069 RID: 4201
	[SerializeField]
	protected GameObject nameAnchor;

	// Token: 0x0400106A RID: 4202
	[Delayed]
	[SerializeField]
	protected string nameAnchor_path;

	// Token: 0x0400106B RID: 4203
	[SerializeField]
	protected GameObject leftArmAnchor;

	// Token: 0x0400106C RID: 4204
	[Delayed]
	[SerializeField]
	protected string leftArmAnchor_path;

	// Token: 0x0400106D RID: 4205
	[SerializeField]
	protected GameObject rightArmAnchor;

	// Token: 0x0400106E RID: 4206
	[Delayed]
	[SerializeField]
	protected string rightArmAnchor_path;

	// Token: 0x0400106F RID: 4207
	[SerializeField]
	protected GameObject chestAnchor;

	// Token: 0x04001070 RID: 4208
	[Delayed]
	[SerializeField]
	protected string chestAnchor_path;

	// Token: 0x04001071 RID: 4209
	[SerializeField]
	protected GameObject huntComputerAnchor;

	// Token: 0x04001072 RID: 4210
	[Delayed]
	[SerializeField]
	protected string huntComputerAnchor_path;

	// Token: 0x04001073 RID: 4211
	[SerializeField]
	protected GameObject builderWatchAnchor;

	// Token: 0x04001074 RID: 4212
	[Delayed]
	[SerializeField]
	protected string builderWatchAnchor_path;

	// Token: 0x04001075 RID: 4213
	[SerializeField]
	protected GameObject friendshipBraceletLeftOverride;

	// Token: 0x04001076 RID: 4214
	[Delayed]
	[SerializeField]
	protected string friendshipBraceletLeftOverride_path;

	// Token: 0x04001077 RID: 4215
	[SerializeField]
	protected GameObject friendshipBraceletRightOverride;

	// Token: 0x04001078 RID: 4216
	[Delayed]
	[SerializeField]
	protected string friendshipBraceletRightOverride_path;

	// Token: 0x04001079 RID: 4217
	[SerializeField]
	protected GameObject badgeAnchor;

	// Token: 0x0400107A RID: 4218
	[Delayed]
	[SerializeField]
	protected string badgeAnchor_path;

	// Token: 0x0400107B RID: 4219
	[SerializeField]
	public CosmeticsController.CosmeticSlots slot;

	// Token: 0x0400107C RID: 4220
	private VRRig vrRig;

	// Token: 0x0400107D RID: 4221
	private VRRigAnchorOverrides anchorOverrides;

	// Token: 0x0400107E RID: 4222
	private bool anchorEnabled;

	// Token: 0x0400107F RID: 4223
	private static GTLogErrorLimiter k_debugLogError_anchorOverridesNull = new GTLogErrorLimiter("The array `anchorOverrides` was null. Is the cosmetic getting initialized properly? ", 10, "\n- ");
}
