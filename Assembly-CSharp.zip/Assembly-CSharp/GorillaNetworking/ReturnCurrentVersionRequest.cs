﻿using System;

namespace GorillaNetworking
{
	// Token: 0x020006C6 RID: 1734
	public class ReturnCurrentVersionRequest
	{
		// Token: 0x04002C3C RID: 11324
		public string CurrentVersion;

		// Token: 0x04002C3D RID: 11325
		public int? UpdatedSynchTest;
	}
}
