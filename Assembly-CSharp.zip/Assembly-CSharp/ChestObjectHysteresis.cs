﻿using System;
using GorillaExtensions;
using GorillaTag;
using UnityEngine;

// Token: 0x0200028E RID: 654
public class ChestObjectHysteresis : MonoBehaviour, ISpawnable
{
	// Token: 0x170001B2 RID: 434
	// (get) Token: 0x06000E88 RID: 3720 RVA: 0x0004C3A9 File Offset: 0x0004A5A9
	// (set) Token: 0x06000E89 RID: 3721 RVA: 0x0004C3B1 File Offset: 0x0004A5B1
	bool ISpawnable.IsSpawned { get; set; }

	// Token: 0x06000E8A RID: 3722 RVA: 0x0004C3BC File Offset: 0x0004A5BC
	void ISpawnable.OnSpawn()
	{
		if (!this.angleFollower && (string.IsNullOrEmpty(this.angleFollower_path) || base.transform.TryFindByPath(this.angleFollower_path, out this.angleFollower, false)))
		{
			Debug.LogError(string.Concat(new string[]
			{
				"ChestObjectHysteresis: DEACTIVATING! Could not find `angleFollower` using path: \"",
				this.angleFollower_path,
				"\". For component at: \"",
				this.GetComponentPath(int.MaxValue),
				"\""
			}), this);
			base.gameObject.SetActive(false);
			return;
		}
	}

	// Token: 0x06000E8B RID: 3723 RVA: 0x00003051 File Offset: 0x00001251
	void ISpawnable.OnDespawn()
	{
	}

	// Token: 0x06000E8C RID: 3724 RVA: 0x0004C44A File Offset: 0x0004A64A
	private void Start()
	{
		this.lastAngleQuat = base.transform.rotation;
		this.currentAngleQuat = base.transform.rotation;
	}

	// Token: 0x06000E8D RID: 3725 RVA: 0x0004C46E File Offset: 0x0004A66E
	private void OnEnable()
	{
		ChestObjectHysteresisManager.RegisterCH(this);
	}

	// Token: 0x06000E8E RID: 3726 RVA: 0x0004C476 File Offset: 0x0004A676
	private void OnDisable()
	{
		ChestObjectHysteresisManager.UnregisterCH(this);
	}

	// Token: 0x06000E8F RID: 3727 RVA: 0x0004C480 File Offset: 0x0004A680
	public void InvokeUpdate()
	{
		this.currentAngleQuat = this.angleFollower.rotation;
		this.angleBetween = Quaternion.Angle(this.currentAngleQuat, this.lastAngleQuat);
		if (this.angleBetween > this.angleHysteresis)
		{
			base.transform.rotation = Quaternion.Slerp(this.currentAngleQuat, this.lastAngleQuat, this.angleHysteresis / this.angleBetween);
			this.lastAngleQuat = base.transform.rotation;
		}
		base.transform.rotation = this.lastAngleQuat;
	}

	// Token: 0x0400105C RID: 4188
	public float angleHysteresis;

	// Token: 0x0400105D RID: 4189
	public float angleBetween;

	// Token: 0x0400105E RID: 4190
	public Transform angleFollower;

	// Token: 0x0400105F RID: 4191
	[Delayed]
	public string angleFollower_path;

	// Token: 0x04001060 RID: 4192
	private Quaternion lastAngleQuat;

	// Token: 0x04001061 RID: 4193
	private Quaternion currentAngleQuat;
}
