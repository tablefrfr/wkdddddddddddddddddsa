﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using GorillaGameModes;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x0200035D RID: 861
public class GorillaBattleManager : GorillaGameManager
{
	// Token: 0x06001388 RID: 5000 RVA: 0x00067056 File Offset: 0x00065256
	private void ActivateBattleBalloons(bool enable)
	{
		if (GorillaTagger.Instance.offlineVRRig != null)
		{
			GorillaTagger.Instance.offlineVRRig.battleBalloons.gameObject.SetActive(enable);
		}
	}

	// Token: 0x06001389 RID: 5001 RVA: 0x00067084 File Offset: 0x00065284
	private bool HasFlag(GorillaBattleManager.BattleStatus state, GorillaBattleManager.BattleStatus statusFlag)
	{
		return (state & statusFlag) > GorillaBattleManager.BattleStatus.None;
	}

	// Token: 0x0600138A RID: 5002 RVA: 0x0006708C File Offset: 0x0006528C
	public override GameModeType GameType()
	{
		return GameModeType.Battle;
	}

	// Token: 0x0600138B RID: 5003 RVA: 0x0006708F File Offset: 0x0006528F
	public override string GameModeName()
	{
		return "BATTLE";
	}

	// Token: 0x0600138C RID: 5004 RVA: 0x00067098 File Offset: 0x00065298
	private void ActivateDefaultSlingShot()
	{
		VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
		if (offlineVRRig != null && !Slingshot.IsSlingShotEnabled())
		{
			CosmeticsController instance = CosmeticsController.instance;
			CosmeticsController.CosmeticItem itemFromDict = instance.GetItemFromDict("Slingshot");
			instance.ApplyCosmeticItemToSet(offlineVRRig.cosmeticSet, itemFromDict, true, false);
		}
	}

	// Token: 0x0600138D RID: 5005 RVA: 0x000670E2 File Offset: 0x000652E2
	public override void Awake()
	{
		base.Awake();
		this.coroutineRunning = false;
		this.currentState = GorillaBattleManager.BattleState.NotEnoughPlayers;
	}

	// Token: 0x0600138E RID: 5006 RVA: 0x000670F8 File Offset: 0x000652F8
	public override void StartPlaying()
	{
		base.StartPlaying();
		this.ActivateBattleBalloons(true);
		this.VerifyPlayersInDict<int>(this.playerLives);
		this.VerifyPlayersInDict<GorillaBattleManager.BattleStatus>(this.playerStatusDict);
		this.VerifyPlayersInDict<float>(this.playerHitTimes);
		this.VerifyPlayersInDict<float>(this.playerStunTimes);
		this.CopyBattleDictToArray();
		this.UpdateBattleState();
	}

	// Token: 0x0600138F RID: 5007 RVA: 0x00067150 File Offset: 0x00065350
	public override void StopPlaying()
	{
		base.StopPlaying();
		if (Slingshot.IsSlingShotEnabled())
		{
			CosmeticsController instance = CosmeticsController.instance;
			VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
			CosmeticsController.CosmeticItem itemFromDict = instance.GetItemFromDict("Slingshot");
			if (offlineVRRig.cosmeticSet.HasItem("Slingshot"))
			{
				instance.ApplyCosmeticItemToSet(offlineVRRig.cosmeticSet, itemFromDict, true, false);
			}
		}
		this.ActivateBattleBalloons(false);
		base.StopAllCoroutines();
		this.coroutineRunning = false;
	}

	// Token: 0x06001390 RID: 5008 RVA: 0x000671C0 File Offset: 0x000653C0
	public override void Reset()
	{
		base.Reset();
		this.playerLives.Clear();
		this.playerStatusDict.Clear();
		this.playerHitTimes.Clear();
		this.playerStunTimes.Clear();
		for (int i = 0; i < this.playerActorNumberArray.Length; i++)
		{
			this.playerLivesArray[i] = 0;
			this.playerActorNumberArray[i] = 0;
			this.playerStatusArray[i] = GorillaBattleManager.BattleStatus.None;
		}
		this.currentState = GorillaBattleManager.BattleState.NotEnoughPlayers;
	}

	// Token: 0x06001391 RID: 5009 RVA: 0x00067234 File Offset: 0x00065434
	private void VerifyPlayersInDict<T>(Dictionary<int, T> dict)
	{
		if (dict.Count < 1)
		{
			return;
		}
		int[] array = dict.Keys.ToArray<int>();
		for (int i = 0; i < array.Length; i++)
		{
			if (!Utils.PlayerInRoom(array[i]))
			{
				dict.Remove(array[i]);
			}
		}
	}

	// Token: 0x06001392 RID: 5010 RVA: 0x00067279 File Offset: 0x00065479
	internal override void NetworkLinkSetup(GameModeSerializer netSerializer)
	{
		base.NetworkLinkSetup(netSerializer);
		netSerializer.AddRPCComponent<BattleRPCs>();
	}

	// Token: 0x06001393 RID: 5011 RVA: 0x00067289 File Offset: 0x00065489
	private void Transition(GorillaBattleManager.BattleState newState)
	{
		this.currentState = newState;
		Debug.Log("current state is: " + this.currentState.ToString());
	}

	// Token: 0x06001394 RID: 5012 RVA: 0x000672B4 File Offset: 0x000654B4
	public void UpdateBattleState()
	{
		if (PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			switch (this.currentState)
			{
			case GorillaBattleManager.BattleState.NotEnoughPlayers:
				if ((float)RoomSystem.PlayersInRoom.Count >= this.playerMin)
				{
					this.Transition(GorillaBattleManager.BattleState.StartCountdown);
				}
				break;
			case GorillaBattleManager.BattleState.GameEnd:
				if (this.EndBattleGame())
				{
					this.Transition(GorillaBattleManager.BattleState.GameEndWaiting);
				}
				break;
			case GorillaBattleManager.BattleState.GameEndWaiting:
				if (this.BattleEnd())
				{
					this.Transition(GorillaBattleManager.BattleState.StartCountdown);
				}
				break;
			case GorillaBattleManager.BattleState.StartCountdown:
				this.RandomizeTeams();
				this.ActivateBattleBalloons(true);
				base.StartCoroutine(this.StartBattleCountdown());
				this.Transition(GorillaBattleManager.BattleState.CountingDownToStart);
				break;
			case GorillaBattleManager.BattleState.CountingDownToStart:
				if (!this.coroutineRunning)
				{
					this.Transition(GorillaBattleManager.BattleState.StartCountdown);
				}
				break;
			case GorillaBattleManager.BattleState.GameStart:
				this.StartBattle();
				this.Transition(GorillaBattleManager.BattleState.GameRunning);
				break;
			case GorillaBattleManager.BattleState.GameRunning:
				if (this.CheckForGameEnd())
				{
					this.Transition(GorillaBattleManager.BattleState.GameEnd);
				}
				if ((float)RoomSystem.PlayersInRoom.Count < this.playerMin)
				{
					this.InitializePlayerStatus();
					this.ActivateBattleBalloons(false);
					this.Transition(GorillaBattleManager.BattleState.NotEnoughPlayers);
				}
				break;
			}
			this.UpdatePlayerStatus();
		}
	}

	// Token: 0x06001395 RID: 5013 RVA: 0x000673C4 File Offset: 0x000655C4
	private bool CheckForGameEnd()
	{
		this.bcount = 0;
		this.rcount = 0;
		foreach (Player player in RoomSystem.PlayersInRoom)
		{
			if (this.playerLives.TryGetValue(player.ActorNumber, out this.lives))
			{
				if (this.lives > 0 && this.playerStatusDict.TryGetValue(player.ActorNumber, out this.tempStatus))
				{
					if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.RedTeam))
					{
						this.rcount++;
					}
					else if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.BlueTeam))
					{
						this.bcount++;
					}
				}
			}
			else
			{
				this.playerLives.Add(player.ActorNumber, 0);
			}
		}
		return this.bcount == 0 || this.rcount == 0;
	}

	// Token: 0x06001396 RID: 5014 RVA: 0x000674C4 File Offset: 0x000656C4
	public IEnumerator StartBattleCountdown()
	{
		this.coroutineRunning = true;
		this.countDownTime = 5;
		while (this.countDownTime > 0)
		{
			try
			{
				RoomSystem.SendSoundEffectAll(6, 0.25f);
				foreach (Player player in RoomSystem.PlayersInRoom)
				{
					this.playerLives[player.ActorNumber] = 3;
				}
			}
			catch
			{
			}
			yield return new WaitForSeconds(1f);
			this.countDownTime--;
		}
		this.coroutineRunning = false;
		this.currentState = GorillaBattleManager.BattleState.GameStart;
		yield return null;
		yield break;
	}

	// Token: 0x06001397 RID: 5015 RVA: 0x000674D4 File Offset: 0x000656D4
	public void StartBattle()
	{
		RoomSystem.SendSoundEffectAll(7, 0.5f);
		foreach (Player player in RoomSystem.PlayersInRoom)
		{
			this.playerLives[player.ActorNumber] = 3;
		}
	}

	// Token: 0x06001398 RID: 5016 RVA: 0x0006753C File Offset: 0x0006573C
	private bool EndBattleGame()
	{
		if ((float)RoomSystem.PlayersInRoom.Count >= this.playerMin)
		{
			RoomSystem.SendStatusEffectAll(RoomSystem.StatusEffects.TaggedTime);
			RoomSystem.SendSoundEffectAll(2, 0.25f);
			this.timeBattleEnded = Time.time;
			return true;
		}
		return false;
	}

	// Token: 0x06001399 RID: 5017 RVA: 0x00067570 File Offset: 0x00065770
	public bool BattleEnd()
	{
		return Time.time > this.timeBattleEnded + this.tagCoolDown;
	}

	// Token: 0x0600139A RID: 5018 RVA: 0x00067586 File Offset: 0x00065786
	public bool SlingshotHit(Player myPlayer, Player otherPlayer)
	{
		return this.playerLives.TryGetValue(otherPlayer.ActorNumber, out this.lives) && this.lives > 0;
	}

	// Token: 0x0600139B RID: 5019 RVA: 0x000675AC File Offset: 0x000657AC
	public void ReportSlingshotHit(Player taggedPlayer, Vector3 hitLocation, int projectileCount, PhotonMessageInfo info)
	{
		if (!PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			return;
		}
		if (this.currentState != GorillaBattleManager.BattleState.GameRunning)
		{
			return;
		}
		if (this.OnSameTeam(taggedPlayer, info.Sender))
		{
			return;
		}
		if (this.GetPlayerLives(taggedPlayer) > 0 && this.GetPlayerLives(info.Sender) > 0 && !this.PlayerInHitCooldown(taggedPlayer))
		{
			if (!this.playerHitTimes.TryGetValue(taggedPlayer.ActorNumber, out this.outHitTime))
			{
				this.playerHitTimes.Add(taggedPlayer.ActorNumber, Time.time);
			}
			else
			{
				this.playerHitTimes[taggedPlayer.ActorNumber] = Time.time;
			}
			Dictionary<int, int> dictionary = this.playerLives;
			int actorNumber = taggedPlayer.ActorNumber;
			int num = dictionary[actorNumber];
			dictionary[actorNumber] = num - 1;
			RoomSystem.SendSoundEffectOnOther(0, 0.25f, taggedPlayer);
			return;
		}
		if (this.GetPlayerLives(info.Sender) == 0 && this.GetPlayerLives(taggedPlayer) > 0)
		{
			this.tempStatus = this.GetPlayerStatus(taggedPlayer);
			if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Normal) && !this.PlayerInHitCooldown(taggedPlayer) && !this.PlayerInStunCooldown(taggedPlayer))
			{
				if (!this.playerStunTimes.TryGetValue(taggedPlayer.ActorNumber, out this.outHitTime))
				{
					this.playerStunTimes.Add(taggedPlayer.ActorNumber, Time.time);
				}
				else
				{
					this.playerStunTimes[taggedPlayer.ActorNumber] = Time.time;
				}
				RoomSystem.SendStatusEffectToPlayer(RoomSystem.StatusEffects.SetSlowedTime, taggedPlayer);
				RoomSystem.SendSoundEffectOnOther(5, 0.125f, taggedPlayer);
				this.tempView = this.FindVRRigForPlayer(taggedPlayer);
			}
		}
	}

	// Token: 0x0600139C RID: 5020 RVA: 0x0006772D File Offset: 0x0006592D
	public override void HitPlayer(Player player)
	{
		if (!PhotonNetwork.LocalPlayer.IsMasterClient || this.currentState != GorillaBattleManager.BattleState.GameRunning)
		{
			return;
		}
		if (this.GetPlayerLives(player) > 0)
		{
			this.playerLives[player.ActorNumber] = 0;
			RoomSystem.SendSoundEffectOnOther(0, 0.25f, player);
		}
	}

	// Token: 0x0600139D RID: 5021 RVA: 0x0006776D File Offset: 0x0006596D
	public override bool CanAffectPlayer(Player player, bool thisFrame)
	{
		return this.playerLives.TryGetValue(player.ActorNumber, out this.lives) && this.lives > 0;
	}

	// Token: 0x0600139E RID: 5022 RVA: 0x00067794 File Offset: 0x00065994
	public override void OnPlayerEnteredRoom(Player newPlayer)
	{
		base.OnPlayerEnteredRoom(newPlayer);
		if (PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			if (this.currentState == GorillaBattleManager.BattleState.GameRunning)
			{
				this.playerLives.Add(newPlayer.ActorNumber, 0);
			}
			else
			{
				this.playerLives.Add(newPlayer.ActorNumber, 3);
			}
			this.playerStatusDict.Add(newPlayer.ActorNumber, GorillaBattleManager.BattleStatus.None);
			this.CopyBattleDictToArray();
			this.AddPlayerToCorrectTeam(newPlayer);
		}
	}

	// Token: 0x0600139F RID: 5023 RVA: 0x00067804 File Offset: 0x00065A04
	public override void OnPlayerLeftRoom(Player otherPlayer)
	{
		base.OnPlayerLeftRoom(otherPlayer);
		if (this.playerLives.ContainsKey(otherPlayer.ActorNumber))
		{
			this.playerLives.Remove(otherPlayer.ActorNumber);
		}
		if (this.playerStatusDict.ContainsKey(otherPlayer.ActorNumber))
		{
			this.playerStatusDict.Remove(otherPlayer.ActorNumber);
		}
	}

	// Token: 0x060013A0 RID: 5024 RVA: 0x00067864 File Offset: 0x00065A64
	public override void OnSerializeWrite(PhotonStream stream, PhotonMessageInfo info)
	{
		this.CopyBattleDictToArray();
		for (int i = 0; i < this.playerLivesArray.Length; i++)
		{
			stream.SendNext(this.playerActorNumberArray[i]);
			stream.SendNext(this.playerLivesArray[i]);
			stream.SendNext(this.playerStatusArray[i]);
		}
		stream.SendNext((int)this.currentState);
	}

	// Token: 0x060013A1 RID: 5025 RVA: 0x000678D4 File Offset: 0x00065AD4
	public override void OnSerializeRead(PhotonStream stream, PhotonMessageInfo info)
	{
		for (int i = 0; i < this.playerLivesArray.Length; i++)
		{
			this.playerActorNumberArray[i] = (int)stream.ReceiveNext();
			this.playerLivesArray[i] = (int)stream.ReceiveNext();
			this.playerStatusArray[i] = (GorillaBattleManager.BattleStatus)stream.ReceiveNext();
		}
		this.currentState = (GorillaBattleManager.BattleState)stream.ReceiveNext();
		this.CopyArrayToBattleDict();
	}

	// Token: 0x060013A2 RID: 5026 RVA: 0x00067944 File Offset: 0x00065B44
	public override int MyMatIndex(Player forPlayer)
	{
		this.tempStatus = this.GetPlayerStatus(forPlayer);
		if (this.tempStatus != GorillaBattleManager.BattleStatus.None)
		{
			if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.RedTeam))
			{
				if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Normal))
				{
					return 8;
				}
				if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Hit))
				{
					return 9;
				}
				if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Stunned))
				{
					return 10;
				}
				if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Grace))
				{
					return 10;
				}
				if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Eliminated))
				{
					return 11;
				}
			}
			else
			{
				if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Normal))
				{
					return 4;
				}
				if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Hit))
				{
					return 5;
				}
				if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Stunned))
				{
					return 6;
				}
				if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Grace))
				{
					return 6;
				}
				if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Eliminated))
				{
					return 7;
				}
			}
		}
		return 0;
	}

	// Token: 0x060013A3 RID: 5027 RVA: 0x00067A30 File Offset: 0x00065C30
	public override float[] LocalPlayerSpeed()
	{
		if (this.playerStatusDict.TryGetValue(PhotonNetwork.LocalPlayer.ActorNumber, out this.tempStatus))
		{
			if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Normal))
			{
				this.playerSpeed[0] = 6.5f;
				this.playerSpeed[1] = 1.1f;
				return this.playerSpeed;
			}
			if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Stunned))
			{
				this.playerSpeed[0] = 2f;
				this.playerSpeed[1] = 0.5f;
				return this.playerSpeed;
			}
			if (this.HasFlag(this.tempStatus, GorillaBattleManager.BattleStatus.Eliminated))
			{
				this.playerSpeed[0] = this.fastJumpLimit;
				this.playerSpeed[1] = this.fastJumpMultiplier;
				return this.playerSpeed;
			}
		}
		this.playerSpeed[0] = 6.5f;
		this.playerSpeed[1] = 1.1f;
		return this.playerSpeed;
	}

	// Token: 0x060013A4 RID: 5028 RVA: 0x00067B11 File Offset: 0x00065D11
	public override void Tick()
	{
		base.Tick();
		if (PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			this.UpdateBattleState();
		}
		this.ActivateDefaultSlingShot();
	}

	// Token: 0x060013A5 RID: 5029 RVA: 0x00067B34 File Offset: 0x00065D34
	public override void InfrequentUpdate()
	{
		base.InfrequentUpdate();
		foreach (int num in this.playerLives.Keys)
		{
			this.playerInList = false;
			using (List<Player>.Enumerator enumerator2 = RoomSystem.PlayersInRoom.GetEnumerator())
			{
				while (enumerator2.MoveNext())
				{
					if (enumerator2.Current.ActorNumber == num)
					{
						this.playerInList = true;
					}
				}
			}
			if (!this.playerInList)
			{
				this.playerLives.Remove(num);
			}
		}
	}

	// Token: 0x060013A6 RID: 5030 RVA: 0x00067BF0 File Offset: 0x00065DF0
	public int GetPlayerLives(Player player)
	{
		if (player == null)
		{
			return 0;
		}
		if (this.playerLives.TryGetValue(player.ActorNumber, out this.outLives))
		{
			return this.outLives;
		}
		return 0;
	}

	// Token: 0x060013A7 RID: 5031 RVA: 0x00067C18 File Offset: 0x00065E18
	public bool PlayerInHitCooldown(Player player)
	{
		float num;
		return this.playerHitTimes.TryGetValue(player.ActorNumber, out num) && num + this.hitCooldown > Time.time;
	}

	// Token: 0x060013A8 RID: 5032 RVA: 0x00067C4C File Offset: 0x00065E4C
	public bool PlayerInStunCooldown(Player player)
	{
		float num;
		return this.playerStunTimes.TryGetValue(player.ActorNumber, out num) && num + this.hitCooldown + this.stunGracePeriod > Time.time;
	}

	// Token: 0x060013A9 RID: 5033 RVA: 0x00067C86 File Offset: 0x00065E86
	public GorillaBattleManager.BattleStatus GetPlayerStatus(Player player)
	{
		if (this.playerStatusDict.TryGetValue(player.ActorNumber, out this.tempStatus))
		{
			return this.tempStatus;
		}
		return GorillaBattleManager.BattleStatus.None;
	}

	// Token: 0x060013AA RID: 5034 RVA: 0x00067CA9 File Offset: 0x00065EA9
	public bool OnRedTeam(GorillaBattleManager.BattleStatus status)
	{
		return this.HasFlag(status, GorillaBattleManager.BattleStatus.RedTeam);
	}

	// Token: 0x060013AB RID: 5035 RVA: 0x00067CB4 File Offset: 0x00065EB4
	public bool OnRedTeam(Player player)
	{
		GorillaBattleManager.BattleStatus playerStatus = this.GetPlayerStatus(player);
		return this.OnRedTeam(playerStatus);
	}

	// Token: 0x060013AC RID: 5036 RVA: 0x00067CD0 File Offset: 0x00065ED0
	public bool OnBlueTeam(GorillaBattleManager.BattleStatus status)
	{
		return this.HasFlag(status, GorillaBattleManager.BattleStatus.BlueTeam);
	}

	// Token: 0x060013AD RID: 5037 RVA: 0x00067CDC File Offset: 0x00065EDC
	public bool OnBlueTeam(Player player)
	{
		GorillaBattleManager.BattleStatus playerStatus = this.GetPlayerStatus(player);
		return this.OnBlueTeam(playerStatus);
	}

	// Token: 0x060013AE RID: 5038 RVA: 0x00067CF8 File Offset: 0x00065EF8
	public bool OnNoTeam(GorillaBattleManager.BattleStatus status)
	{
		return !this.OnRedTeam(status) && !this.OnBlueTeam(status);
	}

	// Token: 0x060013AF RID: 5039 RVA: 0x00067D10 File Offset: 0x00065F10
	public bool OnNoTeam(Player player)
	{
		GorillaBattleManager.BattleStatus playerStatus = this.GetPlayerStatus(player);
		return this.OnNoTeam(playerStatus);
	}

	// Token: 0x060013B0 RID: 5040 RVA: 0x00002076 File Offset: 0x00000276
	public override bool LocalCanTag(Player myPlayer, Player otherPlayer)
	{
		return false;
	}

	// Token: 0x060013B1 RID: 5041 RVA: 0x00067D2C File Offset: 0x00065F2C
	public bool OnSameTeam(GorillaBattleManager.BattleStatus playerA, GorillaBattleManager.BattleStatus playerB)
	{
		bool flag = this.OnRedTeam(playerA) && this.OnRedTeam(playerB);
		bool flag2 = this.OnBlueTeam(playerA) && this.OnBlueTeam(playerB);
		return flag || flag2;
	}

	// Token: 0x060013B2 RID: 5042 RVA: 0x00067D64 File Offset: 0x00065F64
	public bool OnSameTeam(Player myPlayer, Player otherPlayer)
	{
		GorillaBattleManager.BattleStatus playerStatus = this.GetPlayerStatus(myPlayer);
		GorillaBattleManager.BattleStatus playerStatus2 = this.GetPlayerStatus(otherPlayer);
		return this.OnSameTeam(playerStatus, playerStatus2);
	}

	// Token: 0x060013B3 RID: 5043 RVA: 0x00067D8C File Offset: 0x00065F8C
	public bool LocalCanHit(Player myPlayer, Player otherPlayer)
	{
		bool flag = !this.OnSameTeam(myPlayer, otherPlayer);
		bool flag2 = this.GetPlayerLives(otherPlayer) != 0;
		return flag && flag2;
	}

	// Token: 0x060013B4 RID: 5044 RVA: 0x00067DB4 File Offset: 0x00065FB4
	private void CopyBattleDictToArray()
	{
		for (int i = 0; i < this.playerLivesArray.Length; i++)
		{
			this.playerLivesArray[i] = 0;
			this.playerActorNumberArray[i] = 0;
		}
		this.keyValuePairs = this.playerLives.ToArray<KeyValuePair<int, int>>();
		int num = 0;
		while (num < this.playerLivesArray.Length && num < this.keyValuePairs.Length)
		{
			this.playerActorNumberArray[num] = this.keyValuePairs[num].Key;
			this.playerLivesArray[num] = this.keyValuePairs[num].Value;
			this.playerStatusArray[num] = this.GetPlayerStatus(PhotonNetwork.LocalPlayer.Get(this.keyValuePairs[num].Key));
			num++;
		}
	}

	// Token: 0x060013B5 RID: 5045 RVA: 0x00067E70 File Offset: 0x00066070
	private void CopyArrayToBattleDict()
	{
		for (int i = 0; i < this.playerLivesArray.Length; i++)
		{
			if (this.playerActorNumberArray[i] != 0 && Utils.PlayerInRoom(this.playerActorNumberArray[i]))
			{
				if (this.playerLives.TryGetValue(this.playerActorNumberArray[i], out this.outLives))
				{
					this.playerLives[this.playerActorNumberArray[i]] = this.playerLivesArray[i];
				}
				else
				{
					this.playerLives.Add(this.playerActorNumberArray[i], this.playerLivesArray[i]);
				}
				if (this.playerStatusDict.ContainsKey(this.playerActorNumberArray[i]))
				{
					this.playerStatusDict[this.playerActorNumberArray[i]] = this.playerStatusArray[i];
				}
				else
				{
					this.playerStatusDict.Add(this.playerActorNumberArray[i], this.playerStatusArray[i]);
				}
			}
		}
	}

	// Token: 0x060013B6 RID: 5046 RVA: 0x00067F55 File Offset: 0x00066155
	private GorillaBattleManager.BattleStatus SetFlag(GorillaBattleManager.BattleStatus currState, GorillaBattleManager.BattleStatus flag)
	{
		return currState | flag;
	}

	// Token: 0x060013B7 RID: 5047 RVA: 0x00067F5A File Offset: 0x0006615A
	private GorillaBattleManager.BattleStatus SetFlagExclusive(GorillaBattleManager.BattleStatus currState, GorillaBattleManager.BattleStatus flag)
	{
		return flag;
	}

	// Token: 0x060013B8 RID: 5048 RVA: 0x00067F5D File Offset: 0x0006615D
	private GorillaBattleManager.BattleStatus ClearFlag(GorillaBattleManager.BattleStatus currState, GorillaBattleManager.BattleStatus flag)
	{
		return currState & ~flag;
	}

	// Token: 0x060013B9 RID: 5049 RVA: 0x00067084 File Offset: 0x00065284
	private bool FlagIsSet(GorillaBattleManager.BattleStatus currState, GorillaBattleManager.BattleStatus flag)
	{
		return (currState & flag) > GorillaBattleManager.BattleStatus.None;
	}

	// Token: 0x060013BA RID: 5050 RVA: 0x00067F64 File Offset: 0x00066164
	public void RandomizeTeams()
	{
		int[] array = new int[RoomSystem.PlayersInRoom.Count];
		for (int i = 0; i < RoomSystem.PlayersInRoom.Count; i++)
		{
			array[i] = i;
		}
		Random rand = new Random();
		int[] array2 = (from x in array
		orderby rand.Next()
		select x).ToArray<int>();
		GorillaBattleManager.BattleStatus battleStatus = (rand.Next(0, 2) == 0) ? GorillaBattleManager.BattleStatus.RedTeam : GorillaBattleManager.BattleStatus.BlueTeam;
		GorillaBattleManager.BattleStatus battleStatus2 = (battleStatus == GorillaBattleManager.BattleStatus.RedTeam) ? GorillaBattleManager.BattleStatus.BlueTeam : GorillaBattleManager.BattleStatus.RedTeam;
		for (int j = 0; j < RoomSystem.PlayersInRoom.Count; j++)
		{
			GorillaBattleManager.BattleStatus value = (array2[j] % 2 == 0) ? battleStatus2 : battleStatus;
			this.playerStatusDict[RoomSystem.PlayersInRoom[j].ActorNumber] = value;
		}
	}

	// Token: 0x060013BB RID: 5051 RVA: 0x00068030 File Offset: 0x00066230
	public void AddPlayerToCorrectTeam(Player newPlayer)
	{
		this.rcount = 0;
		for (int i = 0; i < RoomSystem.PlayersInRoom.Count; i++)
		{
			if (this.playerStatusDict.ContainsKey(RoomSystem.PlayersInRoom[i].ActorNumber))
			{
				GorillaBattleManager.BattleStatus state = this.playerStatusDict[RoomSystem.PlayersInRoom[i].ActorNumber];
				this.rcount = (this.HasFlag(state, GorillaBattleManager.BattleStatus.RedTeam) ? (this.rcount + 1) : this.rcount);
			}
		}
		if ((RoomSystem.PlayersInRoom.Count - 1) / 2 == this.rcount)
		{
			this.playerStatusDict[newPlayer.ActorNumber] = ((Random.Range(0, 2) == 0) ? this.SetFlag(this.playerStatusDict[newPlayer.ActorNumber], GorillaBattleManager.BattleStatus.RedTeam) : this.SetFlag(this.playerStatusDict[newPlayer.ActorNumber], GorillaBattleManager.BattleStatus.BlueTeam));
			return;
		}
		if (this.rcount <= (RoomSystem.PlayersInRoom.Count - 1) / 2)
		{
			this.playerStatusDict[newPlayer.ActorNumber] = this.SetFlag(this.playerStatusDict[newPlayer.ActorNumber], GorillaBattleManager.BattleStatus.RedTeam);
		}
	}

	// Token: 0x060013BC RID: 5052 RVA: 0x00068154 File Offset: 0x00066354
	private void InitializePlayerStatus()
	{
		this.keyValuePairsStatus = this.playerStatusDict.ToArray<KeyValuePair<int, GorillaBattleManager.BattleStatus>>();
		foreach (KeyValuePair<int, GorillaBattleManager.BattleStatus> keyValuePair in this.keyValuePairsStatus)
		{
			this.playerStatusDict[keyValuePair.Key] = GorillaBattleManager.BattleStatus.Normal;
		}
	}

	// Token: 0x060013BD RID: 5053 RVA: 0x000681A4 File Offset: 0x000663A4
	private void UpdatePlayerStatus()
	{
		this.keyValuePairsStatus = this.playerStatusDict.ToArray<KeyValuePair<int, GorillaBattleManager.BattleStatus>>();
		foreach (KeyValuePair<int, GorillaBattleManager.BattleStatus> keyValuePair in this.keyValuePairsStatus)
		{
			GorillaBattleManager.BattleStatus battleStatus = this.HasFlag(this.playerStatusDict[keyValuePair.Key], GorillaBattleManager.BattleStatus.RedTeam) ? GorillaBattleManager.BattleStatus.RedTeam : GorillaBattleManager.BattleStatus.BlueTeam;
			if (this.playerLives.TryGetValue(keyValuePair.Key, out this.outLives) && this.outLives == 0)
			{
				this.playerStatusDict[keyValuePair.Key] = (battleStatus | GorillaBattleManager.BattleStatus.Eliminated);
			}
			else if (this.playerHitTimes.TryGetValue(keyValuePair.Key, out this.outHitTime) && this.outHitTime + this.hitCooldown > Time.time)
			{
				this.playerStatusDict[keyValuePair.Key] = (battleStatus | GorillaBattleManager.BattleStatus.Hit);
			}
			else if (this.playerStunTimes.TryGetValue(keyValuePair.Key, out this.outHitTime))
			{
				if (this.outHitTime + this.hitCooldown > Time.time)
				{
					this.playerStatusDict[keyValuePair.Key] = (battleStatus | GorillaBattleManager.BattleStatus.Stunned);
				}
				else if (this.outHitTime + this.hitCooldown + this.stunGracePeriod > Time.time)
				{
					this.playerStatusDict[keyValuePair.Key] = (battleStatus | GorillaBattleManager.BattleStatus.Grace);
				}
				else
				{
					this.playerStatusDict[keyValuePair.Key] = (battleStatus | GorillaBattleManager.BattleStatus.Normal);
				}
			}
			else
			{
				this.playerStatusDict[keyValuePair.Key] = (battleStatus | GorillaBattleManager.BattleStatus.Normal);
			}
		}
	}

	// Token: 0x0400165B RID: 5723
	private float playerMin = 2f;

	// Token: 0x0400165C RID: 5724
	public float tagCoolDown = 5f;

	// Token: 0x0400165D RID: 5725
	public Dictionary<int, int> playerLives = new Dictionary<int, int>();

	// Token: 0x0400165E RID: 5726
	public Dictionary<int, GorillaBattleManager.BattleStatus> playerStatusDict = new Dictionary<int, GorillaBattleManager.BattleStatus>();

	// Token: 0x0400165F RID: 5727
	public Dictionary<int, float> playerHitTimes = new Dictionary<int, float>();

	// Token: 0x04001660 RID: 5728
	public Dictionary<int, float> playerStunTimes = new Dictionary<int, float>();

	// Token: 0x04001661 RID: 5729
	public int[] playerActorNumberArray = new int[10];

	// Token: 0x04001662 RID: 5730
	public int[] playerLivesArray = new int[10];

	// Token: 0x04001663 RID: 5731
	public GorillaBattleManager.BattleStatus[] playerStatusArray = new GorillaBattleManager.BattleStatus[10];

	// Token: 0x04001664 RID: 5732
	public bool teamBattle = true;

	// Token: 0x04001665 RID: 5733
	public int countDownTime;

	// Token: 0x04001666 RID: 5734
	private float timeBattleEnded;

	// Token: 0x04001667 RID: 5735
	public float hitCooldown = 3f;

	// Token: 0x04001668 RID: 5736
	public float stunGracePeriod = 2f;

	// Token: 0x04001669 RID: 5737
	public object objRef;

	// Token: 0x0400166A RID: 5738
	private bool playerInList;

	// Token: 0x0400166B RID: 5739
	private bool coroutineRunning;

	// Token: 0x0400166C RID: 5740
	private int lives;

	// Token: 0x0400166D RID: 5741
	private int outLives;

	// Token: 0x0400166E RID: 5742
	private int bcount;

	// Token: 0x0400166F RID: 5743
	private int rcount;

	// Token: 0x04001670 RID: 5744
	private int randInt;

	// Token: 0x04001671 RID: 5745
	private float outHitTime;

	// Token: 0x04001672 RID: 5746
	private PhotonView tempView;

	// Token: 0x04001673 RID: 5747
	private KeyValuePair<int, int>[] keyValuePairs;

	// Token: 0x04001674 RID: 5748
	private KeyValuePair<int, GorillaBattleManager.BattleStatus>[] keyValuePairsStatus;

	// Token: 0x04001675 RID: 5749
	private GorillaBattleManager.BattleStatus tempStatus;

	// Token: 0x04001676 RID: 5750
	private GorillaBattleManager.BattleState currentState;

	// Token: 0x0200035E RID: 862
	public enum BattleStatus
	{
		// Token: 0x04001678 RID: 5752
		RedTeam = 1,
		// Token: 0x04001679 RID: 5753
		BlueTeam,
		// Token: 0x0400167A RID: 5754
		Normal = 4,
		// Token: 0x0400167B RID: 5755
		Hit = 8,
		// Token: 0x0400167C RID: 5756
		Stunned = 16,
		// Token: 0x0400167D RID: 5757
		Grace = 32,
		// Token: 0x0400167E RID: 5758
		Eliminated = 64,
		// Token: 0x0400167F RID: 5759
		None = 0
	}

	// Token: 0x0200035F RID: 863
	private enum BattleState
	{
		// Token: 0x04001681 RID: 5761
		NotEnoughPlayers,
		// Token: 0x04001682 RID: 5762
		GameEnd,
		// Token: 0x04001683 RID: 5763
		GameEndWaiting,
		// Token: 0x04001684 RID: 5764
		StartCountdown,
		// Token: 0x04001685 RID: 5765
		CountingDownToStart,
		// Token: 0x04001686 RID: 5766
		GameStart,
		// Token: 0x04001687 RID: 5767
		GameRunning
	}
}
