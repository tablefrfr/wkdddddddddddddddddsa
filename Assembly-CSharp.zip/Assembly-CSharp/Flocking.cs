﻿using System;
using GorillaExtensions;
using GorillaTagScripts;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Serialization;

// Token: 0x02000342 RID: 834
public class Flocking : MonoBehaviour
{
	// Token: 0x170001EF RID: 495
	// (get) Token: 0x060012A9 RID: 4777 RVA: 0x00063650 File Offset: 0x00061850
	// (set) Token: 0x060012AA RID: 4778 RVA: 0x00063658 File Offset: 0x00061858
	public FlockingManager.FishArea FishArea { get; set; }

	// Token: 0x060012AB RID: 4779 RVA: 0x00063661 File Offset: 0x00061861
	private void Awake()
	{
		this.manager = base.GetComponentInParent<FlockingManager>();
	}

	// Token: 0x060012AC RID: 4780 RVA: 0x0006366F File Offset: 0x0006186F
	private void Start()
	{
		this.speed = Random.Range(this.minSpeed, this.maxSpeed);
		this.fishState = Flocking.FishState.patrol;
	}

	// Token: 0x060012AD RID: 4781 RVA: 0x00063690 File Offset: 0x00061890
	private void OnDisable()
	{
		FlockingManager flockingManager = this.manager;
		flockingManager.onFoodDetected = (UnityAction<SlingshotProjectile, bool>)Delegate.Remove(flockingManager.onFoodDetected, new UnityAction<SlingshotProjectile, bool>(this.HandleOnFoodDetected));
		FlockingManager flockingManager2 = this.manager;
		flockingManager2.onFoodDestroyed = (UnityAction)Delegate.Remove(flockingManager2.onFoodDestroyed, new UnityAction(this.HandleOnFoodDestroyed));
		FlockingUpdateManager.UnregisterFlocking(this);
	}

	// Token: 0x060012AE RID: 4782 RVA: 0x000636F4 File Offset: 0x000618F4
	public void InvokeUpdate()
	{
		this.AvoidPlayerHands();
		this.MaybeTurn();
		switch (this.fishState)
		{
		case Flocking.FishState.flock:
			this.Flock(this.FishArea.nextWaypoint);
			this.SwitchState(Flocking.FishState.patrol);
			break;
		case Flocking.FishState.patrol:
			if (Random.Range(0, 10) < 2)
			{
				this.SwitchState(Flocking.FishState.flock);
			}
			break;
		case Flocking.FishState.followFood:
			if (this.isTurning)
			{
				return;
			}
			if (this.isRealFood)
			{
				if ((double)Vector3.Distance(base.transform.position, this.projectileGameObject.transform.position) > this.FollowFoodStopDistance)
				{
					this.FollowFood();
				}
				else
				{
					this.followingFood = false;
					this.Flock(this.projectileGameObject.transform.position);
					this.feedingTimeStarted += Time.deltaTime;
					if (this.feedingTimeStarted > this.eatFoodDuration)
					{
						this.SwitchState(Flocking.FishState.patrol);
					}
				}
			}
			else if (Vector3.Distance(base.transform.position, this.projectileGameObject.transform.position) > this.FollowFakeFoodStopDistance)
			{
				this.FollowFood();
			}
			else
			{
				this.followingFood = false;
				this.SwitchState(Flocking.FishState.patrol);
			}
			break;
		}
		if (!this.followingFood)
		{
			base.transform.Translate(0f, 0f, this.speed * Time.deltaTime);
		}
		this.pos = base.transform.position;
		this.rot = base.transform.rotation;
	}

	// Token: 0x060012AF RID: 4783 RVA: 0x00063878 File Offset: 0x00061A78
	private void MaybeTurn()
	{
		if (!this.manager.IsInside(base.transform.position, this.FishArea))
		{
			this.Turn(this.FishArea.colliderCenter);
			if (Vector3.Angle(this.FishArea.colliderCenter - base.transform.position, Vector3.forward) > 5f)
			{
				this.isTurning = true;
				return;
			}
		}
		else
		{
			this.isTurning = false;
		}
	}

	// Token: 0x060012B0 RID: 4784 RVA: 0x000638F0 File Offset: 0x00061AF0
	private void Turn(Vector3 towardPoint)
	{
		this.isTurning = true;
		Quaternion to = Quaternion.LookRotation(towardPoint - base.transform.position);
		base.transform.rotation = Quaternion.RotateTowards(base.transform.rotation, to, this.rotationSpeed * Time.deltaTime);
	}

	// Token: 0x060012B1 RID: 4785 RVA: 0x00063943 File Offset: 0x00061B43
	private void SwitchState(Flocking.FishState state)
	{
		this.fishState = state;
	}

	// Token: 0x060012B2 RID: 4786 RVA: 0x0006394C File Offset: 0x00061B4C
	private void Flock(Vector3 nextGoal)
	{
		Vector3 a = Vector3.zero;
		Vector3 vector = Vector3.zero;
		float num = 1f;
		int num2 = 0;
		foreach (Flocking flocking in this.FishArea.fishList)
		{
			if (flocking.gameObject != base.gameObject)
			{
				float num3 = Vector3.Distance(flocking.transform.position, base.transform.position);
				if (num3 <= this.maxNeighbourDistance)
				{
					a += flocking.transform.position;
					num2++;
					if (num3 < this.flockingAvoidanceDistance)
					{
						vector += base.transform.position - flocking.transform.position;
					}
					num += flocking.speed;
				}
			}
		}
		if (num2 > 0)
		{
			this.fishState = Flocking.FishState.flock;
			a = a / (float)num2 + (nextGoal - base.transform.position);
			this.speed = num / (float)num2;
			this.speed = Mathf.Clamp(this.speed, this.minSpeed, this.maxSpeed);
			Vector3 vector2 = a + vector - base.transform.position;
			if (vector2 != Vector3.zero)
			{
				Quaternion to = Quaternion.LookRotation(vector2);
				base.transform.rotation = Quaternion.RotateTowards(base.transform.rotation, to, this.rotationSpeed * Time.deltaTime);
			}
		}
	}

	// Token: 0x060012B3 RID: 4787 RVA: 0x00063AF0 File Offset: 0x00061CF0
	private void HandleOnFoodDetected(SlingshotProjectile projectile, bool _isRealFood)
	{
		this.SwitchState(Flocking.FishState.followFood);
		this.feedingTimeStarted = 0f;
		this.projectileGameObject = projectile.gameObject;
		this.isRealFood = _isRealFood;
	}

	// Token: 0x060012B4 RID: 4788 RVA: 0x00063B17 File Offset: 0x00061D17
	private void HandleOnFoodDestroyed()
	{
		this.SwitchState(Flocking.FishState.patrol);
		this.projectileGameObject = null;
		this.followingFood = false;
	}

	// Token: 0x060012B5 RID: 4789 RVA: 0x00063B30 File Offset: 0x00061D30
	private void FollowFood()
	{
		this.followingFood = true;
		Quaternion to = Quaternion.LookRotation(this.projectileGameObject.transform.position - base.transform.position);
		base.transform.rotation = Quaternion.RotateTowards(base.transform.rotation, to, this.rotationSpeed * Time.deltaTime);
		base.transform.position = Vector3.MoveTowards(base.transform.position, this.projectileGameObject.transform.position, this.speed * this.followFoodSpeedMult * Time.deltaTime);
	}

	// Token: 0x060012B6 RID: 4790 RVA: 0x00063BD0 File Offset: 0x00061DD0
	private void AvoidPlayerHands()
	{
		foreach (GameObject gameObject in FlockingManager.avoidPoints)
		{
			Vector3 position = gameObject.transform.position;
			if ((base.transform.position - position).IsShorterThan(this.avointPointRadius))
			{
				this.isAvoindingHand = true;
				Vector3 randomPointInsideCollider = this.manager.GetRandomPointInsideCollider(this.FishArea);
				this.Turn(randomPointInsideCollider);
				this.speed = this.avoidHandSpeed;
			}
			this.isAvoindingHand = false;
		}
	}

	// Token: 0x060012B7 RID: 4791 RVA: 0x00063C78 File Offset: 0x00061E78
	internal void SetSyncPosRot(Vector3 syncPos, Quaternion syncRot)
	{
		if (syncRot.IsValid())
		{
			this.rot = syncRot;
		}
		if (syncPos.IsValid())
		{
			this.pos = this.manager.RestrictPointToArea(syncPos, this.FishArea);
		}
	}

	// Token: 0x060012B8 RID: 4792 RVA: 0x00063CAC File Offset: 0x00061EAC
	private void OnEnable()
	{
		FlockingManager flockingManager = this.manager;
		flockingManager.onFoodDetected = (UnityAction<SlingshotProjectile, bool>)Delegate.Combine(flockingManager.onFoodDetected, new UnityAction<SlingshotProjectile, bool>(this.HandleOnFoodDetected));
		FlockingManager flockingManager2 = this.manager;
		flockingManager2.onFoodDestroyed = (UnityAction)Delegate.Combine(flockingManager2.onFoodDestroyed, new UnityAction(this.HandleOnFoodDestroyed));
		FlockingUpdateManager.RegisterFlocking(this);
	}

	// Token: 0x040015BD RID: 5565
	[Tooltip("Speed is randomly generated from min and max speed")]
	public float minSpeed = 2f;

	// Token: 0x040015BE RID: 5566
	public float maxSpeed = 4f;

	// Token: 0x040015BF RID: 5567
	public float rotationSpeed = 360f;

	// Token: 0x040015C0 RID: 5568
	[Tooltip("Maximum distance to the neighbours to form a flocking group")]
	public float maxNeighbourDistance = 4f;

	// Token: 0x040015C1 RID: 5569
	public float eatFoodDuration = 10f;

	// Token: 0x040015C2 RID: 5570
	[Tooltip("How fast should it follow the food? This value multiplies by the current speed")]
	public float followFoodSpeedMult = 3f;

	// Token: 0x040015C3 RID: 5571
	[Tooltip("How fast should it run away from players hand?")]
	public float avoidHandSpeed = 1.2f;

	// Token: 0x040015C4 RID: 5572
	[FormerlySerializedAs("avoidanceDistance")]
	[Tooltip("When flocking they will avoid each other if the distance between them is less than this value")]
	public float flockingAvoidanceDistance = 2f;

	// Token: 0x040015C5 RID: 5573
	[Tooltip("Follow the fish food until they are this far from it")]
	[FormerlySerializedAs("distanceToFollowFood")]
	public double FollowFoodStopDistance = 0.20000000298023224;

	// Token: 0x040015C6 RID: 5574
	[Tooltip("Follow any fake fish food until they are this far from it")]
	[FormerlySerializedAs("distanceToFollowFakeFood")]
	public float FollowFakeFoodStopDistance = 2f;

	// Token: 0x040015C7 RID: 5575
	private float speed;

	// Token: 0x040015C8 RID: 5576
	private Vector3 averageHeading;

	// Token: 0x040015C9 RID: 5577
	private Vector3 averagePosition;

	// Token: 0x040015CA RID: 5578
	private float feedingTimeStarted;

	// Token: 0x040015CB RID: 5579
	private GameObject projectileGameObject;

	// Token: 0x040015CC RID: 5580
	private bool followingFood;

	// Token: 0x040015CD RID: 5581
	private FlockingManager manager;

	// Token: 0x040015CE RID: 5582
	private GameObjectManagerWithId _fishSceneGameObjectsManager;

	// Token: 0x040015CF RID: 5583
	private UnityEvent<string, Transform> sendIdEvent;

	// Token: 0x040015D0 RID: 5584
	private Flocking.FishState fishState;

	// Token: 0x040015D1 RID: 5585
	[HideInInspector]
	public Vector3 pos;

	// Token: 0x040015D2 RID: 5586
	[HideInInspector]
	public Quaternion rot;

	// Token: 0x040015D3 RID: 5587
	private float velocity;

	// Token: 0x040015D4 RID: 5588
	private bool isTurning;

	// Token: 0x040015D5 RID: 5589
	private bool isRealFood;

	// Token: 0x040015D6 RID: 5590
	public float avointPointRadius = 0.5f;

	// Token: 0x040015D7 RID: 5591
	private float cacheSpeed;

	// Token: 0x040015D8 RID: 5592
	private bool isAvoindingHand;

	// Token: 0x02000343 RID: 835
	public enum FishState
	{
		// Token: 0x040015DB RID: 5595
		flock,
		// Token: 0x040015DC RID: 5596
		patrol,
		// Token: 0x040015DD RID: 5597
		followFood
	}
}
