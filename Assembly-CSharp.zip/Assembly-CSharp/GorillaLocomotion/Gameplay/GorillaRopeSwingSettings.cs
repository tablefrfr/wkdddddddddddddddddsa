﻿using System;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005C5 RID: 1477
	[CreateAssetMenu(fileName = "GorillaRopeSwingSettings", menuName = "ScriptableObjects/GorillaRopeSwingSettings", order = 0)]
	public class GorillaRopeSwingSettings : ScriptableObject
	{
		// Token: 0x040024F1 RID: 9457
		public float inheritVelocityMultiplier = 1f;

		// Token: 0x040024F2 RID: 9458
		public float frictionWhenNotHeld = 0.25f;
	}
}
