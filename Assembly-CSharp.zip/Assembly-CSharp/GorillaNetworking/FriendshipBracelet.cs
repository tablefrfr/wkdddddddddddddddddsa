﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace GorillaNetworking
{
	// Token: 0x020006B0 RID: 1712
	public class FriendshipBracelet : MonoBehaviour
	{
		// Token: 0x06002862 RID: 10338 RVA: 0x000C68A2 File Offset: 0x000C4AA2
		protected void Awake()
		{
			this.ownerRig = base.GetComponentInParent<VRRig>();
		}

		// Token: 0x06002863 RID: 10339 RVA: 0x000C68B0 File Offset: 0x000C4AB0
		private AudioSource GetAudioSource()
		{
			if (!this.isLeftHand)
			{
				return this.ownerRig.rightHandPlayer;
			}
			return this.ownerRig.leftHandPlayer;
		}

		// Token: 0x06002864 RID: 10340 RVA: 0x000C68D1 File Offset: 0x000C4AD1
		private void OnEnable()
		{
			this.PlayAppearEffects();
		}

		// Token: 0x06002865 RID: 10341 RVA: 0x000C68D9 File Offset: 0x000C4AD9
		public void PlayAppearEffects()
		{
			this.GetAudioSource().PlayOneShot(this.braceletFormedSound);
			if (this.braceletFormedParticle)
			{
				this.braceletFormedParticle.Play();
			}
		}

		// Token: 0x06002866 RID: 10342 RVA: 0x000C6904 File Offset: 0x000C4B04
		private void OnDisable()
		{
			if (!this.ownerRig.gameObject.activeInHierarchy)
			{
				return;
			}
			this.GetAudioSource().PlayOneShot(this.braceletBrokenSound);
			if (this.braceletBrokenParticle)
			{
				this.braceletBrokenParticle.Play();
			}
		}

		// Token: 0x06002867 RID: 10343 RVA: 0x000C6944 File Offset: 0x000C4B44
		public void UpdateBeads(List<Color> colors, int selfIndex)
		{
			int num = colors.Count - 1;
			int num2 = (this.braceletBeads.Length - num) / 2;
			for (int i = 0; i < this.braceletBeads.Length; i++)
			{
				int num3 = i - num2;
				if (num3 >= 0 && num3 < num)
				{
					this.braceletBeads[i].enabled = true;
					this.braceletBeads[i].material.color = colors[num3];
					this.braceletBananas[i].gameObject.SetActive(num3 == selfIndex);
				}
				else
				{
					this.braceletBeads[i].enabled = false;
					this.braceletBananas[i].gameObject.SetActive(false);
				}
			}
			SkinnedMeshRenderer[] array = this.braceletStrings;
			for (int j = 0; j < array.Length; j++)
			{
				array[j].material.color = colors[colors.Count - 1];
			}
		}

		// Token: 0x04002B44 RID: 11076
		[SerializeField]
		private SkinnedMeshRenderer[] braceletStrings;

		// Token: 0x04002B45 RID: 11077
		[SerializeField]
		private MeshRenderer[] braceletBeads;

		// Token: 0x04002B46 RID: 11078
		[SerializeField]
		private MeshRenderer[] braceletBananas;

		// Token: 0x04002B47 RID: 11079
		[SerializeField]
		private bool isLeftHand;

		// Token: 0x04002B48 RID: 11080
		[SerializeField]
		private AudioClip braceletFormedSound;

		// Token: 0x04002B49 RID: 11081
		[SerializeField]
		private AudioClip braceletBrokenSound;

		// Token: 0x04002B4A RID: 11082
		[SerializeField]
		private ParticleSystem braceletFormedParticle;

		// Token: 0x04002B4B RID: 11083
		[SerializeField]
		private ParticleSystem braceletBrokenParticle;

		// Token: 0x04002B4C RID: 11084
		private VRRig ownerRig;
	}
}
