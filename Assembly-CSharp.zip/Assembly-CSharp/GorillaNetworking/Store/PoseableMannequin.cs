﻿using System;
using System.Collections;
using GorillaExtensions;
using UnityEngine;
using UnityEngine.Serialization;

namespace GorillaNetworking.Store
{
	// Token: 0x020006F7 RID: 1783
	public class PoseableMannequin : MonoBehaviour
	{
		// Token: 0x06002A25 RID: 10789 RVA: 0x000CF40F File Offset: 0x000CD60F
		public void Start()
		{
			this.skinnedMeshRenderer.gameObject.SetActive(false);
			this.staticGorillaMesh.gameObject.SetActive(true);
		}

		// Token: 0x06002A26 RID: 10790 RVA: 0x00096880 File Offset: 0x00094A80
		private string GetPrefabPathFromCurrentPrefabStage()
		{
			return "";
		}

		// Token: 0x06002A27 RID: 10791 RVA: 0x00096880 File Offset: 0x00094A80
		private string GetMeshPathFromPrefabPath(string prefabPath)
		{
			return "";
		}

		// Token: 0x06002A28 RID: 10792 RVA: 0x000CF433 File Offset: 0x000CD633
		public void BakeSkinnedMesh()
		{
			this.BakeAndSaveMeshInPath(this.GetMeshPathFromPrefabPath(this.GetPrefabPathFromCurrentPrefabStage()));
		}

		// Token: 0x06002A29 RID: 10793 RVA: 0x00003051 File Offset: 0x00001251
		public void BakeAndSaveMeshInPath(string meshPath)
		{
		}

		// Token: 0x06002A2A RID: 10794 RVA: 0x000CF447 File Offset: 0x000CD647
		private void UpdateStaticMeshMannequin()
		{
			this.staticGorillaMesh.sharedMesh = this.BakedColliderMesh;
			this.staticGorillaMeshRenderer.sharedMaterials = this.skinnedMeshRenderer.sharedMaterials;
			this.staticGorillaMeshCollider.sharedMesh = this.BakedColliderMesh;
		}

		// Token: 0x06002A2B RID: 10795 RVA: 0x000CF481 File Offset: 0x000CD681
		private void UpdateSkinnedMeshCollider()
		{
			this.skinnedMeshCollider.sharedMesh = this.BakedColliderMesh;
		}

		// Token: 0x06002A2C RID: 10796 RVA: 0x000CF494 File Offset: 0x000CD694
		public void UpdateGTPosRotConstraints()
		{
			GTPosRotConstraints[] array = this.cosmeticConstraints;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].constraints.ForEach(delegate(GorillaPosRotConstraint c)
				{
					c.follower.rotation = c.source.rotation;
					c.follower.position = c.source.position;
				});
			}
		}

		// Token: 0x06002A2D RID: 10797 RVA: 0x000CF4E4 File Offset: 0x000CD6E4
		private void HookupCosmeticConstraints()
		{
			this.cosmeticConstraints = base.GetComponentsInChildren<GTPosRotConstraints>();
			foreach (GTPosRotConstraints gtposRotConstraints in this.cosmeticConstraints)
			{
				for (int j = 0; j < gtposRotConstraints.constraints.Length; j++)
				{
					gtposRotConstraints.constraints[j].source = this.FindBone(gtposRotConstraints.constraints[j].follower.name);
				}
			}
		}

		// Token: 0x06002A2E RID: 10798 RVA: 0x000CF558 File Offset: 0x000CD758
		private Transform FindBone(string boneName)
		{
			foreach (Transform transform in this.skinnedMeshRenderer.bones)
			{
				if (transform.name == boneName)
				{
					return transform;
				}
			}
			return null;
		}

		// Token: 0x06002A2F RID: 10799 RVA: 0x00003051 File Offset: 0x00001251
		public void CreasteTestClip()
		{
		}

		// Token: 0x06002A30 RID: 10800 RVA: 0x000CF594 File Offset: 0x000CD794
		public void SerializeVRRig()
		{
			base.StartCoroutine(this.SaveLocalPlayerPose());
		}

		// Token: 0x06002A31 RID: 10801 RVA: 0x000CF5A3 File Offset: 0x000CD7A3
		public IEnumerator SaveLocalPlayerPose()
		{
			yield return null;
			yield break;
		}

		// Token: 0x06002A32 RID: 10802 RVA: 0x00003051 File Offset: 0x00001251
		public void SerializeOutBonesFromSkinnedMesh(SkinnedMeshRenderer paramSkinnedMeshRenderer)
		{
		}

		// Token: 0x06002A33 RID: 10803 RVA: 0x000CF5AC File Offset: 0x000CD7AC
		public void SetCurvesForBone(SkinnedMeshRenderer paramSkinnedMeshRenderer, AnimationClip clip, Transform bone)
		{
			Keyframe[] keys = new Keyframe[]
			{
				new Keyframe(0f, bone.parent.localRotation.x)
			};
			Keyframe[] keys2 = new Keyframe[]
			{
				new Keyframe(0f, bone.parent.localRotation.y)
			};
			Keyframe[] keys3 = new Keyframe[]
			{
				new Keyframe(0f, bone.parent.localRotation.z)
			};
			Keyframe[] keys4 = new Keyframe[]
			{
				new Keyframe(0f, bone.parent.localRotation.w)
			};
			AnimationCurve curve = new AnimationCurve(keys);
			AnimationCurve curve2 = new AnimationCurve(keys2);
			AnimationCurve curve3 = new AnimationCurve(keys3);
			AnimationCurve curve4 = new AnimationCurve(keys4);
			string relativePath = "";
			string b = bone.name.Replace("_new", "");
			foreach (Transform transform in this.skinnedMeshRenderer.bones)
			{
				if (transform.name == b)
				{
					relativePath = transform.GetPath(this.skinnedMeshRenderer.transform.parent).TrimStart('/');
					break;
				}
			}
			clip.SetCurve(relativePath, typeof(Transform), "m_LocalRotation.x", curve);
			clip.SetCurve(relativePath, typeof(Transform), "m_LocalRotation.y", curve2);
			clip.SetCurve(relativePath, typeof(Transform), "m_LocalRotation.z", curve3);
			clip.SetCurve(relativePath, typeof(Transform), "m_LocalRotation.w", curve4);
		}

		// Token: 0x06002A34 RID: 10804 RVA: 0x00003051 File Offset: 0x00001251
		public void UpdatePrefabWithAnimationClip(string AnimationFileName)
		{
		}

		// Token: 0x06002A35 RID: 10805 RVA: 0x00003051 File Offset: 0x00001251
		public void LoadPoseOntoMannequin(AnimationClip clip, float frameTime = 0f)
		{
		}

		// Token: 0x06002A36 RID: 10806 RVA: 0x00003051 File Offset: 0x00001251
		public void OnValidate()
		{
		}

		// Token: 0x04002D3C RID: 11580
		public SkinnedMeshRenderer skinnedMeshRenderer;

		// Token: 0x04002D3D RID: 11581
		[FormerlySerializedAs("meshCollider")]
		public MeshCollider skinnedMeshCollider;

		// Token: 0x04002D3E RID: 11582
		public GTPosRotConstraints[] cosmeticConstraints;

		// Token: 0x04002D3F RID: 11583
		public Mesh BakedColliderMesh;

		// Token: 0x04002D40 RID: 11584
		[SerializeField]
		[FormerlySerializedAs("liveAssetPath")]
		protected string prefabAssetPath;

		// Token: 0x04002D41 RID: 11585
		[SerializeField]
		protected string prefabFolderPath;

		// Token: 0x04002D42 RID: 11586
		[SerializeField]
		protected string prefabAssetName;

		// Token: 0x04002D43 RID: 11587
		public MeshFilter staticGorillaMesh;

		// Token: 0x04002D44 RID: 11588
		public MeshCollider staticGorillaMeshCollider;

		// Token: 0x04002D45 RID: 11589
		public MeshRenderer staticGorillaMeshRenderer;
	}
}
