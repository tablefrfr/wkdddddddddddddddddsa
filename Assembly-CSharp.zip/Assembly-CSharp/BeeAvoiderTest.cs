﻿using System;
using GorillaExtensions;
using UnityEngine;

// Token: 0x0200006D RID: 109
public class BeeAvoiderTest : MonoBehaviour
{
	// Token: 0x0600022F RID: 559 RVA: 0x00010664 File Offset: 0x0000E864
	public void Update()
	{
		Vector3 position = this.patrolPoints[this.nextPatrolPoint].transform.position;
		Vector3 position2 = base.transform.position;
		Vector3 target = (position - position2).normalized * this.speed;
		this.velocity = Vector3.MoveTowards(this.velocity * this.drag, target, this.acceleration);
		if ((position2 - position).IsLongerThan(this.instabilityOffRadius))
		{
			this.velocity += Random.insideUnitSphere * this.instability * Time.deltaTime;
		}
		Vector3 vector = position2 + this.velocity * Time.deltaTime;
		GameObject[] array = this.avoidancePoints;
		for (int i = 0; i < array.Length; i++)
		{
			Vector3 position3 = array[i].transform.position;
			if ((vector - position3).IsShorterThan(this.avoidRadius))
			{
				Vector3 normalized = Vector3.Cross(position3 - vector, position - vector).normalized;
				Vector3 normalized2 = (position - position3).normalized;
				float num = Vector3.Dot(vector - position3, normalized);
				Vector3 b = (this.avoidRadius - num) * normalized;
				vector += b;
				this.velocity += b;
			}
		}
		base.transform.position = vector;
		base.transform.rotation = Quaternion.LookRotation(position - vector);
		if ((vector - position).IsShorterThan(this.patrolArrivedRadius))
		{
			this.nextPatrolPoint = (this.nextPatrolPoint + 1) % this.patrolPoints.Length;
		}
	}

	// Token: 0x04000332 RID: 818
	public GameObject[] patrolPoints;

	// Token: 0x04000333 RID: 819
	public GameObject[] avoidancePoints;

	// Token: 0x04000334 RID: 820
	public float speed;

	// Token: 0x04000335 RID: 821
	public float acceleration;

	// Token: 0x04000336 RID: 822
	public float instability;

	// Token: 0x04000337 RID: 823
	public float instabilityOffRadius;

	// Token: 0x04000338 RID: 824
	public float drag;

	// Token: 0x04000339 RID: 825
	public float avoidRadius;

	// Token: 0x0400033A RID: 826
	public float patrolArrivedRadius;

	// Token: 0x0400033B RID: 827
	private int nextPatrolPoint;

	// Token: 0x0400033C RID: 828
	private Vector3 velocity;
}
