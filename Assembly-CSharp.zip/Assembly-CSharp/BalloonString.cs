﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000239 RID: 569
public class BalloonString : MonoBehaviour
{
	// Token: 0x06000C10 RID: 3088 RVA: 0x0004059C File Offset: 0x0003E79C
	private void Awake()
	{
		this.lineRenderer = base.GetComponent<LineRenderer>();
		this.vertices = new List<Vector3>(this.numSegments + 1);
		if (this.startPositionXf != null && this.endPositionXf != null)
		{
			this.vertices.Add(this.startPositionXf.position);
			int num = this.vertices.Count - 2;
			for (int i = 0; i < num; i++)
			{
				float t = (float)((i + 1) / (this.vertices.Count - 1));
				Vector3 item = Vector3.Lerp(this.startPositionXf.position, this.endPositionXf.position, t);
				this.vertices.Add(item);
			}
			this.vertices.Add(this.endPositionXf.position);
		}
	}

	// Token: 0x06000C11 RID: 3089 RVA: 0x0004066C File Offset: 0x0003E86C
	private void UpdateDynamics()
	{
		this.vertices[0] = this.startPositionXf.position;
		this.vertices[this.vertices.Count - 1] = this.endPositionXf.position;
	}

	// Token: 0x06000C12 RID: 3090 RVA: 0x000406A8 File Offset: 0x0003E8A8
	private void UpdateRenderPositions()
	{
		this.lineRenderer.SetPosition(0, this.startPositionXf.transform.position);
		this.lineRenderer.SetPosition(1, this.endPositionXf.transform.position);
	}

	// Token: 0x06000C13 RID: 3091 RVA: 0x000406E2 File Offset: 0x0003E8E2
	private void LateUpdate()
	{
		if (this.startPositionXf != null && this.endPositionXf != null)
		{
			this.UpdateDynamics();
			this.UpdateRenderPositions();
		}
	}

	// Token: 0x04000D6C RID: 3436
	public Transform startPositionXf;

	// Token: 0x04000D6D RID: 3437
	public Transform endPositionXf;

	// Token: 0x04000D6E RID: 3438
	private List<Vector3> vertices;

	// Token: 0x04000D6F RID: 3439
	public int numSegments = 1;

	// Token: 0x04000D70 RID: 3440
	private bool endPositionFixed;

	// Token: 0x04000D71 RID: 3441
	private LineRenderer lineRenderer;
}
