﻿using System;
using System.Collections.Generic;
using Unity.Collections;
using UnityEngine;

// Token: 0x02000329 RID: 809
public class BuilderTableDataRenderData
{
	// Token: 0x040014D6 RID: 5334
	public const int NUM_SPLIT_MESH_INSTANCE_GROUPS = 1;

	// Token: 0x040014D7 RID: 5335
	public int texWidth;

	// Token: 0x040014D8 RID: 5336
	public int texHeight;

	// Token: 0x040014D9 RID: 5337
	public TextureFormat textureFormat;

	// Token: 0x040014DA RID: 5338
	public Dictionary<Material, int> materialToIndex;

	// Token: 0x040014DB RID: 5339
	public List<Material> materials;

	// Token: 0x040014DC RID: 5340
	public Material sharedMaterial;

	// Token: 0x040014DD RID: 5341
	public Material sharedMaterialIndirect;

	// Token: 0x040014DE RID: 5342
	public Dictionary<Texture2D, int> textureToIndex;

	// Token: 0x040014DF RID: 5343
	public List<Texture2D> textures;

	// Token: 0x040014E0 RID: 5344
	public List<Material> perTextureMaterial;

	// Token: 0x040014E1 RID: 5345
	public List<MaterialPropertyBlock> perTexturePropertyBlock;

	// Token: 0x040014E2 RID: 5346
	public Texture2DArray sharedTexArray;

	// Token: 0x040014E3 RID: 5347
	public Dictionary<Mesh, int> meshToIndex;

	// Token: 0x040014E4 RID: 5348
	public List<Mesh> meshes;

	// Token: 0x040014E5 RID: 5349
	public List<int> meshInstanceCount;

	// Token: 0x040014E6 RID: 5350
	public NativeList<BuilderTableSubMesh> subMeshes;

	// Token: 0x040014E7 RID: 5351
	public Mesh sharedMesh;

	// Token: 0x040014E8 RID: 5352
	public BuilderTableDataRenderIndirectBatch dynamicBatch;

	// Token: 0x040014E9 RID: 5353
	public BuilderTableDataRenderIndirectBatch staticBatch;
}
