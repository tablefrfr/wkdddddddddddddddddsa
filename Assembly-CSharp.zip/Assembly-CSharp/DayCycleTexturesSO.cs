﻿using System;
using UnityEngine;

// Token: 0x02000093 RID: 147
[CreateAssetMenu(fileName = "DayCycleTextures", menuName = "Gorilla Tag/Day Cycle Textures", order = 0)]
public class DayCycleTexturesSO : ScriptableObject
{
	// Token: 0x0400042F RID: 1071
	public DayCycleTextureMoment[] moments = new DayCycleTextureMoment[10];
}
