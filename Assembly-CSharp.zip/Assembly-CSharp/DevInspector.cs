﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x020000A8 RID: 168
public class DevInspector : MonoBehaviour
{
	// Token: 0x06000324 RID: 804 RVA: 0x0001657F File Offset: 0x0001477F
	private void OnEnable()
	{
		Object.Destroy(base.gameObject);
	}

	// Token: 0x04000499 RID: 1177
	public GameObject pivot;

	// Token: 0x0400049A RID: 1178
	public Text outputInfo;

	// Token: 0x0400049B RID: 1179
	public Component[] componentToInspect;

	// Token: 0x0400049C RID: 1180
	public bool isEnabled;

	// Token: 0x0400049D RID: 1181
	public bool autoFind = true;

	// Token: 0x0400049E RID: 1182
	public GameObject canvas;

	// Token: 0x0400049F RID: 1183
	public int sidewaysOffset;
}
