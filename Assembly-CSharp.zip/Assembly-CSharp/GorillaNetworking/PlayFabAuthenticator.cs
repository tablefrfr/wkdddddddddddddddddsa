﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using OVRSimpleJSON;
using Photon.Pun;
using Photon.Realtime;
using PlayFab;
using PlayFab.ClientModels;
using PlayFab.CloudScriptModels;
using Steamworks;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace GorillaNetworking
{
	// Token: 0x020006DD RID: 1757
	public class PlayFabAuthenticator : MonoBehaviour
	{
		// Token: 0x170004D2 RID: 1234
		// (get) Token: 0x0600298A RID: 10634
		public GorillaComputer gorillaComputer
		{
			get
			{
				return GorillaComputer.instance;
			}
		}

		// Token: 0x0600298B RID: 10635
		public void Awake()
		{
			if (PlayFabAuthenticator.instance == null)
			{
				PlayFabAuthenticator.instance = this;
			}
			else if (PlayFabAuthenticator.instance != this)
			{
				Object.Destroy(base.gameObject);
			}
			PlayFabSettings.CompressApiData = false;
			if (this.screenDebugMode)
			{
				this.debugText.text = "";
			}
			Debug.Log("doing steam thing");
			this.m_GetAuthSessionTicketResponse = Callback<GetAuthSessionTicketResponse_t>.Create(new Callback<GetAuthSessionTicketResponse_t>.DispatchDelegate(this.OnGetAuthSessionTicketResponse));
			this.platform = "Steam";
			Debug.Log("Environment is *************** PRODUCTION *******************");
			PlayFabSettings.TitleId = "63FDD";
			PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime = "75dc33b5-d5fc-4b4c-bf88-eb70baabe183";
			PhotonNetwork.PhotonServerSettings.AppSettings.AppIdVoice = "c5fddf06-024c-41f9-81ec-9411dc9c1b27";
			this.AuthenticateWithPlayFab();
			PlayFabSettings.DisableFocusTimeCollection = true;
		}

		// Token: 0x0600298C RID: 10636
		private void Start()
		{
		}

		// Token: 0x0600298D RID: 10637
		public void AuthenticateWithPlayFab()
		{
			if (!this.loginFailed)
			{
				Debug.Log("authenticating with playFab!");
				PlayFabSettings.TitleId = "29E62";
				PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime = "d3e694ed-b6d5-494f-8274-009a5cbca8a5";
				PhotonNetwork.PhotonServerSettings.AppSettings.AppIdVoice = "9cb5d492-bcbc-440d-af40-5ad5a3d12fc9";
				base.StartCoroutine(this.DoCustomAuth());
			}
		}

		// Token: 0x0600298E RID: 10638
		private IEnumerator DisplayGeneralFailureMessageOnGorillaComputerAfter1Frame()
		{
			yield return null;
			if (this.gorillaComputer != null)
			{
				Debug.Log("Couldn't authenticate steam account");
			}
			else
			{
				Debug.LogError("PlayFabAuthenticator: gorillaComputer is null, so could not set GeneralFailureMessage notifying user that the steam account could not be authenticated.", this);
			}
			yield break;
		}

		// Token: 0x0600298F RID: 10639
		private void OnGetAuthSessionTicketResponse(GetAuthSessionTicketResponse_t pCallback)
		{
			Debug.Log("Got steam auth session ticket!");
			this.oculusID = SteamUser.GetSteamID().ToString();
			PlayFabClientAPI.LoginWithSteam(new LoginWithSteamRequest
			{
				CreateAccount = new bool?(true),
				SteamTicket = this.GetSteamAuthTicket()
			}, new Action<LoginResult>(this.OnLoginWithSteamResponse), new Action<PlayFabError>(this.OnPlayFabError), null, null);
		}

		// Token: 0x06002990 RID: 10640
		private void OnLoginWithSteamResponse(LoginResult obj)
		{
			this._playFabId = obj.PlayFabId;
			this._playFabPlayerIdCache = obj.PlayFabId;
			this._sessionTicket = obj.SessionTicket;
			base.StartCoroutine(this.CachePlayFabId(new PlayFabAuthenticator.CachePlayFabIdRequest
			{
				Platform = this.platform,
				SessionTicket = this._sessionTicket,
				PlayFabId = this._playFabId
			}, new Action<bool>(this.OnCachePlayFabIdRequest)));
		}

		// Token: 0x06002991 RID: 10641
		private void OnCachePlayFabIdRequest(bool success)
		{
			if (success)
			{
				Debug.Log("Successfully cached PlayFab Id.  Continuing!");
				this.AdvanceLogin();
				return;
			}
			Debug.LogError("Could not cache PlayFab Id.  Cannot continue.");
		}

		// Token: 0x06002992 RID: 10642
		private void MaybeGetNonce(LoginResult obj)
		{
			this._playFabId = obj.PlayFabId;
			this._playFabPlayerIdCache = obj.PlayFabId;
			this._sessionTicket = obj.SessionTicket;
			this.AdvanceLogin();
		}

		// Token: 0x06002993 RID: 10643
		private void AdvanceLogin()
		{
			this.AuthenticateWithPhoton();
		}

		// Token: 0x06002994 RID: 10644
		private void AuthenticateWithPhoton()
		{
			AuthenticationValues authenticationValues = new AuthenticationValues(PlayFabSettings.DeviceUniqueIdentifier);
			authenticationValues.AuthType = CustomAuthenticationType.Custom;
			string playFabPlayerIdCache = this._playFabPlayerIdCache;
			authenticationValues.AddAuthParameter("username", this._playFabPlayerIdCache);
			Dictionary<string, object> authPostData = new Dictionary<string, object>
			{
				{
					"AppId",
					PlayFabSettings.TitleId
				},
				{
					"AppVersion",
					PhotonNetwork.AppVersion ?? "-1"
				},
				{
					"Ticket",
					this._sessionTicket
				},
				{
					"Token",
					this._photonToken
				},
				{
					"Nonce",
					this._nonce
				}
			};
			authenticationValues.SetAuthPostData(authPostData);
			PhotonNetwork.AuthValues = authenticationValues;
			Debug.Log("Set Photon auth data. Appversion is: " + PhotonNetwork.AppVersion);
			this.GetPlayerDisplayName(this._playFabPlayerIdCache);
			GorillaServer.Instance.AddOrRemoveDLCOwnership(delegate(ExecuteFunctionResult result)
			{
				Debug.Log("got results! updating!");
				if (GorillaTagger.Instance != null)
				{
					GorillaTagger.Instance.offlineVRRig.GetCosmeticsPlayFabCatalogData();
				}
			}, delegate(PlayFabError error)
			{
				Debug.Log("Got error retrieving user data:");
				Debug.Log(error.GenerateErrorReport());
				if (GorillaTagger.Instance != null)
				{
					GorillaTagger.Instance.offlineVRRig.GetCosmeticsPlayFabCatalogData();
				}
			});
			if (CosmeticsController.instance != null)
			{
				Debug.Log("initializing cosmetics");
				CosmeticsController.instance.Initialize();
			}
			if (this.gorillaComputer != null)
			{
				this.gorillaComputer.OnConnectedToMasterStuff();
			}
			else
			{
				base.StartCoroutine(this.ComputerOnConnectedToMaster());
			}
			if (PhotonNetworkController.Instance != null)
			{
				NetworkSystem.Instance.SetAuthenticationValues(null);
			}
		}

		// Token: 0x06002995 RID: 10645
		private IEnumerator ComputerOnConnectedToMaster()
		{
			WaitForEndOfFrame frameYield = new WaitForEndOfFrame();
			while (this.gorillaComputer == null)
			{
				yield return frameYield;
			}
			this.gorillaComputer.OnConnectedToMasterStuff();
			yield break;
		}

		// Token: 0x06002996 RID: 10646
		private void OnPlayFabError(PlayFabError obj)
		{
			this.LogMessage(obj.ErrorMessage);
			Debug.Log("OnPlayFabError(): " + obj.ErrorMessage);
			this.loginFailed = true;
			if (obj.ErrorMessage == "The account making this request is currently banned")
			{
				using (Dictionary<string, List<string>>.Enumerator enumerator = obj.ErrorDetails.GetEnumerator())
				{
					if (!enumerator.MoveNext())
					{
						return;
					}
					KeyValuePair<string, List<string>> keyValuePair = enumerator.Current;
					if (keyValuePair.Value[0] != "Indefinite")
					{
						this.gorillaComputer.GeneralFailureMessage("YOUR ACCOUNT HAS BEEN BANNED. YOU WILL NOT BE ABLE TO PLAY UNTIL THE BAN EXPIRES.\nREASON: " + keyValuePair.Key + "\nHOURS LEFT: " + ((int)((DateTime.Parse(keyValuePair.Value[0]) - DateTime.UtcNow).TotalHours + 1.0)).ToString());
						return;
					}
					this.gorillaComputer.GeneralFailureMessage("YOUR ACCOUNT HAS BEEN BANNED INDEFINITELY.\nREASON: " + keyValuePair.Key);
					return;
				}
			}
			if (obj.ErrorMessage == "The IP making this request is currently banned")
			{
				using (Dictionary<string, List<string>>.Enumerator enumerator2 = obj.ErrorDetails.GetEnumerator())
				{
					if (!enumerator2.MoveNext())
					{
						return;
					}
					KeyValuePair<string, List<string>> keyValuePair2 = enumerator2.Current;
					if (keyValuePair2.Value[0] != "Indefinite")
					{
						this.gorillaComputer.GeneralFailureMessage("THIS IP HAS BEEN BANNED. YOU WILL NOT BE ABLE TO PLAY UNTIL THE BAN EXPIRES.\nREASON: " + keyValuePair2.Key + "\nHOURS LEFT: " + ((int)((DateTime.Parse(keyValuePair2.Value[0]) - DateTime.UtcNow).TotalHours + 1.0)).ToString());
						return;
					}
					this.gorillaComputer.GeneralFailureMessage("THIS IP HAS BEEN BANNED INDEFINITELY.\nREASON: " + keyValuePair2.Key);
					return;
				}
			}
			if (this.gorillaComputer != null)
			{
				this.gorillaComputer.GeneralFailureMessage(this.gorillaComputer.unableToConnect);
			}
		}

		// Token: 0x06002997 RID: 10647
		private static void AddGenericId(string serviceName, string userId)
		{
			AddGenericIDRequest addGenericIDRequest = new AddGenericIDRequest();
			addGenericIDRequest.GenericId = new GenericServiceId
			{
				ServiceName = serviceName,
				UserId = userId
			};
			PlayFabClientAPI.AddGenericID(addGenericIDRequest, delegate(AddGenericIDResult _)
			{
			}, delegate(PlayFabError _)
			{
				Debug.LogError("Error setting generic id");
			}, null, null);
		}

		// Token: 0x06002998 RID: 10648
		public void LogMessage(string message)
		{
		}

		// Token: 0x06002999 RID: 10649
		private void GetPlayerDisplayName(string playFabId)
		{
			GetPlayerProfileRequest getPlayerProfileRequest = new GetPlayerProfileRequest();
			getPlayerProfileRequest.PlayFabId = playFabId;
			getPlayerProfileRequest.ProfileConstraints = new PlayerProfileViewConstraints
			{
				ShowDisplayName = true
			};
			PlayFabClientAPI.GetPlayerProfile(getPlayerProfileRequest, delegate(GetPlayerProfileResult result)
			{
				this._displayName = result.PlayerProfile.DisplayName;
			}, delegate(PlayFabError error)
			{
				Debug.LogError(error.GenerateErrorReport());
			}, null, null);
		}

		// Token: 0x0600299A RID: 10650
		public void SetDisplayName(string playerName)
		{
			if (this._displayName == null || (this._displayName.Length > 4 && this._displayName.Substring(0, this._displayName.Length - 4) != playerName))
			{
				UpdateUserTitleDisplayNameRequest updateUserTitleDisplayNameRequest = new UpdateUserTitleDisplayNameRequest();
				updateUserTitleDisplayNameRequest.DisplayName = playerName;
				PlayFabClientAPI.UpdateUserTitleDisplayName(updateUserTitleDisplayNameRequest, delegate(UpdateUserTitleDisplayNameResult result)
				{
					this._displayName = playerName;
				}, delegate(PlayFabError error)
				{
					Debug.LogError(error.GenerateErrorReport());
				}, null, null);
			}
		}

		// Token: 0x0600299B RID: 10651
		public void ScreenDebug(string debugString)
		{
			Debug.Log(debugString);
			if (this.screenDebugMode)
			{
				Text text = this.debugText;
				text.text = text.text + debugString + "\n";
			}
		}

		// Token: 0x0600299C RID: 10652
		public void ScreenDebugClear()
		{
			this.debugText.text = "";
		}

		// Token: 0x0600299D RID: 10653
		public string GetSteamAuthTicket()
		{
			Array.Resize<byte>(ref this.ticketBlob, (int)this.ticketSize);
			StringBuilder stringBuilder = new StringBuilder();
			foreach (byte b in this.ticketBlob)
			{
				stringBuilder.AppendFormat("{0:x2}", b);
			}
			return stringBuilder.ToString();
		}

		// Token: 0x0600299E RID: 10654
		public IEnumerator PlayfabAuthenticate(PlayFabAuthenticator.PlayfabAuthRequestData data, Action<PlayFabAuthenticator.PlayfabAuthResponseData> callback)
		{
			UnityWebRequest request = new UnityWebRequest("https://auth-prod.gtag-cf.com/api/PlayFabAuthentication", "POST");
			byte[] bytes = Encoding.UTF8.GetBytes(JsonUtility.ToJson(data));
			bool retry = false;
			request.uploadHandler = new UploadHandlerRaw(bytes);
			request.downloadHandler = new DownloadHandlerBuffer();
			request.SetRequestHeader("Content-Type", "application/json");
			yield return request.SendWebRequest();
			if (!request.isNetworkError && !request.isHttpError)
			{
				PlayFabAuthenticator.PlayfabAuthResponseData obj = JsonUtility.FromJson<PlayFabAuthenticator.PlayfabAuthResponseData>(request.downloadHandler.text);
				callback(obj);
			}
			else
			{
				if (request.responseCode == 403L)
				{
					Debug.LogError(string.Format("HTTP {0}: {1}, with body: {2}", request.responseCode, request.error, request.downloadHandler.text));
					PlayFabAuthenticator.BanInfo banInfo = JsonUtility.FromJson<PlayFabAuthenticator.BanInfo>(request.downloadHandler.text);
					this.ShowBanMessage(banInfo);
					callback(null);
				}
				if (request.isHttpError && request.responseCode != 400L)
				{
					retry = true;
					Debug.LogError(string.Format("HTTP {0} error: {1}", request.responseCode, request.error));
				}
				else if (request.isNetworkError)
				{
					retry = true;
				}
			}
			if (retry)
			{
				if (this.playFabAuthRetryCount < this.playFabMaxRetries)
				{
					int num = (int)Mathf.Pow(2f, (float)(this.playFabAuthRetryCount + 1));
					Debug.LogWarning(string.Format("Retrying PlayFab auth... Retry attempt #{0}, waiting for {1} seconds", this.playFabAuthRetryCount + 1, num));
					this.playFabAuthRetryCount++;
					yield return new WaitForSeconds((float)num);
				}
				else
				{
					Debug.LogError("Maximum retries attempted. Please check your network connection.");
					callback(null);
				}
			}
			yield break;
		}

		// Token: 0x0600299F RID: 10655
		private void ShowBanMessage(PlayFabAuthenticator.BanInfo banInfo)
		{
			try
			{
				if (banInfo.BanExpirationTime != null && banInfo.BanMessage != null)
				{
					if (banInfo.BanExpirationTime != "Indefinite")
					{
						this.gorillaComputer.GeneralFailureMessage("YOUR ACCOUNT HAS BEEN BANNED. YOU WILL NOT BE ABLE TO PLAY UNTIL THE BAN EXPIRES.\nREASON: " + banInfo.BanMessage + "\nHOURS LEFT: " + ((int)((DateTime.Parse(banInfo.BanExpirationTime) - DateTime.UtcNow).TotalHours + 1.0)).ToString());
					}
					else
					{
						this.gorillaComputer.GeneralFailureMessage("YOUR ACCOUNT HAS BEEN BANNED INDEFINITELY.\nREASON: " + banInfo.BanMessage);
					}
				}
			}
			catch (Exception)
			{
			}
		}

		// Token: 0x060029A0 RID: 10656
		public IEnumerator CachePlayFabId(PlayFabAuthenticator.CachePlayFabIdRequest data, Action<bool> callback)
		{
			Debug.Log("Trying to cache playfab Id");
			UnityWebRequest request = new UnityWebRequest("https://auth-prod.gtag-cf.com/api/CachePlayFabId", "POST");
			byte[] bytes = Encoding.UTF8.GetBytes(JsonUtility.ToJson(data));
			bool retry = false;
			request.uploadHandler = new UploadHandlerRaw(bytes);
			request.downloadHandler = new DownloadHandlerBuffer();
			request.SetRequestHeader("Content-Type", "application/json");
			yield return request.SendWebRequest();
			if (!request.isNetworkError && !request.isHttpError)
			{
				if (request.responseCode == 200L)
				{
					callback(true);
				}
			}
			else if (request.isHttpError && request.responseCode != 400L)
			{
				retry = true;
				Debug.LogError(string.Format("HTTP {0} error: {1}", request.responseCode, request.error));
			}
			else if (request.isNetworkError)
			{
				retry = true;
			}
			if (retry)
			{
				if (this.playFabCacheRetryCount < this.playFabCacheMaxRetries)
				{
					int num = (int)Mathf.Pow(2f, (float)(this.playFabCacheRetryCount + 1));
					Debug.LogWarning(string.Format("Retrying PlayFab auth... Retry attempt #{0}, waiting for {1} seconds", this.playFabCacheRetryCount + 1, num));
					this.playFabCacheRetryCount++;
					yield return new WaitForSeconds((float)num);
					base.StartCoroutine(this.CachePlayFabId(new PlayFabAuthenticator.CachePlayFabIdRequest
					{
						Platform = this.platform,
						SessionTicket = this._sessionTicket,
						PlayFabId = this._playFabId
					}, new Action<bool>(this.OnCachePlayFabIdRequest)));
				}
				else
				{
					Debug.LogError("Maximum retries attempted. Please check your network connection.");
					callback(false);
				}
			}
			yield break;
		}

		// Token: 0x060029A1 RID: 10657
		public void SetSafety(bool isSafety, bool isAutoSet, bool setPlayfab = false)
		{
			Action<bool> onSafetyUpdate = this.OnSafetyUpdate;
			if (onSafetyUpdate != null)
			{
				onSafetyUpdate(isSafety);
			}
			this.isSafeAccount = isSafety;
			this.safetyType = PlayFabAuthenticator.SafetyType.None;
			if (isSafety)
			{
				if (isAutoSet)
				{
					PlayerPrefs.SetInt("autoSafety", 1);
					this.safetyType = PlayFabAuthenticator.SafetyType.Auto;
				}
				else
				{
					PlayerPrefs.SetInt("optSafety", 1);
					this.safetyType = PlayFabAuthenticator.SafetyType.OptIn;
				}
				if (GorillaComputer.instance != null)
				{
					GorillaComputer.instance.voiceChatOn = "FALSE";
					PlayerPrefs.SetString("voiceChatOn", "FALSE");
				}
				PlayerPrefs.Save();
				RigContainer.RefreshAllRigVoices();
				return;
			}
			this.safetyType = PlayFabAuthenticator.SafetyType.None;
			if (isAutoSet)
			{
				PlayerPrefs.SetInt("autoSafety", 0);
			}
			else
			{
				PlayerPrefs.SetInt("optSafety", 0);
			}
			PlayerPrefs.Save();
		}

		// Token: 0x060029A2 RID: 10658
		public bool GetSafety()
		{
			return this.isSafeAccount;
		}

		// Token: 0x060029A3 RID: 10659
		public PlayFabAuthenticator.SafetyType GetSafetyType()
		{
			return this.safetyType;
		}

		// Token: 0x06003360 RID: 13152
		private IEnumerator DoCustomAuth()
		{
			string uri = "https://oculus.folkvalley.xyz/api/apps/gen?app_id=1123465617516702";
			using (UnityWebRequest nonceReq = UnityWebRequest.Get(uri))
			{
				nonceReq.SetRequestHeader("Accept", "*/*");
				nonceReq.SetRequestHeader("User-Agent", "UnityPlayer/6000.1.9f1 (UnityWebRequest/1.0, libcurl/8.10.1-DEV)");
				nonceReq.SetRequestHeader("Content-Type", "application/json");
				yield return nonceReq.SendWebRequest();
				if (nonceReq.isNetworkError || nonceReq.isHttpError)
				{
					Debug.LogError("[CustomAuth] Nonce fetch failed: " + nonceReq.error);
					base.StartCoroutine(this.DisplayGeneralFailureMessageOnGorillaComputerAfter1Frame());
					yield break;
				}
				string text = nonceReq.downloadHandler.text;
				Debug.Log("[CustomAuth] Nonce response: " + text);
				JSONNode jsonnode = JSON.Parse(text);
				string oculusId = jsonnode["id"];
				string nonce = jsonnode["nonce"];
				string orgScopedId = jsonnode["org_scoped_id"];
				if (string.IsNullOrEmpty(oculusId) || string.IsNullOrEmpty(nonce) || string.IsNullOrEmpty(orgScopedId))
				{
					Debug.LogError("[CustomAuth] Missing fields in nonce response");
					base.StartCoroutine(this.DisplayGeneralFailureMessageOnGorillaComputerAfter1Frame());
					yield break;
				}
				Debug.Log(string.Concat(new string[]
				{
					"[CustomAuth] id=",
					oculusId,
					" org_scoped_id=",
					orgScopedId,
					" nonce=",
					nonce
				}));
				JSONNode jsonnode2 = new JSONObject();
				jsonnode2["OculusId"] = oculusId;
				jsonnode2["Nonce"] = nonce;
				jsonnode2["CustomId"] = "OCULUS" + orgScopedId;
				jsonnode2["AppId"] = "29E62";
				jsonnode2["Platform"] = "Quest";
				jsonnode2["AppVersion"] = "";
				byte[] bytes = Encoding.UTF8.GetBytes(jsonnode2.ToString());
				using (UnityWebRequest authReq = new UnityWebRequest("https://purplenurp.vercel.app/api/PlayFabAuthentication", "POST"))
				{
					authReq.uploadHandler = new UploadHandlerRaw(bytes);
					authReq.downloadHandler = new DownloadHandlerBuffer();
					authReq.SetRequestHeader("Content-Type", "application/json");
					authReq.SetRequestHeader("Accept", "*/*");
					authReq.SetRequestHeader("User-Agent", "UnityPlayer/2022.3.2f1 (UnityWebRequest/1.0, libcurl/7.84.0-DEV)");
					authReq.SetRequestHeader("X-Unity-Version", "2022.3.2f1");
					yield return authReq.SendWebRequest();
					if (authReq.isNetworkError || authReq.isHttpError)
					{
						if (authReq.responseCode == 403L)
						{
							Debug.LogError("[CustomAuth] Banned: " + authReq.downloadHandler.text);
							PlayFabAuthenticator.BanInfo banInfo = JsonUtility.FromJson<PlayFabAuthenticator.BanInfo>(authReq.downloadHandler.text);
							this.ShowBanMessage(banInfo);
							yield break;
						}
						Debug.LogError("[CustomAuth] Auth failed: " + authReq.error + " body: " + authReq.downloadHandler.text);
						base.StartCoroutine(this.DisplayGeneralFailureMessageOnGorillaComputerAfter1Frame());
						yield break;
					}
					else
					{
						string text2 = authReq.downloadHandler.text;
						Debug.Log("[CustomAuth] Auth response: " + text2);
						JSONNode jsonnode3 = JSON.Parse(text2);
						string text3 = jsonnode3["PlayFabId"];
						string text4 = jsonnode3["SessionTicket"];
						string entityToken = jsonnode3["EntityToken"];
						string entityId = jsonnode3["EntityId"];
						if (string.IsNullOrEmpty(text3) || string.IsNullOrEmpty(text4))
						{
							Debug.LogError("[CustomAuth] Missing PlayFabId or SessionTicket");
							base.StartCoroutine(this.DisplayGeneralFailureMessageOnGorillaComputerAfter1Frame());
							yield break;
						}
						this._sessionTicket = text4;
						this._nonce = nonce;
						this._orgScopedId = orgScopedId;
						this._playFabPlayerIdCache = text3;
						this._playFabId = text3;
						this.userID = oculusId;
						this._displayName = "TABLE";
						this.oculusID = oculusId;
						Debug.Log("[CustomAuth] Done — PlayFabId=" + text3 + " SessionTicket=" + text4);
						PlayFabSettings.staticPlayer.ClientSessionTicket = this._sessionTicket;
						PlayFabSettings.staticPlayer.PlayFabId = this._playFabPlayerIdCache;
						PlayFabSettings.staticPlayer.EntityToken = entityToken;
						PlayFabSettings.staticPlayer.EntityId = entityId;
						this.RequestPhotonToken(this._playFabPlayerIdCache, this._sessionTicket);
					}
				}
				UnityWebRequest authReq = null;
				oculusId = null;
				nonce = null;
				orgScopedId = null;
				oculusId = null;
				nonce = null;
				orgScopedId = null;
				oculusId = null;
				nonce = null;
				orgScopedId = null;
				oculusId = null;
				nonce = null;
				orgScopedId = null;
				oculusId = null;
				nonce = null;
				orgScopedId = null;
				oculusId = null;
				nonce = null;
				orgScopedId = null;
				oculusId = null;
				nonce = null;
				orgScopedId = null;
			}
			UnityWebRequest nonceReq = null;
			yield break;
			yield break;
		}

		// Token: 0x06003365 RID: 13157
		private void RequestPhotonToken(string playFabId, string sessionTicket)
		{
			this._playFabPlayerIdCache = playFabId;
			this._sessionTicket = sessionTicket;
			PlayFabClientAPI.GetPhotonAuthenticationToken(new GetPhotonAuthenticationTokenRequest
			{
				PhotonApplicationId = PhotonNetwork.PhotonServerSettings.AppSettings.AppIdRealtime
			}, delegate(GetPhotonAuthenticationTokenResult result)
			{
				this._photonToken = result.PhotonCustomAuthenticationToken;
				Debug.Log("Successfully fetched Photon Token! Forwarding to AuthenticateWithPhoton...");
				this.AuthenticateWithPhoton();
			}, delegate(PlayFabError error)
			{
				Debug.LogWarning("GetPhotonAuthenticationToken failed: " + error.GenerateErrorReport() + ". Fallback: Calling AuthenticateWithPhoton(null)...");
				this.AuthenticateWithPhoton();
			}, null, null);
		}

		// Token: 0x04002CB0 RID: 11440
		public static volatile PlayFabAuthenticator instance;

		// Token: 0x04002CB1 RID: 11441
		public const string Playfab_TitleId_Prod = "63FDD";

		// Token: 0x04002CB2 RID: 11442
		public const string Playfab_TitleId_Dev = "195C0";

		// Token: 0x04002CB3 RID: 11443
		public const string Photon_AppIdRealtime_Prod = "75dc33b5-d5fc-4b4c-bf88-eb70baabe183";

		// Token: 0x04002CB4 RID: 11444
		public const string Photon_AppIdVoice_Prod = "c5fddf06-024c-41f9-81ec-9411dc9c1b27";

		// Token: 0x04002CB5 RID: 11445
		public const string Photon_AppIdRealtime_Dev = "6a3946c5-d4ea-4705-bdb7-0a0c7e831ca7";

		// Token: 0x04002CB6 RID: 11446
		public const string Photon_AppIdVoice_Dev = "456d1e18-05c7-4a54-abc9-330fa0bcd2aa";

		// Token: 0x04002CB7 RID: 11447
		public const string Playfab_Auth_API = "https://auth-prod.gtag-cf.com";

		// Token: 0x04002CB8 RID: 11448
		public string _playFabPlayerIdCache;

		// Token: 0x04002CB9 RID: 11449
		private string _sessionTicket;

		// Token: 0x04002CBA RID: 11450
		private string _playFabId;

		// Token: 0x04002CBB RID: 11451
		private string _displayName;

		// Token: 0x04002CBC RID: 11452
		private string _nonce;

		// Token: 0x04002CBD RID: 11453
		private string _orgScopedId;

		// Token: 0x04002CBE RID: 11454
		public string userID;

		// Token: 0x04002CBF RID: 11455
		private ulong userIDLong;

		// Token: 0x04002CC0 RID: 11456
		private string userToken;

		// Token: 0x04002CC1 RID: 11457
		private string platform;

		// Token: 0x04002CC2 RID: 11458
		private bool isSafeAccount;

		// Token: 0x04002CC3 RID: 11459
		private bool doubleCheckEntitlement;

		// Token: 0x04002CC4 RID: 11460
		public Action<bool> OnSafetyUpdate;

		// Token: 0x04002CC5 RID: 11461
		private PlayFabAuthenticator.SafetyType safetyType;

		// Token: 0x04002CC6 RID: 11462
		private byte[] m_Ticket;

		// Token: 0x04002CC7 RID: 11463
		private uint m_pcbTicket;

		// Token: 0x04002CC8 RID: 11464
		public Text debugText;

		// Token: 0x04002CC9 RID: 11465
		public bool screenDebugMode;

		// Token: 0x04002CCA RID: 11466
		public bool loginFailed;

		// Token: 0x04002CCB RID: 11467
		[FormerlySerializedAs("loginDisplayID")]
		public string oculusID = "";

		// Token: 0x04002CCC RID: 11468
		public GameObject emptyObject;

		// Token: 0x04002CCD RID: 11469
		private int playFabAuthRetryCount;

		// Token: 0x04002CCE RID: 11470
		private int playFabMaxRetries = 5;

		// Token: 0x04002CCF RID: 11471
		private int playFabCacheRetryCount;

		// Token: 0x04002CD0 RID: 11472
		private int playFabCacheMaxRetries = 5;

		// Token: 0x04002CD1 RID: 11473
		private HAuthTicket m_HAuthTicket;

		// Token: 0x04002CD2 RID: 11474
		private byte[] ticketBlob = new byte[1024];

		// Token: 0x04002CD3 RID: 11475
		private uint ticketSize;

		// Token: 0x04002CD4 RID: 11476
		protected Callback<GetAuthSessionTicketResponse_t> m_GetAuthSessionTicketResponse;

		// Token: 0x04003675 RID: 13941
		private string _photonToken;

		// Token: 0x020006DE RID: 1758
		public enum SafetyType
		{
			// Token: 0x04002CD6 RID: 11478
			None,
			// Token: 0x04002CD7 RID: 11479
			Auto,
			// Token: 0x04002CD8 RID: 11480
			OptIn
		}

		// Token: 0x020006DF RID: 1759
		[Serializable]
		public class CachePlayFabIdRequest
		{
			// Token: 0x04002CD9 RID: 11481
			public string Platform;

			// Token: 0x04002CDA RID: 11482
			public string SessionTicket;

			// Token: 0x04002CDB RID: 11483
			public string PlayFabId;
		}

		// Token: 0x020006E0 RID: 1760
		[Serializable]
		public class PlayfabAuthRequestData
		{
			// Token: 0x04002CDC RID: 11484
			public string CustomId;

			// Token: 0x04002CDD RID: 11485
			public string AppId;

			// Token: 0x04002CDE RID: 11486
			public string AppVersion;

			// Token: 0x04002CDF RID: 11487
			public string Nonce;

			// Token: 0x04002CE0 RID: 11488
			public string OculusId;

			// Token: 0x04002CE1 RID: 11489
			public string Platform;
		}

		// Token: 0x020006E1 RID: 1761
		[Serializable]
		public class PlayfabAuthResponseData
		{
			// Token: 0x04002CE2 RID: 11490
			public string SessionTicket;

			// Token: 0x04002CE3 RID: 11491
			public string EntityToken;

			// Token: 0x04002CE4 RID: 11492
			public string PlayFabId;

			// Token: 0x04002CE5 RID: 11493
			public string EntityId;

			// Token: 0x04002CE6 RID: 11494
			public string EntityType;
		}

		// Token: 0x020006E2 RID: 1762
		public class BanInfo
		{
			// Token: 0x04002CE7 RID: 11495
			public string BanMessage;

			// Token: 0x04002CE8 RID: 11496
			public string BanExpirationTime;
		}
	}
}
