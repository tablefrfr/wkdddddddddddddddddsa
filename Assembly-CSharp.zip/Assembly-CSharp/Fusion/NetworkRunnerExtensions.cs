﻿using System;

namespace Fusion
{
	// Token: 0x02000635 RID: 1589
	public static class NetworkRunnerExtensions
	{
		// Token: 0x0600255A RID: 9562 RVA: 0x000B75B4 File Offset: 0x000B57B4
		public static bool SetActiveScene(this NetworkRunner runner, string sceneNameOrPath)
		{
			NetworkSceneManagerBase networkSceneManagerBase = runner.SceneManager as NetworkSceneManagerBase;
			if (networkSceneManagerBase != null)
			{
				SceneRef activeScene;
				if (networkSceneManagerBase.TryGetSceneRef(sceneNameOrPath, out activeScene))
				{
					runner.SetActiveScene(activeScene);
					return true;
				}
				return false;
			}
			else
			{
				int sceneBuildIndex = FusionUnitySceneManagerUtils.GetSceneBuildIndex(sceneNameOrPath);
				if (sceneBuildIndex >= 0)
				{
					runner.SetActiveScene(sceneBuildIndex);
					return true;
				}
				return false;
			}
		}
	}
}
