﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x020000AA RID: 170
public class DevInspectorScanner : MonoBehaviour
{
	// Token: 0x040004A1 RID: 1185
	public Text hintTextOutput;

	// Token: 0x040004A2 RID: 1186
	public float scanDistance = 10f;

	// Token: 0x040004A3 RID: 1187
	public float scanAngle = 30f;

	// Token: 0x040004A4 RID: 1188
	public LayerMask scanLayerMask;

	// Token: 0x040004A5 RID: 1189
	public string targetComponentName;

	// Token: 0x040004A6 RID: 1190
	public float rayPerDegree = 10f;
}
