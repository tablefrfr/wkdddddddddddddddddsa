﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200028F RID: 655
[DefaultExecutionOrder(2000)]
public class ChestObjectHysteresisManager : MonoBehaviour
{
	// Token: 0x06000E91 RID: 3729 RVA: 0x0004C50E File Offset: 0x0004A70E
	protected void Awake()
	{
		if (ChestObjectHysteresisManager.hasInstance && ChestObjectHysteresisManager.instance != this)
		{
			Object.Destroy(this);
			return;
		}
		ChestObjectHysteresisManager.SetInstance(this);
	}

	// Token: 0x06000E92 RID: 3730 RVA: 0x0004C531 File Offset: 0x0004A731
	public static void CreateManager()
	{
		ChestObjectHysteresisManager.SetInstance(new GameObject("ChestObjectHysteresisManager").AddComponent<ChestObjectHysteresisManager>());
	}

	// Token: 0x06000E93 RID: 3731 RVA: 0x0004C547 File Offset: 0x0004A747
	private static void SetInstance(ChestObjectHysteresisManager manager)
	{
		ChestObjectHysteresisManager.instance = manager;
		ChestObjectHysteresisManager.hasInstance = true;
		if (Application.isPlaying)
		{
			Object.DontDestroyOnLoad(manager);
		}
	}

	// Token: 0x06000E94 RID: 3732 RVA: 0x0004C562 File Offset: 0x0004A762
	public static void RegisterCH(ChestObjectHysteresis cOH)
	{
		if (!ChestObjectHysteresisManager.hasInstance)
		{
			ChestObjectHysteresisManager.CreateManager();
		}
		if (!ChestObjectHysteresisManager.allChests.Contains(cOH))
		{
			ChestObjectHysteresisManager.allChests.Add(cOH);
		}
	}

	// Token: 0x06000E95 RID: 3733 RVA: 0x0004C588 File Offset: 0x0004A788
	public static void UnregisterCH(ChestObjectHysteresis cOH)
	{
		if (!ChestObjectHysteresisManager.hasInstance)
		{
			ChestObjectHysteresisManager.CreateManager();
		}
		if (ChestObjectHysteresisManager.allChests.Contains(cOH))
		{
			ChestObjectHysteresisManager.allChests.Remove(cOH);
		}
	}

	// Token: 0x06000E96 RID: 3734 RVA: 0x0004C5B0 File Offset: 0x0004A7B0
	public void Update()
	{
		for (int i = 0; i < ChestObjectHysteresisManager.allChests.Count; i++)
		{
			ChestObjectHysteresisManager.allChests[i].InvokeUpdate();
		}
	}

	// Token: 0x04001063 RID: 4195
	public static ChestObjectHysteresisManager instance;

	// Token: 0x04001064 RID: 4196
	public static bool hasInstance = false;

	// Token: 0x04001065 RID: 4197
	public static List<ChestObjectHysteresis> allChests = new List<ChestObjectHysteresis>();
}
