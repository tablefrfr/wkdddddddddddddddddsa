﻿using System;
using UnityEngine;

namespace Fusion.StatsInternal
{
	// Token: 0x02000643 RID: 1603
	public interface IFusionStatsView
	{
		// Token: 0x0600259E RID: 9630
		void Initialize();

		// Token: 0x0600259F RID: 9631
		void CalculateLayout();

		// Token: 0x060025A0 RID: 9632
		void Refresh();

		// Token: 0x17000440 RID: 1088
		// (get) Token: 0x060025A1 RID: 9633
		bool isActiveAndEnabled { get; }

		// Token: 0x17000441 RID: 1089
		// (get) Token: 0x060025A2 RID: 9634
		Transform transform { get; }
	}
}
