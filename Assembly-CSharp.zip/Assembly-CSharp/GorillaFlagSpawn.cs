﻿using System;
using UnityEngine;

// Token: 0x0200033D RID: 829
public class GorillaFlagSpawn : MonoBehaviour
{
	// Token: 0x040015A5 RID: 5541
	public bool isRedFlagSpawn;
}
