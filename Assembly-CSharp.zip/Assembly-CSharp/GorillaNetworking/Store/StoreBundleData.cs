﻿using System;
using UnityEngine;

namespace GorillaNetworking.Store
{
	// Token: 0x020006FB RID: 1787
	public class StoreBundleData : ScriptableObject
	{
		// Token: 0x06002A50 RID: 10832 RVA: 0x000CFBD0 File Offset: 0x000CDDD0
		public void OnValidate()
		{
			if (this.playfabBundleID.Contains(' '))
			{
				Debug.LogError("ERROR THERE IS A SPACE IN THE PLAYFAB BUNDLE ID " + base.name);
			}
			if (this.bundleSKU.Contains(' '))
			{
				Debug.LogError("ERROR THERE IS A SPACE IN THE BUNDLE SKU " + base.name);
			}
		}

		// Token: 0x04002D51 RID: 11601
		public string playfabBundleID = "NULL";

		// Token: 0x04002D52 RID: 11602
		public string bundleSKU = "NULL SKU";

		// Token: 0x04002D53 RID: 11603
		public Sprite bundleImage;

		// Token: 0x04002D54 RID: 11604
		public string bundleDescriptionText = "THE NULL_BUNDLE PACK WITH 10,000 SHINY ROCKS IN THIS LIMITED TIME DLC!";
	}
}
