﻿using System;
using Fusion;
using Fusion.StatsInternal;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000214 RID: 532
public class FusionStatsObjectIds : Fusion.Behaviour, IFusionStatsView
{
	// Token: 0x06000B18 RID: 2840 RVA: 0x0003BCE7 File Offset: 0x00039EE7
	private void Awake()
	{
		this._fusionStats = base.GetComponentInParent<FusionStats>();
	}

	// Token: 0x06000B19 RID: 2841 RVA: 0x00003051 File Offset: 0x00001251
	void IFusionStatsView.Initialize()
	{
	}

	// Token: 0x06000B1A RID: 2842 RVA: 0x0003BCF5 File Offset: 0x00039EF5
	public static RectTransform Create(RectTransform parent, FusionStats fusionStats)
	{
		RectTransform rectTransform = parent.CreateRectTransform("Object Ids Panel", false).ExpandTopAnchor(new float?((float)6));
		FusionStatsObjectIds fusionStatsObjectIds = rectTransform.gameObject.AddComponent<FusionStatsObjectIds>();
		fusionStatsObjectIds._fusionStats = fusionStats;
		fusionStatsObjectIds.Generate();
		return rectTransform;
	}

	// Token: 0x06000B1B RID: 2843 RVA: 0x0003BD28 File Offset: 0x00039F28
	public void Generate()
	{
		Color fontColor = this._fusionStats.FontColor;
		RectTransform parent = base.transform.CreateRectTransform("IDs Layout", false).ExpandAnchor(null).AddCircleSprite(this._fusionStats.ObjDataBackColor);
		RectTransform parent2 = parent.CreateRectTransform("Object Id Panel", true).ExpandTopAnchor(null).SetAnchors(0f, 0.4f, 0f, 1f);
		parent2.CreateRectTransform("Object Id Label", false).SetAnchors(0f, 1f, 0.7f, 1f).SetOffsets(6f, -6f, 0f, -4f).AddText("OBJECT ID", TextAnchor.MiddleCenter, fontColor).resizeTextMaxSize = 18;
		RectTransform rt = parent2.CreateRectTransform("Object Id Value", false).SetAnchors(0f, 1f, 0f, 0.7f).SetOffsets(6f, -6f, 4f, 0f);
		this._objectIdLabel = rt.AddText("00", TextAnchor.MiddleCenter, fontColor);
		this.AddAuthorityPanel(parent, "Input", ref this._inputValueText, ref this._inputAuthBackImage).SetAnchors(0.4f, 0.7f, 0f, 1f);
		this.AddAuthorityPanel(parent, "State", ref this._stateValueText, ref this._stateAuthBackImage).SetAnchors(0.7f, 1f, 0f, 1f);
	}

	// Token: 0x06000B1C RID: 2844 RVA: 0x0003BEAC File Offset: 0x0003A0AC
	private RectTransform AddAuthorityPanel(RectTransform parent, string label, ref Text valueText, ref Image backImage)
	{
		Color fontColor = this._fusionStats.FontColor;
		RectTransform rectTransform = parent.CreateRectTransform(label + " Id Panel", true).ExpandTopAnchor(null).SetAnchors(0.5f, 1f, 0f, 1f).AddCircleSprite(FusionStatsObjectIds._noneAuthColor, out backImage);
		rectTransform.CreateRectTransform(label + " Label", false).SetAnchors(0f, 1f, 0.7f, 1f).SetOffsets(6f, -6f, 0f, -4f).AddText(label, TextAnchor.MiddleCenter, fontColor).resizeTextMaxSize = 18;
		RectTransform rt = rectTransform.CreateRectTransform(label + " Value", false).SetAnchors(0f, 1f, 0f, 0.7f).SetOffsets(6f, -6f, 4f, 0f);
		valueText = rt.AddText("P0", TextAnchor.MiddleCenter, fontColor);
		return rectTransform;
	}

	// Token: 0x06000B1D RID: 2845 RVA: 0x00003051 File Offset: 0x00001251
	void IFusionStatsView.CalculateLayout()
	{
	}

	// Token: 0x06000B1E RID: 2846 RVA: 0x0003BFB4 File Offset: 0x0003A1B4
	void IFusionStatsView.Refresh()
	{
		if (this._fusionStats == null)
		{
			return;
		}
		NetworkObject @object = this._fusionStats.Object;
		if (@object == null)
		{
			return;
		}
		if (@object.IsValid)
		{
			bool hasInputAuthority = @object.HasInputAuthority;
			if (this._previousHasInputAuth != hasInputAuthority)
			{
				this._inputAuthBackImage.color = (hasInputAuthority ? FusionStatsObjectIds._inputAuthColor : FusionStatsObjectIds._noneAuthColor);
				this._previousHasInputAuth = hasInputAuthority;
			}
			bool flag = @object.HasStateAuthority || @object.Runner.IsServer;
			if (this._previousHasStateAuth != flag)
			{
				this._stateAuthBackImage.color = (flag ? FusionStatsObjectIds._stateAuthColor : FusionStatsObjectIds._noneAuthColor);
				this._previousHasStateAuth = flag;
			}
			PlayerRef inputAuthority = @object.InputAuthority;
			if (this._previousInputAuthValue != inputAuthority)
			{
				this._inputValueText.text = ((inputAuthority == -1) ? "-" : ("P" + inputAuthority.PlayerId.ToString()));
				this._previousInputAuthValue = inputAuthority;
			}
			PlayerRef stateAuthority = @object.StateAuthority;
			if (this._previousStateAuthValue != stateAuthority)
			{
				this._stateValueText.text = ((stateAuthority == -1) ? "-" : ("P" + stateAuthority.PlayerId.ToString()));
				this._previousStateAuthValue = stateAuthority;
			}
		}
		uint raw = @object.Id.Raw;
		if (raw != this._previousObjectIdValue)
		{
			this._objectIdLabel.text = raw.ToString();
			this._previousObjectIdValue = raw;
		}
	}

	// Token: 0x06000B21 RID: 2849 RVA: 0x0003B411 File Offset: 0x00039611
	bool IFusionStatsView.get_isActiveAndEnabled()
	{
		return base.isActiveAndEnabled;
	}

	// Token: 0x06000B22 RID: 2850 RVA: 0x0003B419 File Offset: 0x00039619
	Transform IFusionStatsView.get_transform()
	{
		return base.transform;
	}

	// Token: 0x04000C7C RID: 3196
	protected const int PAD = 10;

	// Token: 0x04000C7D RID: 3197
	protected const int MARGIN = 6;

	// Token: 0x04000C7E RID: 3198
	[SerializeField]
	[HideInInspector]
	private Text _inputValueText;

	// Token: 0x04000C7F RID: 3199
	[SerializeField]
	[HideInInspector]
	private Text _stateValueText;

	// Token: 0x04000C80 RID: 3200
	[SerializeField]
	[HideInInspector]
	private Text _objectIdLabel;

	// Token: 0x04000C81 RID: 3201
	[SerializeField]
	[HideInInspector]
	private Image _stateAuthBackImage;

	// Token: 0x04000C82 RID: 3202
	[SerializeField]
	[HideInInspector]
	private Image _inputAuthBackImage;

	// Token: 0x04000C83 RID: 3203
	private FusionStats _fusionStats;

	// Token: 0x04000C84 RID: 3204
	private static Color _noneAuthColor = new Color(0.2f, 0.2f, 0.2f, 0.9f);

	// Token: 0x04000C85 RID: 3205
	private static Color _inputAuthColor = new Color(0.1f, 0.6f, 0.1f, 1f);

	// Token: 0x04000C86 RID: 3206
	private static Color _stateAuthColor = new Color(0.8f, 0.4f, 0f, 1f);

	// Token: 0x04000C87 RID: 3207
	private const float LABEL_DIVIDING_POINT = 0.7f;

	// Token: 0x04000C88 RID: 3208
	private const float TEXT_PAD = 4f;

	// Token: 0x04000C89 RID: 3209
	private const float TEXT_PAD_HORIZ = 6f;

	// Token: 0x04000C8A RID: 3210
	private const int MAX_TAG_FONT_SIZE = 18;

	// Token: 0x04000C8B RID: 3211
	private bool _previousHasInputAuth;

	// Token: 0x04000C8C RID: 3212
	private bool _previousHasStateAuth;

	// Token: 0x04000C8D RID: 3213
	private int _previousInputAuthValue = -2;

	// Token: 0x04000C8E RID: 3214
	private int _previousStateAuthValue = -2;

	// Token: 0x04000C8F RID: 3215
	private uint _previousObjectIdValue;
}
