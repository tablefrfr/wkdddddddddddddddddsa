﻿using System;
using Fusion.Internal;

namespace Fusion.CodeGen
{
	// Token: 0x02000849 RID: 2121
	[Serializable]
	internal class UnityDictionarySurrogate@ReaderWriter@Fusion_NetworkString`1<Fusion__32>@ReaderWriter@Fusion_NetworkString : UnityDictionarySurrogate<NetworkString<_32>, ReaderWriter@Fusion_NetworkString, NetworkString<_32>, ReaderWriter@Fusion_NetworkString>
	{
		// Token: 0x1700057B RID: 1403
		// (get) Token: 0x0600332A RID: 13098 RVA: 0x00100508 File Offset: 0x000FE708
		// (set) Token: 0x0600332B RID: 13099 RVA: 0x00100510 File Offset: 0x000FE710
		public override SerializableDictionary<NetworkString<_32>, NetworkString<_32>> DataProperty
		{
			get
			{
				return this.Data;
			}
			set
			{
				this.Data = value;
			}
		}

		// Token: 0x04003653 RID: 13907
		public SerializableDictionary<NetworkString<_32>, NetworkString<_32>> Data = SerializableDictionary.Create<NetworkString<_32>, NetworkString<_32>>();
	}
}
