﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace GorillaNetworking
{
	// Token: 0x02000694 RID: 1684
	public class CosmeticItemRegistry
	{
		// Token: 0x06002793 RID: 10131 RVA: 0x000C0688 File Offset: 0x000BE888
		public void Initialize(GameObject[] cosmetics)
		{
			if (this._isInitialized)
			{
				return;
			}
			this._isInitialized = true;
			foreach (GameObject gameObject in cosmetics)
			{
				string key = gameObject.name.Replace("LEFT.", "").Replace("RIGHT.", "").TrimEnd();
				CosmeticItemInstance cosmeticItemInstance;
				if (this.nameToCosmeticMap.ContainsKey(key))
				{
					cosmeticItemInstance = this.nameToCosmeticMap[key];
				}
				else
				{
					cosmeticItemInstance = new CosmeticItemInstance();
					this.nameToCosmeticMap.Add(key, cosmeticItemInstance);
				}
				bool flag = gameObject.name.Contains("LEFT.");
				bool flag2 = gameObject.name.Contains("RIGHT.");
				if (flag)
				{
					cosmeticItemInstance.leftObjects.Add(gameObject);
				}
				else if (flag2)
				{
					cosmeticItemInstance.rightObjects.Add(gameObject);
				}
				else
				{
					cosmeticItemInstance.objects.Add(gameObject);
				}
			}
		}

		// Token: 0x06002794 RID: 10132 RVA: 0x000C076F File Offset: 0x000BE96F
		public CosmeticItemInstance Cosmetic(string itemName)
		{
			if (!this._isInitialized)
			{
				Debug.LogError("Tried to use CosmeticItemRegistry before it was initialized!");
				return null;
			}
			if (itemName.Length == 0 || itemName == "NOTHING")
			{
				return null;
			}
			return this.nameToCosmeticMap[itemName];
		}

		// Token: 0x04002A5A RID: 10842
		private bool _isInitialized;

		// Token: 0x04002A5B RID: 10843
		private Dictionary<string, CosmeticItemInstance> nameToCosmeticMap = new Dictionary<string, CosmeticItemInstance>();

		// Token: 0x04002A5C RID: 10844
		private GameObject nullItem;
	}
}
