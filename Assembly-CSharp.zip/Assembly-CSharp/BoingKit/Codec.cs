﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

namespace BoingKit
{
	// Token: 0x02000822 RID: 2082
	public class Codec
	{
		// Token: 0x06003261 RID: 12897 RVA: 0x000FDA54 File Offset: 0x000FBC54
		public static float PackSaturated(float a, float b)
		{
			a = Mathf.Floor(a * 4095f);
			b = Mathf.Floor(b * 4095f);
			return a * 4096f + b;
		}

		// Token: 0x06003262 RID: 12898 RVA: 0x000FDA7B File Offset: 0x000FBC7B
		public static float PackSaturated(Vector2 v)
		{
			return Codec.PackSaturated(v.x, v.y);
		}

		// Token: 0x06003263 RID: 12899 RVA: 0x000FDA8E File Offset: 0x000FBC8E
		public static Vector2 UnpackSaturated(float f)
		{
			return new Vector2(Mathf.Floor(f / 4096f), Mathf.Repeat(f, 4096f)) / 4095f;
		}

		// Token: 0x06003264 RID: 12900 RVA: 0x000FDAB8 File Offset: 0x000FBCB8
		public static Vector2 OctWrap(Vector2 v)
		{
			return (Vector2.one - new Vector2(Mathf.Abs(v.y), Mathf.Abs(v.x))) * new Vector2(Mathf.Sign(v.x), Mathf.Sign(v.y));
		}

		// Token: 0x06003265 RID: 12901 RVA: 0x000FDB0C File Offset: 0x000FBD0C
		public static float PackNormal(Vector3 n)
		{
			n /= Mathf.Abs(n.x) + Mathf.Abs(n.y) + Mathf.Abs(n.z);
			return Codec.PackSaturated(((n.z >= 0f) ? new Vector2(n.x, n.y) : Codec.OctWrap(new Vector2(n.x, n.y))) * 0.5f + 0.5f * Vector2.one);
		}

		// Token: 0x06003266 RID: 12902 RVA: 0x000FDBA0 File Offset: 0x000FBDA0
		public static Vector3 UnpackNormal(float f)
		{
			Vector2 vector = Codec.UnpackSaturated(f);
			vector = vector * 2f - Vector2.one;
			Vector3 vector2 = new Vector3(vector.x, vector.y, 1f - Mathf.Abs(vector.x) - Mathf.Abs(vector.y));
			float num = Mathf.Clamp01(-vector2.z);
			vector2.x += ((vector2.x >= 0f) ? (-num) : num);
			vector2.y += ((vector2.y >= 0f) ? (-num) : num);
			return vector2.normalized;
		}

		// Token: 0x06003267 RID: 12903 RVA: 0x000FDC48 File Offset: 0x000FBE48
		public static uint PackRgb(Color color)
		{
			return (uint)(color.b * 255f) << 16 | (uint)(color.g * 255f) << 8 | (uint)(color.r * 255f);
		}

		// Token: 0x06003268 RID: 12904 RVA: 0x000FDC78 File Offset: 0x000FBE78
		public static Color UnpackRgb(uint i)
		{
			return new Color((i & 255U) / 255f, ((i & 65280U) >> 8) / 255f, ((i & 16711680U) >> 16) / 255f);
		}

		// Token: 0x06003269 RID: 12905 RVA: 0x000FDCB4 File Offset: 0x000FBEB4
		public static uint PackRgba(Color color)
		{
			return (uint)(color.a * 255f) << 24 | (uint)(color.b * 255f) << 16 | (uint)(color.g * 255f) << 8 | (uint)(color.r * 255f);
		}

		// Token: 0x0600326A RID: 12906 RVA: 0x000FDD00 File Offset: 0x000FBF00
		public static Color UnpackRgba(uint i)
		{
			return new Color((i & 255U) / 255f, ((i & 65280U) >> 8) / 255f, ((i & 16711680U) >> 16) / 255f, ((i & 4278190080U) >> 24) / 255f);
		}

		// Token: 0x0600326B RID: 12907 RVA: 0x000FDD56 File Offset: 0x000FBF56
		public static uint Pack8888(uint x, uint y, uint z, uint w)
		{
			return (x & 255U) << 24 | (y & 255U) << 16 | (z & 255U) << 8 | (w & 255U);
		}

		// Token: 0x0600326C RID: 12908 RVA: 0x000FDD7F File Offset: 0x000FBF7F
		public static void Unpack8888(uint i, out uint x, out uint y, out uint z, out uint w)
		{
			x = (i >> 24 & 255U);
			y = (i >> 16 & 255U);
			z = (i >> 8 & 255U);
			w = (i & 255U);
		}

		// Token: 0x0600326D RID: 12909 RVA: 0x000FDDB0 File Offset: 0x000FBFB0
		private static int IntReinterpret(float f)
		{
			return new Codec.IntFloat
			{
				FloatValue = f
			}.IntValue;
		}

		// Token: 0x0600326E RID: 12910 RVA: 0x000FDDD3 File Offset: 0x000FBFD3
		public static int HashConcat(int hash, int i)
		{
			return (hash ^ i) * Codec.FnvPrime;
		}

		// Token: 0x0600326F RID: 12911 RVA: 0x000FDDDE File Offset: 0x000FBFDE
		public static int HashConcat(int hash, long i)
		{
			hash = Codec.HashConcat(hash, (int)(i & (long)((ulong)-1)));
			hash = Codec.HashConcat(hash, (int)(i >> 32));
			return hash;
		}

		// Token: 0x06003270 RID: 12912 RVA: 0x000FDDFB File Offset: 0x000FBFFB
		public static int HashConcat(int hash, float f)
		{
			return Codec.HashConcat(hash, Codec.IntReinterpret(f));
		}

		// Token: 0x06003271 RID: 12913 RVA: 0x000FDE09 File Offset: 0x000FC009
		public static int HashConcat(int hash, bool b)
		{
			return Codec.HashConcat(hash, b ? 1 : 0);
		}

		// Token: 0x06003272 RID: 12914 RVA: 0x000FDE18 File Offset: 0x000FC018
		public static int HashConcat(int hash, params int[] ints)
		{
			foreach (int i2 in ints)
			{
				hash = Codec.HashConcat(hash, i2);
			}
			return hash;
		}

		// Token: 0x06003273 RID: 12915 RVA: 0x000FDE44 File Offset: 0x000FC044
		public static int HashConcat(int hash, params float[] floats)
		{
			foreach (float f in floats)
			{
				hash = Codec.HashConcat(hash, f);
			}
			return hash;
		}

		// Token: 0x06003274 RID: 12916 RVA: 0x000FDE6F File Offset: 0x000FC06F
		public static int HashConcat(int hash, Vector2 v)
		{
			return Codec.HashConcat(hash, new float[]
			{
				v.x,
				v.y
			});
		}

		// Token: 0x06003275 RID: 12917 RVA: 0x000FDE8F File Offset: 0x000FC08F
		public static int HashConcat(int hash, Vector3 v)
		{
			return Codec.HashConcat(hash, new float[]
			{
				v.x,
				v.y,
				v.z
			});
		}

		// Token: 0x06003276 RID: 12918 RVA: 0x000FDEB8 File Offset: 0x000FC0B8
		public static int HashConcat(int hash, Vector4 v)
		{
			return Codec.HashConcat(hash, new float[]
			{
				v.x,
				v.y,
				v.z,
				v.w
			});
		}

		// Token: 0x06003277 RID: 12919 RVA: 0x000FDEEA File Offset: 0x000FC0EA
		public static int HashConcat(int hash, Quaternion q)
		{
			return Codec.HashConcat(hash, new float[]
			{
				q.x,
				q.y,
				q.z,
				q.w
			});
		}

		// Token: 0x06003278 RID: 12920 RVA: 0x000FDF1C File Offset: 0x000FC11C
		public static int HashConcat(int hash, Color c)
		{
			return Codec.HashConcat(hash, new float[]
			{
				c.r,
				c.g,
				c.b,
				c.a
			});
		}

		// Token: 0x06003279 RID: 12921 RVA: 0x000FDF4E File Offset: 0x000FC14E
		public static int HashConcat(int hash, Transform t)
		{
			return Codec.HashConcat(hash, t.GetHashCode());
		}

		// Token: 0x0600327A RID: 12922 RVA: 0x000FDF5C File Offset: 0x000FC15C
		public static int Hash(int i)
		{
			return Codec.HashConcat(Codec.FnvDefaultBasis, i);
		}

		// Token: 0x0600327B RID: 12923 RVA: 0x000FDF69 File Offset: 0x000FC169
		public static int Hash(long i)
		{
			return Codec.HashConcat(Codec.FnvDefaultBasis, i);
		}

		// Token: 0x0600327C RID: 12924 RVA: 0x000FDF76 File Offset: 0x000FC176
		public static int Hash(float f)
		{
			return Codec.HashConcat(Codec.FnvDefaultBasis, f);
		}

		// Token: 0x0600327D RID: 12925 RVA: 0x000FDF83 File Offset: 0x000FC183
		public static int Hash(bool b)
		{
			return Codec.HashConcat(Codec.FnvDefaultBasis, b);
		}

		// Token: 0x0600327E RID: 12926 RVA: 0x000FDF90 File Offset: 0x000FC190
		public static int Hash(params int[] ints)
		{
			return Codec.HashConcat(Codec.FnvDefaultBasis, ints);
		}

		// Token: 0x0600327F RID: 12927 RVA: 0x000FDF9D File Offset: 0x000FC19D
		public static int Hash(params float[] floats)
		{
			return Codec.HashConcat(Codec.FnvDefaultBasis, floats);
		}

		// Token: 0x06003280 RID: 12928 RVA: 0x000FDFAA File Offset: 0x000FC1AA
		public static int Hash(Vector2 v)
		{
			return Codec.HashConcat(Codec.FnvDefaultBasis, v);
		}

		// Token: 0x06003281 RID: 12929 RVA: 0x000FDFB7 File Offset: 0x000FC1B7
		public static int Hash(Vector3 v)
		{
			return Codec.HashConcat(Codec.FnvDefaultBasis, v);
		}

		// Token: 0x06003282 RID: 12930 RVA: 0x000FDFC4 File Offset: 0x000FC1C4
		public static int Hash(Vector4 v)
		{
			return Codec.HashConcat(Codec.FnvDefaultBasis, v);
		}

		// Token: 0x06003283 RID: 12931 RVA: 0x000FDFD1 File Offset: 0x000FC1D1
		public static int Hash(Quaternion q)
		{
			return Codec.HashConcat(Codec.FnvDefaultBasis, q);
		}

		// Token: 0x06003284 RID: 12932 RVA: 0x000FDFDE File Offset: 0x000FC1DE
		public static int Hash(Color c)
		{
			return Codec.HashConcat(Codec.FnvDefaultBasis, c);
		}

		// Token: 0x06003285 RID: 12933 RVA: 0x000FDFEC File Offset: 0x000FC1EC
		private static int HashTransformHierarchyRecurvsive(int hash, Transform t)
		{
			hash = Codec.HashConcat(hash, t);
			hash = Codec.HashConcat(hash, t.childCount);
			for (int i = 0; i < t.childCount; i++)
			{
				hash = Codec.HashTransformHierarchyRecurvsive(hash, t.GetChild(i));
			}
			return hash;
		}

		// Token: 0x06003286 RID: 12934 RVA: 0x000FE031 File Offset: 0x000FC231
		public static int HashTransformHierarchy(Transform t)
		{
			return Codec.HashTransformHierarchyRecurvsive(Codec.FnvDefaultBasis, t);
		}

		// Token: 0x04003519 RID: 13593
		public static readonly int FnvDefaultBasis = -2128831035;

		// Token: 0x0400351A RID: 13594
		public static readonly int FnvPrime = 16777619;

		// Token: 0x02000823 RID: 2083
		[StructLayout(LayoutKind.Explicit)]
		private struct IntFloat
		{
			// Token: 0x0400351B RID: 13595
			[FieldOffset(0)]
			public int IntValue;

			// Token: 0x0400351C RID: 13596
			[FieldOffset(0)]
			public float FloatValue;
		}
	}
}
