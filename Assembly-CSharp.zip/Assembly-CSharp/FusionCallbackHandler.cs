﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Fusion;
using Fusion.Sockets;
using UnityEngine;

// Token: 0x02000106 RID: 262
public class FusionCallbackHandler : MonoBehaviour, INetworkRunnerCallbacks
{
	// Token: 0x060004D8 RID: 1240 RVA: 0x0001D19A File Offset: 0x0001B39A
	public void Setup(NetworkSystemFusion parentController)
	{
		this.parent = parentController;
		this.parent.runner.AddCallbacks(new INetworkRunnerCallbacks[]
		{
			this
		});
	}

	// Token: 0x060004D9 RID: 1241 RVA: 0x0001D1BD File Offset: 0x0001B3BD
	private void OnDestroy()
	{
		this.RemoveCallbacks();
	}

	// Token: 0x060004DA RID: 1242 RVA: 0x0001D1C8 File Offset: 0x0001B3C8
	private void RemoveCallbacks()
	{
		FusionCallbackHandler.<RemoveCallbacks>d__3 <RemoveCallbacks>d__;
		<RemoveCallbacks>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
		<RemoveCallbacks>d__.<>4__this = this;
		<RemoveCallbacks>d__.<>1__state = -1;
		<RemoveCallbacks>d__.<>t__builder.Start<FusionCallbackHandler.<RemoveCallbacks>d__3>(ref <RemoveCallbacks>d__);
	}

	// Token: 0x060004DB RID: 1243 RVA: 0x0001D1FF File Offset: 0x0001B3FF
	public void OnConnectedToServer(NetworkRunner runner)
	{
		this.parent.OnJoinedSession();
	}

	// Token: 0x060004DC RID: 1244 RVA: 0x0001D20C File Offset: 0x0001B40C
	public void OnConnectFailed(NetworkRunner runner, NetAddress remoteAddress, NetConnectFailedReason reason)
	{
		this.parent.OnJoinFailed(reason);
	}

	// Token: 0x060004DD RID: 1245 RVA: 0x00003051 File Offset: 0x00001251
	public void OnConnectRequest(NetworkRunner runner, NetworkRunnerCallbackArgs.ConnectRequest request, byte[] token)
	{
	}

	// Token: 0x060004DE RID: 1246 RVA: 0x0001D21C File Offset: 0x0001B41C
	public void OnCustomAuthenticationResponse(NetworkRunner runner, Dictionary<string, object> data)
	{
		Debug.Log("Received custom auth response:");
		foreach (KeyValuePair<string, object> keyValuePair in data)
		{
			Debug.Log(keyValuePair.Key + ":" + (keyValuePair.Value as string));
		}
	}

	// Token: 0x060004DF RID: 1247 RVA: 0x0001D290 File Offset: 0x0001B490
	public void OnDisconnectedFromServer(NetworkRunner runner)
	{
		this.parent.OnDisconnectedFromSession();
	}

	// Token: 0x060004E0 RID: 1248 RVA: 0x0001D29D File Offset: 0x0001B49D
	public void OnHostMigration(NetworkRunner runner, HostMigrationToken hostMigrationToken)
	{
		this.parent.MigrateHost(hostMigrationToken);
	}

	// Token: 0x060004E1 RID: 1249 RVA: 0x0001D2AC File Offset: 0x0001B4AC
	public void OnInput(NetworkRunner runner, NetworkInput input)
	{
		NetworkedInput input2 = NetInput.GetInput();
		input.Set<NetworkedInput>(input2);
	}

	// Token: 0x060004E2 RID: 1250 RVA: 0x00003051 File Offset: 0x00001251
	public void OnInputMissing(NetworkRunner runner, PlayerRef player, NetworkInput input)
	{
	}

	// Token: 0x060004E3 RID: 1251 RVA: 0x0001D2C7 File Offset: 0x0001B4C7
	public void OnPlayerJoined(NetworkRunner runner, PlayerRef player)
	{
		this.parent.OnFusionPlayerJoined(player);
	}

	// Token: 0x060004E4 RID: 1252 RVA: 0x0001D2D5 File Offset: 0x0001B4D5
	public void OnPlayerLeft(NetworkRunner runner, PlayerRef player)
	{
		this.parent.OnFusionPlayerLeft(player);
	}

	// Token: 0x060004E5 RID: 1253 RVA: 0x00003051 File Offset: 0x00001251
	public void OnReliableDataReceived(NetworkRunner runner, PlayerRef player, ArraySegment<byte> data)
	{
	}

	// Token: 0x060004E6 RID: 1254 RVA: 0x00003051 File Offset: 0x00001251
	public void OnSceneLoadDone(NetworkRunner runner)
	{
	}

	// Token: 0x060004E7 RID: 1255 RVA: 0x00003051 File Offset: 0x00001251
	public void OnSceneLoadStart(NetworkRunner runner)
	{
	}

	// Token: 0x060004E8 RID: 1256 RVA: 0x00003051 File Offset: 0x00001251
	public void OnSessionListUpdated(NetworkRunner runner, List<SessionInfo> sessionList)
	{
	}

	// Token: 0x060004E9 RID: 1257 RVA: 0x0001D2E3 File Offset: 0x0001B4E3
	public void OnShutdown(NetworkRunner runner, ShutdownReason shutdownReason)
	{
		this.parent.OnRunnerShutDown();
	}

	// Token: 0x060004EA RID: 1258 RVA: 0x00003051 File Offset: 0x00001251
	public void OnUserSimulationMessage(NetworkRunner runner, SimulationMessagePtr message)
	{
	}

	// Token: 0x0400067B RID: 1659
	private NetworkSystemFusion parent;
}
