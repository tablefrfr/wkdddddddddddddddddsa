﻿using System;
using System.Collections;
using System.Collections.Generic;
using GorillaLocomotion;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;

// Token: 0x02000337 RID: 823
internal class ConnectedControllerHandler : MonoBehaviour
{
	// Token: 0x170001E7 RID: 487
	// (get) Token: 0x06001264 RID: 4708 RVA: 0x00062216 File Offset: 0x00060416
	// (set) Token: 0x06001265 RID: 4709 RVA: 0x0006221D File Offset: 0x0006041D
	public static ConnectedControllerHandler Instance { get; private set; }

	// Token: 0x170001E8 RID: 488
	// (get) Token: 0x06001266 RID: 4710 RVA: 0x00062225 File Offset: 0x00060425
	public bool RightValid
	{
		get
		{
			return this.rightValid;
		}
	}

	// Token: 0x170001E9 RID: 489
	// (get) Token: 0x06001267 RID: 4711 RVA: 0x0006222D File Offset: 0x0006042D
	public bool LeftValid
	{
		get
		{
			return this.leftValid;
		}
	}

	// Token: 0x06001268 RID: 4712 RVA: 0x00062238 File Offset: 0x00060438
	private void Awake()
	{
		if (ConnectedControllerHandler.Instance != null && ConnectedControllerHandler.Instance != this)
		{
			Object.Destroy(this);
			return;
		}
		ConnectedControllerHandler.Instance = this;
		if (this.leftHandFollower == null || this.rightHandFollower == null || this.rightXRController == null || this.leftXRController == null || this.snapTurnController == null)
		{
			base.enabled = false;
			return;
		}
		this.rightControllerList = new List<XRController>();
		this.leftcontrollerList = new List<XRController>();
		this.rightControllerList.Add(this.rightXRController);
		this.leftcontrollerList.Add(this.leftXRController);
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.RightHand);
		InputDevice deviceAtXRNode2 = InputDevices.GetDeviceAtXRNode(XRNode.LeftHand);
		Debug.Log(string.Format("right controller? {0}", (deviceAtXRNode.characteristics & (InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right)) == (InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right)));
		this.rightControllerValid = deviceAtXRNode.isValid;
		this.leftControllerValid = deviceAtXRNode2.isValid;
		InputDevices.deviceConnected += this.DeviceConnected;
		InputDevices.deviceDisconnected += this.DeviceDisconnected;
		this.UpdateControllerStates();
	}

	// Token: 0x06001269 RID: 4713 RVA: 0x00062360 File Offset: 0x00060560
	private void Start()
	{
		if (this.leftHandFollower == null || this.rightHandFollower == null || this.leftXRController == null || this.rightXRController == null || this.snapTurnController == null)
		{
			return;
		}
		this.playerHandler = Player.Instance;
		this.rightHandFollower.followTransform = GorillaTagger.Instance.offlineVRRig.transform;
		this.leftHandFollower.followTransform = GorillaTagger.Instance.offlineVRRig.transform;
	}

	// Token: 0x0600126A RID: 4714 RVA: 0x000623E7 File Offset: 0x000605E7
	private void OnEnable()
	{
		base.StartCoroutine(this.ControllerValidator());
	}

	// Token: 0x0600126B RID: 4715 RVA: 0x000623F6 File Offset: 0x000605F6
	private void ONDisable()
	{
		base.StopCoroutine(this.ControllerValidator());
	}

	// Token: 0x0600126C RID: 4716 RVA: 0x00062404 File Offset: 0x00060604
	private void OnDestroy()
	{
		if (ConnectedControllerHandler.Instance != null && ConnectedControllerHandler.Instance == this)
		{
			ConnectedControllerHandler.Instance = null;
		}
		InputDevices.deviceConnected -= this.DeviceConnected;
		InputDevices.deviceDisconnected -= this.DeviceDisconnected;
	}

	// Token: 0x0600126D RID: 4717 RVA: 0x00062453 File Offset: 0x00060653
	private void LateUpdate()
	{
		if (!this.rightValid)
		{
			this.rightHandFollower.UpdatePositionRotation();
		}
		if (!this.leftValid)
		{
			this.leftHandFollower.UpdatePositionRotation();
		}
	}

	// Token: 0x0600126E RID: 4718 RVA: 0x0006247B File Offset: 0x0006067B
	private IEnumerator ControllerValidator()
	{
		yield return null;
		this.lastRightPos = ControllerInputPoller.DevicePosition(XRNode.RightHand);
		this.lastLeftPos = ControllerInputPoller.DevicePosition(XRNode.LeftHand);
		for (;;)
		{
			yield return new WaitForSeconds(this.overridePollRate);
			this.updateControllers = false;
			if (!this.playerHandler.inOverlay)
			{
				if (this.rightControllerValid)
				{
					this.tempRightPos = ControllerInputPoller.DevicePosition(XRNode.RightHand);
					if (this.tempRightPos == this.lastRightPos)
					{
						if ((this.overrideController & OverrideControllers.RightController) != OverrideControllers.RightController)
						{
							this.overrideController |= OverrideControllers.RightController;
							this.updateControllers = true;
						}
					}
					else if ((this.overrideController & OverrideControllers.RightController) == OverrideControllers.RightController)
					{
						this.overrideController &= ~OverrideControllers.RightController;
						this.updateControllers = true;
					}
					this.lastRightPos = this.tempRightPos;
				}
				if (this.leftControllerValid)
				{
					this.tempLeftPos = ControllerInputPoller.DevicePosition(XRNode.LeftHand);
					if (this.tempLeftPos == this.lastLeftPos)
					{
						if ((this.overrideController & OverrideControllers.LeftController) != OverrideControllers.LeftController)
						{
							this.overrideController |= OverrideControllers.LeftController;
							this.updateControllers = true;
						}
					}
					else if ((this.overrideController & OverrideControllers.LeftController) == OverrideControllers.LeftController)
					{
						this.overrideController &= ~OverrideControllers.LeftController;
						this.updateControllers = true;
					}
					this.lastLeftPos = this.tempLeftPos;
				}
				if (this.updateControllers)
				{
					this.overrideEnabled = (this.overrideController > OverrideControllers.None);
					this.UpdateControllerStates();
				}
			}
		}
		yield break;
	}

	// Token: 0x0600126F RID: 4719 RVA: 0x0006248A File Offset: 0x0006068A
	private void DeviceDisconnected(InputDevice device)
	{
		if ((device.characteristics & (InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right)) == (InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right))
		{
			this.rightControllerValid = false;
		}
		if ((device.characteristics & (InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left)) == (InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left))
		{
			this.leftControllerValid = false;
		}
		this.UpdateControllerStates();
	}

	// Token: 0x06001270 RID: 4720 RVA: 0x000624C8 File Offset: 0x000606C8
	private void DeviceConnected(InputDevice device)
	{
		if ((device.characteristics & (InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right)) == (InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right))
		{
			this.rightControllerValid = true;
		}
		if ((device.characteristics & (InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left)) == (InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left))
		{
			this.leftControllerValid = true;
		}
		this.UpdateControllerStates();
	}

	// Token: 0x06001271 RID: 4721 RVA: 0x00062508 File Offset: 0x00060708
	private void UpdateControllerStates()
	{
		if (this.overrideEnabled && this.overrideController != OverrideControllers.None)
		{
			this.rightValid = (this.rightControllerValid && (this.overrideController & OverrideControllers.RightController) != OverrideControllers.RightController);
			this.leftValid = (this.leftControllerValid && (this.overrideController & OverrideControllers.LeftController) != OverrideControllers.LeftController);
		}
		else
		{
			this.rightValid = this.rightControllerValid;
			this.leftValid = this.leftControllerValid;
		}
		this.rightXRController.enabled = this.rightValid;
		this.leftXRController.enabled = this.leftValid;
		this.AssignSnapturnController();
	}

	// Token: 0x06001272 RID: 4722 RVA: 0x000625A8 File Offset: 0x000607A8
	private void AssignSnapturnController()
	{
		if (!this.leftValid && this.rightValid)
		{
			this.snapTurnController.controllers = this.rightControllerList;
			return;
		}
		if (!this.rightValid && this.leftValid)
		{
			this.snapTurnController.controllers = this.leftcontrollerList;
			return;
		}
		this.snapTurnController.controllers = this.rightControllerList;
	}

	// Token: 0x06001273 RID: 4723 RVA: 0x0006260C File Offset: 0x0006080C
	public bool GetValidForXRNode(XRNode controllerNode)
	{
		bool result;
		if (controllerNode != XRNode.LeftHand)
		{
			result = (controllerNode != XRNode.RightHand || this.rightValid);
		}
		else
		{
			result = this.leftValid;
		}
		return result;
	}

	// Token: 0x04001555 RID: 5461
	[SerializeField]
	private HandTransformFollowOffest rightHandFollower;

	// Token: 0x04001556 RID: 5462
	[SerializeField]
	private HandTransformFollowOffest leftHandFollower;

	// Token: 0x04001557 RID: 5463
	[SerializeField]
	private XRController rightXRController;

	// Token: 0x04001558 RID: 5464
	[SerializeField]
	private XRController leftXRController;

	// Token: 0x04001559 RID: 5465
	[SerializeField]
	private GorillaSnapTurn snapTurnController;

	// Token: 0x0400155A RID: 5466
	private List<XRController> rightControllerList;

	// Token: 0x0400155B RID: 5467
	private List<XRController> leftcontrollerList;

	// Token: 0x0400155C RID: 5468
	private const InputDeviceCharacteristics rightCharecteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Right;

	// Token: 0x0400155D RID: 5469
	private const InputDeviceCharacteristics leftCharecteristics = InputDeviceCharacteristics.Controller | InputDeviceCharacteristics.Left;

	// Token: 0x0400155E RID: 5470
	private bool rightControllerValid = true;

	// Token: 0x0400155F RID: 5471
	private bool leftControllerValid = true;

	// Token: 0x04001560 RID: 5472
	[SerializeField]
	private bool rightValid = true;

	// Token: 0x04001561 RID: 5473
	[SerializeField]
	private bool leftValid = true;

	// Token: 0x04001562 RID: 5474
	[SerializeField]
	private Vector3 lastRightPos;

	// Token: 0x04001563 RID: 5475
	[SerializeField]
	private Vector3 lastLeftPos;

	// Token: 0x04001564 RID: 5476
	private Vector3 tempRightPos;

	// Token: 0x04001565 RID: 5477
	private Vector3 tempLeftPos;

	// Token: 0x04001566 RID: 5478
	private bool updateControllers;

	// Token: 0x04001567 RID: 5479
	private Player playerHandler;

	// Token: 0x04001568 RID: 5480
	[Tooltip("The rate at which controllers are checked to be moving, if they not moving, overrides and enables one hand mode")]
	[SerializeField]
	private float overridePollRate = 15f;

	// Token: 0x04001569 RID: 5481
	[SerializeField]
	private bool overrideEnabled;

	// Token: 0x0400156A RID: 5482
	[SerializeField]
	private OverrideControllers overrideController;
}
