﻿using System;

namespace emotitron.CompressionTests
{
	// Token: 0x020007C5 RID: 1989
	public class BasicWriter
	{
		// Token: 0x06003041 RID: 12353 RVA: 0x000ECC66 File Offset: 0x000EAE66
		public static void Reset()
		{
			BasicWriter.pos = 0;
		}

		// Token: 0x06003042 RID: 12354 RVA: 0x000ECC6E File Offset: 0x000EAE6E
		public static byte[] BasicWrite(byte[] buffer, byte value)
		{
			buffer[BasicWriter.pos] = value;
			BasicWriter.pos++;
			return buffer;
		}

		// Token: 0x06003043 RID: 12355 RVA: 0x000ECC85 File Offset: 0x000EAE85
		public static byte BasicRead(byte[] buffer)
		{
			byte result = buffer[BasicWriter.pos];
			BasicWriter.pos++;
			return result;
		}

		// Token: 0x040032B8 RID: 12984
		public static int pos;
	}
}
