﻿using System;
using UnityEngine;

// Token: 0x02000301 RID: 769
public class GorillaHeadset : MonoBehaviour
{
	// Token: 0x0600118F RID: 4495 RVA: 0x00003051 File Offset: 0x00001251
	private void Start()
	{
	}

	// Token: 0x06001190 RID: 4496 RVA: 0x00003051 File Offset: 0x00001251
	private void Update()
	{
	}
}
