﻿using System;
using System.Collections;
using System.Threading;
using UnityEngine;

// Token: 0x0200036D RID: 877
public class GorillaDayNight : MonoBehaviour
{
	// Token: 0x060013EC RID: 5100 RVA: 0x00068CE4 File Offset: 0x00066EE4
	public void Awake()
	{
		if (GorillaDayNight.instance == null)
		{
			GorillaDayNight.instance = this;
		}
		else if (GorillaDayNight.instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		this.test = false;
		this.working = false;
		this.lerpValue = 0.5f;
		this.workingLightMapDatas = new LightmapData[3];
		this.workingLightMapData = new LightmapData();
		this.workingLightMapData.lightmapColor = this.lightmapDatas[0].lightTextures[0];
		this.workingLightMapData.lightmapDir = this.lightmapDatas[0].dirTextures[0];
	}

	// Token: 0x060013ED RID: 5101 RVA: 0x00068D88 File Offset: 0x00066F88
	public void Update()
	{
		if (this.test)
		{
			this.test = false;
			base.StartCoroutine(this.LightMapSet(this.firstData, this.secondData, this.lerpValue));
		}
	}

	// Token: 0x060013EE RID: 5102 RVA: 0x00068DB8 File Offset: 0x00066FB8
	public void DoWork()
	{
		this.k = 0;
		while (this.k < this.lightmapDatas[this.firstData].lights.Length)
		{
			this.fromPixels = this.lightmapDatas[this.firstData].lights[this.k];
			this.toPixels = this.lightmapDatas[this.secondData].lights[this.k];
			this.mixedPixels = this.fromPixels;
			this.j = 0;
			while (this.j < this.mixedPixels.Length)
			{
				this.mixedPixels[this.j] = Color.Lerp(this.fromPixels[this.j], this.toPixels[this.j], this.lerpValue);
				this.j++;
			}
			this.workingLightMapData.lightmapColor.SetPixels(this.mixedPixels);
			this.workingLightMapData.lightmapDir.Apply(false);
			this.fromPixels = this.lightmapDatas[this.firstData].dirs[this.k];
			this.toPixels = this.lightmapDatas[this.secondData].dirs[this.k];
			this.mixedPixels = this.fromPixels;
			this.j = 0;
			while (this.j < this.mixedPixels.Length)
			{
				this.mixedPixels[this.j] = Color.Lerp(this.fromPixels[this.j], this.toPixels[this.j], this.lerpValue);
				this.j++;
			}
			this.workingLightMapData.lightmapDir.SetPixels(this.mixedPixels);
			this.workingLightMapData.lightmapDir.Apply(false);
			this.workingLightMapDatas[this.k] = this.workingLightMapData;
			this.k++;
		}
		this.done = true;
	}

	// Token: 0x060013EF RID: 5103 RVA: 0x00068FC4 File Offset: 0x000671C4
	public void DoLightsStep()
	{
		this.fromPixels = this.lightmapDatas[this.firstData].lights[this.k];
		this.toPixels = this.lightmapDatas[this.secondData].lights[this.k];
		this.mixedPixels = this.fromPixels;
		this.j = 0;
		while (this.j < this.mixedPixels.Length)
		{
			this.mixedPixels[this.j] = Color.Lerp(this.fromPixels[this.j], this.toPixels[this.j], this.lerpValue);
			this.j++;
		}
		this.finishedStep = true;
	}

	// Token: 0x060013F0 RID: 5104 RVA: 0x00069088 File Offset: 0x00067288
	public void DoDirsStep()
	{
		this.fromPixels = this.lightmapDatas[this.firstData].dirs[this.k];
		this.toPixels = this.lightmapDatas[this.secondData].dirs[this.k];
		this.mixedPixels = this.fromPixels;
		this.j = 0;
		while (this.j < this.mixedPixels.Length)
		{
			this.mixedPixels[this.j] = Color.Lerp(this.fromPixels[this.j], this.toPixels[this.j], this.lerpValue);
			this.j++;
		}
		this.finishedStep = true;
	}

	// Token: 0x060013F1 RID: 5105 RVA: 0x0006914B File Offset: 0x0006734B
	private IEnumerator LightMapSet(int setFirstData, int setSecondData, float setLerp)
	{
		this.working = true;
		this.firstData = setFirstData;
		this.secondData = setSecondData;
		this.lerpValue = setLerp;
		this.k = 0;
		while (this.k < this.lightmapDatas[this.firstData].lights.Length)
		{
			this.lightsThread = new Thread(new ThreadStart(this.DoLightsStep));
			this.lightsThread.Start();
			yield return new WaitUntil(() => this.finishedStep);
			this.finishedStep = false;
			this.workingLightMapData.lightmapColor.SetPixels(this.mixedPixels);
			this.workingLightMapData.lightmapColor.Apply(false);
			this.dirsThread = new Thread(new ThreadStart(this.DoDirsStep));
			this.dirsThread.Start();
			yield return new WaitUntil(() => this.finishedStep);
			this.finishedStep = false;
			this.workingLightMapData.lightmapDir.SetPixels(this.mixedPixels);
			this.workingLightMapData.lightmapDir.Apply(false);
			this.workingLightMapDatas[this.k] = this.workingLightMapData;
			this.k++;
		}
		LightmapSettings.lightmaps = this.workingLightMapDatas;
		this.working = false;
		this.done = true;
		yield break;
	}

	// Token: 0x040016B8 RID: 5816
	[OnEnterPlay_SetNull]
	public static volatile GorillaDayNight instance;

	// Token: 0x040016B9 RID: 5817
	public GorillaLightmapData[] lightmapDatas;

	// Token: 0x040016BA RID: 5818
	private LightmapData[] workingLightMapDatas;

	// Token: 0x040016BB RID: 5819
	private LightmapData workingLightMapData;

	// Token: 0x040016BC RID: 5820
	public float lerpValue;

	// Token: 0x040016BD RID: 5821
	public bool done;

	// Token: 0x040016BE RID: 5822
	public bool finishedStep;

	// Token: 0x040016BF RID: 5823
	private Color[] fromPixels;

	// Token: 0x040016C0 RID: 5824
	private Color[] toPixels;

	// Token: 0x040016C1 RID: 5825
	private Color[] mixedPixels;

	// Token: 0x040016C2 RID: 5826
	public int firstData;

	// Token: 0x040016C3 RID: 5827
	public int secondData;

	// Token: 0x040016C4 RID: 5828
	public int i;

	// Token: 0x040016C5 RID: 5829
	public int j;

	// Token: 0x040016C6 RID: 5830
	public int k;

	// Token: 0x040016C7 RID: 5831
	public int l;

	// Token: 0x040016C8 RID: 5832
	private Thread lightsThread;

	// Token: 0x040016C9 RID: 5833
	private Thread dirsThread;

	// Token: 0x040016CA RID: 5834
	public bool test;

	// Token: 0x040016CB RID: 5835
	public bool working;
}
