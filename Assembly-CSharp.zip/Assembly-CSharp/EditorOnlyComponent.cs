﻿using System;
using UnityEngine;

// Token: 0x02000425 RID: 1061
public abstract class EditorOnlyComponent : MonoBehaviour
{
}
