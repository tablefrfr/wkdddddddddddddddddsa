﻿using System;
using UnityEngine;

namespace BoingKit
{
	// Token: 0x02000828 RID: 2088
	[Serializable]
	public struct Bits32
	{
		// Token: 0x17000576 RID: 1398
		// (get) Token: 0x060032A4 RID: 12964 RVA: 0x000FE4A7 File Offset: 0x000FC6A7
		public int IntValue
		{
			get
			{
				return this.m_bits;
			}
		}

		// Token: 0x060032A5 RID: 12965 RVA: 0x000FE4AF File Offset: 0x000FC6AF
		public Bits32(int bits = 0)
		{
			this.m_bits = bits;
		}

		// Token: 0x060032A6 RID: 12966 RVA: 0x000FE4B8 File Offset: 0x000FC6B8
		public void Clear()
		{
			this.m_bits = 0;
		}

		// Token: 0x060032A7 RID: 12967 RVA: 0x000FE4C1 File Offset: 0x000FC6C1
		public void SetBit(int index, bool value)
		{
			if (value)
			{
				this.m_bits |= 1 << index;
				return;
			}
			this.m_bits &= ~(1 << index);
		}

		// Token: 0x060032A8 RID: 12968 RVA: 0x000FE4EE File Offset: 0x000FC6EE
		public bool IsBitSet(int index)
		{
			return (this.m_bits & 1 << index) != 0;
		}

		// Token: 0x04003528 RID: 13608
		[SerializeField]
		private int m_bits;
	}
}
