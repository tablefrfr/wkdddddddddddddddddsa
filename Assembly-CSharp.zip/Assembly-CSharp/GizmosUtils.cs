﻿using System;
using System.Diagnostics;
using UnityEngine;

// Token: 0x020004C3 RID: 1219
public static class GizmosUtils
{
	// Token: 0x06001BA8 RID: 7080 RVA: 0x00003051 File Offset: 0x00001251
	[Conditional("UNITY_EDITOR")]
	public static void DrawCubeTRS(Vector3 t, Quaternion r, Vector3 s)
	{
	}

	// Token: 0x06001BA9 RID: 7081 RVA: 0x00003051 File Offset: 0x00001251
	[Conditional("UNITY_EDITOR")]
	public static void DrawWireCubeTRS(Vector3 t, Quaternion r, Vector3 s)
	{
	}
}
