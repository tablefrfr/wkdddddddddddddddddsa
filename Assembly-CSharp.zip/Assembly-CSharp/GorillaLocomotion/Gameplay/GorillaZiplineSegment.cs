﻿using System;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005C7 RID: 1479
	public class GorillaZiplineSegment : MonoBehaviour
	{
		// Token: 0x04002502 RID: 9474
		public float startT;
	}
}
