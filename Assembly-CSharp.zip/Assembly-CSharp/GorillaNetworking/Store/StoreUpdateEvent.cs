﻿using System;
using System.Collections.Generic;
using LitJson;
using Newtonsoft.Json;
using UnityEngine;

namespace GorillaNetworking.Store
{
	// Token: 0x020006FD RID: 1789
	public class StoreUpdateEvent
	{
		// Token: 0x06002A54 RID: 10836 RVA: 0x00002050 File Offset: 0x00000250
		public StoreUpdateEvent()
		{
		}

		// Token: 0x06002A55 RID: 10837 RVA: 0x000CFDCC File Offset: 0x000CDFCC
		public StoreUpdateEvent(string pedestalID, string itemName, DateTime startTimeUTC, DateTime endTimeUTC)
		{
			this.PedestalID = pedestalID;
			this.ItemName = itemName;
			this.StartTimeUTC = startTimeUTC;
			this.EndTimeUTC = endTimeUTC;
		}

		// Token: 0x06002A56 RID: 10838 RVA: 0x000CFDF1 File Offset: 0x000CDFF1
		public static string SerializeAsJSon(StoreUpdateEvent storeEvent)
		{
			return JsonUtility.ToJson(storeEvent);
		}

		// Token: 0x06002A57 RID: 10839 RVA: 0x000CFDF9 File Offset: 0x000CDFF9
		public static string SerializeArrayAsJSon(StoreUpdateEvent[] storeEvents)
		{
			return JsonConvert.SerializeObject(storeEvents);
		}

		// Token: 0x06002A58 RID: 10840 RVA: 0x000CFE01 File Offset: 0x000CE001
		public static StoreUpdateEvent DeserializeFromJSon(string json)
		{
			return JsonUtility.FromJson<StoreUpdateEvent>(json);
		}

		// Token: 0x06002A59 RID: 10841 RVA: 0x000CFE0C File Offset: 0x000CE00C
		public static StoreUpdateEvent[] DeserializeFromJSonArray(string json)
		{
			List<StoreUpdateEvent> list = JsonConvert.DeserializeObject<List<StoreUpdateEvent>>(json);
			return JsonMapper.ToObject<List<StoreUpdateEvent>>(json).ToArray();
		}

		// Token: 0x06002A5A RID: 10842 RVA: 0x000CFE2C File Offset: 0x000CE02C
		public static List<StoreUpdateEvent> DeserializeFromJSonList(string json)
		{
			return JsonMapper.ToObject<List<StoreUpdateEvent>>(json);
		}

		// Token: 0x04002D65 RID: 11621
		public string PedestalID;

		// Token: 0x04002D66 RID: 11622
		public string ItemName;

		// Token: 0x04002D67 RID: 11623
		public DateTime StartTimeUTC;

		// Token: 0x04002D68 RID: 11624
		public DateTime EndTimeUTC;
	}
}
