﻿using System;
using UnityEngine;

// Token: 0x02000055 RID: 85
public class CloudUmbrellaCloud : MonoBehaviour
{
	// Token: 0x060001C1 RID: 449 RVA: 0x0000D45D File Offset: 0x0000B65D
	protected void Awake()
	{
		this.umbrellaXform = this.umbrella.transform;
		this.cloudScaleXform = this.cloudRenderer.transform;
	}

	// Token: 0x060001C2 RID: 450 RVA: 0x0000D484 File Offset: 0x0000B684
	protected void LateUpdate()
	{
		float time = Vector3.Dot(this.umbrellaXform.up, Vector3.up);
		float num = Mathf.Clamp01(this.scaleCurve.Evaluate(time));
		this.rendererOn = ((num > 0.09f && num < 0.1f) ? this.rendererOn : (num > 0.1f));
		this.cloudRenderer.enabled = this.rendererOn;
		this.cloudScaleXform.localScale = new Vector3(num, num, num);
		this.cloudRotateXform.up = Vector3.up;
	}

	// Token: 0x0400024F RID: 591
	public UmbrellaItem umbrella;

	// Token: 0x04000250 RID: 592
	public Transform cloudRotateXform;

	// Token: 0x04000251 RID: 593
	public Renderer cloudRenderer;

	// Token: 0x04000252 RID: 594
	public AnimationCurve scaleCurve;

	// Token: 0x04000253 RID: 595
	private const float kHideAtScale = 0.1f;

	// Token: 0x04000254 RID: 596
	private const float kHideAtScaleTolerance = 0.01f;

	// Token: 0x04000255 RID: 597
	private bool rendererOn;

	// Token: 0x04000256 RID: 598
	private Transform umbrellaXform;

	// Token: 0x04000257 RID: 599
	private Transform cloudScaleXform;
}
