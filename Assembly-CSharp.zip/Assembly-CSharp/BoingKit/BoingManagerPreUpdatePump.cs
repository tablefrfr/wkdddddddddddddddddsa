﻿using System;
using UnityEngine;

namespace BoingKit
{
	// Token: 0x0200080C RID: 2060
	public class BoingManagerPreUpdatePump : MonoBehaviour
	{
		// Token: 0x060031FD RID: 12797 RVA: 0x000F868E File Offset: 0x000F688E
		private void FixedUpdate()
		{
			this.TryPump();
		}

		// Token: 0x060031FE RID: 12798 RVA: 0x000F868E File Offset: 0x000F688E
		private void Update()
		{
			this.TryPump();
		}

		// Token: 0x060031FF RID: 12799 RVA: 0x000F8696 File Offset: 0x000F6896
		private void TryPump()
		{
			if (this.m_lastPumpedFrame >= Time.frameCount)
			{
				return;
			}
			if (this.m_lastPumpedFrame >= 0)
			{
				this.DoPump();
			}
			this.m_lastPumpedFrame = Time.frameCount;
		}

		// Token: 0x06003200 RID: 12800 RVA: 0x000F86C0 File Offset: 0x000F68C0
		private void DoPump()
		{
			BoingManager.RestoreBehaviors();
			BoingManager.RestoreReactors();
			BoingManager.RestoreBones();
			BoingManager.DispatchReactorFieldCompute();
		}

		// Token: 0x04003448 RID: 13384
		private int m_lastPumpedFrame = -1;
	}
}
