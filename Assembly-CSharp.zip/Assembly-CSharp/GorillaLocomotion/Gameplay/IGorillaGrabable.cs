﻿using System;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005C9 RID: 1481
	internal interface IGorillaGrabable
	{
		// Token: 0x060022A5 RID: 8869
		Transform OnGrabbed(GorillaGrabber grabber);

		// Token: 0x060022A6 RID: 8870
		Transform OnGrabReleased(GorillaGrabber grabber);
	}
}
