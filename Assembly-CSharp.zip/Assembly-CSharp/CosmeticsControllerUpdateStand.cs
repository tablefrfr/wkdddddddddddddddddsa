﻿using System;
using System.Collections;
using GorillaNetworking;
using UnityEngine;

// Token: 0x02000282 RID: 642
public class CosmeticsControllerUpdateStand : MonoBehaviour
{
	// Token: 0x06000E2E RID: 3630 RVA: 0x0004A930 File Offset: 0x00048B30
	public GameObject ReturnChildWithCosmeticNameMatch(Transform parentTransform)
	{
		GameObject gameObject = null;
		using (IEnumerator enumerator = parentTransform.GetEnumerator())
		{
			while (enumerator.MoveNext())
			{
				Transform child = (Transform)enumerator.Current;
				if (child.gameObject.activeInHierarchy && this.cosmeticsController.allCosmetics.FindIndex((CosmeticsController.CosmeticItem x) => child.name == x.itemName) > -1)
				{
					return child.gameObject;
				}
				gameObject = this.ReturnChildWithCosmeticNameMatch(child);
				if (gameObject != null)
				{
					return gameObject;
				}
			}
		}
		return gameObject;
	}

	// Token: 0x0400100D RID: 4109
	public CosmeticsController cosmeticsController;

	// Token: 0x0400100E RID: 4110
	public bool FailEntitlement;

	// Token: 0x0400100F RID: 4111
	public bool PlayerUnlocked;

	// Token: 0x04001010 RID: 4112
	public bool ItemNotGrantedYet;

	// Token: 0x04001011 RID: 4113
	public bool ItemSuccessfullyGranted;

	// Token: 0x04001012 RID: 4114
	public bool AttemptToConsumeEntitlement;

	// Token: 0x04001013 RID: 4115
	public bool EntitlementSuccessfullyConsumed;

	// Token: 0x04001014 RID: 4116
	public bool LockSuccessfullyCleared;

	// Token: 0x04001015 RID: 4117
	public bool RunDebug;

	// Token: 0x04001016 RID: 4118
	public Transform textParent;

	// Token: 0x04001017 RID: 4119
	private CosmeticsController.CosmeticItem outItem;

	// Token: 0x04001018 RID: 4120
	public HeadModel[] inventoryHeadModels;

	// Token: 0x04001019 RID: 4121
	public string headModelsPrefabPath;
}
