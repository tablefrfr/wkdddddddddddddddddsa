﻿using System;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005BE RID: 1470
	public class CustomRopeNode : MonoBehaviour
	{
		// Token: 0x040024C1 RID: 9409
		public Vector3 previousPos;
	}
}
