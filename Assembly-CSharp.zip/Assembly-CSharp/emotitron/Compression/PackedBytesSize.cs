﻿using System;

namespace emotitron.Compression
{
	// Token: 0x020007B4 RID: 1972
	public enum PackedBytesSize
	{
		// Token: 0x04003263 RID: 12899
		UInt8 = 1,
		// Token: 0x04003264 RID: 12900
		UInt16,
		// Token: 0x04003265 RID: 12901
		UInt32,
		// Token: 0x04003266 RID: 12902
		UInt64
	}
}
