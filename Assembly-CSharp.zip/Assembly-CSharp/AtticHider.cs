﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000312 RID: 786
public class AtticHider : MonoBehaviour
{
	// Token: 0x060011BC RID: 4540 RVA: 0x0005CBFB File Offset: 0x0005ADFB
	private void Start()
	{
		this.OnZoneChanged();
		ZoneManagement instance = ZoneManagement.instance;
		instance.onZoneChanged = (Action)Delegate.Combine(instance.onZoneChanged, new Action(this.OnZoneChanged));
	}

	// Token: 0x060011BD RID: 4541 RVA: 0x0005CC29 File Offset: 0x0005AE29
	private void OnDestroy()
	{
		ZoneManagement instance = ZoneManagement.instance;
		instance.onZoneChanged = (Action)Delegate.Remove(instance.onZoneChanged, new Action(this.OnZoneChanged));
	}

	// Token: 0x060011BE RID: 4542 RVA: 0x0005CC54 File Offset: 0x0005AE54
	private void OnZoneChanged()
	{
		if (this.AtticRenderer == null)
		{
			return;
		}
		if (ZoneManagement.instance.IsZoneActive(GTZone.attic))
		{
			if (this._coroutine != null)
			{
				base.StopCoroutine(this._coroutine);
				this._coroutine = null;
			}
			this._coroutine = base.StartCoroutine(this.WaitForAtticLoad());
			return;
		}
		if (this._coroutine != null)
		{
			base.StopCoroutine(this._coroutine);
			this._coroutine = null;
		}
		this.AtticRenderer.enabled = true;
	}

	// Token: 0x060011BF RID: 4543 RVA: 0x0005CCD3 File Offset: 0x0005AED3
	private IEnumerator WaitForAtticLoad()
	{
		while (!ZoneManagement.instance.IsSceneLoaded(GTZone.attic))
		{
			yield return new WaitForSeconds(0.2f);
		}
		yield return null;
		this.AtticRenderer.enabled = false;
		this._coroutine = null;
		yield break;
	}

	// Token: 0x04001442 RID: 5186
	[SerializeField]
	private MeshRenderer AtticRenderer;

	// Token: 0x04001443 RID: 5187
	private Coroutine _coroutine;
}
