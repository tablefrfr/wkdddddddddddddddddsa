﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Fusion.CodeGen
{
	// Token: 0x02000842 RID: 2114
	[NetworkStructWeaved(17)]
	[Serializable]
	[StructLayout(LayoutKind.Explicit)]
	internal struct FixedStorage@17 : INetworkStruct
	{
		// Token: 0x0400356E RID: 13678
		[FixedBuffer(typeof(int), 17)]
		[FieldOffset(0)]
		public FixedStorage@17.<Data>e__FixedBuffer Data;

		// Token: 0x0400356F RID: 13679
		[NonSerialized]
		[FieldOffset(4)]
		private int _1;

		// Token: 0x04003570 RID: 13680
		[NonSerialized]
		[FieldOffset(8)]
		private int _2;

		// Token: 0x04003571 RID: 13681
		[NonSerialized]
		[FieldOffset(12)]
		private int _3;

		// Token: 0x04003572 RID: 13682
		[NonSerialized]
		[FieldOffset(16)]
		private int _4;

		// Token: 0x04003573 RID: 13683
		[NonSerialized]
		[FieldOffset(20)]
		private int _5;

		// Token: 0x04003574 RID: 13684
		[NonSerialized]
		[FieldOffset(24)]
		private int _6;

		// Token: 0x04003575 RID: 13685
		[NonSerialized]
		[FieldOffset(28)]
		private int _7;

		// Token: 0x04003576 RID: 13686
		[NonSerialized]
		[FieldOffset(32)]
		private int _8;

		// Token: 0x04003577 RID: 13687
		[NonSerialized]
		[FieldOffset(36)]
		private int _9;

		// Token: 0x04003578 RID: 13688
		[NonSerialized]
		[FieldOffset(40)]
		private int _10;

		// Token: 0x04003579 RID: 13689
		[NonSerialized]
		[FieldOffset(44)]
		private int _11;

		// Token: 0x0400357A RID: 13690
		[NonSerialized]
		[FieldOffset(48)]
		private int _12;

		// Token: 0x0400357B RID: 13691
		[NonSerialized]
		[FieldOffset(52)]
		private int _13;

		// Token: 0x0400357C RID: 13692
		[NonSerialized]
		[FieldOffset(56)]
		private int _14;

		// Token: 0x0400357D RID: 13693
		[NonSerialized]
		[FieldOffset(60)]
		private int _15;

		// Token: 0x0400357E RID: 13694
		[NonSerialized]
		[FieldOffset(64)]
		private int _16;

		// Token: 0x02000843 RID: 2115
		[CompilerGenerated]
		[UnsafeValueType]
		[StructLayout(LayoutKind.Sequential, Size = 68)]
		public struct <Data>e__FixedBuffer
		{
			// Token: 0x0400357F RID: 13695
			private int FixedElementField;
		}
	}
}
