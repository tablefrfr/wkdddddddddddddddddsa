﻿using System;
using UnityEngine;

namespace CjLib
{
	// Token: 0x020007D1 RID: 2001
	[ExecuteInEditMode]
	public class DrawArc : DrawBase
	{
		// Token: 0x06003073 RID: 12403 RVA: 0x000ED466 File Offset: 0x000EB666
		private void OnValidate()
		{
			this.Wireframe = true;
			this.Style = DebugUtil.Style.Wireframe;
			this.Radius = Mathf.Max(0f, this.Radius);
			this.NumSegments = Mathf.Max(0, this.NumSegments);
		}

		// Token: 0x06003074 RID: 12404 RVA: 0x000ED4A0 File Offset: 0x000EB6A0
		protected override void Draw(Color color, DebugUtil.Style style, bool depthTest)
		{
			Quaternion rhs = QuaternionUtil.AxisAngle(Vector3.forward, this.StartAngle * MathUtil.Deg2Rad);
			DebugUtil.DrawArc(base.transform.position, base.transform.rotation * rhs * Vector3.right, base.transform.rotation * Vector3.forward, this.ArcAngle * MathUtil.Deg2Rad, this.Radius, this.NumSegments, color, depthTest);
		}

		// Token: 0x040032DE RID: 13022
		public float Radius = 1f;

		// Token: 0x040032DF RID: 13023
		public int NumSegments = 64;

		// Token: 0x040032E0 RID: 13024
		public float StartAngle;

		// Token: 0x040032E1 RID: 13025
		public float ArcAngle = 60f;
	}
}
