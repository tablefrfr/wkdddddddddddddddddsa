﻿using System;
using System.Collections.Generic;
using System.Text;
using GorillaLocomotion;
using GorillaNetworking;
using TMPro;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x020004BB RID: 1211
public class DebugHudStats : MonoBehaviour
{
	// Token: 0x17000337 RID: 823
	// (get) Token: 0x06001B96 RID: 7062 RVA: 0x0008C093 File Offset: 0x0008A293
	public static DebugHudStats Instance
	{
		get
		{
			return DebugHudStats._instance;
		}
	}

	// Token: 0x06001B97 RID: 7063 RVA: 0x0008C09A File Offset: 0x0008A29A
	private void Awake()
	{
		if (DebugHudStats._instance != null && DebugHudStats._instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		else
		{
			DebugHudStats._instance = this;
		}
		base.gameObject.SetActive(false);
	}

	// Token: 0x06001B98 RID: 7064 RVA: 0x0008C0D5 File Offset: 0x0008A2D5
	private void OnDestroy()
	{
		if (DebugHudStats._instance == this)
		{
			DebugHudStats._instance = null;
		}
	}

	// Token: 0x06001B99 RID: 7065 RVA: 0x0008C0EC File Offset: 0x0008A2EC
	private void Update()
	{
		bool flag = ControllerInputPoller.SecondaryButtonPress(XRNode.LeftHand);
		if (flag != this.buttonDown)
		{
			this.buttonDown = flag;
			if (!this.buttonDown)
			{
				if (!this.text.gameObject.activeInHierarchy)
				{
					this.text.gameObject.SetActive(true);
					this.showLog = false;
				}
				else if (!this.showLog)
				{
					this.showLog = true;
				}
				else
				{
					this.text.gameObject.SetActive(false);
				}
			}
		}
		if (this.firstAwake == 0f)
		{
			this.firstAwake = Time.time;
		}
		if (this.updateTimer < this.delayUpdateRate)
		{
			this.updateTimer += Time.deltaTime;
			return;
		}
		this.builder.Clear();
		this.builder.Append("v: ");
		this.builder.Append(GorillaComputer.instance.version);
		this.builder.Append(":");
		this.builder.Append(GorillaComputer.instance.buildCode);
		int num = Mathf.RoundToInt(1f / Time.smoothDeltaTime);
		if (num < 89)
		{
			this.lowFps++;
		}
		else
		{
			this.lowFps = 0;
		}
		this.fpsWarning.gameObject.SetActive(this.lowFps > 5);
		num = Mathf.Min(num, 90);
		this.builder.Append((num < 89) ? " - <color=\"red\">" : " - <color=\"white\">");
		this.builder.Append(num);
		this.builder.AppendLine(" fps</color>");
		if (GorillaComputer.instance != null)
		{
			this.builder.AppendLine(GorillaComputer.instance.GetServerTime().ToString());
		}
		else
		{
			this.builder.AppendLine("Server Time Unavailable");
		}
		float magnitude = Player.Instance.currentVelocity.magnitude;
		this.builder.Append(Mathf.RoundToInt(magnitude));
		this.builder.AppendLine(" m/s");
		if (this.showLog)
		{
			this.builder.AppendLine();
			for (int i = 0; i < this.logMessages.Count; i++)
			{
				this.builder.AppendLine(this.logMessages[i]);
			}
		}
		this.text.text = this.builder.ToString();
		this.updateTimer = 0f;
	}

	// Token: 0x06001B9A RID: 7066 RVA: 0x0008C364 File Offset: 0x0008A564
	private void OnEnable()
	{
		Application.logMessageReceived += this.LogMessageReceived;
	}

	// Token: 0x06001B9B RID: 7067 RVA: 0x0008C377 File Offset: 0x0008A577
	private void LogMessageReceived(string condition, string stackTrace, LogType type)
	{
		this.logMessages.Add(this.getColorStringFromLogType(type) + condition + "</color>");
		if (this.logMessages.Count > 6)
		{
			this.logMessages.RemoveAt(0);
		}
	}

	// Token: 0x06001B9C RID: 7068 RVA: 0x0008C3B0 File Offset: 0x0008A5B0
	private string getColorStringFromLogType(LogType type)
	{
		switch (type)
		{
		case LogType.Error:
		case LogType.Assert:
		case LogType.Exception:
			return "<color=\"red\">";
		case LogType.Warning:
			return "<color=\"yellow\">";
		}
		return "<color=\"white\">";
	}

	// Token: 0x06001B9D RID: 7069 RVA: 0x0008C3DF File Offset: 0x0008A5DF
	private void OnDisable()
	{
		Application.logMessageReceived -= this.LogMessageReceived;
	}

	// Token: 0x04001F5E RID: 8030
	private static DebugHudStats _instance;

	// Token: 0x04001F5F RID: 8031
	[SerializeField]
	private TMP_Text text;

	// Token: 0x04001F60 RID: 8032
	[SerializeField]
	private TMP_Text fpsWarning;

	// Token: 0x04001F61 RID: 8033
	[SerializeField]
	private float delayUpdateRate = 0.25f;

	// Token: 0x04001F62 RID: 8034
	private float updateTimer;

	// Token: 0x04001F63 RID: 8035
	public float sessionAnytrackingLost;

	// Token: 0x04001F64 RID: 8036
	public float last30SecondsTrackingLost;

	// Token: 0x04001F65 RID: 8037
	private float firstAwake;

	// Token: 0x04001F66 RID: 8038
	private bool wasTrackingLost;

	// Token: 0x04001F67 RID: 8039
	private bool leftHandTracked;

	// Token: 0x04001F68 RID: 8040
	private bool rightHandTracked;

	// Token: 0x04001F69 RID: 8041
	private StringBuilder builder;

	// Token: 0x04001F6A RID: 8042
	private List<string> logMessages = new List<string>();

	// Token: 0x04001F6B RID: 8043
	private bool buttonDown;

	// Token: 0x04001F6C RID: 8044
	private bool showLog;

	// Token: 0x04001F6D RID: 8045
	private int lowFps;
}
