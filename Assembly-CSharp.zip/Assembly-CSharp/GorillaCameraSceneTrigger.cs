﻿using System;
using UnityEngine;

// Token: 0x020002FE RID: 766
public class GorillaCameraSceneTrigger : MonoBehaviour
{
	// Token: 0x06001186 RID: 4486 RVA: 0x0005C470 File Offset: 0x0005A670
	public void ChangeScene(GorillaCameraTriggerIndex triggerLeft)
	{
		if (triggerLeft == this.currentSceneTrigger || this.currentSceneTrigger == null)
		{
			if (this.mostRecentSceneTrigger != this.currentSceneTrigger)
			{
				this.sceneCamera.SetSceneCamera(this.mostRecentSceneTrigger.sceneTriggerIndex);
				this.currentSceneTrigger = this.mostRecentSceneTrigger;
				return;
			}
			this.currentSceneTrigger = null;
		}
	}

	// Token: 0x040013E4 RID: 5092
	public GorillaSceneCamera sceneCamera;

	// Token: 0x040013E5 RID: 5093
	public GorillaCameraTriggerIndex currentSceneTrigger;

	// Token: 0x040013E6 RID: 5094
	public GorillaCameraTriggerIndex mostRecentSceneTrigger;
}
