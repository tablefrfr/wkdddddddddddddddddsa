﻿using System;
using Sirenix.OdinInspector;

// Token: 0x02000423 RID: 1059
[IncludeMyAttributes]
public class DebugReadOnlyAttribute : Attribute
{
}
