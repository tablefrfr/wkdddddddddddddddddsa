﻿using System;
using UnityEngine;

// Token: 0x020002FF RID: 767
public class GorillaCameraTriggerIndex : MonoBehaviour
{
	// Token: 0x06001188 RID: 4488 RVA: 0x0005C4D6 File Offset: 0x0005A6D6
	private void Start()
	{
		this.parentTrigger = base.GetComponentInParent<GorillaCameraSceneTrigger>();
	}

	// Token: 0x06001189 RID: 4489 RVA: 0x0005C4E4 File Offset: 0x0005A6E4
	private void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.CompareTag("SceneChanger"))
		{
			this.parentTrigger.mostRecentSceneTrigger = this;
			this.parentTrigger.ChangeScene(this);
		}
	}

	// Token: 0x0600118A RID: 4490 RVA: 0x0005C510 File Offset: 0x0005A710
	private void OnTriggerExit(Collider other)
	{
		if (other.gameObject.CompareTag("SceneChanger"))
		{
			this.parentTrigger.ChangeScene(this);
		}
	}

	// Token: 0x040013E7 RID: 5095
	public int sceneTriggerIndex;

	// Token: 0x040013E8 RID: 5096
	public GorillaCameraSceneTrigger parentTrigger;
}
