﻿using System;
using System.Collections;
using Unity.Collections;
using Unity.Jobs;
using UnityEngine;
using UnityEngine.Experimental.Rendering;

// Token: 0x020003F2 RID: 1010
public class DayNightCycle : MonoBehaviour
{
	// Token: 0x0600178A RID: 6026 RVA: 0x00078968 File Offset: 0x00076B68
	public void Awake()
	{
		this.fromMap = new Texture2D(this._sunriseMap.width, this._sunriseMap.height);
		this.fromMap = LightmapSettings.lightmaps[0].lightmapColor;
		this.toMap = new Texture2D(this._dayMap.width, this._dayMap.height);
		this.toMap.SetPixels(this._dayMap.GetPixels());
		this.toMap.Apply();
		this.workBlockMix = new Color[this.subTextureSize * this.subTextureSize];
		this.newTexture = new Texture2D(this.fromMap.width, this.fromMap.height, this.fromMap.graphicsFormat, TextureCreationFlags.None);
		this.newData = new LightmapData();
		this.textureHeight = this.fromMap.height;
		this.textureWidth = this.fromMap.width;
		this.subTextureArray = new Texture2D[(int)Mathf.Pow((float)(this.textureHeight / this.subTextureSize), 2f)];
		Debug.Log("aaaa " + this.fromMap.format.ToString());
		Debug.Log("aaaa " + this.fromMap.graphicsFormat.ToString());
		this.startJob = false;
		this.startCoroutine = false;
		this.startedCoroutine = false;
		this.finishedCoroutine = false;
	}

	// Token: 0x0600178B RID: 6027 RVA: 0x00078AEC File Offset: 0x00076CEC
	public void Update()
	{
		if (this.startJob)
		{
			this.startJob = false;
			this.startTime = Time.realtimeSinceStartup;
			base.StartCoroutine(this.UpdateWork());
			this.timeTakenStartingJob = Time.realtimeSinceStartup - this.startTime;
			this.startTime = Time.realtimeSinceStartup;
		}
		if (this.jobStarted && this.jobHandle.IsCompleted)
		{
			this.timeTakenDuringJob = Time.realtimeSinceStartup - this.startTime;
			this.startTime = Time.realtimeSinceStartup;
			this.jobHandle.Complete();
			this.jobStarted = false;
			this.newTexture.SetPixels(this.job.mixedPixels.ToArray());
			this.newData.lightmapDir = LightmapSettings.lightmaps[0].lightmapDir;
			LightmapSettings.lightmaps = new LightmapData[]
			{
				this.newData
			};
			this.job.fromPixels.Dispose();
			this.job.toPixels.Dispose();
			this.job.mixedPixels.Dispose();
			this.timeTakenPostJob = Time.realtimeSinceStartup - this.startTime;
		}
		if (this.startCoroutine)
		{
			this.startCoroutine = false;
			this.startTime = Time.realtimeSinceStartup;
			this.newTexture = new Texture2D(this.fromMap.width, this.fromMap.height);
			base.StartCoroutine(this.UpdateWork());
		}
		if (this.startedCoroutine && this.finishedCoroutine)
		{
			this.startedCoroutine = false;
			this.finishedCoroutine = false;
			this.timeTakenDuringJob = Time.realtimeSinceStartup - this.startTime;
			this.startTime = Time.realtimeSinceStartup;
			this.newData = LightmapSettings.lightmaps[0];
			this.newData.lightmapColor = this.fromMap;
			LightmapData[] lightmaps = LightmapSettings.lightmaps;
			lightmaps[0].lightmapColor = this.fromMap;
			LightmapSettings.lightmaps = lightmaps;
			this.timeTakenPostJob = Time.realtimeSinceStartup - this.startTime;
		}
	}

	// Token: 0x0600178C RID: 6028 RVA: 0x00078CDA File Offset: 0x00076EDA
	public IEnumerator UpdateWork()
	{
		yield return 0;
		this.timeTakenStartingJob = Time.realtimeSinceStartup - this.startTime;
		this.startTime = Time.realtimeSinceStartup;
		this.startedCoroutine = true;
		this.currentSubTexture = 0;
		int num;
		for (int i = 0; i < this.subTextureArray.Length; i = num + 1)
		{
			this.subTextureArray[i] = new Texture2D(this.subTextureSize, this.subTextureSize, this.fromMap.graphicsFormat, TextureCreationFlags.None);
			yield return 0;
			num = i;
		}
		for (int i = 0; i < this.textureWidth / this.subTextureSize; i = num + 1)
		{
			this.currentColumn = i;
			for (int j = 0; j < this.textureHeight / this.subTextureSize; j = num + 1)
			{
				this.currentRow = j;
				this.workBlockFrom = this.fromMap.GetPixels(i * this.subTextureSize, j * this.subTextureSize, this.subTextureSize, this.subTextureSize);
				this.workBlockTo = this.toMap.GetPixels(i * this.subTextureSize, j * this.subTextureSize, this.subTextureSize, this.subTextureSize);
				for (int k = 0; k < this.subTextureSize * this.subTextureSize - 1; k++)
				{
					this.workBlockMix[k] = Color.Lerp(this.workBlockFrom[k], this.workBlockTo[k], this.lerpAmount);
				}
				this.subTextureArray[j * (this.textureWidth / this.subTextureSize) + i].SetPixels(0, 0, this.subTextureSize, this.subTextureSize, this.workBlockMix);
				yield return 0;
				num = j;
			}
			num = i;
		}
		for (int i = 0; i < this.subTextureArray.Length; i = num + 1)
		{
			this.currentSubTexture = i;
			this.subTextureArray[i].Apply();
			yield return 0;
			Graphics.CopyTexture(this.subTextureArray[i], 0, 0, 0, 0, this.subTextureSize, this.subTextureSize, this.newTexture, 0, 0, i * this.subTextureSize % this.textureHeight, (int)Mathf.Floor((float)(this.subTextureSize * i / this.textureHeight)) * this.subTextureSize);
			yield return 0;
			num = i;
		}
		this.finishedCoroutine = true;
		yield break;
	}

	// Token: 0x04001AD9 RID: 6873
	public Texture2D _dayMap;

	// Token: 0x04001ADA RID: 6874
	private Texture2D fromMap;

	// Token: 0x04001ADB RID: 6875
	public Texture2D _sunriseMap;

	// Token: 0x04001ADC RID: 6876
	private Texture2D toMap;

	// Token: 0x04001ADD RID: 6877
	public DayNightCycle.LerpBakedLightingJob job;

	// Token: 0x04001ADE RID: 6878
	public JobHandle jobHandle;

	// Token: 0x04001ADF RID: 6879
	public bool isComplete;

	// Token: 0x04001AE0 RID: 6880
	private float startTime;

	// Token: 0x04001AE1 RID: 6881
	public float timeTakenStartingJob;

	// Token: 0x04001AE2 RID: 6882
	public float timeTakenPostJob;

	// Token: 0x04001AE3 RID: 6883
	public float timeTakenDuringJob;

	// Token: 0x04001AE4 RID: 6884
	public LightmapData newData;

	// Token: 0x04001AE5 RID: 6885
	private Color[] fromPixels;

	// Token: 0x04001AE6 RID: 6886
	private Color[] toPixels;

	// Token: 0x04001AE7 RID: 6887
	private Color[] mixedPixels;

	// Token: 0x04001AE8 RID: 6888
	private LightmapData[] newDatas;

	// Token: 0x04001AE9 RID: 6889
	public Texture2D newTexture;

	// Token: 0x04001AEA RID: 6890
	public int textureWidth;

	// Token: 0x04001AEB RID: 6891
	public int textureHeight;

	// Token: 0x04001AEC RID: 6892
	private Color[] workBlockFrom;

	// Token: 0x04001AED RID: 6893
	private Color[] workBlockTo;

	// Token: 0x04001AEE RID: 6894
	private Color[] workBlockMix;

	// Token: 0x04001AEF RID: 6895
	public int subTextureSize = 1024;

	// Token: 0x04001AF0 RID: 6896
	public Texture2D[] subTextureArray;

	// Token: 0x04001AF1 RID: 6897
	public bool startCoroutine;

	// Token: 0x04001AF2 RID: 6898
	public bool startedCoroutine;

	// Token: 0x04001AF3 RID: 6899
	public bool finishedCoroutine;

	// Token: 0x04001AF4 RID: 6900
	public bool startJob;

	// Token: 0x04001AF5 RID: 6901
	public float switchTimeTaken;

	// Token: 0x04001AF6 RID: 6902
	public bool jobStarted;

	// Token: 0x04001AF7 RID: 6903
	public float lerpAmount;

	// Token: 0x04001AF8 RID: 6904
	public int currentRow;

	// Token: 0x04001AF9 RID: 6905
	public int currentColumn;

	// Token: 0x04001AFA RID: 6906
	public int currentSubTexture;

	// Token: 0x04001AFB RID: 6907
	public int currentRowInSubtexture;

	// Token: 0x020003F3 RID: 1011
	public struct LerpBakedLightingJob : IJob
	{
		// Token: 0x0600178E RID: 6030 RVA: 0x00078CFC File Offset: 0x00076EFC
		public void Execute()
		{
			for (int i = 0; i < this.fromPixels.Length; i++)
			{
				this.mixedPixels[i] = Color.Lerp(this.fromPixels[i], this.toPixels[i], 0.5f);
			}
		}

		// Token: 0x04001AFC RID: 6908
		public NativeArray<Color> fromPixels;

		// Token: 0x04001AFD RID: 6909
		public NativeArray<Color> toPixels;

		// Token: 0x04001AFE RID: 6910
		public NativeArray<Color> mixedPixels;

		// Token: 0x04001AFF RID: 6911
		public float lerpValue;
	}
}
