﻿using System;

namespace GorillaNetworking
{
	// Token: 0x020006BF RID: 1727
	public enum GorillaKeyboardBindings
	{
		// Token: 0x04002BDE RID: 11230
		zero,
		// Token: 0x04002BDF RID: 11231
		one,
		// Token: 0x04002BE0 RID: 11232
		two,
		// Token: 0x04002BE1 RID: 11233
		three,
		// Token: 0x04002BE2 RID: 11234
		four,
		// Token: 0x04002BE3 RID: 11235
		five,
		// Token: 0x04002BE4 RID: 11236
		six,
		// Token: 0x04002BE5 RID: 11237
		seven,
		// Token: 0x04002BE6 RID: 11238
		eight,
		// Token: 0x04002BE7 RID: 11239
		nine,
		// Token: 0x04002BE8 RID: 11240
		up,
		// Token: 0x04002BE9 RID: 11241
		down,
		// Token: 0x04002BEA RID: 11242
		delete,
		// Token: 0x04002BEB RID: 11243
		enter,
		// Token: 0x04002BEC RID: 11244
		option1,
		// Token: 0x04002BED RID: 11245
		option2,
		// Token: 0x04002BEE RID: 11246
		option3,
		// Token: 0x04002BEF RID: 11247
		A,
		// Token: 0x04002BF0 RID: 11248
		B,
		// Token: 0x04002BF1 RID: 11249
		C,
		// Token: 0x04002BF2 RID: 11250
		D,
		// Token: 0x04002BF3 RID: 11251
		E,
		// Token: 0x04002BF4 RID: 11252
		F,
		// Token: 0x04002BF5 RID: 11253
		G,
		// Token: 0x04002BF6 RID: 11254
		H,
		// Token: 0x04002BF7 RID: 11255
		I,
		// Token: 0x04002BF8 RID: 11256
		J,
		// Token: 0x04002BF9 RID: 11257
		K,
		// Token: 0x04002BFA RID: 11258
		L,
		// Token: 0x04002BFB RID: 11259
		M,
		// Token: 0x04002BFC RID: 11260
		N,
		// Token: 0x04002BFD RID: 11261
		O,
		// Token: 0x04002BFE RID: 11262
		P,
		// Token: 0x04002BFF RID: 11263
		Q,
		// Token: 0x04002C00 RID: 11264
		R,
		// Token: 0x04002C01 RID: 11265
		S,
		// Token: 0x04002C02 RID: 11266
		T,
		// Token: 0x04002C03 RID: 11267
		U,
		// Token: 0x04002C04 RID: 11268
		V,
		// Token: 0x04002C05 RID: 11269
		W,
		// Token: 0x04002C06 RID: 11270
		X,
		// Token: 0x04002C07 RID: 11271
		Y,
		// Token: 0x04002C08 RID: 11272
		Z
	}
}
