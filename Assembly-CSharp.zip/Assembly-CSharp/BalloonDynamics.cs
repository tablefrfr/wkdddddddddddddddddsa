﻿using System;
using UnityEngine;

// Token: 0x02000234 RID: 564
public class BalloonDynamics : MonoBehaviour, ITetheredObjectBehavior
{
	// Token: 0x06000BE0 RID: 3040 RVA: 0x0003F530 File Offset: 0x0003D730
	private void Awake()
	{
		this.rb = base.GetComponent<Rigidbody>();
		this.knotRb = this.knot.GetComponent<Rigidbody>();
		this.balloonCollider = base.GetComponent<Collider>();
		this.grabPtInitParent = this.grabPt.transform.parent;
	}

	// Token: 0x06000BE1 RID: 3041 RVA: 0x0003F57C File Offset: 0x0003D77C
	private void Start()
	{
		this.airResistance = Mathf.Clamp(this.airResistance, 0f, 1f);
		this.balloonCollider.enabled = false;
	}

	// Token: 0x06000BE2 RID: 3042 RVA: 0x0003F5A8 File Offset: 0x0003D7A8
	public void ReParent()
	{
		if (this.grabPt != null)
		{
			this.grabPt.transform.parent = this.grabPtInitParent.transform;
		}
		this.bouyancyActualHeight = Random.Range(this.bouyancyMinHeight, this.bouyancyMaxHeight);
	}

	// Token: 0x06000BE3 RID: 3043 RVA: 0x0003F5F8 File Offset: 0x0003D7F8
	private void ApplyBouyancyForce()
	{
		float num = this.bouyancyActualHeight + Mathf.Sin(Time.time) * this.varianceMaxheight;
		float num2 = (num - base.transform.position.y) / num;
		float y = this.bouyancyForce * num2 * this.balloonScale;
		this.rb.AddForce(new Vector3(0f, y, 0f), ForceMode.Acceleration);
	}

	// Token: 0x06000BE4 RID: 3044 RVA: 0x0003F660 File Offset: 0x0003D860
	private void ApplyUpRightForce()
	{
		Vector3 torque = Vector3.Cross(base.transform.up, Vector3.up) * this.upRightTorque * this.balloonScale;
		this.rb.AddTorque(torque);
	}

	// Token: 0x06000BE5 RID: 3045 RVA: 0x0003F6A5 File Offset: 0x0003D8A5
	private void ApplyAirResistance()
	{
		this.rb.velocity *= 1f - this.airResistance;
	}

	// Token: 0x06000BE6 RID: 3046 RVA: 0x0003F6CC File Offset: 0x0003D8CC
	private void ApplyDistanceConstraint()
	{
		this.knot.transform.position - base.transform.position;
		Vector3 vector = this.grabPt.transform.position - this.knot.transform.position;
		Vector3 normalized = vector.normalized;
		float magnitude = vector.magnitude;
		float num = this.stringLength * this.balloonScale;
		if (magnitude > num)
		{
			Vector3 vector2 = Vector3.Dot(this.knotRb.velocity, normalized) * normalized;
			float num2 = magnitude - num;
			float num3 = num2 / Time.fixedDeltaTime;
			if (vector2.magnitude < num3)
			{
				float b = num3 - vector2.magnitude;
				float num4 = Mathf.Clamp01(num2 / this.stringStretch);
				Vector3 force = Mathf.Lerp(0f, b, num4 * num4) * normalized * this.stringStrength;
				this.rb.AddForceAtPosition(force, this.knot.transform.position, ForceMode.VelocityChange);
			}
		}
	}

	// Token: 0x06000BE7 RID: 3047 RVA: 0x0003F7D8 File Offset: 0x0003D9D8
	public void EnableDynamics(bool enable, bool kinematic)
	{
		this.enableDynamics = enable;
		if (this.balloonCollider)
		{
			this.balloonCollider.enabled = enable;
		}
		if (this.rb != null)
		{
			this.rb.isKinematic = kinematic;
			if (!enable)
			{
				this.rb.velocity = Vector3.zero;
				this.rb.angularVelocity = Vector3.zero;
			}
		}
	}

	// Token: 0x06000BE8 RID: 3048 RVA: 0x0003F842 File Offset: 0x0003DA42
	public void EnableDistanceConstraints(bool enable, float scale = 1f)
	{
		this.enableDistanceConstraints = enable;
		this.balloonScale = scale;
	}

	// Token: 0x1700017E RID: 382
	// (get) Token: 0x06000BE9 RID: 3049 RVA: 0x0003F852 File Offset: 0x0003DA52
	public bool ColliderEnabled
	{
		get
		{
			return this.balloonCollider && this.balloonCollider.enabled;
		}
	}

	// Token: 0x06000BEA RID: 3050 RVA: 0x0003F870 File Offset: 0x0003DA70
	private void FixedUpdate()
	{
		if (this.enableDynamics && !this.rb.isKinematic)
		{
			this.ApplyBouyancyForce();
			this.ApplyUpRightForce();
			this.ApplyAirResistance();
			if (this.enableDistanceConstraints)
			{
				this.ApplyDistanceConstraint();
			}
			Vector3 velocity = this.rb.velocity;
			float magnitude = velocity.magnitude;
			this.rb.velocity = velocity.normalized * Mathf.Min(magnitude, this.maximumVelocity * this.balloonScale);
		}
	}

	// Token: 0x06000BEB RID: 3051 RVA: 0x000195E8 File Offset: 0x000177E8
	void ITetheredObjectBehavior.DbgClear()
	{
		throw new NotImplementedException();
	}

	// Token: 0x06000BEC RID: 3052 RVA: 0x0003F8F0 File Offset: 0x0003DAF0
	bool ITetheredObjectBehavior.IsEnabled()
	{
		return base.enabled;
	}

	// Token: 0x06000BED RID: 3053 RVA: 0x0003F8F8 File Offset: 0x0003DAF8
	void ITetheredObjectBehavior.TriggerEnter(Collider other, ref Vector3 force, ref Vector3 collisionPt, ref bool transferOwnership)
	{
		if (other.gameObject.IsOnLayer(UnityLayer.GorillaHand))
		{
			transferOwnership = true;
			TransformFollow component = other.gameObject.GetComponent<TransformFollow>();
			if (component)
			{
				Vector3 a = (component.transform.position - component.prevPos) / Time.deltaTime;
				if (this.rb)
				{
					force = a * this.bopSpeed;
					force = Mathf.Min(this.maximumVelocity, force.magnitude) * force.normalized * this.balloonScale;
					collisionPt = other.ClosestPointOnBounds(base.transform.position);
					this.rb.AddForceAtPosition(force, collisionPt, ForceMode.VelocityChange);
					GorillaTriggerColliderHandIndicator component2 = other.GetComponent<GorillaTriggerColliderHandIndicator>();
					if (component2 != null)
					{
						float amplitude = GorillaTagger.Instance.tapHapticStrength / 4f;
						float fixedDeltaTime = Time.fixedDeltaTime;
						GorillaTagger.Instance.StartVibration(component2.isLeftHand, amplitude, fixedDeltaTime);
					}
				}
			}
		}
	}

	// Token: 0x06000BEE RID: 3054 RVA: 0x0003FA0C File Offset: 0x0003DC0C
	public bool ReturnStep()
	{
		return true;
	}

	// Token: 0x04000D33 RID: 3379
	private Rigidbody rb;

	// Token: 0x04000D34 RID: 3380
	private Collider balloonCollider;

	// Token: 0x04000D35 RID: 3381
	private Bounds bounds;

	// Token: 0x04000D36 RID: 3382
	public float bouyancyForce = 1f;

	// Token: 0x04000D37 RID: 3383
	public float bouyancyMinHeight = 10f;

	// Token: 0x04000D38 RID: 3384
	public float bouyancyMaxHeight = 20f;

	// Token: 0x04000D39 RID: 3385
	private float bouyancyActualHeight = 20f;

	// Token: 0x04000D3A RID: 3386
	public float varianceMaxheight = 5f;

	// Token: 0x04000D3B RID: 3387
	public float airResistance = 0.01f;

	// Token: 0x04000D3C RID: 3388
	public GameObject knot;

	// Token: 0x04000D3D RID: 3389
	private Rigidbody knotRb;

	// Token: 0x04000D3E RID: 3390
	public Transform grabPt;

	// Token: 0x04000D3F RID: 3391
	private Transform grabPtInitParent;

	// Token: 0x04000D40 RID: 3392
	public float stringLength = 2f;

	// Token: 0x04000D41 RID: 3393
	public float stringStrength = 0.9f;

	// Token: 0x04000D42 RID: 3394
	public float stringStretch = 0.1f;

	// Token: 0x04000D43 RID: 3395
	public float maximumVelocity = 2f;

	// Token: 0x04000D44 RID: 3396
	public float upRightTorque = 1f;

	// Token: 0x04000D45 RID: 3397
	private bool enableDynamics;

	// Token: 0x04000D46 RID: 3398
	private bool enableDistanceConstraints;

	// Token: 0x04000D47 RID: 3399
	public float balloonScale = 1f;

	// Token: 0x04000D48 RID: 3400
	public float bopSpeed = 1f;
}
