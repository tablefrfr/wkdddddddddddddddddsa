﻿using System;
using BoingKit;
using UnityEngine;

// Token: 0x0200000B RID: 11
public class ColliderSpinner : MonoBehaviour
{
	// Token: 0x0600001C RID: 28 RVA: 0x000029A8 File Offset: 0x00000BA8
	private void Start()
	{
		this.m_targetOffset = ((this.Target != null) ? (base.transform.position - this.Target.position) : Vector3.zero);
		this.m_spring.Reset(base.transform.position);
	}

	// Token: 0x0600001D RID: 29 RVA: 0x00002A04 File Offset: 0x00000C04
	private void FixedUpdate()
	{
		Vector3 targetValue = this.Target.position + this.m_targetOffset;
		base.transform.position = this.m_spring.TrackExponential(targetValue, 0.02f, Time.fixedDeltaTime);
	}

	// Token: 0x0400001F RID: 31
	public Transform Target;

	// Token: 0x04000020 RID: 32
	private Vector3 m_targetOffset;

	// Token: 0x04000021 RID: 33
	private Vector3Spring m_spring;
}
