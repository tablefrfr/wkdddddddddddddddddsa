﻿using System;
using System.Collections.Generic;
using Unity.Burst;
using Unity.Collections;
using Unity.Collections.LowLevel.Unsafe;
using Unity.Jobs;
using UnityEngine;
using UnityEngine.Jobs;

// Token: 0x0200032A RID: 810
public class BuilderRenderer : MonoBehaviour
{
	// Token: 0x06001224 RID: 4644 RVA: 0x0005FC3A File Offset: 0x0005DE3A
	private void Awake()
	{
		this.InitIfNeeded();
	}

	// Token: 0x06001225 RID: 4645 RVA: 0x0005FC44 File Offset: 0x0005DE44
	public void InitIfNeeded()
	{
		if (this.initialized)
		{
			return;
		}
		this.initialized = true;
		this.renderData = new BuilderTableDataRenderData();
		this.renderData.materialToIndex = new Dictionary<Material, int>(256);
		this.renderData.materials = new List<Material>(256);
		this.renderData.meshToIndex = new Dictionary<Mesh, int>(1024);
		this.renderData.meshInstanceCount = new List<int>(1024);
		this.renderData.meshes = new List<Mesh>(4096);
		this.renderData.textureToIndex = new Dictionary<Texture2D, int>(256);
		this.renderData.textures = new List<Texture2D>(256);
		this.renderData.perTextureMaterial = new List<Material>(256);
		this.renderData.perTexturePropertyBlock = new List<MaterialPropertyBlock>(256);
		this.renderData.sharedMaterial = new Material(this.sharedMaterialBase);
		this.renderData.sharedMaterialIndirect = new Material(this.sharedMaterialIndirectBase);
		this.built = false;
		this.showing = false;
	}

	// Token: 0x06001226 RID: 4646 RVA: 0x0005FD63 File Offset: 0x0005DF63
	public void Show(bool show)
	{
		this.showing = show;
	}

	// Token: 0x06001227 RID: 4647 RVA: 0x0005FD6C File Offset: 0x0005DF6C
	public void BuildRenderer(List<BuilderPiece> piecePrefabs)
	{
		this.InitIfNeeded();
		for (int i = 0; i < piecePrefabs.Count; i++)
		{
			if (piecePrefabs[i] != null)
			{
				this.AddPrefab(piecePrefabs[i]);
			}
			else
			{
				Debug.LogErrorFormat("Prefab at {0} is null", new object[]
				{
					i
				});
			}
		}
		this.BuildSharedMaterial();
		this.BuildSharedMesh();
		this.BuildBuffer();
		this.built = true;
	}

	// Token: 0x06001228 RID: 4648 RVA: 0x0005FDE0 File Offset: 0x0005DFE0
	public void LateUpdate()
	{
		if (!this.built || !this.showing)
		{
			return;
		}
		this.RenderIndirect();
	}

	// Token: 0x06001229 RID: 4649 RVA: 0x0005FDFC File Offset: 0x0005DFFC
	public void AddPrefab(BuilderPiece prefab)
	{
		BuilderRenderer.meshRenderers.Clear();
		prefab.GetComponentsInChildren<MeshRenderer>(BuilderRenderer.meshRenderers);
		for (int i = 0; i < BuilderRenderer.meshRenderers.Count; i++)
		{
			MeshRenderer meshRenderer = BuilderRenderer.meshRenderers[i];
			Material sharedMaterial = meshRenderer.sharedMaterial;
			if (sharedMaterial == null)
			{
				Debug.LogErrorFormat("{0} {1} is missing a material", new object[]
				{
					prefab.name,
					meshRenderer.name
				});
			}
			else if (this.AddMaterial(sharedMaterial))
			{
				MeshFilter component = meshRenderer.GetComponent<MeshFilter>();
				if (component != null)
				{
					Mesh sharedMesh = component.sharedMesh;
					int num;
					if (sharedMesh != null && !this.renderData.meshToIndex.TryGetValue(sharedMesh, out num))
					{
						this.renderData.meshToIndex.Add(sharedMesh, this.renderData.meshToIndex.Count);
						this.renderData.meshInstanceCount.Add(0);
						for (int j = 0; j < 1; j++)
						{
							this.renderData.meshes.Add(sharedMesh);
						}
					}
				}
			}
		}
		if (prefab.materialOptions != null)
		{
			for (int k = 0; k < prefab.materialOptions.options.Count; k++)
			{
				Material material = prefab.materialOptions.options[k].material;
				this.AddMaterial(material);
			}
		}
	}

	// Token: 0x0600122A RID: 4650 RVA: 0x0005FF64 File Offset: 0x0005E164
	private bool AddMaterial(Material material)
	{
		if (material == null)
		{
			return false;
		}
		if (!material.HasTexture("_BaseMap"))
		{
			return false;
		}
		Texture2D texture2D = material.GetTexture("_BaseMap") as Texture2D;
		if (texture2D == null)
		{
			return false;
		}
		int num;
		if (!this.renderData.materialToIndex.TryGetValue(material, out num))
		{
			this.renderData.materialToIndex.Add(material, this.renderData.materials.Count);
			this.renderData.materials.Add(material);
		}
		int num2;
		if (!this.renderData.textureToIndex.TryGetValue(texture2D, out num2))
		{
			this.renderData.textureToIndex.Add(texture2D, this.renderData.textures.Count);
			this.renderData.textures.Add(texture2D);
			if (this.renderData.textures.Count == 1)
			{
				this.renderData.textureFormat = texture2D.format;
				this.renderData.texWidth = texture2D.width;
				this.renderData.texHeight = texture2D.height;
			}
		}
		return true;
	}

	// Token: 0x0600122B RID: 4651 RVA: 0x0006007C File Offset: 0x0005E27C
	public void BuildSharedMaterial()
	{
		this.renderData.sharedTexArray = new Texture2DArray(this.renderData.texWidth, this.renderData.texHeight, this.renderData.textures.Count, TextureFormat.RGBA32, true);
		this.renderData.sharedTexArray.filterMode = FilterMode.Point;
		for (int i = 0; i < this.renderData.textures.Count; i++)
		{
			this.renderData.sharedTexArray.SetPixels(this.renderData.textures[i].GetPixels(), i);
		}
		this.renderData.sharedTexArray.Apply(true, true);
		this.renderData.sharedMaterial.SetTexture("_BaseMapArray", this.renderData.sharedTexArray);
		this.renderData.sharedMaterialIndirect.SetTexture("_BaseMapArray", this.renderData.sharedTexArray);
		this.renderData.sharedMaterialIndirect.enableInstancing = true;
		for (int j = 0; j < this.renderData.textures.Count; j++)
		{
			Material material = new Material(this.renderData.sharedMaterial);
			material.SetInt("_BaseMapArrayIndex", j);
			this.renderData.perTextureMaterial.Add(material);
			MaterialPropertyBlock materialPropertyBlock = new MaterialPropertyBlock();
			materialPropertyBlock.SetInt("_BaseMapArrayIndex", j);
			this.renderData.perTexturePropertyBlock.Add(materialPropertyBlock);
		}
	}

	// Token: 0x0600122C RID: 4652 RVA: 0x000601E4 File Offset: 0x0005E3E4
	public void BuildSharedMesh()
	{
		this.renderData.sharedMesh = new Mesh();
		BuilderRenderer.verticesAll.Clear();
		BuilderRenderer.normalsAll.Clear();
		BuilderRenderer.uv1All.Clear();
		BuilderRenderer.trianglesAll.Clear();
		this.renderData.subMeshes = new NativeList<BuilderTableSubMesh>(512, Allocator.Persistent);
		for (int i = 0; i < this.renderData.meshes.Count; i++)
		{
			Mesh mesh = this.renderData.meshes[i];
			int count = BuilderRenderer.trianglesAll.Count;
			int count2 = BuilderRenderer.verticesAll.Count;
			BuilderRenderer.vertices.Clear();
			BuilderRenderer.normals.Clear();
			BuilderRenderer.uv1.Clear();
			BuilderRenderer.triangles.Clear();
			mesh.GetVertices(BuilderRenderer.vertices);
			mesh.GetNormals(BuilderRenderer.normals);
			mesh.GetUVs(0, BuilderRenderer.uv1);
			mesh.GetTriangles(BuilderRenderer.triangles, 0);
			BuilderRenderer.verticesAll.AddRange(BuilderRenderer.vertices);
			BuilderRenderer.normalsAll.AddRange(BuilderRenderer.normals);
			BuilderRenderer.uv1All.AddRange(BuilderRenderer.uv1);
			BuilderRenderer.trianglesAll.AddRange(BuilderRenderer.triangles);
			int indexCount = BuilderRenderer.trianglesAll.Count - count;
			BuilderTableSubMesh builderTableSubMesh = new BuilderTableSubMesh
			{
				startIndex = count,
				indexCount = indexCount,
				startVertex = count2
			};
			this.renderData.subMeshes.Add(builderTableSubMesh);
		}
		this.renderData.sharedMesh.SetVertices(BuilderRenderer.verticesAll);
		this.renderData.sharedMesh.SetNormals(BuilderRenderer.normalsAll);
		this.renderData.sharedMesh.SetUVs(0, BuilderRenderer.uv1All);
		this.renderData.sharedMesh.SetTriangles(BuilderRenderer.trianglesAll, 0);
	}

	// Token: 0x0600122D RID: 4653 RVA: 0x000603B8 File Offset: 0x0005E5B8
	public void BuildBuffer()
	{
		this.renderData.dynamicBatch = new BuilderTableDataRenderIndirectBatch();
		BuilderRenderer.BuildBatch(this.renderData.dynamicBatch, this.renderData.meshes.Count, 2048);
		this.renderData.staticBatch = new BuilderTableDataRenderIndirectBatch();
		BuilderRenderer.BuildBatch(this.renderData.staticBatch, this.renderData.meshes.Count, 2048);
	}

	// Token: 0x0600122E RID: 4654 RVA: 0x00060430 File Offset: 0x0005E630
	public static void BuildBatch(BuilderTableDataRenderIndirectBatch indirectBatch, int meshCount, int maxInstances)
	{
		indirectBatch.totalInstances = 0;
		indirectBatch.commandCount = meshCount;
		indirectBatch.commandBuf = new GraphicsBuffer(GraphicsBuffer.Target.IndirectArguments, indirectBatch.commandCount, 20);
		indirectBatch.commandData = new NativeArray<GraphicsBuffer.IndirectDrawIndexedArgs>(indirectBatch.commandCount, Allocator.Persistent, NativeArrayOptions.ClearMemory);
		indirectBatch.matrixBuf = new GraphicsBuffer(GraphicsBuffer.Target.Structured, maxInstances, 64);
		indirectBatch.texIndexBuf = new GraphicsBuffer(GraphicsBuffer.Target.Structured, maxInstances, 4);
		indirectBatch.tintBuf = new GraphicsBuffer(GraphicsBuffer.Target.Structured, maxInstances, 4);
		indirectBatch.instanceObjectToWorld = new NativeArray<Matrix4x4>(maxInstances, Allocator.Persistent, NativeArrayOptions.ClearMemory);
		indirectBatch.instanceTexIndex = new NativeArray<int>(maxInstances, Allocator.Persistent, NativeArrayOptions.ClearMemory);
		indirectBatch.instanceTint = new NativeArray<float>(maxInstances, Allocator.Persistent, NativeArrayOptions.ClearMemory);
		indirectBatch.renderMeshes = new NativeList<BuilderTableMeshInstances>(512, Allocator.Persistent);
		for (int i = 0; i < meshCount; i++)
		{
			BuilderTableMeshInstances builderTableMeshInstances = new BuilderTableMeshInstances
			{
				transforms = new TransformAccessArray(maxInstances, 3),
				texIndex = new NativeList<int>(Allocator.Persistent),
				tint = new NativeList<float>(Allocator.Persistent)
			};
			indirectBatch.renderMeshes.Add(builderTableMeshInstances);
		}
	}

	// Token: 0x0600122F RID: 4655 RVA: 0x00060539 File Offset: 0x0005E739
	public void DestroyBuffer()
	{
		BuilderRenderer.DestroyBatch(this.renderData.staticBatch);
		BuilderRenderer.DestroyBatch(this.renderData.dynamicBatch);
	}

	// Token: 0x06001230 RID: 4656 RVA: 0x0006055C File Offset: 0x0005E75C
	public static void DestroyBatch(BuilderTableDataRenderIndirectBatch indirectBatch)
	{
		indirectBatch.commandBuf.Dispose();
		indirectBatch.commandData.Dispose();
		indirectBatch.matrixBuf.Dispose();
		indirectBatch.texIndexBuf.Dispose();
		indirectBatch.tintBuf.Dispose();
		indirectBatch.instanceObjectToWorld.Dispose();
		indirectBatch.instanceTexIndex.Dispose();
		indirectBatch.instanceTint.Dispose();
		indirectBatch.renderMeshes.Dispose();
	}

	// Token: 0x06001231 RID: 4657 RVA: 0x000605CC File Offset: 0x0005E7CC
	public void RenderIndirect()
	{
		JobHandle job = default(JobHandle);
		BuilderRenderer.SetupIndirectBatchArgs(this.renderData.dynamicBatch, this.renderData.subMeshes);
		BuilderRenderer.SetupIndirectBatchArgs(this.renderData.staticBatch, this.renderData.subMeshes);
		for (int i = 0; i < this.renderData.dynamicBatch.commandCount; i++)
		{
			BuilderTableMeshInstances builderTableMeshInstances = this.renderData.dynamicBatch.renderMeshes[i];
			JobHandle job2 = new BuilderRenderer.SetupInstanceDataForMesh
			{
				texIndex = builderTableMeshInstances.texIndex,
				tint = builderTableMeshInstances.tint,
				commandData = this.renderData.dynamicBatch.commandData[i],
				instanceTexIndex = this.renderData.dynamicBatch.instanceTexIndex,
				instanceTint = this.renderData.dynamicBatch.instanceTint,
				objectToWorld = this.renderData.dynamicBatch.instanceObjectToWorld
			}.Schedule(builderTableMeshInstances.transforms, default(JobHandle));
			job = JobHandle.CombineDependencies(job, job2);
		}
		job.Complete();
		this.RenderIndirectBatch(this.renderData.staticBatch);
		this.RenderIndirectBatch(this.renderData.dynamicBatch);
	}

	// Token: 0x06001232 RID: 4658 RVA: 0x0006071C File Offset: 0x0005E91C
	private static void SetupIndirectBatchArgs(BuilderTableDataRenderIndirectBatch indirectBatch, NativeList<BuilderTableSubMesh> subMeshes)
	{
		uint num = 0U;
		for (int i = 0; i < indirectBatch.commandCount; i++)
		{
			BuilderTableMeshInstances builderTableMeshInstances = indirectBatch.renderMeshes[i];
			BuilderTableSubMesh builderTableSubMesh = subMeshes[i];
			GraphicsBuffer.IndirectDrawIndexedArgs value = default(GraphicsBuffer.IndirectDrawIndexedArgs);
			value.indexCountPerInstance = (uint)builderTableSubMesh.indexCount;
			value.startIndex = (uint)builderTableSubMesh.startIndex;
			value.baseVertexIndex = (uint)builderTableSubMesh.startVertex;
			value.startInstance = num;
			value.instanceCount = (uint)builderTableMeshInstances.transforms.length;
			num += value.instanceCount;
			indirectBatch.commandData[i] = value;
		}
	}

	// Token: 0x06001233 RID: 4659 RVA: 0x000607B8 File Offset: 0x0005E9B8
	private void RenderIndirectBatch(BuilderTableDataRenderIndirectBatch indirectBatch)
	{
		RenderParams renderParams = new RenderParams(this.renderData.sharedMaterialIndirect);
		renderParams.worldBounds = new Bounds(Vector3.zero, 10000f * Vector3.one);
		renderParams.matProps = new MaterialPropertyBlock();
		renderParams.matProps.SetMatrix("_ObjectToWorld", Matrix4x4.identity);
		indirectBatch.matrixBuf.SetData<Matrix4x4>(indirectBatch.instanceObjectToWorld);
		indirectBatch.texIndexBuf.SetData<int>(indirectBatch.instanceTexIndex);
		indirectBatch.tintBuf.SetData<float>(indirectBatch.instanceTint);
		renderParams.matProps.SetBuffer("_TransformMatrix", indirectBatch.matrixBuf);
		renderParams.matProps.SetBuffer("_TexIndex", indirectBatch.texIndexBuf);
		renderParams.matProps.SetBuffer("_Tint", indirectBatch.tintBuf);
		indirectBatch.commandBuf.SetData<GraphicsBuffer.IndirectDrawIndexedArgs>(indirectBatch.commandData);
		Graphics.RenderMeshIndirect(renderParams, this.renderData.sharedMesh, indirectBatch.commandBuf, indirectBatch.commandCount, 0);
	}

	// Token: 0x06001234 RID: 4660 RVA: 0x000608C4 File Offset: 0x0005EAC4
	public void AddPiece(BuilderPiece piece)
	{
		bool isStatic = piece.isStatic;
		BuilderRenderer.meshRenderers.Clear();
		piece.GetComponentsInChildren<MeshRenderer>(false, BuilderRenderer.meshRenderers);
		for (int i = 0; i < BuilderRenderer.meshRenderers.Count; i++)
		{
			MeshRenderer meshRenderer = BuilderRenderer.meshRenderers[i];
			if (meshRenderer.enabled)
			{
				Material material = meshRenderer.material;
				if (material.HasTexture("_BaseMap"))
				{
					Texture2D texture2D = material.GetTexture("_BaseMap") as Texture2D;
					int value;
					if (!(texture2D == null) && this.renderData.textureToIndex.TryGetValue(texture2D, out value))
					{
						MeshFilter component = meshRenderer.GetComponent<MeshFilter>();
						if (!(component == null))
						{
							Mesh sharedMesh = component.sharedMesh;
							int num;
							if (!(sharedMesh == null) && this.renderData.meshToIndex.TryGetValue(sharedMesh, out num))
							{
								int num2 = this.renderData.meshInstanceCount[num] % 1;
								this.renderData.meshInstanceCount[num] = this.renderData.meshInstanceCount[num] + 1;
								num += num2;
								if (isStatic)
								{
									BuilderTableMeshInstances builderTableMeshInstances = this.renderData.staticBatch.renderMeshes[num];
									int num3 = 0;
									for (int j = 0; j <= num; j++)
									{
										num3 += this.renderData.staticBatch.renderMeshes[j].transforms.length;
									}
									builderTableMeshInstances.transforms.Add(meshRenderer.transform);
									builderTableMeshInstances.texIndex.Add(value);
									builderTableMeshInstances.tint.Add(piece.tint);
									for (int k = this.renderData.staticBatch.totalInstances - 1; k >= num3; k--)
									{
										this.renderData.staticBatch.instanceTexIndex[k + 1] = this.renderData.staticBatch.instanceTexIndex[k];
										this.renderData.staticBatch.instanceObjectToWorld[k + 1] = this.renderData.staticBatch.instanceObjectToWorld[k];
										this.renderData.staticBatch.instanceTint[k + 1] = this.renderData.staticBatch.instanceTint[k];
									}
									this.renderData.staticBatch.instanceObjectToWorld[num3] = meshRenderer.transform.localToWorldMatrix;
									this.renderData.staticBatch.instanceTexIndex[num3] = value;
									this.renderData.staticBatch.instanceTint[num3] = 1f;
									this.renderData.staticBatch.totalInstances++;
								}
								else
								{
									BuilderTableMeshInstances builderTableMeshInstances2 = this.renderData.dynamicBatch.renderMeshes[num];
									builderTableMeshInstances2.transforms.Add(meshRenderer.transform);
									builderTableMeshInstances2.texIndex.Add(value);
									builderTableMeshInstances2.tint.Add(piece.tint);
									this.renderData.dynamicBatch.totalInstances++;
								}
								piece.renderingIndirect.Add(meshRenderer);
								meshRenderer.enabled = false;
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x06001235 RID: 4661 RVA: 0x00060C24 File Offset: 0x0005EE24
	public void RemovePiece(BuilderPiece piece)
	{
		bool isStatic = piece.isStatic;
		for (int i = 0; i < piece.renderingIndirect.Count; i++)
		{
			MeshRenderer meshRenderer = piece.renderingIndirect[i];
			Material sharedMaterial = meshRenderer.sharedMaterial;
			if (sharedMaterial.HasTexture("_BaseMap"))
			{
				Texture2D texture2D = sharedMaterial.GetTexture("_BaseMap") as Texture2D;
				int num;
				if (!(texture2D == null) && this.renderData.textureToIndex.TryGetValue(texture2D, out num))
				{
					MeshFilter component = meshRenderer.GetComponent<MeshFilter>();
					if (!(component == null))
					{
						Mesh sharedMesh = component.sharedMesh;
						int num2;
						if (this.renderData.meshToIndex.TryGetValue(sharedMesh, out num2))
						{
							Transform transform = meshRenderer.transform;
							bool flag = false;
							int num3 = 0;
							if (isStatic)
							{
								for (int j = 0; j < num2; j++)
								{
									num3 += this.renderData.staticBatch.renderMeshes[j].transforms.length;
								}
							}
							for (int k = 0; k < 1; k++)
							{
								int index = num2 + k;
								if (isStatic)
								{
									BuilderTableMeshInstances builderTableMeshInstances = this.renderData.staticBatch.renderMeshes[index];
									for (int l = 0; l < builderTableMeshInstances.transforms.length; l++)
									{
										if (builderTableMeshInstances.transforms[l] == transform)
										{
											num3 += l;
											BuilderRenderer.RemoveAt(builderTableMeshInstances.transforms, l);
											builderTableMeshInstances.texIndex.RemoveAt(l);
											builderTableMeshInstances.tint.RemoveAt(l);
											flag = true;
											this.renderData.staticBatch.totalInstances--;
											break;
										}
									}
								}
								else
								{
									BuilderTableMeshInstances builderTableMeshInstances2 = this.renderData.dynamicBatch.renderMeshes[index];
									for (int m = 0; m < builderTableMeshInstances2.transforms.length; m++)
									{
										if (builderTableMeshInstances2.transforms[m] == transform)
										{
											BuilderRenderer.RemoveAt(builderTableMeshInstances2.transforms, m);
											builderTableMeshInstances2.texIndex.RemoveAt(m);
											builderTableMeshInstances2.tint.RemoveAt(m);
											flag = true;
											this.renderData.dynamicBatch.totalInstances--;
											break;
										}
									}
								}
								if (flag)
								{
									break;
								}
							}
							if (flag && isStatic)
							{
								int num4 = this.renderData.staticBatch.totalInstances + 1;
								for (int n = num3; n < num4; n++)
								{
									this.renderData.staticBatch.instanceTexIndex[n] = this.renderData.staticBatch.instanceTexIndex[n + 1];
									this.renderData.staticBatch.instanceObjectToWorld[n] = this.renderData.staticBatch.instanceObjectToWorld[n + 1];
									this.renderData.staticBatch.instanceTint[n] = this.renderData.staticBatch.instanceTint[n + 1];
								}
							}
							meshRenderer.enabled = true;
						}
					}
				}
			}
		}
		piece.renderingIndirect.Clear();
	}

	// Token: 0x06001236 RID: 4662 RVA: 0x00060F64 File Offset: 0x0005F164
	public void ChangePieceIndirectMaterial(BuilderPiece piece, List<MeshRenderer> targetRenderers, Material targetMaterial)
	{
		if (targetMaterial == null)
		{
			return;
		}
		if (!targetMaterial.HasTexture("_BaseMap"))
		{
			Debug.LogError("New Material is missing a texture");
			return;
		}
		Texture2D texture2D = targetMaterial.GetTexture("_BaseMap") as Texture2D;
		if (texture2D == null)
		{
			Debug.LogError("New Material does not have a \"_BaseMap\" property");
			return;
		}
		int value;
		if (!this.renderData.textureToIndex.TryGetValue(texture2D, out value))
		{
			Debug.LogError("New Material is not in the texture array");
			return;
		}
		bool isStatic = piece.isStatic;
		for (int i = 0; i < piece.renderingIndirect.Count; i++)
		{
			MeshRenderer meshRenderer = piece.renderingIndirect[i];
			if (!targetRenderers.Contains(meshRenderer))
			{
				Debug.Log("renderer not in target list");
			}
			else
			{
				meshRenderer.material = targetMaterial;
				MeshFilter component = meshRenderer.GetComponent<MeshFilter>();
				if (!(component == null))
				{
					Mesh sharedMesh = component.sharedMesh;
					int num;
					if (this.renderData.meshToIndex.TryGetValue(sharedMesh, out num))
					{
						Transform transform = meshRenderer.transform;
						bool flag = false;
						int num2 = 0;
						if (isStatic)
						{
							for (int j = 0; j < num; j++)
							{
								num2 += this.renderData.staticBatch.renderMeshes[j].transforms.length;
							}
						}
						for (int k = 0; k < 1; k++)
						{
							int index = num + k;
							if (isStatic)
							{
								BuilderTableMeshInstances builderTableMeshInstances = this.renderData.staticBatch.renderMeshes[index];
								for (int l = 0; l < builderTableMeshInstances.transforms.length; l++)
								{
									if (builderTableMeshInstances.transforms[l] == transform)
									{
										num2 += l;
										this.renderData.staticBatch.instanceTexIndex[num2] = value;
										flag = true;
										break;
									}
								}
							}
							else
							{
								BuilderTableMeshInstances builderTableMeshInstances2 = this.renderData.dynamicBatch.renderMeshes[index];
								for (int m = 0; m < builderTableMeshInstances2.transforms.length; m++)
								{
									if (builderTableMeshInstances2.transforms[m] == transform)
									{
										this.renderData.staticBatch.renderMeshes.ElementAt(index).texIndex[m] = value;
										flag = true;
										break;
									}
								}
							}
							if (flag)
							{
								break;
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x06001237 RID: 4663 RVA: 0x000611BC File Offset: 0x0005F3BC
	public static void RemoveAt(TransformAccessArray a, int i)
	{
		int length = a.length;
		for (int j = i; j < length - 1; j++)
		{
			a[j] = a[j + 1];
		}
		a.RemoveAtSwapBack(length - 1);
	}

	// Token: 0x06001238 RID: 4664 RVA: 0x000611FC File Offset: 0x0005F3FC
	public void SetPieceTint(BuilderPiece piece, float tint)
	{
		for (int i = 0; i < piece.renderingIndirect.Count; i++)
		{
			MeshRenderer meshRenderer = piece.renderingIndirect[i];
			Material sharedMaterial = meshRenderer.sharedMaterial;
			if (sharedMaterial.HasTexture("_BaseMap"))
			{
				Texture2D texture2D = sharedMaterial.GetTexture("_BaseMap") as Texture2D;
				int num;
				if (!(texture2D == null) && this.renderData.textureToIndex.TryGetValue(texture2D, out num))
				{
					MeshFilter component = meshRenderer.GetComponent<MeshFilter>();
					if (!(component == null))
					{
						Mesh sharedMesh = component.sharedMesh;
						int num2;
						if (this.renderData.meshToIndex.TryGetValue(sharedMesh, out num2))
						{
							Transform transform = meshRenderer.transform;
							int num3 = 0;
							if (piece.isStatic)
							{
								for (int j = 0; j < num2; j++)
								{
									num3 += this.renderData.staticBatch.renderMeshes[j].transforms.length;
								}
							}
							for (int k = 0; k < 1; k++)
							{
								int index = num2 + k;
								if (piece.isStatic)
								{
									BuilderTableMeshInstances builderTableMeshInstances = this.renderData.staticBatch.renderMeshes[index];
									for (int l = 0; l < builderTableMeshInstances.transforms.length; l++)
									{
										if (builderTableMeshInstances.transforms[l] == transform)
										{
											num3 += l;
											break;
										}
									}
								}
								else
								{
									BuilderTableMeshInstances builderTableMeshInstances2 = this.renderData.dynamicBatch.renderMeshes[index];
									for (int m = 0; m < builderTableMeshInstances2.transforms.length; m++)
									{
										if (builderTableMeshInstances2.transforms[m] == transform)
										{
											builderTableMeshInstances2.tint[m] = tint;
											break;
										}
									}
								}
							}
							if (piece.isStatic)
							{
								this.renderData.staticBatch.instanceTint[num3] = tint;
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x040014EA RID: 5354
	public Material sharedMaterialBase;

	// Token: 0x040014EB RID: 5355
	public Material sharedMaterialIndirectBase;

	// Token: 0x040014EC RID: 5356
	private BuilderTableDataRenderData renderData;

	// Token: 0x040014ED RID: 5357
	private const string texturePropName = "_BaseMap";

	// Token: 0x040014EE RID: 5358
	private const string textureArrayPropName = "_BaseMapArray";

	// Token: 0x040014EF RID: 5359
	private const string textureArrayIndexPropName = "_BaseMapArrayIndex";

	// Token: 0x040014F0 RID: 5360
	private const string transformMatrixPropName = "_TransformMatrix";

	// Token: 0x040014F1 RID: 5361
	private const string texIndexPropName = "_TexIndex";

	// Token: 0x040014F2 RID: 5362
	private const string tintPropName = "_Tint";

	// Token: 0x040014F3 RID: 5363
	public const int MAX_STATIC_INSTANCES = 2048;

	// Token: 0x040014F4 RID: 5364
	public const int MAX_DYNAMIC_INSTANCES = 2048;

	// Token: 0x040014F5 RID: 5365
	private bool initialized;

	// Token: 0x040014F6 RID: 5366
	private bool built;

	// Token: 0x040014F7 RID: 5367
	private bool showing;

	// Token: 0x040014F8 RID: 5368
	private static List<MeshRenderer> meshRenderers = new List<MeshRenderer>(128);

	// Token: 0x040014F9 RID: 5369
	private const int MAX_TOTAL_VERTS = 65536;

	// Token: 0x040014FA RID: 5370
	private const int MAX_TOTAL_TRIS = 65536;

	// Token: 0x040014FB RID: 5371
	private static List<Vector3> verticesAll = new List<Vector3>(65536);

	// Token: 0x040014FC RID: 5372
	private static List<Vector3> normalsAll = new List<Vector3>(65536);

	// Token: 0x040014FD RID: 5373
	private static List<Vector2> uv1All = new List<Vector2>(65536);

	// Token: 0x040014FE RID: 5374
	private static List<int> trianglesAll = new List<int>(65536);

	// Token: 0x040014FF RID: 5375
	private static List<Vector3> vertices = new List<Vector3>(65536);

	// Token: 0x04001500 RID: 5376
	private static List<Vector3> normals = new List<Vector3>(65536);

	// Token: 0x04001501 RID: 5377
	private static List<Vector2> uv1 = new List<Vector2>(65536);

	// Token: 0x04001502 RID: 5378
	private static List<int> triangles = new List<int>(65536);

	// Token: 0x0200032B RID: 811
	[BurstCompile]
	public struct SetupInstanceDataForMesh : IJobParallelForTransform
	{
		// Token: 0x0600123B RID: 4667 RVA: 0x00061490 File Offset: 0x0005F690
		public void Execute(int index, TransformAccess transform)
		{
			int index2 = index + (int)this.commandData.startInstance;
			this.objectToWorld[index2] = transform.localToWorldMatrix;
			this.instanceTexIndex[index2] = this.texIndex[index];
			this.instanceTint[index2] = this.tint[index];
		}

		// Token: 0x04001503 RID: 5379
		[ReadOnly]
		public NativeList<int> texIndex;

		// Token: 0x04001504 RID: 5380
		[ReadOnly]
		public NativeList<float> tint;

		// Token: 0x04001505 RID: 5381
		[ReadOnly]
		public GraphicsBuffer.IndirectDrawIndexedArgs commandData;

		// Token: 0x04001506 RID: 5382
		[ReadOnly]
		public Vector3 cameraPos;

		// Token: 0x04001507 RID: 5383
		[NativeDisableContainerSafetyRestriction]
		public NativeArray<int> instanceTexIndex;

		// Token: 0x04001508 RID: 5384
		[NativeDisableContainerSafetyRestriction]
		public NativeArray<Matrix4x4> objectToWorld;

		// Token: 0x04001509 RID: 5385
		[NativeDisableContainerSafetyRestriction]
		public NativeArray<float> instanceTint;

		// Token: 0x0400150A RID: 5386
		[NativeDisableContainerSafetyRestriction]
		public NativeArray<int> lodLevel;

		// Token: 0x0400150B RID: 5387
		[NativeDisableContainerSafetyRestriction]
		public NativeArray<int> lodDirty;
	}
}
