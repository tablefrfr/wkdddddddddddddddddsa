﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x020000A1 RID: 161
public class DevErrorSoundAnnoyer : MonoBehaviour
{
	// Token: 0x0400048D RID: 1165
	[SerializeField]
	private AudioClip errorSound;

	// Token: 0x0400048E RID: 1166
	[SerializeField]
	private AudioSource audioSource;

	// Token: 0x0400048F RID: 1167
	[SerializeField]
	private Text errorUIText;

	// Token: 0x04000490 RID: 1168
	[SerializeField]
	private Font errorFont;

	// Token: 0x04000491 RID: 1169
	public string displayedText;
}
