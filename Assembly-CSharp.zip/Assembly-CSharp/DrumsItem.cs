﻿using System;
using System.Collections.Generic;
using GorillaTag;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000293 RID: 659
public class DrumsItem : MonoBehaviour, ISpawnable
{
	// Token: 0x170001B4 RID: 436
	// (get) Token: 0x06000EB4 RID: 3764 RVA: 0x0004CDE2 File Offset: 0x0004AFE2
	// (set) Token: 0x06000EB5 RID: 3765 RVA: 0x0004CDEA File Offset: 0x0004AFEA
	bool ISpawnable.IsSpawned { get; set; }

	// Token: 0x06000EB6 RID: 3766 RVA: 0x0004CDF4 File Offset: 0x0004AFF4
	void ISpawnable.OnSpawn()
	{
		this.myRig = base.GetComponentInParent<VRRig>(true);
		this.leftHandIndicator = GorillaTagger.Instance.leftHandTriggerCollider.GetComponent<GorillaTriggerColliderHandIndicator>();
		this.rightHandIndicator = GorillaTagger.Instance.rightHandTriggerCollider.GetComponent<GorillaTriggerColliderHandIndicator>();
		this.sphereRadius = this.leftHandIndicator.GetComponent<SphereCollider>().radius;
		for (int i = 0; i < this.collidersForThisDrum.Length; i++)
		{
			this.collidersForThisDrumList.Add(this.collidersForThisDrum[i]);
		}
		for (int j = 0; j < this.drumsAS.Length; j++)
		{
			this.myRig.AssignDrumToMusicDrums(j + this.onlineOffset, this.drumsAS[j]);
		}
	}

	// Token: 0x06000EB7 RID: 3767 RVA: 0x00003051 File Offset: 0x00001251
	void ISpawnable.OnDespawn()
	{
	}

	// Token: 0x06000EB8 RID: 3768 RVA: 0x0004CEA2 File Offset: 0x0004B0A2
	private void LateUpdate()
	{
		this.CheckHandHit(ref this.leftHandIn, ref this.leftHandIndicator, true);
		this.CheckHandHit(ref this.rightHandIn, ref this.rightHandIndicator, false);
	}

	// Token: 0x06000EB9 RID: 3769 RVA: 0x0004CECC File Offset: 0x0004B0CC
	private void CheckHandHit(ref bool handIn, ref GorillaTriggerColliderHandIndicator handIndicator, bool isLeftHand)
	{
		this.spherecastSweep = handIndicator.transform.position - handIndicator.lastPosition;
		if (this.spherecastSweep.magnitude < 0.0001f)
		{
			this.spherecastSweep = Vector3.up * 0.0001f;
		}
		for (int i = 0; i < this.collidersHit.Length; i++)
		{
			this.collidersHit[i] = this.nullHit;
		}
		this.collidersHitCount = Physics.SphereCastNonAlloc(handIndicator.lastPosition, this.sphereRadius, this.spherecastSweep.normalized, this.collidersHit, this.spherecastSweep.magnitude, this.drumsTouchable, QueryTriggerInteraction.Collide);
		this.drumHit = false;
		if (this.collidersHitCount > 0)
		{
			this.hitList.Clear();
			for (int j = 0; j < this.collidersHit.Length; j++)
			{
				if (this.collidersHit[j].collider != null && this.collidersForThisDrumList.Contains(this.collidersHit[j].collider) && this.collidersHit[j].collider.gameObject.activeSelf)
				{
					this.hitList.Add(this.collidersHit[j]);
				}
			}
			this.hitList.Sort(new Comparison<RaycastHit>(this.RayCastHitCompare));
			int k = 0;
			while (k < this.hitList.Count)
			{
				this.tempDrum = this.hitList[k].collider.GetComponent<Drum>();
				if (this.tempDrum != null)
				{
					this.drumHit = true;
					if (!handIn && !this.tempDrum.disabler)
					{
						this.DrumHit(this.tempDrum, isLeftHand, handIndicator.currentVelocity.magnitude);
						break;
					}
					break;
				}
				else
				{
					k++;
				}
			}
		}
		if (!this.drumHit & handIn)
		{
			GorillaTagger.Instance.StartVibration(isLeftHand, GorillaTagger.Instance.tapHapticStrength / 8f, GorillaTagger.Instance.tapHapticDuration);
		}
		handIn = this.drumHit;
	}

	// Token: 0x06000EBA RID: 3770 RVA: 0x0004D0E7 File Offset: 0x0004B2E7
	private int RayCastHitCompare(RaycastHit a, RaycastHit b)
	{
		if (a.distance < b.distance)
		{
			return -1;
		}
		if (a.distance == b.distance)
		{
			return 0;
		}
		return 1;
	}

	// Token: 0x06000EBB RID: 3771 RVA: 0x0004D110 File Offset: 0x0004B310
	public void DrumHit(Drum tempDrumInner, bool isLeftHand, float hitVelocity)
	{
		if (isLeftHand)
		{
			if (this.leftHandIn)
			{
				return;
			}
			this.leftHandIn = true;
		}
		else
		{
			if (this.rightHandIn)
			{
				return;
			}
			this.rightHandIn = true;
		}
		this.volToPlay = Mathf.Max(Mathf.Min(1f, hitVelocity / this.maxDrumVolumeVelocity) * this.maxDrumVolume, this.minDrumVolume);
		if (PhotonNetwork.InRoom)
		{
			if (!this.myRig.isOfflineVRRig)
			{
				PhotonView photonView = this.myRig.photonView;
				if (photonView != null)
				{
					photonView.RPC("PlayDrum", RpcTarget.Others, new object[]
					{
						tempDrumInner.myIndex + this.onlineOffset,
						this.volToPlay
					});
				}
			}
			else
			{
				GorillaTagger.Instance.myVRRig.RPC("PlayDrum", RpcTarget.Others, new object[]
				{
					tempDrumInner.myIndex + this.onlineOffset,
					this.volToPlay
				});
			}
		}
		GorillaTagger.Instance.StartVibration(isLeftHand, GorillaTagger.Instance.tapHapticStrength / 4f, GorillaTagger.Instance.tapHapticDuration);
		this.drumsAS[tempDrumInner.myIndex].volume = this.maxDrumVolume;
		this.drumsAS[tempDrumInner.myIndex].PlayOneShot(this.drumsAS[tempDrumInner.myIndex].clip, this.volToPlay);
	}

	// Token: 0x04001084 RID: 4228
	[Tooltip("Array of colliders for this specific drum.")]
	public Collider[] collidersForThisDrum;

	// Token: 0x04001085 RID: 4229
	private List<Collider> collidersForThisDrumList = new List<Collider>();

	// Token: 0x04001086 RID: 4230
	[Tooltip("AudioSources where each index must match the index given to the corresponding Drum component.")]
	public AudioSource[] drumsAS;

	// Token: 0x04001087 RID: 4231
	[Tooltip("Max volume a drum can reach.")]
	public float maxDrumVolume = 0.2f;

	// Token: 0x04001088 RID: 4232
	[Tooltip("Min volume a drum can reach.")]
	public float minDrumVolume = 0.05f;

	// Token: 0x04001089 RID: 4233
	[Tooltip("Multiplies against actual velocity before capping by min & maxDrumVolume values.")]
	public float maxDrumVolumeVelocity = 1f;

	// Token: 0x0400108A RID: 4234
	private bool rightHandIn;

	// Token: 0x0400108B RID: 4235
	private bool leftHandIn;

	// Token: 0x0400108C RID: 4236
	private float volToPlay;

	// Token: 0x0400108D RID: 4237
	private GorillaTriggerColliderHandIndicator rightHandIndicator;

	// Token: 0x0400108E RID: 4238
	private GorillaTriggerColliderHandIndicator leftHandIndicator;

	// Token: 0x0400108F RID: 4239
	private RaycastHit[] collidersHit = new RaycastHit[20];

	// Token: 0x04001090 RID: 4240
	private Collider[] actualColliders = new Collider[20];

	// Token: 0x04001091 RID: 4241
	public LayerMask drumsTouchable;

	// Token: 0x04001092 RID: 4242
	private float sphereRadius;

	// Token: 0x04001093 RID: 4243
	private Vector3 spherecastSweep;

	// Token: 0x04001094 RID: 4244
	private int collidersHitCount;

	// Token: 0x04001095 RID: 4245
	private List<RaycastHit> hitList = new List<RaycastHit>();

	// Token: 0x04001096 RID: 4246
	private Drum tempDrum;

	// Token: 0x04001097 RID: 4247
	private bool drumHit;

	// Token: 0x04001098 RID: 4248
	private RaycastHit nullHit;

	// Token: 0x04001099 RID: 4249
	public int onlineOffset;

	// Token: 0x0400109A RID: 4250
	[Tooltip("VRRig object of the player, used to determine if it is an offline rig.")]
	private VRRig myRig;
}
