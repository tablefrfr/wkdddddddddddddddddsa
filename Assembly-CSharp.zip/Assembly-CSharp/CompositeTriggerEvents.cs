﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020004B9 RID: 1209
public class CompositeTriggerEvents : MonoBehaviour
{
	// Token: 0x14000027 RID: 39
	// (add) Token: 0x06001B83 RID: 7043 RVA: 0x0008BD2C File Offset: 0x00089F2C
	// (remove) Token: 0x06001B84 RID: 7044 RVA: 0x0008BD64 File Offset: 0x00089F64
	public event CompositeTriggerEvents.TriggerEvent CompositeTriggerEnter;

	// Token: 0x14000028 RID: 40
	// (add) Token: 0x06001B85 RID: 7045 RVA: 0x0008BD9C File Offset: 0x00089F9C
	// (remove) Token: 0x06001B86 RID: 7046 RVA: 0x0008BDD4 File Offset: 0x00089FD4
	public event CompositeTriggerEvents.TriggerEvent CompositeTriggerExit;

	// Token: 0x06001B87 RID: 7047 RVA: 0x0008BE0C File Offset: 0x0008A00C
	private void Awake()
	{
		if (this.individualTriggerColliders.Count > 32)
		{
			Debug.LogError("The max number of triggers was exceeded in this composite trigger event sender on GameObject: " + base.gameObject.name + ".");
		}
		for (int i = 0; i < this.individualTriggerColliders.Count; i++)
		{
			TriggerEventNotifier triggerEventNotifier = this.individualTriggerColliders[i].gameObject.AddComponent<TriggerEventNotifier>();
			triggerEventNotifier.maskIndex = i;
			triggerEventNotifier.TriggerEnterEvent += this.TriggerEnterReceiver;
			triggerEventNotifier.TriggerExitEvent += this.TriggerExitReceiver;
			this.triggerEventNotifiers.Add(triggerEventNotifier);
		}
	}

	// Token: 0x06001B88 RID: 7048 RVA: 0x0008BEAC File Offset: 0x0008A0AC
	private void OnDestroy()
	{
		for (int i = 0; i < this.triggerEventNotifiers.Count; i++)
		{
			if (this.triggerEventNotifiers[i] != null)
			{
				this.triggerEventNotifiers[i].TriggerEnterEvent -= this.TriggerEnterReceiver;
				this.triggerEventNotifiers[i].TriggerExitEvent -= this.TriggerExitReceiver;
			}
		}
	}

	// Token: 0x06001B89 RID: 7049 RVA: 0x0008BF20 File Offset: 0x0008A120
	public void TriggerEnterReceiver(TriggerEventNotifier notifier, Collider other)
	{
		int num;
		if (this.overlapMask.TryGetValue(other, out num))
		{
			num = this.SetMaskIndexTrue(num, notifier.maskIndex);
			this.overlapMask[other] = num;
			return;
		}
		int value = this.SetMaskIndexTrue(0, notifier.maskIndex);
		this.overlapMask.Add(other, value);
		CompositeTriggerEvents.TriggerEvent compositeTriggerEnter = this.CompositeTriggerEnter;
		if (compositeTriggerEnter == null)
		{
			return;
		}
		compositeTriggerEnter(other);
	}

	// Token: 0x06001B8A RID: 7050 RVA: 0x0008BF88 File Offset: 0x0008A188
	public void TriggerExitReceiver(TriggerEventNotifier notifier, Collider other)
	{
		int num;
		if (this.overlapMask.TryGetValue(other, out num))
		{
			num = this.SetMaskIndexFalse(num, notifier.maskIndex);
			if (num == 0)
			{
				this.overlapMask.Remove(other);
				CompositeTriggerEvents.TriggerEvent compositeTriggerExit = this.CompositeTriggerExit;
				if (compositeTriggerExit == null)
				{
					return;
				}
				compositeTriggerExit(other);
				return;
			}
			else
			{
				this.overlapMask[other] = num;
			}
		}
	}

	// Token: 0x06001B8B RID: 7051 RVA: 0x0008BFE2 File Offset: 0x0008A1E2
	public void CompositeTriggerEnterReceiver(Collider other)
	{
		CompositeTriggerEvents.TriggerEvent compositeTriggerEnter = this.CompositeTriggerEnter;
		if (compositeTriggerEnter == null)
		{
			return;
		}
		compositeTriggerEnter(other);
	}

	// Token: 0x06001B8C RID: 7052 RVA: 0x0008BFF5 File Offset: 0x0008A1F5
	public void CompositeTriggerExitReceiver(Collider other)
	{
		CompositeTriggerEvents.TriggerEvent compositeTriggerExit = this.CompositeTriggerExit;
		if (compositeTriggerExit == null)
		{
			return;
		}
		compositeTriggerExit(other);
	}

	// Token: 0x06001B8D RID: 7053 RVA: 0x0008C008 File Offset: 0x0008A208
	private bool TestMaskIndex(int mask, int index)
	{
		return (mask & 1 << index) != 0;
	}

	// Token: 0x06001B8E RID: 7054 RVA: 0x0008C015 File Offset: 0x0008A215
	private int SetMaskIndexTrue(int mask, int index)
	{
		return mask | 1 << index;
	}

	// Token: 0x06001B8F RID: 7055 RVA: 0x0008C01F File Offset: 0x0008A21F
	private int SetMaskIndexFalse(int mask, int index)
	{
		return mask & ~(1 << index);
	}

	// Token: 0x06001B90 RID: 7056 RVA: 0x0008C02C File Offset: 0x0008A22C
	private string MaskToString(int mask)
	{
		string text = "";
		for (int i = 31; i >= 0; i--)
		{
			text += (this.TestMaskIndex(mask, i) ? "1" : "0");
		}
		return text;
	}

	// Token: 0x04001F5B RID: 8027
	[SerializeField]
	private List<Collider> individualTriggerColliders = new List<Collider>();

	// Token: 0x04001F5C RID: 8028
	private List<TriggerEventNotifier> triggerEventNotifiers = new List<TriggerEventNotifier>();

	// Token: 0x04001F5D RID: 8029
	private Dictionary<Collider, int> overlapMask = new Dictionary<Collider, int>();

	// Token: 0x020004BA RID: 1210
	// (Invoke) Token: 0x06001B93 RID: 7059
	public delegate void TriggerEvent(Collider collider);
}
