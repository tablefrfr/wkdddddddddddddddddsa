﻿using System;
using UnityEngine;

namespace CjLib
{
	// Token: 0x020007D2 RID: 2002
	[ExecuteInEditMode]
	public class DrawArrow : DrawBase
	{
		// Token: 0x06003076 RID: 12406 RVA: 0x000ED544 File Offset: 0x000EB744
		private void OnValidate()
		{
			this.ConeRadius = Mathf.Max(0f, this.ConeRadius);
			this.ConeHeight = Mathf.Max(0f, this.ConeHeight);
			this.StemThickness = Mathf.Max(0f, this.StemThickness);
			this.NumSegments = Mathf.Max(4, this.NumSegments);
		}

		// Token: 0x06003077 RID: 12407 RVA: 0x000ED5A8 File Offset: 0x000EB7A8
		protected override void Draw(Color color, DebugUtil.Style style, bool depthTest)
		{
			DebugUtil.DrawArrow(base.transform.position, base.transform.position + base.transform.TransformVector(this.LocalEndVector), this.ConeRadius, this.ConeHeight, this.NumSegments, this.StemThickness, color, depthTest, style);
		}

		// Token: 0x040032E2 RID: 13026
		public Vector3 LocalEndVector = Vector3.right;

		// Token: 0x040032E3 RID: 13027
		public float ConeRadius = 0.05f;

		// Token: 0x040032E4 RID: 13028
		public float ConeHeight = 0.1f;

		// Token: 0x040032E5 RID: 13029
		public float StemThickness = 0.05f;

		// Token: 0x040032E6 RID: 13030
		public int NumSegments = 8;
	}
}
