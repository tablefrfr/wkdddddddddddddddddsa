﻿using System;
using System.Collections.Generic;
using Cysharp.Text;
using GorillaExtensions;
using GorillaLocomotion;
using GorillaNetworking;
using GorillaTag;
using GorillaTag.CosmeticSystem;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.ResourceManagement.AsyncOperations;

// Token: 0x0200008D RID: 141
public class CosmeticsV2Spawner_Dirty : IDelayedExecListener, ITickSystemTick
{
	// Token: 0x1700003E RID: 62
	// (get) Token: 0x060002DF RID: 735 RVA: 0x00014CC3 File Offset: 0x00012EC3
	// (set) Token: 0x060002E0 RID: 736 RVA: 0x00014CCA File Offset: 0x00012ECA
	[OnEnterPlay_Set(false)]
	public static bool allPartsInstantiated { get; private set; }

	// Token: 0x1700003F RID: 63
	// (get) Token: 0x060002E1 RID: 737 RVA: 0x00014CD2 File Offset: 0x00012ED2
	// (set) Token: 0x060002E2 RID: 738 RVA: 0x00014CD9 File Offset: 0x00012ED9
	[OnEnterPlay_Set(false)]
	public static bool completed { get; private set; }

	// Token: 0x17000040 RID: 64
	// (get) Token: 0x060002E3 RID: 739 RVA: 0x00014CE1 File Offset: 0x00012EE1
	// (set) Token: 0x060002E4 RID: 740 RVA: 0x00014CE8 File Offset: 0x00012EE8
	[OnEnterPlay_Set(false)]
	public static bool failed { get; private set; }

	// Token: 0x17000041 RID: 65
	// (get) Token: 0x060002E5 RID: 741 RVA: 0x00014CF0 File Offset: 0x00012EF0
	// (set) Token: 0x060002E6 RID: 742 RVA: 0x00014CF8 File Offset: 0x00012EF8
	public bool TickRunning { get; set; }

	// Token: 0x060002E7 RID: 743 RVA: 0x00014D01 File Offset: 0x00012F01
	void ITickSystemTick.Tick()
	{
		this._shouldTick = false;
		if (CosmeticsV2Spawner_Dirty._g_loadOp_to_index.Count < CosmeticsV2Spawner_Dirty._g_loadOpInfos.Count)
		{
			this._shouldTick = true;
			CosmeticsV2Spawner_Dirty._Step2_UpdateLoadOpStarting();
		}
		if (!this._shouldTick)
		{
			TickSystem<object>.RemoveTickCallback(this);
		}
	}

	// Token: 0x060002E8 RID: 744 RVA: 0x00014D3A File Offset: 0x00012F3A
	void IDelayedExecListener.OnDelayedAction(int contextId)
	{
		if (contextId >= 0 && contextId < 1000000)
		{
			CosmeticsV2Spawner_Dirty._RetryDownload(contextId);
			return;
		}
		if (contextId == -100)
		{
			this._DelayedStatusCheck();
			return;
		}
		if (contextId == -Mathf.Abs("_Step5_InitializeVRRigsAndCosmeticsControllerFinalize".GetHashCode()))
		{
			CosmeticsV2Spawner_Dirty._Step5_InitializeVRRigsAndCosmeticsControllerFinalize();
		}
	}

	// Token: 0x060002E9 RID: 745 RVA: 0x00014D74 File Offset: 0x00012F74
	public static void StartInstantiatingPrefabs()
	{
		if (ApplicationQuittingState.IsQuitting)
		{
			return;
		}
		if (CosmeticsV2Spawner_Dirty._instance == null)
		{
			CosmeticsV2Spawner_Dirty._instance = new CosmeticsV2Spawner_Dirty();
		}
		CosmeticsV2Spawner_Dirty.g_gorillaPlayer = Object.FindObjectOfType<Player>();
		foreach (SnowballMaker snowballMaker in CosmeticsV2Spawner_Dirty.g_gorillaPlayer.GetComponentsInChildren<SnowballMaker>(true))
		{
			if (snowballMaker.isLeftHand)
			{
				CosmeticsV2Spawner_Dirty._gSnowballMakerLeft = snowballMaker;
			}
			else
			{
				CosmeticsV2Spawner_Dirty._gSnowballMakerRight = snowballMaker;
			}
		}
		if (!CosmeticsController.hasInstance)
		{
			Debug.LogError("(should never happen) cannot instantiate prefabs before cosmetics controller instance is available.");
			CosmeticsV2Spawner_Dirty.FailedInstantiateAllPrefabs();
			return;
		}
		if (!CosmeticsController.instance.v2_allCosmeticsInfoAssetRef.IsValid())
		{
			Debug.LogError("(should never happen) cannot load prefabs before v2_allCosmeticsInfoAssetRef is loaded.");
			CosmeticsV2Spawner_Dirty.FailedInstantiateAllPrefabs();
			return;
		}
		AllCosmeticsArraySO allCosmeticsArraySO = CosmeticsController.instance.v2_allCosmeticsInfoAssetRef.Asset as AllCosmeticsArraySO;
		if (allCosmeticsArraySO == null)
		{
			Debug.LogError("(should never happen) v2_allCosmeticsInfoAssetRef is valid but null.");
			CosmeticsV2Spawner_Dirty.FailedInstantiateAllPrefabs();
			return;
		}
		CosmeticsV2Spawner_Dirty._gVRRigDatas.Add(new CosmeticsV2Spawner_Dirty.VRRigData(VRRig.LocalRig, GTHardCodedBones.GetBoneXforms(VRRig.LocalRig)));
		int vrRigIndex = 0;
		foreach (VRRig vrRig in VRRigCache.Instance.GetAllRigs())
		{
			CosmeticsV2Spawner_Dirty._gVRRigDatas.Add(new CosmeticsV2Spawner_Dirty.VRRigData(vrRig, GTHardCodedBones.GetBoneXforms(vrRig)));
		}
		CosmeticsV2Spawner_Dirty._gDeactivatedSpawnParent = GlobalDeactivatedSpawnRoot.GetOrCreate();
		GTDelayedExec.Add(CosmeticsV2Spawner_Dirty._instance, 2f, -100);
		int num = 0;
		int num2 = 0;
		CosmeticSO[] cosmetics = allCosmeticsArraySO.cosmetics;
		for (int i = 0; i < cosmetics.Length; i++)
		{
			CosmeticInfoV2 info = cosmetics[i].info;
			if (info.functionalParts != null)
			{
				for (int j = 0; j < CosmeticsV2Spawner_Dirty._gVRRigDatas.Count; j++)
				{
					for (int k = 0; k < info.functionalParts.Length; k++)
					{
						CosmeticsV2Spawner_Dirty.AddEachAttachInfoToLoadOpInfosList(info.functionalParts[k], k, info, j, ref num);
					}
				}
			}
			if (info.firstPersonViewParts != null)
			{
				for (int l = 0; l < info.firstPersonViewParts.Length; l++)
				{
					CosmeticsV2Spawner_Dirty.AddEachAttachInfoToLoadOpInfosList(info.firstPersonViewParts[l], l, info, vrRigIndex, ref num2);
				}
			}
		}
		TickSystem<object>.AddTickCallback(CosmeticsV2Spawner_Dirty._instance);
	}

	// Token: 0x060002EA RID: 746 RVA: 0x00014F8C File Offset: 0x0001318C
	private static void AddEachAttachInfoToLoadOpInfosList(CosmeticPart part, int partIndex, CosmeticInfoV2 cosmeticInfo, int vrRigIndex, ref int partCount)
	{
		if (ApplicationQuittingState.IsQuitting)
		{
			return;
		}
		for (int i = 0; i < part.attachAnchors.Length; i++)
		{
			bool flag = cosmeticInfo.category == CosmeticsController.CosmeticCategory.Chest;
			GTHardCodedBones.SturdyEBone parentBone = part.attachAnchors[i].parentBone;
			if (part.partType != ECosmeticPartType.Functional || !cosmeticInfo.isHoldable || cosmeticInfo.isThrowable || ((flag || parentBone == GTHardCodedBones.EBone.None) && (!flag || parentBone == GTHardCodedBones.EBone.body_AnchorFront_StowSlot)))
			{
				CosmeticsV2Spawner_Dirty.LoadOpInfo item = new CosmeticsV2Spawner_Dirty.LoadOpInfo(part.attachAnchors[i], part, partIndex, cosmeticInfo, vrRigIndex);
				CosmeticsV2Spawner_Dirty._g_loadOpInfos.Add(item);
				partCount++;
				if (flag)
				{
					break;
				}
			}
		}
	}

	// Token: 0x060002EB RID: 747 RVA: 0x00015038 File Offset: 0x00013238
	private static void _Step2_UpdateLoadOpStarting()
	{
		int num = CosmeticsV2Spawner_Dirty._g_loadOp_to_index.Count - CosmeticsV2Spawner_Dirty._g_loadOpsCountCompleted;
		while (CosmeticsV2Spawner_Dirty._g_loadOp_to_index.Count < CosmeticsV2Spawner_Dirty._g_loadOpInfos.Count && num < 1000000)
		{
			num++;
			int count = CosmeticsV2Spawner_Dirty._g_loadOp_to_index.Count;
			CosmeticsV2Spawner_Dirty.LoadOpInfo loadOpInfo = CosmeticsV2Spawner_Dirty._g_loadOpInfos[count];
			loadOpInfo.loadOp = loadOpInfo.part.prefabAssetRef.InstantiateAsync(CosmeticsV2Spawner_Dirty._gDeactivatedSpawnParent, false);
			loadOpInfo.isStarted = true;
			CosmeticsV2Spawner_Dirty._g_loadOp_to_index.Add(loadOpInfo.loadOp, count);
			loadOpInfo.loadOp.Completed += CosmeticsV2Spawner_Dirty._Step3_HandleLoadOpCompleted;
			CosmeticsV2Spawner_Dirty._g_loadOpInfos[count] = loadOpInfo;
			loadOpInfo.loadOp.WaitForCompletion();
		}
	}

	// Token: 0x060002EC RID: 748 RVA: 0x00015100 File Offset: 0x00013300
	private static void _Step3_HandleLoadOpCompleted(AsyncOperationHandle<GameObject> loadOp)
	{
		if (ApplicationQuittingState.IsQuitting)
		{
			return;
		}
		int num;
		if (!CosmeticsV2Spawner_Dirty._g_loadOp_to_index.TryGetValue(loadOp, out num))
		{
			throw new Exception("(this should never happen) could not find LoadOpInfo in `_g_loadOpInfos`.");
		}
		CosmeticsV2Spawner_Dirty.LoadOpInfo loadOpInfo = CosmeticsV2Spawner_Dirty._g_loadOpInfos[num];
		if (loadOp.Status == AsyncOperationStatus.Failed)
		{
			Debug.Log("CosmeticsV2Spawner_Dirty: Failed to load a part for cosmetic \"" + loadOpInfo.cosmeticInfoV2.displayName + "\"! waiting for 10 seconds before trying again.");
			GTDelayedExec.Add(CosmeticsV2Spawner_Dirty._instance, 10f, num);
			return;
		}
		CosmeticsV2Spawner_Dirty._g_loadOpsCountCompleted++;
		ECosmeticSelectSide ecosmeticSelectSide = loadOpInfo.attachInfo.selectSide;
		string text = loadOpInfo.cosmeticInfoV2.playFabID;
		int length = text.Length;
		if ((length == 5 || length == 6) && text[0] == 'L')
		{
			char c = text[1];
			if (c == 'B' || c == 'H' || c == 'F' || c == 'M' || c == 'S')
			{
				string playFabID = loadOpInfo.cosmeticInfoV2.playFabID;
				string arg;
				if (ecosmeticSelectSide != ECosmeticSelectSide.Left)
				{
					if (ecosmeticSelectSide != ECosmeticSelectSide.Right)
					{
						arg = ".";
					}
					else
					{
						arg = ". RIGHT.";
					}
				}
				else
				{
					arg = ". LEFT.";
				}
				text = ZString.Concat<string, string>(playFabID, arg);
			}
		}
		loadOpInfo.resultGObj = loadOp.Result;
		loadOpInfo.resultGObj.SetActive(false);
		Transform transform = loadOpInfo.resultGObj.transform;
		Transform transform2 = transform;
		if (loadOpInfo.cosmeticInfoV2.isHoldable)
		{
			TransferrableObject componentInChildren = loadOpInfo.resultGObj.GetComponentInChildren<TransferrableObject>(true);
			if (componentInChildren && componentInChildren.gameObject != loadOpInfo.resultGObj)
			{
				transform2 = componentInChildren.transform;
				transform2.gameObject.SetActive(false);
				loadOpInfo.resultGObj.SetActive(true);
			}
		}
		if (loadOpInfo.cosmeticInfoV2.isThrowable)
		{
			SnowballThrowable componentInChildren2 = loadOpInfo.resultGObj.GetComponentInChildren<SnowballThrowable>(true);
			if (componentInChildren2 && componentInChildren2.gameObject != loadOpInfo.resultGObj)
			{
				transform2 = componentInChildren2.transform;
				transform2.gameObject.SetActive(false);
				loadOpInfo.resultGObj.SetActive(true);
			}
		}
		transform2.name = text;
		CosmeticsV2Spawner_Dirty.VRRigData vrrigData = (loadOpInfo.vrRigIndex != -1) ? CosmeticsV2Spawner_Dirty._gVRRigDatas[loadOpInfo.vrRigIndex] : default(CosmeticsV2Spawner_Dirty.VRRigData);
		ECosmeticPartType partType = loadOpInfo.part.partType;
		Transform transform3;
		if (partType != ECosmeticPartType.Functional)
		{
			if (partType != ECosmeticPartType.FirstPerson)
			{
				throw new ArgumentOutOfRangeException("partType", "unhandled part type.");
			}
			transform3 = CosmeticsV2Spawner_Dirty.g_gorillaPlayer.headCollider.transform;
		}
		else
		{
			transform3 = ((loadOpInfo.cosmeticInfoV2.isHoldable && loadOpInfo.attachInfo.parentBone != GTHardCodedBones.EBone.body_AnchorFront_StowSlot) ? vrrigData.parentOfDeactivatedHoldables : vrrigData.boneXforms[(int)loadOpInfo.attachInfo.parentBone]);
		}
		Transform transform4 = transform3;
		if (transform4)
		{
			transform.SetParent(transform4, false);
			transform.localPosition = loadOpInfo.attachInfo.offset.pos;
			transform.localRotation = loadOpInfo.attachInfo.offset.rot;
			transform.localScale = loadOpInfo.attachInfo.offset.scale;
		}
		else
		{
			Debug.LogError(string.Concat(new string[]
			{
				string.Format("Bone transform not found for cosmetic part type {0}. Cosmetic: ", loadOpInfo.part.partType),
				"\"",
				loadOpInfo.cosmeticInfoV2.displayName,
				"\",",
				string.Format("part: \"{0}\"", loadOpInfo.part.prefabAssetRef.RuntimeKey)
			}));
		}
		partType = loadOpInfo.part.partType;
		if (partType != ECosmeticPartType.Functional)
		{
			if (partType != ECosmeticPartType.FirstPerson)
			{
				throw new ArgumentOutOfRangeException("Unexpected ECosmeticPartType value encountered: " + string.Format("{0}, ", loadOpInfo.part.partType) + string.Format("int: {0}.", (int)loadOpInfo.part.partType));
			}
			vrrigData.vrRig_override.Add(transform2.gameObject);
		}
		else
		{
			vrrigData.vrRig_cosmetics.Add(transform2.gameObject);
			HoldableObject componentInChildren3 = loadOpInfo.resultGObj.GetComponentInChildren<HoldableObject>(true);
			SnowballThrowable snowballThrowable = componentInChildren3 as SnowballThrowable;
			if (snowballThrowable == null)
			{
				TransferrableObject transferrableObject = componentInChildren3 as TransferrableObject;
				if (transferrableObject == null)
				{
					if (componentInChildren3 != null)
					{
						throw new Exception("Encountered unexpected HoldableObject derived type on cosmetic part: \"" + loadOpInfo.cosmeticInfoV2.displayName + "\"");
					}
				}
				else
				{
					vrrigData.bdPositions_allObjects.Add(transferrableObject);
					string text2 = loadOpInfo.cosmeticInfoV2.playFabID;
					int[] array;
					if (CosmeticsLegacyV1Info.TryGetBodyDockAllObjectsIndexes(text2, out array))
					{
						if (loadOpInfo.partIndex < array.Length && loadOpInfo.partIndex >= 0)
						{
							transferrableObject.myIndex = array[loadOpInfo.partIndex];
						}
					}
					else if (text2.Length >= 5 && text2[0] == 'L')
					{
						if (text2[1] != 'M')
						{
							throw new Exception("(this should never happen) A TransferrableObject cosmetic added sometime after 2024-06 does not use the expected PlayFabID format where the string starts with \"LM\" and ends with \".\". Path: " + transform2.GetPathQ());
						}
						string text3 = text2;
						text2 = ((text3[text3.Length - 1] == '.') ? text2 : (text2 + "."));
						int num2 = 224;
						transferrableObject.myIndex = num2 + CosmeticIDUtils.PlayFabIdToIndexInCategory(text2);
					}
					else
					{
						transferrableObject.myIndex = -2;
						if (!(text2 == "STICKABLE TARGET"))
						{
							Debug.LogError(string.Concat(new string[]
							{
								"Cosmetic \"",
								loadOpInfo.cosmeticInfoV2.displayName,
								"\" cannot derive `TransferrableObject.myIndex` from playFabId \"",
								text2,
								"\" and so will not be included in `BodyDockPositions.allObjects` array."
							}));
						}
					}
					vrrigData.bdPositions_allObjects_length = math.max(transferrableObject.myIndex + 1, vrrigData.bdPositions_allObjects_length);
				}
			}
			else
			{
				CosmeticsV2Spawner_Dirty.AddPartToThrowableLists(loadOpInfo, snowballThrowable);
			}
		}
		if (loadOpInfo.vrRigIndex > -1)
		{
			CosmeticsV2Spawner_Dirty._gVRRigDatas[loadOpInfo.vrRigIndex] = vrrigData;
		}
		ISpawnable[] componentsInChildren = loadOpInfo.resultGObj.GetComponentsInChildren<ISpawnable>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].IsSpawned = true;
			componentsInChildren[i].OnSpawn();
		}
		if (CosmeticsV2Spawner_Dirty._g_loadOpsCountCompleted < CosmeticsV2Spawner_Dirty._g_loadOpInfos.Count)
		{
			return;
		}
		CosmeticsV2Spawner_Dirty._Step4_PopulateAllArrays();
	}

	// Token: 0x060002ED RID: 749 RVA: 0x00015704 File Offset: 0x00013904
	private static void _RetryDownload(int loadOpIndex)
	{
		if (loadOpIndex < 0 || loadOpIndex >= CosmeticsV2Spawner_Dirty._g_loadOpInfos.Count)
		{
			Debug.LogError("(should never happen) Unexpected! While trying to recover from a failed download, the value " + string.Format("{0}={1} was out of range of ", "loadOpIndex", loadOpIndex) + string.Format("{0}.Count={1}.", "_g_loadOpInfos", CosmeticsV2Spawner_Dirty._g_loadOpInfos.Count));
			CosmeticsV2Spawner_Dirty.FailedInstantiateAllPrefabs();
			return;
		}
		CosmeticsV2Spawner_Dirty.LoadOpInfo loadOpInfo = CosmeticsV2Spawner_Dirty._g_loadOpInfos[loadOpIndex];
		if (!CosmeticsV2Spawner_Dirty._g_loadOp_to_index.Remove(loadOpInfo.loadOp))
		{
			Debug.LogWarning(string.Concat(new string[]
			{
				"(should never happen) Unexpected! Could not find the loadOp to remove it in the _g_loadOp_to_index. If you see this message then comparison does not work the way I thought and we need a different way to store/retrieve loadOpInfos. Happened while trying to retry failed download prefab part of cosmetic \"",
				loadOpInfo.cosmeticInfoV2.displayName,
				"\" with guid \"",
				loadOpInfo.part.prefabAssetRef.AssetGUID,
				"\"."
			}));
		}
		Debug.Log("Retrying prefab part of cosmetic \"{loadOpInfo.cosmeticInfoV2.displayName}\" with guid \"" + loadOpInfo.part.prefabAssetRef.AssetGUID + "\".");
		loadOpInfo.loadOp = loadOpInfo.part.prefabAssetRef.InstantiateAsync(CosmeticsV2Spawner_Dirty._gDeactivatedSpawnParent, false);
		CosmeticsV2Spawner_Dirty._g_loadOpInfos[loadOpIndex] = loadOpInfo;
		CosmeticsV2Spawner_Dirty._g_loadOp_to_index[loadOpInfo.loadOp] = loadOpIndex;
		loadOpInfo.loadOp.Completed += CosmeticsV2Spawner_Dirty._Step3_HandleLoadOpCompleted;
	}

	// Token: 0x060002EE RID: 750 RVA: 0x00015848 File Offset: 0x00013A48
	private static void AddPartToThrowableLists(CosmeticsV2Spawner_Dirty.LoadOpInfo loadOpInfo, SnowballThrowable throwable)
	{
		CosmeticsV2Spawner_Dirty.VRRigData vrrigData = CosmeticsV2Spawner_Dirty._gVRRigDatas[loadOpInfo.vrRigIndex];
		EHandedness handednessFromBone = GTHardCodedBones.GetHandednessFromBone(loadOpInfo.attachInfo.parentBone);
		bool flag = vrrigData.vrRig == CosmeticsV2Spawner_Dirty._gVRRigDatas[0].vrRig;
		switch (handednessFromBone)
		{
		case EHandedness.None:
			throw new ArgumentException(string.Concat(new string[]
			{
				"Encountered throwable cosmetic \"",
				loadOpInfo.cosmeticInfoV2.displayName,
				"\" where handedness ",
				string.Format("could not be determined from bone `{0}`. ", loadOpInfo.attachInfo.parentBone),
				"Path: \"",
				throwable.transform.GetPath(),
				"\""
			}));
		case EHandedness.Left:
			vrrigData.bdPositions_leftHandThrowables.Add(throwable.gameObject);
			if (flag)
			{
				CosmeticsV2Spawner_Dirty._gSnowballMakerLeft_throwables.Add(throwable);
				return;
			}
			break;
		case EHandedness.Right:
			vrrigData.bdPositions_rightHandThrowables.Add(throwable.gameObject);
			if (flag)
			{
				CosmeticsV2Spawner_Dirty._gSnowballMakerRight_throwables.Add(throwable);
				return;
			}
			break;
		default:
			throw new ArgumentOutOfRangeException("Unexpected ECosmeticSelectSide value encountered: " + string.Format("{0}, ", handednessFromBone) + string.Format("int: {0}.", (int)handednessFromBone));
		}
	}

	// Token: 0x060002EF RID: 751 RVA: 0x00015990 File Offset: 0x00013B90
	private static void _Step4_PopulateAllArrays()
	{
		if (CosmeticsV2Spawner_Dirty.allPartsInstantiated)
		{
			Debug.LogError("_Step4_PopulateAllArrays: (should never happen) CALLED MORE THAN ONCE!");
			CosmeticsV2Spawner_Dirty.FailedInstantiateAllPrefabs();
			return;
		}
		CosmeticsV2Spawner_Dirty._gSnowballMakerLeft.SetupThrowables(CosmeticsV2Spawner_Dirty._gSnowballMakerLeft_throwables.ToArray());
		CosmeticsV2Spawner_Dirty._gSnowballMakerRight.SetupThrowables(CosmeticsV2Spawner_Dirty._gSnowballMakerRight_throwables.ToArray());
		foreach (CosmeticsV2Spawner_Dirty.VRRigData vrrigData in CosmeticsV2Spawner_Dirty._gVRRigDatas)
		{
			vrrigData.vrRig.cosmetics = vrrigData.vrRig_cosmetics.ToArray();
			vrrigData.vrRig.overrideCosmetics = vrrigData.vrRig_override.ToArray();
			vrrigData.bdPositionsComp.leftHandThrowables = vrrigData.bdPositions_leftHandThrowables.ToArray();
			vrrigData.bdPositionsComp.rightHandThrowables = vrrigData.bdPositions_rightHandThrowables.ToArray();
			vrrigData.bdPositionsComp._allObjects = new TransferrableObject[vrrigData.bdPositions_allObjects_length];
			foreach (TransferrableObject transferrableObject in vrrigData.bdPositions_allObjects)
			{
				if (transferrableObject.myIndex >= 0 && transferrableObject.myIndex < vrrigData.bdPositions_allObjects_length)
				{
					vrrigData.bdPositionsComp._allObjects[transferrableObject.myIndex] = transferrableObject;
				}
			}
		}
		CosmeticsV2Spawner_Dirty.allPartsInstantiated = true;
		GTDelayedExec.Add(CosmeticsV2Spawner_Dirty._instance, 1f, -Mathf.Abs("_Step5_InitializeVRRigsAndCosmeticsControllerFinalize".GetHashCode()));
	}

	// Token: 0x060002F0 RID: 752 RVA: 0x00015B18 File Offset: 0x00013D18
	private static void _Step5_InitializeVRRigsAndCosmeticsControllerFinalize()
	{
		CosmeticsController.instance.UpdateWardrobeModelsAndButtons();
		try
		{
			Action onPostInstantiateAllPrefabs = CosmeticsV2Spawner_Dirty.OnPostInstantiateAllPrefabs;
			if (onPostInstantiateAllPrefabs != null)
			{
				onPostInstantiateAllPrefabs();
			}
		}
		catch (Exception exception)
		{
			Debug.LogException(exception);
		}
		try
		{
			CosmeticsController.instance.InitializeCosmeticStands();
		}
		catch (Exception exception2)
		{
			Debug.LogException(exception2);
		}
		try
		{
			Action onPostInstantiateAllPrefabs2 = CosmeticsV2Spawner_Dirty.OnPostInstantiateAllPrefabs2;
			if (onPostInstantiateAllPrefabs2 != null)
			{
				onPostInstantiateAllPrefabs2();
			}
		}
		catch (Exception exception3)
		{
			Debug.LogException(exception3);
		}
		try
		{
			CosmeticsController.instance.UpdateWornCosmetics(false);
		}
		catch (Exception exception4)
		{
			Debug.LogException(exception4);
		}
		foreach (CosmeticsV2Spawner_Dirty.VRRigData vrrigData in CosmeticsV2Spawner_Dirty._gVRRigDatas)
		{
			try
			{
				if (vrrigData.bdPositionsComp.isActiveAndEnabled)
				{
					vrrigData.bdPositionsComp.RefreshTransferrableItems();
				}
			}
			catch (Exception exception5)
			{
				Debug.LogException(exception5, vrrigData.vrRig);
			}
		}
		CosmeticsV2Spawner_Dirty.completed = true;
	}

	// Token: 0x060002F1 RID: 753 RVA: 0x00015C38 File Offset: 0x00013E38
	private void _DelayedStatusCheck()
	{
		int count = CosmeticsV2Spawner_Dirty._g_loadOpInfos.Count;
		Debug.Log(ZString.Concat<string, string, string, string, double, string, int, string, int, string>("CosmeticsV2Spawner_Dirty", ".", "_DelayedStatusCheck", ": Load progress ", (double)CosmeticsV2Spawner_Dirty._g_loadOpsCountCompleted / (double)count * 100.0, "% (", CosmeticsV2Spawner_Dirty._g_loadOpsCountCompleted, "/", count, ")."));
		if (CosmeticsV2Spawner_Dirty._g_loadOpsCountCompleted < count)
		{
			GTDelayedExec.Add(this, 2f, -100);
		}
	}

	// Token: 0x060002F2 RID: 754 RVA: 0x00015CAC File Offset: 0x00013EAC
	private static void FailedInstantiateAllPrefabs()
	{
		Debug.LogError("Failed to instantiate all prefabs for cosmetics. " + string.Format("_g_loadOpInfos.Count={0}, ", CosmeticsV2Spawner_Dirty._g_loadOpInfos.Count) + string.Format("_g_loadOpsCountCompleted={0}", CosmeticsV2Spawner_Dirty._g_loadOpsCountCompleted));
		CosmeticsV2Spawner_Dirty.failed = true;
		Action onFailedInstantiateAllPrefabs = CosmeticsV2Spawner_Dirty.OnFailedInstantiateAllPrefabs;
		if (onFailedInstantiateAllPrefabs == null)
		{
			return;
		}
		onFailedInstantiateAllPrefabs();
	}

	// Token: 0x040003FE RID: 1022
	private static CosmeticsV2Spawner_Dirty _instance;

	// Token: 0x040003FF RID: 1023
	public static Action OnPostInstantiateAllPrefabs;

	// Token: 0x04000400 RID: 1024
	public static Action OnPostInstantiateAllPrefabs2;

	// Token: 0x04000401 RID: 1025
	public static Action OnFailedInstantiateAllPrefabs;

	// Token: 0x04000405 RID: 1029
	[OnEnterPlay_SetNull]
	private static Transform _gDeactivatedSpawnParent;

	// Token: 0x04000406 RID: 1030
	[OnEnterPlay_Set(0)]
	private static int _g_loadOpsCountCompleted = 0;

	// Token: 0x04000407 RID: 1031
	private const int _k_maxActiveLoadOps = 1000000;

	// Token: 0x04000408 RID: 1032
	private const int _k_maxTotalLoadOps = 1000000;

	// Token: 0x04000409 RID: 1033
	private const int _k_delayedStatusCheckContextId = -100;

	// Token: 0x0400040A RID: 1034
	[OnEnterPlay_Clear]
	private static readonly List<CosmeticsV2Spawner_Dirty.LoadOpInfo> _g_loadOpInfos = new List<CosmeticsV2Spawner_Dirty.LoadOpInfo>(100000);

	// Token: 0x0400040B RID: 1035
	[OnEnterPlay_Clear]
	private static readonly Dictionary<AsyncOperationHandle<GameObject>, int> _g_loadOp_to_index = new Dictionary<AsyncOperationHandle<GameObject>, int>(100000);

	// Token: 0x0400040C RID: 1036
	[OnEnterPlay_SetNull]
	private static SnowballMaker _gSnowballMakerLeft;

	// Token: 0x0400040D RID: 1037
	[OnEnterPlay_Clear]
	private static readonly List<SnowballThrowable> _gSnowballMakerLeft_throwables = new List<SnowballThrowable>(20);

	// Token: 0x0400040E RID: 1038
	[OnEnterPlay_SetNull]
	private static SnowballMaker _gSnowballMakerRight;

	// Token: 0x0400040F RID: 1039
	[OnEnterPlay_Clear]
	private static readonly List<SnowballThrowable> _gSnowballMakerRight_throwables = new List<SnowballThrowable>(20);

	// Token: 0x04000410 RID: 1040
	[OnEnterPlay_SetNull]
	private static Player g_gorillaPlayer;

	// Token: 0x04000411 RID: 1041
	[OnEnterPlay_SetNull]
	private static Transform[] g_allInstantiatedParts;

	// Token: 0x04000412 RID: 1042
	[OnEnterPlay_Clear]
	private static readonly List<CosmeticsV2Spawner_Dirty.VRRigData> _gVRRigDatas = new List<CosmeticsV2Spawner_Dirty.VRRigData>(11);

	// Token: 0x04000413 RID: 1043
	private bool _shouldTick;

	// Token: 0x0200008E RID: 142
	private struct LoadOpInfo
	{
		// Token: 0x060002F5 RID: 757 RVA: 0x00015D64 File Offset: 0x00013F64
		public LoadOpInfo(CosmeticAttachInfo attachInfo, CosmeticPart part, int partIndex, CosmeticInfoV2 cosmeticInfoV2, int vrRigIndex)
		{
			this.isStarted = false;
			this.loadOp = default(AsyncOperationHandle<GameObject>);
			this.resultGObj = null;
			this.attachInfo = attachInfo;
			this.part = part;
			this.partIndex = partIndex;
			this.cosmeticInfoV2 = cosmeticInfoV2;
			this.vrRigIndex = vrRigIndex;
		}

		// Token: 0x04000415 RID: 1045
		public bool isStarted;

		// Token: 0x04000416 RID: 1046
		public AsyncOperationHandle<GameObject> loadOp;

		// Token: 0x04000417 RID: 1047
		public GameObject resultGObj;

		// Token: 0x04000418 RID: 1048
		public readonly CosmeticAttachInfo attachInfo;

		// Token: 0x04000419 RID: 1049
		public readonly CosmeticPart part;

		// Token: 0x0400041A RID: 1050
		public readonly int partIndex;

		// Token: 0x0400041B RID: 1051
		public readonly CosmeticInfoV2 cosmeticInfoV2;

		// Token: 0x0400041C RID: 1052
		public readonly int vrRigIndex;
	}

	// Token: 0x0200008F RID: 143
	private struct VRRigData
	{
		// Token: 0x060002F6 RID: 758 RVA: 0x00015DB0 File Offset: 0x00013FB0
		public VRRigData(VRRig vrRig, Transform[] boneXforms)
		{
			this.vrRig = vrRig;
			this.boneXforms = boneXforms;
			if (!vrRig.transform.TryFindByPath("./**/Holdables", out this.parentOfDeactivatedHoldables, false))
			{
				Debug.LogError("Could not find parent for deactivated holdables. Falling back to VRRig transform: \"" + vrRig.transform.GetPath() + "\"");
			}
			this.bdPositionsComp = vrRig.GetComponentInChildren<BodyDockPositions>(true);
			this.vrRig_cosmetics = new List<GameObject>(500);
			this.vrRig_override = new List<GameObject>(500);
			this.bdPositions_leftHandThrowables = new List<GameObject>(20);
			this.bdPositions_rightHandThrowables = new List<GameObject>(20);
			this.bdPositions_allObjects = new List<TransferrableObject>(20);
			this.bdPositions_allObjects_length = 0;
		}

		// Token: 0x0400041D RID: 1053
		public readonly VRRig vrRig;

		// Token: 0x0400041E RID: 1054
		public readonly Transform[] boneXforms;

		// Token: 0x0400041F RID: 1055
		public readonly BodyDockPositions bdPositionsComp;

		// Token: 0x04000420 RID: 1056
		public readonly List<GameObject> vrRig_cosmetics;

		// Token: 0x04000421 RID: 1057
		public readonly List<GameObject> vrRig_override;

		// Token: 0x04000422 RID: 1058
		public readonly Transform parentOfDeactivatedHoldables;

		// Token: 0x04000423 RID: 1059
		public readonly List<TransferrableObject> bdPositions_allObjects;

		// Token: 0x04000424 RID: 1060
		public int bdPositions_allObjects_length;

		// Token: 0x04000425 RID: 1061
		public readonly List<GameObject> bdPositions_leftHandThrowables;

		// Token: 0x04000426 RID: 1062
		public readonly List<GameObject> bdPositions_rightHandThrowables;
	}
}
