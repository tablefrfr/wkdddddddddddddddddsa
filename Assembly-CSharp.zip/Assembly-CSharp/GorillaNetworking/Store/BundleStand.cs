﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace GorillaNetworking.Store
{
	// Token: 0x020006F5 RID: 1781
	public class BundleStand : MonoBehaviour
	{
		// Token: 0x170004E4 RID: 1252
		// (get) Token: 0x06002A1C RID: 10780 RVA: 0x000CF313 File Offset: 0x000CD513
		public string playfabBundleID
		{
			get
			{
				return this._bundleDataReference.playfabBundleID;
			}
		}

		// Token: 0x06002A1D RID: 10781 RVA: 0x000CF320 File Offset: 0x000CD520
		public void Awake()
		{
			this._bundlePurchaseButton.playfabID = this.playfabBundleID;
			if (this._bundleIcon != null && this._bundleDataReference != null && this._bundleDataReference.bundleImage != null)
			{
				this._bundleIcon.sprite = this._bundleDataReference.bundleImage;
			}
		}

		// Token: 0x06002A1E RID: 10782 RVA: 0x000CF383 File Offset: 0x000CD583
		public void InitializeEventListeners()
		{
			this.AlreadyOwnEvent.AddListener(new UnityAction(this._bundlePurchaseButton.AlreadyOwn));
			this.ErrorHappenedEvent.AddListener(new UnityAction(this._bundlePurchaseButton.ErrorHappened));
		}

		// Token: 0x06002A1F RID: 10783 RVA: 0x000CF3BD File Offset: 0x000CD5BD
		public void NotifyAlreadyOwn()
		{
			this.AlreadyOwnEvent.Invoke();
		}

		// Token: 0x06002A20 RID: 10784 RVA: 0x000CF3CA File Offset: 0x000CD5CA
		public void ErrorHappened()
		{
			this.ErrorHappenedEvent.Invoke();
		}

		// Token: 0x06002A21 RID: 10785 RVA: 0x000CF3D7 File Offset: 0x000CD5D7
		public void UpdatePurchaseButtonText(string purchaseText)
		{
			if (this._bundlePurchaseButton != null)
			{
				this._bundlePurchaseButton.UpdatePurchaseButtonText(purchaseText);
			}
		}

		// Token: 0x06002A22 RID: 10786 RVA: 0x000CF3F3 File Offset: 0x000CD5F3
		public void UpdateDescriptionText(string descriptionText)
		{
			if (this._bundleDescriptionText != null)
			{
				this._bundleDescriptionText.text = descriptionText;
			}
		}

		// Token: 0x04002D35 RID: 11573
		public BundlePurchaseButton _bundlePurchaseButton;

		// Token: 0x04002D36 RID: 11574
		[SerializeField]
		public StoreBundleData _bundleDataReference;

		// Token: 0x04002D37 RID: 11575
		public GameObject[] EditorOnlyObjects;

		// Token: 0x04002D38 RID: 11576
		public Text _bundleDescriptionText;

		// Token: 0x04002D39 RID: 11577
		public Image _bundleIcon;

		// Token: 0x04002D3A RID: 11578
		public UnityEvent AlreadyOwnEvent;

		// Token: 0x04002D3B RID: 11579
		public UnityEvent ErrorHappenedEvent;
	}
}
