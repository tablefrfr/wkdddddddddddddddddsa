﻿using System;
using System.Collections;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005CD RID: 1485
	public class TestRopePerf : MonoBehaviour
	{
		// Token: 0x060022CA RID: 8906 RVA: 0x000A96AE File Offset: 0x000A78AE
		private IEnumerator Start()
		{
			yield break;
		}

		// Token: 0x04002531 RID: 9521
		[SerializeField]
		private GameObject ropesOld;

		// Token: 0x04002532 RID: 9522
		[SerializeField]
		private GameObject ropesCustom;

		// Token: 0x04002533 RID: 9523
		[SerializeField]
		private GameObject ropesCustomVectorized;
	}
}
