﻿using System;
using GorillaLocomotion;
using GorillaNetworking;
using GorillaTag;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000378 RID: 888
public class GorillaHuntComputer : MonoBehaviour
{
	// Token: 0x06001446 RID: 5190 RVA: 0x00069F7C File Offset: 0x0006817C
	private void Update()
	{
		if (PhotonNetwork.InRoom && GorillaGameManager.instance != null && GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>() != null)
		{
			if (!GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().huntStarted)
			{
				if (GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().waitingToStartNextHuntGame && GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().currentTarget.Contains(PhotonNetwork.LocalPlayer) && !GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().currentHunted.Contains(PhotonNetwork.LocalPlayer) && GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().countDownTime == 0)
				{
					this.material.gameObject.SetActive(false);
					this.hat.gameObject.SetActive(false);
					this.face.gameObject.SetActive(false);
					this.badge.gameObject.SetActive(false);
					this.leftHand.gameObject.SetActive(false);
					this.rightHand.gameObject.SetActive(false);
					this.text.text = "YOU WON! CONGRATS, HUNTER!";
					return;
				}
				if (GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().countDownTime != 0)
				{
					this.material.gameObject.SetActive(false);
					this.hat.gameObject.SetActive(false);
					this.face.gameObject.SetActive(false);
					this.badge.gameObject.SetActive(false);
					this.leftHand.gameObject.SetActive(false);
					this.rightHand.gameObject.SetActive(false);
					this.text.text = "GAME STARTING IN:\n" + GorillaGameManager.instance.gameObject.GetComponent<GorillaHuntManager>().countDownTime.ToString() + "...";
					return;
				}
				this.material.gameObject.SetActive(false);
				this.hat.gameObject.SetActive(false);
				this.face.gameObject.SetActive(false);
				this.badge.gameObject.SetActive(false);
				this.leftHand.gameObject.SetActive(false);
				this.rightHand.gameObject.SetActive(false);
				this.text.text = "WAITING TO START";
				return;
			}
			else
			{
				this.myTarget = GorillaGameManager.instance.GetComponent<GorillaHuntManager>().GetTargetOf(PhotonNetwork.LocalPlayer);
				if (this.myTarget == null)
				{
					this.material.gameObject.SetActive(false);
					this.hat.gameObject.SetActive(false);
					this.face.gameObject.SetActive(false);
					this.badge.gameObject.SetActive(false);
					this.leftHand.gameObject.SetActive(false);
					this.rightHand.gameObject.SetActive(false);
					this.text.text = "YOU ARE DEAD\nTAG OTHERS\nTO SLOW THEM";
					return;
				}
				if (GorillaGameManager.instance.FindVRRigForPlayer(this.myTarget) != null)
				{
					this.myRig = GorillaGameManager.instance.FindPlayerVRRig(this.myTarget);
					if (this.myRig != null)
					{
						if (this.myRig.setMatIndex == 0)
						{
							if (this.myRig.scoreboardMaterial != null)
							{
								this.material.material = this.myRig.scoreboardMaterial;
								this.material.color = Color.white;
							}
							else
							{
								this.material.material = null;
								this.material.color = this.myRig.playerColor;
							}
						}
						else
						{
							this.material.material = this.myRig.materialsToChangeTo[this.myRig.setMatIndex];
							this.material.color = Color.white;
						}
						Text text = this.text;
						string[] array = new string[5];
						array[0] = "TARGET:\n";
						int num = 1;
						bool doIt = true;
						Photon.Realtime.Player creator = this.myRig.creator;
						array[num] = this.NormalizeName(doIt, (creator != null) ? creator.NickName : null);
						array[2] = "\nDISTANCE: ";
						array[3] = Mathf.CeilToInt((GorillaLocomotion.Player.Instance.headCollider.transform.position - this.myRig.transform.position).magnitude).ToString();
						array[4] = "M";
						text.text = string.Concat(array);
						this.SetImage(this.myRig.cosmeticSet.items[0].displayName, ref this.hat);
						this.SetImage(this.myRig.cosmeticSet.items[2].displayName, ref this.face);
						this.SetImage(this.myRig.cosmeticSet.items[1].displayName, ref this.badge);
						this.SetImage(this.GetPrioritizedItemForHand(this.myRig, true).displayName, ref this.leftHand);
						this.SetImage(this.GetPrioritizedItemForHand(this.myRig, false).displayName, ref this.rightHand);
						this.material.gameObject.SetActive(true);
						return;
					}
				}
			}
		}
		else
		{
			GorillaTagger.Instance.offlineVRRig.huntComputer.SetActive(false);
		}
	}

	// Token: 0x06001447 RID: 5191 RVA: 0x0006A4D0 File Offset: 0x000686D0
	private void SetImage(string itemDisplayName, ref Image image)
	{
		this.tempItem = CosmeticsController.instance.GetItemFromDict(CosmeticsController.instance.GetItemNameFromDisplayName(itemDisplayName));
		if (this.tempItem.displayName != "NOTHING" && this.myRig != null && this.myRig.IsItemAllowed(this.tempItem.itemName))
		{
			image.gameObject.SetActive(true);
			image.sprite = this.tempItem.itemPicture;
			return;
		}
		image.gameObject.SetActive(false);
	}

	// Token: 0x06001448 RID: 5192 RVA: 0x0006A568 File Offset: 0x00068768
	public string NormalizeName(bool doIt, string text)
	{
		if (doIt)
		{
			if (GorillaComputer.instance.CheckAutoBanListForName(text))
			{
				text = new string(Array.FindAll<char>(text.ToCharArray(), (char c) => char.IsLetterOrDigit(c)));
				if (text.Length > 12)
				{
					text = text.Substring(0, 11);
				}
				text = text.ToUpper();
			}
			else
			{
				text = "BADGORILLA";
			}
		}
		return text;
	}

	// Token: 0x06001449 RID: 5193 RVA: 0x0006A5E0 File Offset: 0x000687E0
	public CosmeticsController.CosmeticItem GetPrioritizedItemForHand(VRRig targetRig, bool forLeftHand)
	{
		if (forLeftHand)
		{
			CosmeticsController.CosmeticItem cosmeticItem = targetRig.cosmeticSet.items[7];
			if (cosmeticItem.displayName != "null")
			{
				return cosmeticItem;
			}
			cosmeticItem = targetRig.cosmeticSet.items[4];
			if (cosmeticItem.displayName != "null")
			{
				return cosmeticItem;
			}
			return targetRig.cosmeticSet.items[5];
		}
		else
		{
			CosmeticsController.CosmeticItem cosmeticItem = targetRig.cosmeticSet.items[8];
			if (cosmeticItem.displayName != "null")
			{
				return cosmeticItem;
			}
			cosmeticItem = targetRig.cosmeticSet.items[3];
			if (cosmeticItem.displayName != "null")
			{
				return cosmeticItem;
			}
			return targetRig.cosmeticSet.items[6];
		}
	}

	// Token: 0x0400171C RID: 5916
	public Text text;

	// Token: 0x0400171D RID: 5917
	public Image material;

	// Token: 0x0400171E RID: 5918
	public Image hat;

	// Token: 0x0400171F RID: 5919
	public Image face;

	// Token: 0x04001720 RID: 5920
	public Image badge;

	// Token: 0x04001721 RID: 5921
	public Image leftHand;

	// Token: 0x04001722 RID: 5922
	public Image rightHand;

	// Token: 0x04001723 RID: 5923
	public Photon.Realtime.Player myTarget;

	// Token: 0x04001724 RID: 5924
	public Photon.Realtime.Player tempTarget;

	// Token: 0x04001725 RID: 5925
	[DebugReadout]
	public VRRig myRig;

	// Token: 0x04001726 RID: 5926
	public Sprite tempSprite;

	// Token: 0x04001727 RID: 5927
	public CosmeticsController.CosmeticItem tempItem;
}
