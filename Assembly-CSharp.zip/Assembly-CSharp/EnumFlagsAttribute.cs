﻿using System;
using UnityEngine;

// Token: 0x020004BE RID: 1214
public class EnumFlagsAttribute : PropertyAttribute
{
}
