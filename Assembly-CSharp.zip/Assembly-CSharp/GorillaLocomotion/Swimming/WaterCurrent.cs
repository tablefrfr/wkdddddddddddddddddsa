﻿using System;
using System.Collections.Generic;
using AA;
using CjLib;
using UnityEngine;

namespace GorillaLocomotion.Swimming
{
	// Token: 0x020005B7 RID: 1463
	public class WaterCurrent : MonoBehaviour
	{
		// Token: 0x170003FF RID: 1023
		// (get) Token: 0x06002232 RID: 8754 RVA: 0x000A5521 File Offset: 0x000A3721
		public float Speed
		{
			get
			{
				return this.currentSpeed;
			}
		}

		// Token: 0x17000400 RID: 1024
		// (get) Token: 0x06002233 RID: 8755 RVA: 0x000A5529 File Offset: 0x000A3729
		public float Accel
		{
			get
			{
				return this.currentAccel;
			}
		}

		// Token: 0x17000401 RID: 1025
		// (get) Token: 0x06002234 RID: 8756 RVA: 0x000A5531 File Offset: 0x000A3731
		public float InwardSpeed
		{
			get
			{
				return this.inwardCurrentSpeed;
			}
		}

		// Token: 0x17000402 RID: 1026
		// (get) Token: 0x06002235 RID: 8757 RVA: 0x000A5539 File Offset: 0x000A3739
		public float InwardAccel
		{
			get
			{
				return this.inwardCurrentAccel;
			}
		}

		// Token: 0x06002236 RID: 8758 RVA: 0x000A5544 File Offset: 0x000A3744
		public bool GetCurrentAtPoint(Vector3 worldPoint, Vector3 startingVelocity, float dt, out Vector3 currentVelocity, out Vector3 velocityChange)
		{
			float num = (this.fullEffectDistance + this.fadeDistance) * (this.fullEffectDistance + this.fadeDistance);
			bool result = false;
			velocityChange = Vector3.zero;
			currentVelocity = Vector3.zero;
			float num2 = 0.0001f;
			float magnitude = startingVelocity.magnitude;
			if (magnitude > num2)
			{
				Vector3 a = startingVelocity / magnitude;
				float d = Spring.DamperDecayExact(magnitude, this.dampingHalfLife, dt, 1E-05f);
				Vector3 a2 = a * d;
				velocityChange += a2 - startingVelocity;
			}
			for (int i = 0; i < this.splines.Count; i++)
			{
				CatmullRomSpline catmullRomSpline = this.splines[i];
				Vector3 vector;
				float closestEvaluationOnSpline = catmullRomSpline.GetClosestEvaluationOnSpline(worldPoint, out vector);
				Vector3 a3 = catmullRomSpline.Evaluate(closestEvaluationOnSpline);
				Vector3 vector2 = a3 - worldPoint;
				if (vector2.sqrMagnitude < num)
				{
					result = true;
					float magnitude2 = vector2.magnitude;
					float num3 = (magnitude2 > this.fullEffectDistance) ? (1f - Mathf.Clamp01((magnitude2 - this.fullEffectDistance) / this.fadeDistance)) : 1f;
					float t = Mathf.Clamp01(closestEvaluationOnSpline + this.velocityAnticipationAdjustment);
					Vector3 forwardTangent = catmullRomSpline.GetForwardTangent(t, 0.01f);
					if (this.currentSpeed > num2 && Vector3.Dot(startingVelocity, forwardTangent) < num3 * this.currentSpeed)
					{
						velocityChange += forwardTangent * (this.currentAccel * dt);
					}
					else if (this.currentSpeed < num2 && Vector3.Dot(startingVelocity, forwardTangent) > num3 * this.currentSpeed)
					{
						velocityChange -= forwardTangent * (this.currentAccel * dt);
					}
					currentVelocity += forwardTangent * num3 * this.currentSpeed;
					float num4 = Mathf.InverseLerp(this.inwardCurrentNoEffectRadius, this.inwardCurrentFullEffectRadius, magnitude2);
					if (num4 > num2)
					{
						vector = Vector3.ProjectOnPlane(vector2, forwardTangent);
						Vector3 normalized = vector.normalized;
						if (this.inwardCurrentSpeed > num2 && Vector3.Dot(startingVelocity, normalized) < num4 * this.inwardCurrentSpeed)
						{
							velocityChange += normalized * (this.InwardAccel * dt);
						}
						else if (this.inwardCurrentSpeed < num2 && Vector3.Dot(startingVelocity, normalized) > num4 * this.inwardCurrentSpeed)
						{
							velocityChange -= normalized * (this.InwardAccel * dt);
						}
					}
					this.debugSplinePoint = a3;
				}
			}
			this.debugCurrentVelocity = velocityChange.normalized;
			return result;
		}

		// Token: 0x06002237 RID: 8759 RVA: 0x000A57F8 File Offset: 0x000A39F8
		private void Update()
		{
			if (this.debugDrawCurrentQueries)
			{
				DebugUtil.DrawSphere(this.debugSplinePoint, 0.15f, 12, 12, Color.green, false, DebugUtil.Style.Wireframe);
				DebugUtil.DrawArrow(this.debugSplinePoint, this.debugSplinePoint + this.debugCurrentVelocity, 0.1f, 0.1f, 12, 0.1f, Color.yellow, false, DebugUtil.Style.Wireframe);
			}
		}

		// Token: 0x06002238 RID: 8760 RVA: 0x000A585C File Offset: 0x000A3A5C
		private void OnDrawGizmosSelected()
		{
			int num = 16;
			for (int i = 0; i < this.splines.Count; i++)
			{
				CatmullRomSpline catmullRomSpline = this.splines[i];
				Vector3 b = catmullRomSpline.Evaluate(0f);
				for (int j = 1; j <= num; j++)
				{
					float t = (float)j / (float)num;
					Vector3 vector = catmullRomSpline.Evaluate(t);
					vector - b;
					Quaternion rotation = Quaternion.LookRotation(catmullRomSpline.GetForwardTangent(t, 0.01f), Vector3.up);
					Gizmos.color = new Color(0f, 0.5f, 0.75f);
					this.DrawGizmoCircle(vector, rotation, this.fullEffectDistance);
					Gizmos.color = new Color(0f, 0.25f, 0.5f);
					this.DrawGizmoCircle(vector, rotation, this.fullEffectDistance + this.fadeDistance);
				}
			}
		}

		// Token: 0x06002239 RID: 8761 RVA: 0x000A5944 File Offset: 0x000A3B44
		private void DrawGizmoCircle(Vector3 center, Quaternion rotation, float radius)
		{
			Vector3 point = Vector3.right * radius;
			int num = 16;
			for (int i = 1; i <= num; i++)
			{
				float f = (float)i / (float)num * 2f * 3.1415927f;
				Vector3 vector = new Vector3(Mathf.Cos(f), Mathf.Sin(f), 0f) * radius;
				Gizmos.DrawLine(center + rotation * point, center + rotation * vector);
				point = vector;
			}
		}

		// Token: 0x04002468 RID: 9320
		[SerializeField]
		private List<CatmullRomSpline> splines = new List<CatmullRomSpline>();

		// Token: 0x04002469 RID: 9321
		[SerializeField]
		private float fullEffectDistance = 1f;

		// Token: 0x0400246A RID: 9322
		[SerializeField]
		private float fadeDistance = 0.5f;

		// Token: 0x0400246B RID: 9323
		[SerializeField]
		private float currentSpeed = 1f;

		// Token: 0x0400246C RID: 9324
		[SerializeField]
		private float currentAccel = 10f;

		// Token: 0x0400246D RID: 9325
		[SerializeField]
		private float velocityAnticipationAdjustment = 0.05f;

		// Token: 0x0400246E RID: 9326
		[SerializeField]
		private float inwardCurrentFullEffectRadius = 1f;

		// Token: 0x0400246F RID: 9327
		[SerializeField]
		private float inwardCurrentNoEffectRadius = 0.25f;

		// Token: 0x04002470 RID: 9328
		[SerializeField]
		private float inwardCurrentSpeed = 1f;

		// Token: 0x04002471 RID: 9329
		[SerializeField]
		private float inwardCurrentAccel = 10f;

		// Token: 0x04002472 RID: 9330
		[SerializeField]
		private float dampingHalfLife = 0.25f;

		// Token: 0x04002473 RID: 9331
		[SerializeField]
		private bool debugDrawCurrentQueries;

		// Token: 0x04002474 RID: 9332
		private Vector3 debugCurrentVelocity = Vector3.zero;

		// Token: 0x04002475 RID: 9333
		private Vector3 debugSplinePoint = Vector3.zero;
	}
}
