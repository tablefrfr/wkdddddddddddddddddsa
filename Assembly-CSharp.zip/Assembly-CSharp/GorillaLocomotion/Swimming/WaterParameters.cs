﻿using System;
using UnityEngine;

namespace GorillaLocomotion.Swimming
{
	// Token: 0x020005B9 RID: 1465
	[CreateAssetMenu(fileName = "Data", menuName = "ScriptableObjects/WaterParameters", order = 1)]
	public class WaterParameters : ScriptableObject
	{
		// Token: 0x04002488 RID: 9352
		[Header("Splash Effect")]
		public bool playSplashEffect = true;

		// Token: 0x04002489 RID: 9353
		public GameObject splashEffect;

		// Token: 0x0400248A RID: 9354
		public float splashEffectScale = 1f;

		// Token: 0x0400248B RID: 9355
		public bool sendSplashEffectRPCs;

		// Token: 0x0400248C RID: 9356
		public float splashSpeedRequirement = 0.8f;

		// Token: 0x0400248D RID: 9357
		public float bigSplashSpeedRequirement = 1.9f;

		// Token: 0x0400248E RID: 9358
		public Gradient splashColorBySpeedGradient;

		// Token: 0x0400248F RID: 9359
		[Header("Ripple Effect")]
		public bool playRippleEffect = true;

		// Token: 0x04002490 RID: 9360
		public GameObject rippleEffect;

		// Token: 0x04002491 RID: 9361
		public float rippleEffectScale = 1f;

		// Token: 0x04002492 RID: 9362
		public float defaultDistanceBetweenRipples = 0.75f;

		// Token: 0x04002493 RID: 9363
		public float minDistanceBetweenRipples = 0.2f;

		// Token: 0x04002494 RID: 9364
		public float minTimeBetweenRipples = 0.75f;

		// Token: 0x04002495 RID: 9365
		public Color rippleSpriteColor = Color.white;

		// Token: 0x04002496 RID: 9366
		[Header("Drip Effect")]
		public bool playDripEffect = true;

		// Token: 0x04002497 RID: 9367
		public float postExitDripDuration = 1.5f;

		// Token: 0x04002498 RID: 9368
		public float perDripTimeDelay = 0.2f;

		// Token: 0x04002499 RID: 9369
		public float perDripTimeRandRange = 0.15f;

		// Token: 0x0400249A RID: 9370
		public float perDripDefaultRadius = 0.01f;

		// Token: 0x0400249B RID: 9371
		public float perDripRadiusRandRange = 0.01f;

		// Token: 0x0400249C RID: 9372
		[Header("Misc")]
		public float recomputeSurfaceForColliderDist = 0.2f;

		// Token: 0x0400249D RID: 9373
		public bool allowBubblesInVolume;
	}
}
