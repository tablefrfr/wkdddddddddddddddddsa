﻿using System;
using UnityEngine;

namespace BuildSafe
{
	// Token: 0x02000626 RID: 1574
	public static class ObjectFactory
	{
		// Token: 0x1400003C RID: 60
		// (add) Token: 0x06002515 RID: 9493 RVA: 0x00003051 File Offset: 0x00001251
		// (remove) Token: 0x06002516 RID: 9494 RVA: 0x00003051 File Offset: 0x00001251
		public static event Action<Component> componentWasAdded
		{
			add
			{
			}
			remove
			{
			}
		}
	}
}
