﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

// Token: 0x02000020 RID: 32
public class ColliderOffsetOverride : MonoBehaviour
{
	// Token: 0x06000060 RID: 96 RVA: 0x00004760 File Offset: 0x00002960
	private void Awake()
	{
		if (this.autoSearch)
		{
			this.FindColliders();
		}
		foreach (Collider collider in this.colliders)
		{
			if (collider != null)
			{
				collider.contactOffset = 0.01f * this.targetScale;
			}
		}
	}

	// Token: 0x06000061 RID: 97 RVA: 0x000047D8 File Offset: 0x000029D8
	public void FindColliders()
	{
		foreach (Collider item in base.gameObject.GetComponents<Collider>().ToList<Collider>())
		{
			if (!this.colliders.Contains(item))
			{
				this.colliders.Add(item);
			}
		}
	}

	// Token: 0x06000062 RID: 98 RVA: 0x00004848 File Offset: 0x00002A48
	public void FindCollidersRecursively()
	{
		foreach (Collider item in base.gameObject.GetComponentsInChildren<Collider>().ToList<Collider>())
		{
			if (!this.colliders.Contains(item))
			{
				this.colliders.Add(item);
			}
		}
	}

	// Token: 0x06000063 RID: 99 RVA: 0x000048B8 File Offset: 0x00002AB8
	private void AutoDisabled()
	{
		this.autoSearch = true;
	}

	// Token: 0x06000064 RID: 100 RVA: 0x000048C1 File Offset: 0x00002AC1
	private void AutoEnabled()
	{
		this.autoSearch = false;
	}

	// Token: 0x04000097 RID: 151
	public List<Collider> colliders;

	// Token: 0x04000098 RID: 152
	[HideInInspector]
	public bool autoSearch;

	// Token: 0x04000099 RID: 153
	public float targetScale = 1f;
}
