﻿using System;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005C8 RID: 1480
	[CreateAssetMenu(fileName = "GorillaZiplineSettings", menuName = "ScriptableObjects/GorillaZiplineSettings", order = 0)]
	public class GorillaZiplineSettings : ScriptableObject
	{
		// Token: 0x04002503 RID: 9475
		public float minSlidePitch = 0.5f;

		// Token: 0x04002504 RID: 9476
		public float maxSlidePitch = 1f;

		// Token: 0x04002505 RID: 9477
		public float minSlideVolume;

		// Token: 0x04002506 RID: 9478
		public float maxSlideVolume = 0.2f;

		// Token: 0x04002507 RID: 9479
		public float maxSpeed = 10f;

		// Token: 0x04002508 RID: 9480
		public float gravityMulti = 1.1f;

		// Token: 0x04002509 RID: 9481
		[Header("Friction")]
		public float friction = 0.25f;

		// Token: 0x0400250A RID: 9482
		public float maxFriction = 1f;

		// Token: 0x0400250B RID: 9483
		public float maxFrictionSpeed = 15f;
	}
}
