﻿using System;
using UnityEngine;

// Token: 0x020004E8 RID: 1256
public class BezierCurve : MonoBehaviour
{
	// Token: 0x06001C31 RID: 7217 RVA: 0x0008E250 File Offset: 0x0008C450
	public Vector3 GetPoint(float t)
	{
		return base.transform.TransformPoint(Bezier.GetPoint(this.points[0], this.points[1], this.points[2], this.points[3], t));
	}

	// Token: 0x06001C32 RID: 7218 RVA: 0x0008E2A0 File Offset: 0x0008C4A0
	public Vector3 GetVelocity(float t)
	{
		return base.transform.TransformPoint(Bezier.GetFirstDerivative(this.points[0], this.points[1], this.points[2], this.points[3], t)) - base.transform.position;
	}

	// Token: 0x06001C33 RID: 7219 RVA: 0x0008E300 File Offset: 0x0008C500
	public Vector3 GetDirection(float t)
	{
		return this.GetVelocity(t).normalized;
	}

	// Token: 0x06001C34 RID: 7220 RVA: 0x0008E31C File Offset: 0x0008C51C
	public void Reset()
	{
		this.points = new Vector3[]
		{
			new Vector3(1f, 0f, 0f),
			new Vector3(2f, 0f, 0f),
			new Vector3(3f, 0f, 0f),
			new Vector3(4f, 0f, 0f)
		};
	}

	// Token: 0x04001FC4 RID: 8132
	public Vector3[] points;
}
