﻿using System;
using System.Collections.Generic;

namespace GorillaNetworking
{
	// Token: 0x020006C9 RID: 1737
	public class SubmitAcceptedAgreementsRequest
	{
		// Token: 0x04002C42 RID: 11330
		public Dictionary<string, string> Agreements;
	}
}
