﻿using System;
using GorillaGameModes;
using Photon.Pun;

// Token: 0x020002F8 RID: 760
public class CasualGameMode : GorillaGameManager
{
	// Token: 0x0600116B RID: 4459 RVA: 0x00003051 File Offset: 0x00001251
	public override void OnSerializeRead(PhotonStream stream, PhotonMessageInfo info)
	{
	}

	// Token: 0x0600116C RID: 4460 RVA: 0x00003051 File Offset: 0x00001251
	public override void OnSerializeWrite(PhotonStream stream, PhotonMessageInfo info)
	{
	}

	// Token: 0x0600116D RID: 4461 RVA: 0x00002076 File Offset: 0x00000276
	public override GameModeType GameType()
	{
		return GameModeType.Casual;
	}

	// Token: 0x0600116E RID: 4462 RVA: 0x0005BFF7 File Offset: 0x0005A1F7
	public override string GameModeName()
	{
		return "CASUAL";
	}
}
