﻿using System;
using UnityEngine;

// Token: 0x020004BC RID: 1212
public class DelayedDestroyPooledObj : MonoBehaviour
{
	// Token: 0x06001B9F RID: 7071 RVA: 0x0008C410 File Offset: 0x0008A610
	protected void OnEnable()
	{
		if (ObjectPools.instance == null || !ObjectPools.instance.initialized)
		{
			return;
		}
		this.timeToDie = Time.time + this.destroyDelay;
	}

	// Token: 0x06001BA0 RID: 7072 RVA: 0x0008C43E File Offset: 0x0008A63E
	protected void LateUpdate()
	{
		if (Time.time > this.timeToDie)
		{
			ObjectPools.instance.Destroy(base.gameObject);
		}
	}

	// Token: 0x04001F6E RID: 8046
	[Tooltip("Return to the object pool after this many seconds.")]
	public float destroyDelay;

	// Token: 0x04001F6F RID: 8047
	private float timeToDie = -1f;
}
