﻿using System;
using UnityEngine;

namespace BoingKit
{
	// Token: 0x02000827 RID: 2087
	public struct Aabb
	{
		// Token: 0x1700056D RID: 1389
		// (get) Token: 0x0600328A RID: 12938 RVA: 0x000FE067 File Offset: 0x000FC267
		// (set) Token: 0x0600328B RID: 12939 RVA: 0x000FE074 File Offset: 0x000FC274
		public float MinX
		{
			get
			{
				return this.Min.x;
			}
			set
			{
				this.Min.x = value;
			}
		}

		// Token: 0x1700056E RID: 1390
		// (get) Token: 0x0600328C RID: 12940 RVA: 0x000FE082 File Offset: 0x000FC282
		// (set) Token: 0x0600328D RID: 12941 RVA: 0x000FE08F File Offset: 0x000FC28F
		public float MinY
		{
			get
			{
				return this.Min.y;
			}
			set
			{
				this.Min.y = value;
			}
		}

		// Token: 0x1700056F RID: 1391
		// (get) Token: 0x0600328E RID: 12942 RVA: 0x000FE09D File Offset: 0x000FC29D
		// (set) Token: 0x0600328F RID: 12943 RVA: 0x000FE0AA File Offset: 0x000FC2AA
		public float MinZ
		{
			get
			{
				return this.Min.z;
			}
			set
			{
				this.Min.z = value;
			}
		}

		// Token: 0x17000570 RID: 1392
		// (get) Token: 0x06003290 RID: 12944 RVA: 0x000FE0B8 File Offset: 0x000FC2B8
		// (set) Token: 0x06003291 RID: 12945 RVA: 0x000FE0C5 File Offset: 0x000FC2C5
		public float MaxX
		{
			get
			{
				return this.Max.x;
			}
			set
			{
				this.Max.x = value;
			}
		}

		// Token: 0x17000571 RID: 1393
		// (get) Token: 0x06003292 RID: 12946 RVA: 0x000FE0D3 File Offset: 0x000FC2D3
		// (set) Token: 0x06003293 RID: 12947 RVA: 0x000FE0E0 File Offset: 0x000FC2E0
		public float MaxY
		{
			get
			{
				return this.Max.y;
			}
			set
			{
				this.Max.y = value;
			}
		}

		// Token: 0x17000572 RID: 1394
		// (get) Token: 0x06003294 RID: 12948 RVA: 0x000FE0EE File Offset: 0x000FC2EE
		// (set) Token: 0x06003295 RID: 12949 RVA: 0x000FE0FB File Offset: 0x000FC2FB
		public float MaxZ
		{
			get
			{
				return this.Max.z;
			}
			set
			{
				this.Max.z = value;
			}
		}

		// Token: 0x17000573 RID: 1395
		// (get) Token: 0x06003296 RID: 12950 RVA: 0x000FE109 File Offset: 0x000FC309
		public Vector3 Center
		{
			get
			{
				return 0.5f * (this.Min + this.Max);
			}
		}

		// Token: 0x17000574 RID: 1396
		// (get) Token: 0x06003297 RID: 12951 RVA: 0x000FE128 File Offset: 0x000FC328
		public Vector3 Size
		{
			get
			{
				Vector3 vector = this.Max - this.Min;
				vector.x = Mathf.Max(0f, vector.x);
				vector.y = Mathf.Max(0f, vector.y);
				vector.z = Mathf.Max(0f, vector.z);
				return vector;
			}
		}

		// Token: 0x17000575 RID: 1397
		// (get) Token: 0x06003298 RID: 12952 RVA: 0x000FE18D File Offset: 0x000FC38D
		public static Aabb Empty
		{
			get
			{
				return new Aabb(new Vector3(float.MaxValue, float.MaxValue, float.MaxValue), new Vector3(float.MinValue, float.MinValue, float.MinValue));
			}
		}

		// Token: 0x06003299 RID: 12953 RVA: 0x000FE1BC File Offset: 0x000FC3BC
		public static Aabb FromPoint(Vector3 p)
		{
			Aabb empty = Aabb.Empty;
			empty.Include(p);
			return empty;
		}

		// Token: 0x0600329A RID: 12954 RVA: 0x000FE1D8 File Offset: 0x000FC3D8
		public static Aabb FromPoints(Vector3 a, Vector3 b)
		{
			Aabb empty = Aabb.Empty;
			empty.Include(a);
			empty.Include(b);
			return empty;
		}

		// Token: 0x0600329B RID: 12955 RVA: 0x000FE1FC File Offset: 0x000FC3FC
		public Aabb(Vector3 min, Vector3 max)
		{
			this.Min = min;
			this.Max = max;
		}

		// Token: 0x0600329C RID: 12956 RVA: 0x000FE20C File Offset: 0x000FC40C
		public void Include(Vector3 p)
		{
			this.MinX = Mathf.Min(this.MinX, p.x);
			this.MinY = Mathf.Min(this.MinY, p.y);
			this.MinZ = Mathf.Min(this.MinZ, p.z);
			this.MaxX = Mathf.Max(this.MaxX, p.x);
			this.MaxY = Mathf.Max(this.MaxY, p.y);
			this.MaxZ = Mathf.Max(this.MaxZ, p.z);
		}

		// Token: 0x0600329D RID: 12957 RVA: 0x000FE2A4 File Offset: 0x000FC4A4
		public bool Contains(Vector3 p)
		{
			return this.MinX <= p.x && this.MinY <= p.y && this.MinZ <= p.z && this.MaxX >= p.x && this.MaxY >= p.y && this.MaxZ >= p.z;
		}

		// Token: 0x0600329E RID: 12958 RVA: 0x000FE30A File Offset: 0x000FC50A
		public bool ContainsX(Vector3 p)
		{
			return this.MinX <= p.x && this.MaxX >= p.x;
		}

		// Token: 0x0600329F RID: 12959 RVA: 0x000FE32D File Offset: 0x000FC52D
		public bool ContainsY(Vector3 p)
		{
			return this.MinY <= p.y && this.MaxY >= p.y;
		}

		// Token: 0x060032A0 RID: 12960 RVA: 0x000FE350 File Offset: 0x000FC550
		public bool ContainsZ(Vector3 p)
		{
			return this.MinZ <= p.z && this.MaxZ >= p.z;
		}

		// Token: 0x060032A1 RID: 12961 RVA: 0x000FE374 File Offset: 0x000FC574
		public bool Intersects(Aabb rhs)
		{
			return this.MinX <= rhs.MaxX && this.MinY <= rhs.MaxY && this.MinZ <= rhs.MaxZ && this.MaxX >= rhs.MinX && this.MaxY >= rhs.MinY && this.MaxZ >= rhs.MinZ;
		}

		// Token: 0x060032A2 RID: 12962 RVA: 0x000FE3E0 File Offset: 0x000FC5E0
		public bool Intersects(ref BoingEffector.Params effector)
		{
			if (!effector.Bits.IsBitSet(0))
			{
				return this.Intersects(Aabb.FromPoint(effector.CurrPosition).Expand(effector.Radius));
			}
			return this.Intersects(Aabb.FromPoints(effector.PrevPosition, effector.CurrPosition).Expand(effector.Radius));
		}

		// Token: 0x060032A3 RID: 12963 RVA: 0x000FE440 File Offset: 0x000FC640
		public Aabb Expand(float amount)
		{
			this.MinX -= amount;
			this.MinY -= amount;
			this.MinZ -= amount;
			this.MaxX += amount;
			this.MaxY += amount;
			this.MaxZ += amount;
			return this;
		}

		// Token: 0x04003526 RID: 13606
		public Vector3 Min;

		// Token: 0x04003527 RID: 13607
		public Vector3 Max;
	}
}
