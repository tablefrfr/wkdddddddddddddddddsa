﻿using System;
using Unity.Collections;
using UnityEngine.Jobs;

// Token: 0x02000326 RID: 806
public struct BuilderTableMeshInstances
{
	// Token: 0x040014C3 RID: 5315
	public TransformAccessArray transforms;

	// Token: 0x040014C4 RID: 5316
	public NativeList<int> texIndex;

	// Token: 0x040014C5 RID: 5317
	public NativeList<float> tint;
}
