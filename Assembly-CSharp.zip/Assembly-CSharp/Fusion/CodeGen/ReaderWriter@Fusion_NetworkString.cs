﻿using System;
using System.Runtime.CompilerServices;

namespace Fusion.CodeGen
{
	// Token: 0x02000844 RID: 2116
	internal struct ReaderWriter@Fusion_NetworkString : IElementReaderWriter<NetworkString<_16>>
	{
		// Token: 0x0600331D RID: 13085 RVA: 0x00100430 File Offset: 0x000FE630
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public unsafe NetworkString<_16> Read(byte* data, int index)
		{
			return *(NetworkString<_16>*)(data + index * 68);
		}

		// Token: 0x0600331E RID: 13086 RVA: 0x00100440 File Offset: 0x000FE640
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public unsafe ref NetworkString<_16> ReadRef(byte* data, int index)
		{
			return ref *(NetworkString<_16>*)(data + index * 68);
		}

		// Token: 0x0600331F RID: 13087 RVA: 0x0010044B File Offset: 0x000FE64B
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public unsafe void Write(byte* data, int index, NetworkString<_16> val)
		{
			*(NetworkString<_16>*)(data + index * 68) = val;
		}

		// Token: 0x06003320 RID: 13088 RVA: 0x0010045C File Offset: 0x000FE65C
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public int GetElementWordCount()
		{
			return 17;
		}

		// Token: 0x06003321 RID: 13089 RVA: 0x00100464 File Offset: 0x000FE664
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public static IElementReaderWriter<NetworkString<_16>> GetInstance()
		{
			if (ReaderWriter@Fusion_NetworkString.Instance == null)
			{
				ReaderWriter@Fusion_NetworkString.Instance = default(ReaderWriter@Fusion_NetworkString);
			}
			return ReaderWriter@Fusion_NetworkString.Instance;
		}

		// Token: 0x04003580 RID: 13696
		public static IElementReaderWriter<NetworkString<_16>> Instance;
	}
}
