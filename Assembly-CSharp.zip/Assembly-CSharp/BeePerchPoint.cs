﻿using System;
using UnityEngine;

// Token: 0x0200006F RID: 111
public class BeePerchPoint : MonoBehaviour
{
	// Token: 0x06000234 RID: 564 RVA: 0x0001085F File Offset: 0x0000EA5F
	public Vector3 GetPoint()
	{
		return base.transform.TransformPoint(this.localPosition);
	}

	// Token: 0x0400033D RID: 829
	[SerializeField]
	private Vector3 localPosition;
}
