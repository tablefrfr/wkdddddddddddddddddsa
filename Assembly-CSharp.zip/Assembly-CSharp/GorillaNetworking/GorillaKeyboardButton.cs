﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using GorillaTag;
using Photon.Pun;
using UnityEngine;

namespace GorillaNetworking
{
	// Token: 0x020006C0 RID: 1728
	public class GorillaKeyboardButton : MonoBehaviour
	{
		// Token: 0x06002905 RID: 10501 RVA: 0x000CA1F6 File Offset: 0x000C83F6
		private void Start()
		{
			if (this.ButtonRenderer == null)
			{
				this.ButtonRenderer = base.GetComponent<Renderer>();
			}
			this.propBlock = new MaterialPropertyBlock();
			this.pressTime = 0f;
		}

		// Token: 0x06002906 RID: 10502 RVA: 0x000CA228 File Offset: 0x000C8428
		private void OnTriggerEnter(Collider collider)
		{
			if (collider.GetComponentInParent<GorillaTriggerColliderHandIndicator>() != null)
			{
				GorillaTriggerColliderHandIndicator component = collider.GetComponent<GorillaTriggerColliderHandIndicator>();
				GameEvents.OnGorrillaKeyboardButtonPressedEvent.Invoke(this.Binding);
				this.PressButtonColourUpdate();
				if (component != null)
				{
					GorillaTagger.Instance.StartVibration(component.isLeftHand, GorillaTagger.Instance.tapHapticStrength / 2f, GorillaTagger.Instance.tapHapticDuration);
					GorillaTagger.Instance.offlineVRRig.PlayHandTapLocal(66, component.isLeftHand, 0.1f);
					if (PhotonNetwork.InRoom && GorillaTagger.Instance.myVRRig != null)
					{
						GorillaTagger.Instance.myVRRig.RPC("PlayHandTap", RpcTarget.Others, new object[]
						{
							66,
							component.isLeftHand,
							0.1f
						});
					}
				}
			}
		}

		// Token: 0x06002907 RID: 10503 RVA: 0x000CA310 File Offset: 0x000C8510
		public void PressButtonColourUpdate()
		{
			this.propBlock.SetColor("_BaseColor", this.ButtonColorSettings.PressedColor);
			this.propBlock.SetColor("_Color", this.ButtonColorSettings.PressedColor);
			this.ButtonRenderer.SetPropertyBlock(this.propBlock);
			this.pressTime = Time.time;
			base.StartCoroutine(this.<PressButtonColourUpdate>g__ButtonColorUpdate_Local|13_0());
		}

		// Token: 0x06002909 RID: 10505 RVA: 0x000CA38F File Offset: 0x000C858F
		[CompilerGenerated]
		private IEnumerator <PressButtonColourUpdate>g__ButtonColorUpdate_Local|13_0()
		{
			yield return new WaitForSeconds(this.ButtonColorSettings.PressedTime);
			if (this.pressTime != 0f && Time.time > this.ButtonColorSettings.PressedTime + this.pressTime)
			{
				this.propBlock.SetColor("_BaseColor", this.ButtonColorSettings.UnpressedColor);
				this.propBlock.SetColor("_Color", this.ButtonColorSettings.UnpressedColor);
				this.ButtonRenderer.SetPropertyBlock(this.propBlock);
				this.pressTime = 0f;
			}
			yield break;
		}

		// Token: 0x04002C09 RID: 11273
		public string characterString;

		// Token: 0x04002C0A RID: 11274
		public GorillaKeyboardBindings Binding;

		// Token: 0x04002C0B RID: 11275
		public float pressTime;

		// Token: 0x04002C0C RID: 11276
		public bool functionKey;

		// Token: 0x04002C0D RID: 11277
		public bool testClick;

		// Token: 0x04002C0E RID: 11278
		public bool repeatTestClick;

		// Token: 0x04002C0F RID: 11279
		public float repeatCooldown = 2f;

		// Token: 0x04002C10 RID: 11280
		public Renderer ButtonRenderer;

		// Token: 0x04002C11 RID: 11281
		public ButtonColorSettings ButtonColorSettings;

		// Token: 0x04002C12 RID: 11282
		private float lastTestClick;

		// Token: 0x04002C13 RID: 11283
		private MaterialPropertyBlock propBlock;
	}
}
