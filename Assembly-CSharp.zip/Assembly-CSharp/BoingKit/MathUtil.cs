﻿using System;
using UnityEngine;

namespace BoingKit
{
	// Token: 0x0200082C RID: 2092
	public class MathUtil
	{
		// Token: 0x060032BD RID: 12989 RVA: 0x000F3A60 File Offset: 0x000F1C60
		public static float AsinSafe(float x)
		{
			return Mathf.Asin(Mathf.Clamp(x, -1f, 1f));
		}

		// Token: 0x060032BE RID: 12990 RVA: 0x000F3A77 File Offset: 0x000F1C77
		public static float AcosSafe(float x)
		{
			return Mathf.Acos(Mathf.Clamp(x, -1f, 1f));
		}

		// Token: 0x060032BF RID: 12991 RVA: 0x000FEB10 File Offset: 0x000FCD10
		public static float InvSafe(float x)
		{
			return 1f / Mathf.Max(MathUtil.Epsilon, x);
		}

		// Token: 0x060032C0 RID: 12992 RVA: 0x000FEB24 File Offset: 0x000FCD24
		public static float PointLineDist(Vector2 point, Vector2 linePos, Vector2 lineDir)
		{
			Vector2 vector = point - linePos;
			return (vector - Vector2.Dot(vector, lineDir) * lineDir).magnitude;
		}

		// Token: 0x060032C1 RID: 12993 RVA: 0x000FEB54 File Offset: 0x000FCD54
		public static float PointSegmentDist(Vector2 point, Vector2 segmentPosA, Vector2 segmentPosB)
		{
			Vector2 a = segmentPosB - segmentPosA;
			float num = 1f / a.magnitude;
			Vector2 rhs = a * num;
			float value = Vector2.Dot(point - segmentPosA, rhs) * num;
			return (segmentPosA + Mathf.Clamp(value, 0f, 1f) * a - point).magnitude;
		}

		// Token: 0x060032C2 RID: 12994 RVA: 0x000FEBBC File Offset: 0x000FCDBC
		public static float Seek(float current, float target, float maxDelta)
		{
			float num = target - current;
			num = Mathf.Sign(num) * Mathf.Min(maxDelta, Mathf.Abs(num));
			return current + num;
		}

		// Token: 0x060032C3 RID: 12995 RVA: 0x000FEBE4 File Offset: 0x000FCDE4
		public static Vector2 Seek(Vector2 current, Vector2 target, float maxDelta)
		{
			Vector2 b = target - current;
			float magnitude = b.magnitude;
			if (magnitude < MathUtil.Epsilon)
			{
				return target;
			}
			b = Mathf.Min(maxDelta, magnitude) * b.normalized;
			return current + b;
		}

		// Token: 0x060032C4 RID: 12996 RVA: 0x000FEC26 File Offset: 0x000FCE26
		public static float Remainder(float a, float b)
		{
			return a - a / b * b;
		}

		// Token: 0x060032C5 RID: 12997 RVA: 0x000FEC26 File Offset: 0x000FCE26
		public static int Remainder(int a, int b)
		{
			return a - a / b * b;
		}

		// Token: 0x060032C6 RID: 12998 RVA: 0x000FEC2F File Offset: 0x000FCE2F
		public static float Modulo(float a, float b)
		{
			return Mathf.Repeat(a, b);
		}

		// Token: 0x060032C7 RID: 12999 RVA: 0x000FEC38 File Offset: 0x000FCE38
		public static int Modulo(int a, int b)
		{
			int num = a % b;
			if (num < 0)
			{
				return num + b;
			}
			return num;
		}

		// Token: 0x04003535 RID: 13621
		public static readonly float Pi = 3.1415927f;

		// Token: 0x04003536 RID: 13622
		public static readonly float TwoPi = 6.2831855f;

		// Token: 0x04003537 RID: 13623
		public static readonly float HalfPi = 1.5707964f;

		// Token: 0x04003538 RID: 13624
		public static readonly float QuaterPi = 0.7853982f;

		// Token: 0x04003539 RID: 13625
		public static readonly float SixthPi = 0.5235988f;

		// Token: 0x0400353A RID: 13626
		public static readonly float Sqrt2 = Mathf.Sqrt(2f);

		// Token: 0x0400353B RID: 13627
		public static readonly float Sqrt2Inv = 1f / Mathf.Sqrt(2f);

		// Token: 0x0400353C RID: 13628
		public static readonly float Sqrt3 = Mathf.Sqrt(3f);

		// Token: 0x0400353D RID: 13629
		public static readonly float Sqrt3Inv = 1f / Mathf.Sqrt(3f);

		// Token: 0x0400353E RID: 13630
		public static readonly float Epsilon = 1E-06f;

		// Token: 0x0400353F RID: 13631
		public static readonly float Rad2Deg = 57.295776f;

		// Token: 0x04003540 RID: 13632
		public static readonly float Deg2Rad = 0.017453292f;
	}
}
