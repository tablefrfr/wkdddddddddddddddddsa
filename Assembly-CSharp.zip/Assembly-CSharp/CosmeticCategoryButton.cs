﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x020002D1 RID: 721
public class CosmeticCategoryButton : CosmeticButton
{
	// Token: 0x060010A5 RID: 4261 RVA: 0x000580E0 File Offset: 0x000562E0
	public void SetIcon(Sprite sprite)
	{
		this.equippedLeftIcon.enabled = false;
		this.equippedRightIcon.enabled = false;
		this.equippedIcon.enabled = (sprite != null);
		this.equippedIcon.sprite = sprite;
	}

	// Token: 0x060010A6 RID: 4262 RVA: 0x00058118 File Offset: 0x00056318
	public void SetDualIcon(Sprite leftSprite, Sprite rightSprite)
	{
		this.equippedLeftIcon.enabled = (leftSprite != null);
		this.equippedRightIcon.enabled = (rightSprite != null);
		this.equippedIcon.enabled = false;
		this.equippedLeftIcon.sprite = leftSprite;
		this.equippedRightIcon.sprite = rightSprite;
	}

	// Token: 0x040012CD RID: 4813
	[SerializeField]
	private Image equippedIcon;

	// Token: 0x040012CE RID: 4814
	[SerializeField]
	private Image equippedLeftIcon;

	// Token: 0x040012CF RID: 4815
	[SerializeField]
	private Image equippedRightIcon;
}
