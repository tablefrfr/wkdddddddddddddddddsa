﻿using System;
using GorillaLocomotion.Swimming;
using GorillaTag;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x02000235 RID: 565
public class BalloonHoldable : TransferrableObject, IFXContext
{
	// Token: 0x06000BF0 RID: 3056 RVA: 0x0003FAB2 File Offset: 0x0003DCB2
	public override void OnSpawn()
	{
		base.OnSpawn();
		this.balloonDynamics = base.GetComponent<ITetheredObjectBehavior>();
		this.mesh = base.GetComponent<Renderer>();
		this.lineRenderer = base.GetComponent<LineRenderer>();
		this.itemState = (TransferrableObject.ItemStates)0;
		this.rb = base.GetComponent<Rigidbody>();
	}

	// Token: 0x06000BF1 RID: 3057 RVA: 0x0003FAF1 File Offset: 0x0003DCF1
	protected override void Start()
	{
		base.Start();
		this.EnableDynamics(false, false);
	}

	// Token: 0x06000BF2 RID: 3058 RVA: 0x0003FB04 File Offset: 0x0003DD04
	public override void OnEnable()
	{
		base.OnEnable();
		this.EnableDynamics(false, false);
		this.mesh.enabled = true;
		this.lineRenderer.enabled = false;
		if (NetworkSystem.Instance.InRoom)
		{
			if (this.worldShareableInstance != null)
			{
				return;
			}
			base.SpawnTransferableObjectViews();
		}
		if (base.InHand())
		{
			this.Grab();
			return;
		}
		if (base.Dropped())
		{
			this.Release();
		}
	}

	// Token: 0x06000BF3 RID: 3059 RVA: 0x0003FB75 File Offset: 0x0003DD75
	public override void OnJoinedRoom()
	{
		base.OnJoinedRoom();
		if (this.worldShareableInstance != null)
		{
			return;
		}
		base.SpawnTransferableObjectViews();
	}

	// Token: 0x06000BF4 RID: 3060 RVA: 0x0003FB92 File Offset: 0x0003DD92
	private bool ShouldSimulate()
	{
		return (base.Dropped() || base.InHand()) && this.balloonState == BalloonHoldable.BalloonStates.Normal;
	}

	// Token: 0x06000BF5 RID: 3061 RVA: 0x0003FBAF File Offset: 0x0003DDAF
	public override void OnDisable()
	{
		base.OnDisable();
		this.lineRenderer.enabled = false;
		this.EnableDynamics(false, false);
	}

	// Token: 0x06000BF6 RID: 3062 RVA: 0x0003FBCB File Offset: 0x0003DDCB
	public override void PreDisable()
	{
		this.originalOwner = null;
		base.PreDisable();
	}

	// Token: 0x06000BF7 RID: 3063 RVA: 0x0003FBDA File Offset: 0x0003DDDA
	public override void ResetToDefaultState()
	{
		base.ResetToDefaultState();
		this.balloonState = BalloonHoldable.BalloonStates.Normal;
		base.transform.localScale = Vector3.one;
	}

	// Token: 0x06000BF8 RID: 3064 RVA: 0x0003FBFC File Offset: 0x0003DDFC
	protected override void OnWorldShareableItemSpawn()
	{
		WorldShareableItem worldShareableInstance = this.worldShareableInstance;
		if (worldShareableInstance != null)
		{
			worldShareableInstance.rpcCallBack = new Action(this.PopBalloonRemote);
			worldShareableInstance.onOwnerChangeCb = new WorldShareableItem.OnOwnerChangeDelegate(this.OnOwnerChangeCb);
			worldShareableInstance.EnableRemoteSync = this.ShouldSimulate();
		}
		this.originalOwner = worldShareableInstance.Target.owner;
	}

	// Token: 0x06000BF9 RID: 3065 RVA: 0x0003FC5C File Offset: 0x0003DE5C
	public override void ResetToHome()
	{
		if (base.IsLocalObject() && this.worldShareableInstance != null && !this.worldShareableInstance.guard.isTrulyMine)
		{
			PhotonView photonView = PhotonView.Get(this.worldShareableInstance);
			if (photonView != null)
			{
				photonView.RPC("RPCWorldShareable", RpcTarget.Others, Array.Empty<object>());
			}
			this.worldShareableInstance.guard.RequestOwnershipImmediatelyWithGuaranteedAuthority();
		}
		this.PopBalloon();
		this.balloonState = BalloonHoldable.BalloonStates.WaitForReDock;
		base.ResetToHome();
	}

	// Token: 0x06000BFA RID: 3066 RVA: 0x0003FCDA File Offset: 0x0003DEDA
	protected override void PlayDestroyedOrDisabledEffect()
	{
		base.PlayDestroyedOrDisabledEffect();
		this.PlayPopBalloonFX();
	}

	// Token: 0x06000BFB RID: 3067 RVA: 0x0003FCE8 File Offset: 0x0003DEE8
	protected override void OnItemDestroyedOrDisabled()
	{
		this.PlayPopBalloonFX();
		if (this.balloonDynamics != null)
		{
			this.balloonDynamics.ReParent();
		}
		base.transform.parent = base.DefaultAnchor();
		base.OnItemDestroyedOrDisabled();
	}

	// Token: 0x06000BFC RID: 3068 RVA: 0x0003FD1C File Offset: 0x0003DF1C
	private void PlayPopBalloonFX()
	{
		FXSystem.PlayFXForRig(FXType.BalloonPop, this, default(PhotonMessageInfo));
	}

	// Token: 0x06000BFD RID: 3069 RVA: 0x0003FD3C File Offset: 0x0003DF3C
	private void EnableDynamics(bool enable, bool forceKinematicOn = false)
	{
		bool kinematic = false;
		if (forceKinematicOn)
		{
			kinematic = true;
		}
		else if (NetworkSystem.Instance.InRoom && this.worldShareableInstance != null)
		{
			PhotonView photonView = PhotonView.Get(this.worldShareableInstance.gameObject);
			if (photonView != null && !photonView.IsMine)
			{
				kinematic = true;
			}
		}
		if (this.balloonDynamics != null)
		{
			this.balloonDynamics.EnableDynamics(enable, kinematic);
		}
	}

	// Token: 0x06000BFE RID: 3070 RVA: 0x0003FDA8 File Offset: 0x0003DFA8
	private void PopBalloon()
	{
		this.PlayPopBalloonFX();
		this.EnableDynamics(false, false);
		this.mesh.enabled = false;
		this.lineRenderer.enabled = false;
		if (this.gripInteractor != null)
		{
			this.gripInteractor.gameObject.SetActive(false);
		}
		if ((object.Equals(this.originalOwner, PhotonNetwork.LocalPlayer) || !NetworkSystem.Instance.InRoom) && NetworkSystem.Instance.InRoom && this.worldShareableInstance != null && !this.worldShareableInstance.guard.isTrulyMine)
		{
			this.worldShareableInstance.guard.RequestOwnershipImmediatelyWithGuaranteedAuthority();
		}
		if (this.balloonDynamics != null)
		{
			this.balloonDynamics.ReParent();
			this.EnableDynamics(false, false);
		}
		if (this.IsMyItem())
		{
			if (base.InLeftHand())
			{
				EquipmentInteractor.instance.ReleaseLeftHand();
			}
			if (base.InRightHand())
			{
				EquipmentInteractor.instance.ReleaseRightHand();
			}
		}
	}

	// Token: 0x06000BFF RID: 3071 RVA: 0x0003FE9F File Offset: 0x0003E09F
	public void PopBalloonRemote()
	{
		if (this.ShouldSimulate())
		{
			this.balloonState = BalloonHoldable.BalloonStates.Pop;
		}
	}

	// Token: 0x06000C00 RID: 3072 RVA: 0x00003051 File Offset: 0x00001251
	public void OnOwnerChangeCb(Player newOwner, Player prevOwner)
	{
	}

	// Token: 0x06000C01 RID: 3073 RVA: 0x0003FEB0 File Offset: 0x0003E0B0
	public override void OnOwnershipTransferred(Player newOwner, Player prevOwner)
	{
		base.OnOwnershipTransferred(newOwner, prevOwner);
		if (object.Equals(prevOwner, PhotonNetwork.LocalPlayer) && newOwner == null)
		{
			return;
		}
		if (!object.Equals(newOwner, PhotonNetwork.LocalPlayer))
		{
			this.EnableDynamics(false, true);
			return;
		}
		if (this.ShouldSimulate() && this.balloonDynamics != null)
		{
			this.balloonDynamics.EnableDynamics(true, false);
		}
		if (!this.rb)
		{
			return;
		}
		this.rb.AddForceAtPosition(this.forceAppliedAsRemote, this.collisionPtAsRemote, ForceMode.VelocityChange);
		this.forceAppliedAsRemote = Vector3.zero;
		this.collisionPtAsRemote = Vector3.zero;
	}

	// Token: 0x06000C02 RID: 3074 RVA: 0x0003FF48 File Offset: 0x0003E148
	private void OwnerPopBalloon()
	{
		if (this.worldShareableInstance != null)
		{
			PhotonView photonView = PhotonView.Get(this.worldShareableInstance);
			if (photonView != null)
			{
				photonView.RPC("RPCWorldShareable", RpcTarget.Others, Array.Empty<object>());
			}
		}
		this.balloonState = BalloonHoldable.BalloonStates.Pop;
	}

	// Token: 0x06000C03 RID: 3075 RVA: 0x0003FF90 File Offset: 0x0003E190
	private void RunLocalPopSM()
	{
		switch (this.balloonState)
		{
		case BalloonHoldable.BalloonStates.Normal:
			break;
		case BalloonHoldable.BalloonStates.Pop:
			this.timer = Time.time;
			this.PopBalloon();
			this.balloonState = BalloonHoldable.BalloonStates.WaitForOwnershipTransfer;
			this.lastOwnershipRequest = Time.time;
			return;
		case BalloonHoldable.BalloonStates.Waiting:
			if (Time.time - this.timer >= this.poppedTimerLength)
			{
				this.timer = Time.time;
				this.mesh.enabled = true;
				this.localScale = new Vector3(this.beginScale, this.beginScale, this.beginScale);
				base.transform.localScale = this.localScale;
				this.balloonInflatSource.Play();
				this.balloonState = BalloonHoldable.BalloonStates.Refilling;
				return;
			}
			break;
		case BalloonHoldable.BalloonStates.WaitForOwnershipTransfer:
			if (!NetworkSystem.Instance.InRoom)
			{
				this.balloonState = BalloonHoldable.BalloonStates.WaitForReDock;
				base.ReDock();
				return;
			}
			if (this.worldShareableInstance != null)
			{
				PhotonView photonView = PhotonView.Get(this.worldShareableInstance.gameObject);
				if (photonView != null && photonView.Owner == this.originalOwner)
				{
					this.balloonState = BalloonHoldable.BalloonStates.WaitForReDock;
					base.ReDock();
				}
				if (base.IsLocalObject() && this.lastOwnershipRequest + 5f < Time.time)
				{
					this.worldShareableInstance.guard.RequestOwnershipImmediatelyWithGuaranteedAuthority();
					this.lastOwnershipRequest = Time.time;
					return;
				}
			}
			break;
		case BalloonHoldable.BalloonStates.WaitForReDock:
			if (base.Attached())
			{
				base.ReDock();
				this.balloonState = BalloonHoldable.BalloonStates.Waiting;
				return;
			}
			break;
		case BalloonHoldable.BalloonStates.Refilling:
		{
			float num = Time.time - this.timer;
			if (num >= this.scaleTimerLength)
			{
				this.balloonState = BalloonHoldable.BalloonStates.Normal;
				if (this.gripInteractor != null)
				{
					this.gripInteractor.gameObject.SetActive(true);
				}
			}
			num = Mathf.Clamp01(num / this.scaleTimerLength);
			float num2 = Mathf.Lerp(this.beginScale, 1f, num);
			this.localScale = new Vector3(num2, num2, num2);
			base.transform.localScale = this.localScale;
			return;
		}
		case BalloonHoldable.BalloonStates.Returning:
			if (this.balloonDynamics.ReturnStep())
			{
				this.balloonState = BalloonHoldable.BalloonStates.Normal;
				base.ReDock();
			}
			break;
		default:
			return;
		}
	}

	// Token: 0x06000C04 RID: 3076 RVA: 0x000401A8 File Offset: 0x0003E3A8
	protected override void LateUpdateShared()
	{
		base.LateUpdateShared();
		if (this.previousState != this.currentState || Time.frameCount == this.enabledOnFrame)
		{
			if (base.InHand())
			{
				this.Grab();
			}
			else if (base.Dropped())
			{
				this.Release();
			}
			else if (base.OnShoulder())
			{
				if (this.balloonDynamics != null && this.balloonDynamics.IsEnabled())
				{
					this.EnableDynamics(false, false);
				}
				this.lineRenderer.enabled = false;
			}
		}
		if (base.InHand())
		{
			float d = (this.targetRig != null) ? this.targetRig.transform.localScale.x : 1f;
			base.transform.localScale = Vector3.one * d;
		}
		if (this.worldShareableInstance != null && !this.worldShareableInstance.guard.isMine)
		{
			this.worldShareableInstance.EnableRemoteSync = this.ShouldSimulate();
		}
		if (this.balloonState != BalloonHoldable.BalloonStates.Normal)
		{
			this.RunLocalPopSM();
		}
	}

	// Token: 0x06000C05 RID: 3077 RVA: 0x000402A9 File Offset: 0x0003E4A9
	protected override void LateUpdateReplicated()
	{
		base.LateUpdateReplicated();
	}

	// Token: 0x06000C06 RID: 3078 RVA: 0x000402B4 File Offset: 0x0003E4B4
	private void Grab()
	{
		if (this.balloonDynamics == null)
		{
			return;
		}
		float num = (this.targetRig != null) ? this.targetRig.transform.localScale.x : 1f;
		base.transform.localScale = Vector3.one * num;
		this.EnableDynamics(true, false);
		this.balloonDynamics.EnableDistanceConstraints(true, num);
		this.lineRenderer.enabled = true;
	}

	// Token: 0x06000C07 RID: 3079 RVA: 0x0004032C File Offset: 0x0003E52C
	private void Release()
	{
		if (this.disableRelease)
		{
			this.balloonState = BalloonHoldable.BalloonStates.Returning;
			return;
		}
		if (this.balloonDynamics == null)
		{
			return;
		}
		float num = (this.targetRig != null) ? this.targetRig.transform.localScale.x : 1f;
		base.transform.localScale = Vector3.one * num;
		this.EnableDynamics(true, false);
		this.balloonDynamics.EnableDistanceConstraints(false, num);
		this.lineRenderer.enabled = false;
	}

	// Token: 0x06000C08 RID: 3080 RVA: 0x000403B4 File Offset: 0x0003E5B4
	public void OnTriggerEnter(Collider other)
	{
		if (!this.ShouldSimulate())
		{
			return;
		}
		Vector3 zero = Vector3.zero;
		Vector3 zero2 = Vector3.zero;
		bool flag = false;
		if (this.balloonDynamics != null)
		{
			this.balloonDynamics.TriggerEnter(other, ref zero, ref zero2, ref flag);
		}
		if (!NetworkSystem.Instance.InRoom)
		{
			return;
		}
		if (this.worldShareableInstance == null)
		{
			return;
		}
		if (flag)
		{
			RequestableOwnershipGuard component = PhotonView.Get(this.worldShareableInstance.gameObject).GetComponent<RequestableOwnershipGuard>();
			if (!component.isTrulyMine)
			{
				if (zero.magnitude > this.forceAppliedAsRemote.magnitude)
				{
					this.forceAppliedAsRemote = zero;
					this.collisionPtAsRemote = zero2;
				}
				component.RequestOwnershipImmediately(delegate
				{
				});
			}
		}
	}

	// Token: 0x06000C09 RID: 3081 RVA: 0x00040478 File Offset: 0x0003E678
	public void OnCollisionEnter(Collision collision)
	{
		if (!this.ShouldSimulate() || this.disableCollisionHandling)
		{
			return;
		}
		this.balloonBopSource.Play();
		if (!collision.gameObject.IsOnLayer(UnityLayer.GorillaThrowable))
		{
			return;
		}
		if (!NetworkSystem.Instance.InRoom)
		{
			this.OwnerPopBalloon();
			return;
		}
		if (this.worldShareableInstance == null)
		{
			return;
		}
		if (PhotonView.Get(this.worldShareableInstance.gameObject).IsMine)
		{
			this.OwnerPopBalloon();
		}
	}

	// Token: 0x1700017F RID: 383
	// (get) Token: 0x06000C0A RID: 3082 RVA: 0x000404F0 File Offset: 0x0003E6F0
	FXSystemSettings IFXContext.settings
	{
		get
		{
			return this.ownerRig.fxSettings;
		}
	}

	// Token: 0x06000C0B RID: 3083 RVA: 0x00040500 File Offset: 0x0003E700
	void IFXContext.OnPlayFX()
	{
		GameObject gameObject = ObjectPools.instance.Instantiate(this.balloonPopFXPrefab);
		gameObject.transform.SetPositionAndRotation(base.transform.position, base.transform.rotation);
		GorillaColorizableBase componentInChildren = gameObject.GetComponentInChildren<GorillaColorizableBase>();
		if (componentInChildren != null)
		{
			componentInChildren.SetColor(this.balloonPopFXColor);
		}
	}

	// Token: 0x04000D49 RID: 3401
	private ITetheredObjectBehavior balloonDynamics;

	// Token: 0x04000D4A RID: 3402
	private Renderer mesh;

	// Token: 0x04000D4B RID: 3403
	private LineRenderer lineRenderer;

	// Token: 0x04000D4C RID: 3404
	private Rigidbody rb;

	// Token: 0x04000D4D RID: 3405
	private Player originalOwner;

	// Token: 0x04000D4E RID: 3406
	public GameObject balloonPopFXPrefab;

	// Token: 0x04000D4F RID: 3407
	public Color balloonPopFXColor;

	// Token: 0x04000D50 RID: 3408
	private float timer;

	// Token: 0x04000D51 RID: 3409
	public float scaleTimerLength = 2f;

	// Token: 0x04000D52 RID: 3410
	public float poppedTimerLength = 2.5f;

	// Token: 0x04000D53 RID: 3411
	public float beginScale = 0.1f;

	// Token: 0x04000D54 RID: 3412
	public float bopSpeed = 1f;

	// Token: 0x04000D55 RID: 3413
	private Vector3 localScale;

	// Token: 0x04000D56 RID: 3414
	public AudioSource balloonBopSource;

	// Token: 0x04000D57 RID: 3415
	public AudioSource balloonInflatSource;

	// Token: 0x04000D58 RID: 3416
	private Vector3 forceAppliedAsRemote;

	// Token: 0x04000D59 RID: 3417
	private Vector3 collisionPtAsRemote;

	// Token: 0x04000D5A RID: 3418
	private WaterVolume waterVolume;

	// Token: 0x04000D5B RID: 3419
	[DebugReadout]
	private BalloonHoldable.BalloonStates balloonState;

	// Token: 0x04000D5C RID: 3420
	private float returnTimer;

	// Token: 0x04000D5D RID: 3421
	public float lastOwnershipRequest;

	// Token: 0x04000D5E RID: 3422
	[SerializeField]
	private bool disableCollisionHandling;

	// Token: 0x04000D5F RID: 3423
	[SerializeField]
	private bool disableRelease;

	// Token: 0x02000236 RID: 566
	private enum BalloonStates
	{
		// Token: 0x04000D61 RID: 3425
		Normal,
		// Token: 0x04000D62 RID: 3426
		Pop,
		// Token: 0x04000D63 RID: 3427
		Waiting,
		// Token: 0x04000D64 RID: 3428
		WaitForOwnershipTransfer,
		// Token: 0x04000D65 RID: 3429
		WaitForReDock,
		// Token: 0x04000D66 RID: 3430
		Refilling,
		// Token: 0x04000D67 RID: 3431
		Returning
	}
}
