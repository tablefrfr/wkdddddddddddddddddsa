﻿using System;
using BuildSafe;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000315 RID: 789
public class BlinkingLight : SceneBakeTask
{
	// Token: 0x060011C9 RID: 4553 RVA: 0x0005CEBC File Offset: 0x0005B0BC
	public override void OnSceneBake(Scene scene, SceneBakeMode mode)
	{
		MeshRenderer meshRenderer;
		if (base.TryGetComponent<MeshRenderer>(out meshRenderer))
		{
			meshRenderer.material = this.materialArray[BlinkingLight.gColor.NextInt(this.materialArray.Length)];
		}
	}

	// Token: 0x04001450 RID: 5200
	[SerializeField]
	private Material[] materialArray;

	// Token: 0x04001451 RID: 5201
	private static SRand gColor = new SRand("BlinkingLight");
}
