﻿using System;
using UnityEngine;

namespace BuildSafe
{
	// Token: 0x0200062F RID: 1583
	public static class SceneViewUtils
	{
		// Token: 0x06002540 RID: 9536 RVA: 0x000B7115 File Offset: 0x000B5315
		private static bool RaycastWorldSafe(Vector2 screenPos, out RaycastHit hit)
		{
			hit = default(RaycastHit);
			return false;
		}

		// Token: 0x04002805 RID: 10245
		public static readonly SceneViewUtils.FuncRaycastWorld RaycastWorld = new SceneViewUtils.FuncRaycastWorld(SceneViewUtils.RaycastWorldSafe);

		// Token: 0x02000630 RID: 1584
		// (Invoke) Token: 0x06002543 RID: 9539
		public delegate bool FuncRaycastWorld(Vector2 screenPos, out RaycastHit hit);

		// Token: 0x02000631 RID: 1585
		// (Invoke) Token: 0x06002547 RID: 9543
		public delegate GameObject FuncPickClosestGameObject(Camera cam, int layers, Vector2 position, GameObject[] ignore, GameObject[] filter, out int materialIndex);
	}
}
