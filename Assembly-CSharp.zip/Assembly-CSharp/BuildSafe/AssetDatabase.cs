﻿using System;
using System.Diagnostics;
using UnityEngine;

namespace BuildSafe
{
	// Token: 0x0200061D RID: 1565
	public static class AssetDatabase
	{
		// Token: 0x06002505 RID: 9477 RVA: 0x000B6D98 File Offset: 0x000B4F98
		public static T LoadAssetAtPath<T>(string assetPath) where T : Object
		{
			return default(T);
		}

		// Token: 0x06002506 RID: 9478 RVA: 0x000B6DAE File Offset: 0x000B4FAE
		public static T[] LoadAssetsOfType<T>() where T : Object
		{
			return Array.Empty<T>();
		}

		// Token: 0x06002507 RID: 9479 RVA: 0x000B6DB5 File Offset: 0x000B4FB5
		public static string[] FindAssetsOfType<T>() where T : Object
		{
			return Array.Empty<string>();
		}

		// Token: 0x06002508 RID: 9480 RVA: 0x000B6DBC File Offset: 0x000B4FBC
		[Conditional("UNITY_EDITOR")]
		public static void SaveToDisk(params Object[] assetsToSave)
		{
			AssetDatabase.SaveAssetsToDisk(assetsToSave, true);
		}

		// Token: 0x06002509 RID: 9481 RVA: 0x00003051 File Offset: 0x00001251
		public static void SaveAssetsToDisk(Object[] assetsToSave, bool saveProject = true)
		{
		}
	}
}
