﻿using System;
using System.Collections.Generic;
using Fusion;
using UnityEngine;

// Token: 0x02000109 RID: 265
public class FusionNetPlayer : NetPlayer
{
	// Token: 0x1700006A RID: 106
	// (get) Token: 0x060004F2 RID: 1266 RVA: 0x0001D640 File Offset: 0x0001B840
	// (set) Token: 0x060004F3 RID: 1267 RVA: 0x0001D648 File Offset: 0x0001B848
	public PlayerRef playerRef { get; private set; }

	// Token: 0x060004F4 RID: 1268 RVA: 0x0001D651 File Offset: 0x0001B851
	public FusionNetPlayer(PlayerRef playerRef)
	{
		this.playerRef = playerRef;
	}

	// Token: 0x1700006B RID: 107
	// (get) Token: 0x060004F5 RID: 1269 RVA: 0x0001D660 File Offset: 0x0001B860
	private NetworkRunner runner
	{
		get
		{
			return ((NetworkSystemFusion)NetworkSystem.Instance).runner;
		}
	}

	// Token: 0x1700006C RID: 108
	// (get) Token: 0x060004F6 RID: 1270 RVA: 0x0001D674 File Offset: 0x0001B874
	public override bool IsValid
	{
		get
		{
			return this.playerRef.IsValid;
		}
	}

	// Token: 0x1700006D RID: 109
	// (get) Token: 0x060004F7 RID: 1271 RVA: 0x0001D690 File Offset: 0x0001B890
	public override int ID
	{
		get
		{
			return this.playerRef.PlayerId;
		}
	}

	// Token: 0x1700006E RID: 110
	// (get) Token: 0x060004F8 RID: 1272 RVA: 0x0001D6AC File Offset: 0x0001B8AC
	public override string UserId
	{
		get
		{
			return NetworkSystem.Instance.GetUserID(this.playerRef.PlayerId);
		}
	}

	// Token: 0x1700006F RID: 111
	// (get) Token: 0x060004F9 RID: 1273 RVA: 0x0001D6D1 File Offset: 0x0001B8D1
	public override bool IsMaster
	{
		get
		{
			return this.runner.IsSharedModeMasterClient;
		}
	}

	// Token: 0x17000070 RID: 112
	// (get) Token: 0x060004FA RID: 1274 RVA: 0x0001D6DE File Offset: 0x0001B8DE
	public override bool IsLocal
	{
		get
		{
			return this.playerRef == this.runner.LocalPlayer;
		}
	}

	// Token: 0x17000071 RID: 113
	// (get) Token: 0x060004FB RID: 1275 RVA: 0x0001D6F6 File Offset: 0x0001B8F6
	public override bool IsNull
	{
		get
		{
			PlayerRef playerRef = this.playerRef;
			return false;
		}
	}

	// Token: 0x17000072 RID: 114
	// (get) Token: 0x060004FC RID: 1276 RVA: 0x0001D700 File Offset: 0x0001B900
	public override string NickName
	{
		get
		{
			return NetworkSystem.Instance.GetNickName(this.ID);
		}
	}

	// Token: 0x17000073 RID: 115
	// (get) Token: 0x060004FD RID: 1277 RVA: 0x0001D714 File Offset: 0x0001B914
	public override string DefaultName
	{
		get
		{
			return "gorilla" + Random.Range(0, 9999).ToString().PadLeft(4, '0');
		}
	}

	// Token: 0x17000074 RID: 116
	// (get) Token: 0x060004FE RID: 1278 RVA: 0x0001D748 File Offset: 0x0001B948
	public override bool InRoom
	{
		get
		{
			using (IEnumerator<PlayerRef> enumerator = this.runner.ActivePlayers.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current == this.playerRef)
					{
						return true;
					}
				}
			}
			return false;
		}
	}

	// Token: 0x060004FF RID: 1279 RVA: 0x0001D7A8 File Offset: 0x0001B9A8
	public override bool Equals(NetPlayer myPlayer, NetPlayer other)
	{
		return myPlayer != null && other != null && ((FusionNetPlayer)myPlayer).playerRef.Equals(((FusionNetPlayer)other).playerRef);
	}
}
