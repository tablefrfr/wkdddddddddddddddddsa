﻿using System;
using UnityEngine;

// Token: 0x020004AD RID: 1197
public abstract class BasePageHandler : MonoBehaviour
{
	// Token: 0x17000331 RID: 817
	// (get) Token: 0x06001B5B RID: 7003 RVA: 0x0008B3F8 File Offset: 0x000895F8
	// (set) Token: 0x06001B5C RID: 7004 RVA: 0x0008B400 File Offset: 0x00089600
	private protected int selectedIndex { protected get; private set; }

	// Token: 0x17000332 RID: 818
	// (get) Token: 0x06001B5D RID: 7005 RVA: 0x0008B409 File Offset: 0x00089609
	// (set) Token: 0x06001B5E RID: 7006 RVA: 0x0008B411 File Offset: 0x00089611
	private protected int currentPage { protected get; private set; }

	// Token: 0x17000333 RID: 819
	// (get) Token: 0x06001B5F RID: 7007 RVA: 0x0008B41A File Offset: 0x0008961A
	// (set) Token: 0x06001B60 RID: 7008 RVA: 0x0008B422 File Offset: 0x00089622
	private protected int pages { protected get; private set; }

	// Token: 0x17000334 RID: 820
	// (get) Token: 0x06001B61 RID: 7009 RVA: 0x0008B42B File Offset: 0x0008962B
	// (set) Token: 0x06001B62 RID: 7010 RVA: 0x0008B433 File Offset: 0x00089633
	private protected int maxEntires { protected get; private set; }

	// Token: 0x17000335 RID: 821
	// (get) Token: 0x06001B63 RID: 7011
	protected abstract int pageSize { get; }

	// Token: 0x17000336 RID: 822
	// (get) Token: 0x06001B64 RID: 7012
	protected abstract int entriesCount { get; }

	// Token: 0x06001B65 RID: 7013 RVA: 0x0008B43C File Offset: 0x0008963C
	protected virtual void Start()
	{
		Debug.Log("base page handler " + this.entriesCount.ToString() + " " + this.pageSize.ToString());
		this.pages = this.entriesCount / this.pageSize + 1;
		this.maxEntires = this.pages * this.pageSize;
	}

	// Token: 0x06001B66 RID: 7014 RVA: 0x0008B4A4 File Offset: 0x000896A4
	public void SelectEntryOnPage(int entryIndex)
	{
		int num = entryIndex + this.pageSize * this.currentPage;
		if (num > this.entriesCount)
		{
			return;
		}
		this.selectedIndex = num;
		this.PageEntrySelected(entryIndex, this.selectedIndex);
	}

	// Token: 0x06001B67 RID: 7015 RVA: 0x0008B4E0 File Offset: 0x000896E0
	public void SelectEntryFromIndex(int index)
	{
		this.selectedIndex = index;
		this.currentPage = this.selectedIndex / this.pageSize;
		int pageEntry = index - this.pageSize * this.currentPage;
		this.PageEntrySelected(pageEntry, index);
		this.SetPage(this.currentPage);
	}

	// Token: 0x06001B68 RID: 7016 RVA: 0x0008B52C File Offset: 0x0008972C
	public void ChangePage(bool left)
	{
		int num = left ? -1 : 1;
		this.SetPage(Mathf.Abs((this.currentPage + num) % this.pages));
	}

	// Token: 0x06001B69 RID: 7017 RVA: 0x0008B55C File Offset: 0x0008975C
	public void SetPage(int page)
	{
		if (page > this.pages)
		{
			return;
		}
		this.currentPage = page;
		int num = this.pageSize * page;
		this.ShowPage(this.currentPage, num, Mathf.Min(num + this.pageSize, this.entriesCount));
	}

	// Token: 0x06001B6A RID: 7018
	protected abstract void ShowPage(int selectedPage, int startIndex, int endIndex);

	// Token: 0x06001B6B RID: 7019
	protected abstract void PageEntrySelected(int pageEntry, int selectionIndex);
}
