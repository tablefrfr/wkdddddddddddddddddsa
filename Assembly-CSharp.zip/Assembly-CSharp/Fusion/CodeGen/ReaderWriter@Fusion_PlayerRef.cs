﻿using System;
using System.Runtime.CompilerServices;

namespace Fusion.CodeGen
{
	// Token: 0x0200084A RID: 2122
	internal struct ReaderWriter@Fusion_PlayerRef : IElementReaderWriter<PlayerRef>
	{
		// Token: 0x0600332D RID: 13101 RVA: 0x0010052C File Offset: 0x000FE72C
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public unsafe PlayerRef Read(byte* data, int index)
		{
			return *(PlayerRef*)(data + index * 4);
		}

		// Token: 0x0600332E RID: 13102 RVA: 0x0010053C File Offset: 0x000FE73C
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public unsafe ref PlayerRef ReadRef(byte* data, int index)
		{
			return ref *(PlayerRef*)(data + index * 4);
		}

		// Token: 0x0600332F RID: 13103 RVA: 0x00100547 File Offset: 0x000FE747
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public unsafe void Write(byte* data, int index, PlayerRef val)
		{
			*(PlayerRef*)(data + index * 4) = val;
		}

		// Token: 0x06003330 RID: 13104 RVA: 0x0003FA0C File Offset: 0x0003DC0C
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public int GetElementWordCount()
		{
			return 1;
		}

		// Token: 0x06003331 RID: 13105 RVA: 0x00100558 File Offset: 0x000FE758
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public static IElementReaderWriter<PlayerRef> GetInstance()
		{
			if (ReaderWriter@Fusion_PlayerRef.Instance == null)
			{
				ReaderWriter@Fusion_PlayerRef.Instance = default(ReaderWriter@Fusion_PlayerRef);
			}
			return ReaderWriter@Fusion_PlayerRef.Instance;
		}

		// Token: 0x04003654 RID: 13908
		public static IElementReaderWriter<PlayerRef> Instance;
	}
}
