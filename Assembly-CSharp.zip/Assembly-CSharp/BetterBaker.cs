﻿using System;
using UnityEngine;

// Token: 0x020004AE RID: 1198
public class BetterBaker : MonoBehaviour
{
	// Token: 0x04001F48 RID: 8008
	public string bakeryLightmapDirectory;

	// Token: 0x04001F49 RID: 8009
	public string dayNightLightmapsDirectory;

	// Token: 0x04001F4A RID: 8010
	public GameObject[] allLights;

	// Token: 0x020004AF RID: 1199
	public struct LightMapMap
	{
		// Token: 0x04001F4B RID: 8011
		public string timeOfDayName;

		// Token: 0x04001F4C RID: 8012
		public GameObject lightObject;
	}
}
