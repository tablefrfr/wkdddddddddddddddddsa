﻿using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x02000345 RID: 837
public class FlockingManager : MonoBehaviourPunCallbacks, IPunObservable
{
	// Token: 0x060012C2 RID: 4802 RVA: 0x00063E94 File Offset: 0x00062094
	private void Awake()
	{
		foreach (GameObject gameObject in this.fishAreaContainer)
		{
			Flocking[] componentsInChildren = gameObject.GetComponentsInChildren<Flocking>(false);
			FlockingManager.FishArea fishArea = new FlockingManager.FishArea();
			fishArea.id = gameObject.name;
			fishArea.colliders = gameObject.GetComponentsInChildren<BoxCollider>();
			fishArea.colliderCenter = fishArea.colliders[0].bounds.center;
			fishArea.fishList.AddRange(componentsInChildren);
			fishArea.zoneBasedObject = gameObject.GetComponent<ZoneBasedObject>();
			this.areaToWaypointDict[fishArea.id] = Vector3.zero;
			Flocking[] array = componentsInChildren;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].FishArea = fishArea;
			}
			this.fishAreaList.Add(fishArea);
			this.allFish.AddRange(fishArea.fishList);
			SlingshotProjectileHitNotifier component = gameObject.GetComponent<SlingshotProjectileHitNotifier>();
			if (component != null)
			{
				component.OnProjectileTriggerEnter += this.ProjectileHitReceiver;
				component.OnProjectileTriggerExit += this.ProjectileHitExit;
			}
			else
			{
				Debug.LogError("Needs SlingshotProjectileHitNotifier added to each fish area");
			}
		}
	}

	// Token: 0x060012C3 RID: 4803 RVA: 0x00063FE4 File Offset: 0x000621E4
	private void OnDestroy()
	{
		this.fishAreaList.Clear();
		this.areaToWaypointDict.Clear();
		this.allFish.Clear();
		foreach (GameObject gameObject in this.fishAreaContainer)
		{
			SlingshotProjectileHitNotifier component = gameObject.GetComponent<SlingshotProjectileHitNotifier>();
			if (component != null)
			{
				component.OnProjectileTriggerExit -= this.ProjectileHitExit;
				component.OnProjectileTriggerEnter -= this.ProjectileHitReceiver;
			}
		}
	}

	// Token: 0x060012C4 RID: 4804 RVA: 0x00064084 File Offset: 0x00062284
	private void Update()
	{
		if (Random.Range(0, 10000) < 50)
		{
			foreach (FlockingManager.FishArea fishArea in this.fishAreaList)
			{
				if (fishArea.zoneBasedObject != null)
				{
					fishArea.zoneBasedObject.gameObject.SetActive(fishArea.zoneBasedObject.IsLocalPlayerInZone());
				}
				fishArea.nextWaypoint = this.GetRandomPointInsideCollider(fishArea);
				this.areaToWaypointDict[fishArea.id] = fishArea.nextWaypoint;
				Debug.DrawLine(fishArea.nextWaypoint, Vector3.forward * 5f, Color.magenta);
			}
		}
	}

	// Token: 0x060012C5 RID: 4805 RVA: 0x00064150 File Offset: 0x00062350
	public Vector3 GetRandomPointInsideCollider(FlockingManager.FishArea fishArea)
	{
		int num = Random.Range(0, fishArea.colliders.Length);
		BoxCollider boxCollider = fishArea.colliders[num];
		Vector3 vector = boxCollider.size / 2f;
		Vector3 position = new Vector3(Random.Range(-vector.x, vector.x), Random.Range(-vector.y, vector.y), Random.Range(-vector.z, vector.z));
		return boxCollider.transform.TransformPoint(position);
	}

	// Token: 0x060012C6 RID: 4806 RVA: 0x000641D0 File Offset: 0x000623D0
	public bool IsInside(Vector3 point, FlockingManager.FishArea fish)
	{
		foreach (BoxCollider boxCollider in fish.colliders)
		{
			Vector3 center = boxCollider.center;
			Vector3 vector = boxCollider.transform.InverseTransformPoint(point);
			vector -= center;
			Vector3 size = boxCollider.size;
			if (Mathf.Abs(vector.x) < size.x / 2f && Mathf.Abs(vector.y) < size.y / 2f && Mathf.Abs(vector.z) < size.z / 2f)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x060012C7 RID: 4807 RVA: 0x0006426C File Offset: 0x0006246C
	public Vector3 RestrictPointToArea(Vector3 point, FlockingManager.FishArea fish)
	{
		Vector3 result = default(Vector3);
		float num = float.MaxValue;
		foreach (BoxCollider boxCollider in fish.colliders)
		{
			Vector3 center = boxCollider.center;
			Vector3 vector = boxCollider.transform.InverseTransformPoint(point);
			Vector3 vector2 = vector - center;
			Vector3 size = boxCollider.size;
			float num2 = size.x / 2f;
			float num3 = size.y / 2f;
			float num4 = size.z / 2f;
			if (Mathf.Abs(vector2.x) < num2 && Mathf.Abs(vector2.y) < num3 && Mathf.Abs(vector2.z) < num4)
			{
				return point;
			}
			Vector3 vector3 = new Vector3(center.x - num2, center.y - num3, center.z - num4);
			Vector3 vector4 = new Vector3(center.x + num2, center.y + num3, center.z + num4);
			Vector3 vector5 = new Vector3(Mathf.Clamp(vector.x, vector3.x, vector4.x), Mathf.Clamp(vector.y, vector3.y, vector4.y), Mathf.Clamp(vector.z, vector3.z, vector4.z));
			float num5 = Vector3.Distance(vector, vector5);
			if (num5 < num)
			{
				num = num5;
				if (num5 > 1f)
				{
					Vector3 a = Vector3.Normalize(vector - vector5);
					result = boxCollider.transform.TransformPoint(vector5 + a * 1f);
				}
				else
				{
					result = point;
				}
			}
		}
		return result;
	}

	// Token: 0x060012C8 RID: 4808 RVA: 0x0006441C File Offset: 0x0006261C
	private void ProjectileHitReceiver(SlingshotProjectile projectile, Collider collider)
	{
		bool arg = projectile.CompareTag(this.foodProjectileTag);
		UnityAction<SlingshotProjectile, bool> unityAction = this.onFoodDetected;
		if (unityAction == null)
		{
			return;
		}
		unityAction(projectile, arg);
	}

	// Token: 0x060012C9 RID: 4809 RVA: 0x00064448 File Offset: 0x00062648
	private void ProjectileHitExit(SlingshotProjectile projectile, Collider collider1)
	{
		UnityAction unityAction = this.onFoodDestroyed;
		if (unityAction == null)
		{
			return;
		}
		unityAction();
	}

	// Token: 0x060012CA RID: 4810 RVA: 0x0006445C File Offset: 0x0006265C
	public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
	}

	// Token: 0x060012CB RID: 4811 RVA: 0x00064469 File Offset: 0x00062669
	public static void RegisterAvoidPoint(GameObject obj)
	{
		FlockingManager.avoidPoints.Add(obj);
	}

	// Token: 0x060012CC RID: 4812 RVA: 0x00064476 File Offset: 0x00062676
	public static void UnregisterAvoidPoint(GameObject obj)
	{
		FlockingManager.avoidPoints.Remove(obj);
	}

	// Token: 0x040015E1 RID: 5601
	public List<GameObject> fishAreaContainer;

	// Token: 0x040015E2 RID: 5602
	public string foodProjectileTag = "WaterBalloonProjectile";

	// Token: 0x040015E3 RID: 5603
	private Dictionary<string, Vector3> areaToWaypointDict = new Dictionary<string, Vector3>();

	// Token: 0x040015E4 RID: 5604
	private List<FlockingManager.FishArea> fishAreaList = new List<FlockingManager.FishArea>();

	// Token: 0x040015E5 RID: 5605
	private List<Flocking> allFish = new List<Flocking>();

	// Token: 0x040015E6 RID: 5606
	public UnityAction<SlingshotProjectile, bool> onFoodDetected;

	// Token: 0x040015E7 RID: 5607
	public UnityAction onFoodDestroyed;

	// Token: 0x040015E8 RID: 5608
	private bool hasBeenSerialized;

	// Token: 0x040015E9 RID: 5609
	public static readonly List<GameObject> avoidPoints = new List<GameObject>();

	// Token: 0x02000346 RID: 838
	public class FishArea
	{
		// Token: 0x040015EA RID: 5610
		public string id;

		// Token: 0x040015EB RID: 5611
		public List<Flocking> fishList = new List<Flocking>();

		// Token: 0x040015EC RID: 5612
		public Vector3 colliderCenter;

		// Token: 0x040015ED RID: 5613
		public BoxCollider[] colliders;

		// Token: 0x040015EE RID: 5614
		public Vector3 nextWaypoint = Vector3.zero;

		// Token: 0x040015EF RID: 5615
		public ZoneBasedObject zoneBasedObject;
	}
}
