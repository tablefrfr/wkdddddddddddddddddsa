﻿using System;

// Token: 0x02000478 RID: 1144
[Serializable]
public class CallLimitType<T> where T : CallLimiter
{
	// Token: 0x06001A8A RID: 6794 RVA: 0x000880DE File Offset: 0x000862DE
	public static implicit operator CallLimitType<CallLimiter>(CallLimitType<T> clt)
	{
		return new CallLimitType<CallLimiter>
		{
			Key = clt.Key,
			UseNetWorkTime = clt.UseNetWorkTime,
			CallLimitSettings = clt.CallLimitSettings
		};
	}

	// Token: 0x04001E81 RID: 7809
	public FXType Key;

	// Token: 0x04001E82 RID: 7810
	public bool UseNetWorkTime;

	// Token: 0x04001E83 RID: 7811
	public T CallLimitSettings;
}
