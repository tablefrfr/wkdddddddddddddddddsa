﻿using System;
using System.Linq;
using UnityEngine;

// Token: 0x0200050F RID: 1295
public class Firework : MonoBehaviour
{
	// Token: 0x06001D32 RID: 7474 RVA: 0x00091C56 File Offset: 0x0008FE56
	private void Launch()
	{
		if (!Application.isPlaying)
		{
			return;
		}
		if (this._controller)
		{
			this._controller.Launch(this);
		}
	}

	// Token: 0x06001D33 RID: 7475 RVA: 0x00091C7C File Offset: 0x0008FE7C
	private void OnValidate()
	{
		if (!this._controller)
		{
			this._controller = base.GetComponentInParent<FireworksController>();
		}
		if (!this._controller)
		{
			return;
		}
		Firework[] array = this._controller.fireworks;
		if (array.Contains(this))
		{
			return;
		}
		array = (from x in array.Concat(new Firework[]
		{
			this
		})
		where x != null
		select x).ToArray<Firework>();
		this._controller.fireworks = array;
	}

	// Token: 0x06001D34 RID: 7476 RVA: 0x00091D0C File Offset: 0x0008FF0C
	private void OnDrawGizmos()
	{
		if (!this._controller)
		{
			return;
		}
		this._controller.RenderGizmo(this, Color.cyan);
	}

	// Token: 0x06001D35 RID: 7477 RVA: 0x00091D2D File Offset: 0x0008FF2D
	private void OnDrawGizmosSelected()
	{
		if (!this._controller)
		{
			return;
		}
		this._controller.RenderGizmo(this, Color.yellow);
	}

	// Token: 0x04002034 RID: 8244
	[SerializeField]
	private FireworksController _controller;

	// Token: 0x04002035 RID: 8245
	[Space]
	public Transform origin;

	// Token: 0x04002036 RID: 8246
	public Transform target;

	// Token: 0x04002037 RID: 8247
	[Space]
	public Color colorOrigin = Color.cyan;

	// Token: 0x04002038 RID: 8248
	public Color colorTarget = Color.magenta;

	// Token: 0x04002039 RID: 8249
	[Space]
	public AudioSource sourceOrigin;

	// Token: 0x0400203A RID: 8250
	public AudioSource sourceTarget;

	// Token: 0x0400203B RID: 8251
	[Space]
	public ParticleSystem trail;

	// Token: 0x0400203C RID: 8252
	[Space]
	public ParticleSystem[] explosions;

	// Token: 0x0400203D RID: 8253
	[Space]
	public bool doTrail = true;

	// Token: 0x0400203E RID: 8254
	public bool doTrailAudio = true;

	// Token: 0x0400203F RID: 8255
	public bool doExplosion = true;
}
