﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using LitJson;
using PlayFab;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.Networking;

namespace GorillaNetworking
{
	// Token: 0x020006EA RID: 1770
	public class PlayFabTitleDataCache : MonoBehaviour
	{
		// Token: 0x170004DB RID: 1243
		// (get) Token: 0x060029CE RID: 10702 RVA: 0x000CDE00 File Offset: 0x000CC000
		// (set) Token: 0x060029CF RID: 10703 RVA: 0x000CDE07 File Offset: 0x000CC007
		public static PlayFabTitleDataCache Instance { get; private set; }

		// Token: 0x170004DC RID: 1244
		// (get) Token: 0x060029D0 RID: 10704 RVA: 0x000CDE0F File Offset: 0x000CC00F
		private static string FilePath
		{
			get
			{
				return Path.Combine(Application.persistentDataPath, "TitleDataCache.json");
			}
		}

		// Token: 0x060029D1 RID: 10705 RVA: 0x000CDE20 File Offset: 0x000CC020
		public void GetTitleData(string name, Action<string> callback, Action<PlayFabError> errorCallback)
		{
			if (this.isDataUpToDate && this.titleData.ContainsKey(name))
			{
				callback.SafeInvoke(this.titleData[name]);
				return;
			}
			PlayFabTitleDataCache.DataRequest item = new PlayFabTitleDataCache.DataRequest
			{
				Name = name,
				Callback = callback,
				ErrorCallback = errorCallback
			};
			this.requests.Add(item);
			if (this.isDataUpToDate && this.updateDataCoroutine == null)
			{
				this.UpdateData();
			}
		}

		// Token: 0x060029D2 RID: 10706 RVA: 0x000CDE93 File Offset: 0x000CC093
		private void Awake()
		{
			if (PlayFabTitleDataCache.Instance != null)
			{
				Object.Destroy(this);
				return;
			}
			PlayFabTitleDataCache.Instance = this;
		}

		// Token: 0x060029D3 RID: 10707 RVA: 0x000CDEAF File Offset: 0x000CC0AF
		private void Start()
		{
			this.UpdateData();
		}

		// Token: 0x060029D4 RID: 10708 RVA: 0x000CDEB8 File Offset: 0x000CC0B8
		public void LoadDataFromFile()
		{
			try
			{
				if (!File.Exists(PlayFabTitleDataCache.FilePath))
				{
					Debug.LogWarning("Title data file " + PlayFabTitleDataCache.FilePath + " does not exist!");
				}
				else
				{
					string json = File.ReadAllText(PlayFabTitleDataCache.FilePath);
					this.titleData = JsonMapper.ToObject<Dictionary<string, string>>(json);
				}
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("Error reading PlayFab title data from file: {0}", arg));
			}
		}

		// Token: 0x060029D5 RID: 10709 RVA: 0x000CDF28 File Offset: 0x000CC128
		private void SaveDataToFile(string filepath)
		{
			try
			{
				string contents = JsonMapper.ToJson(this.titleData);
				File.WriteAllText(filepath, contents);
			}
			catch (Exception arg)
			{
				Debug.LogError(string.Format("Error writing PlayFab title data to file: {0}", arg));
			}
		}

		// Token: 0x060029D6 RID: 10710 RVA: 0x000CDF70 File Offset: 0x000CC170
		public void UpdateData()
		{
			this.updateDataCoroutine = base.StartCoroutine(this.UpdateDataCo());
		}

		// Token: 0x060029D7 RID: 10711 RVA: 0x000CDF84 File Offset: 0x000CC184
		private IEnumerator UpdateDataCo()
		{
			this.LoadDataFromFile();
			this.LoadKey();
			Dictionary<string, string> dictionary = this.titleData;
			Dictionary<string, string> dictionary2 = new Dictionary<string, string>((dictionary != null) ? dictionary.Count : 0);
			if (this.titleData != null)
			{
				foreach (KeyValuePair<string, string> keyValuePair in this.titleData)
				{
					string text;
					string text2;
					keyValuePair.Deconstruct(out text, out text2);
					string text3 = text;
					string text4 = text2;
					if (text3 != null)
					{
						dictionary2[text3] = ((text4 != null) ? PlayFabTitleDataCache.MD5(text4) : null);
					}
				}
			}
			string s = JsonMapper.ToJson(new Dictionary<string, object>
			{
				{
					"version",
					Application.version
				},
				{
					"key",
					this.titleDataKey
				},
				{
					"data",
					dictionary2
				}
			});
			Stopwatch sw = Stopwatch.StartNew();
			Dictionary<string, JsonData> dictionary3;
			using (UnityWebRequest www = new UnityWebRequest("https://title-data.gtag-cf.com", "POST"))
			{
				byte[] bytes = new UTF8Encoding(true).GetBytes(s);
				www.uploadHandler = new UploadHandlerRaw(bytes);
				www.downloadHandler = new DownloadHandlerBuffer();
				www.SetRequestHeader("Content-Type", "application/json");
				yield return www.SendWebRequest();
				if (www.isNetworkError || www.isHttpError)
				{
					Debug.LogError("Failed to get TitleData from the server.\n" + www.error);
					this.ClearRequestWithError(null);
					yield break;
				}
				dictionary3 = JsonMapper.ToObject<Dictionary<string, JsonData>>(www.downloadHandler.text);
			}
			UnityWebRequest www = null;
			Debug.Log(string.Format("TitleData fetched: {0:N5}", sw.Elapsed.TotalSeconds));
			foreach (KeyValuePair<string, JsonData> keyValuePair2 in dictionary3)
			{
				PlayFabTitleDataCache.DataUpdate onTitleDataUpdate = this.OnTitleDataUpdate;
				if (onTitleDataUpdate != null)
				{
					onTitleDataUpdate.Invoke(keyValuePair2.Key);
				}
				if (keyValuePair2.Value == null)
				{
					this.titleData.Remove(keyValuePair2.Key);
				}
				else
				{
					this.titleData.AddOrUpdate(keyValuePair2.Key, JsonMapper.ToJson(keyValuePair2.Value));
				}
			}
			if (dictionary3.Keys.Count > 0)
			{
				this.SaveDataToFile(PlayFabTitleDataCache.FilePath);
			}
			this.requests.RemoveAll(delegate(PlayFabTitleDataCache.DataRequest request)
			{
				string data;
				if (this.titleData.TryGetValue(request.Name, out data))
				{
					request.Callback.SafeInvoke(data);
					return true;
				}
				return false;
			});
			this.ClearRequestWithError(null);
			this.isDataUpToDate = true;
			this.updateDataCoroutine = null;
			yield break;
			yield break;
		}

		// Token: 0x060029D8 RID: 10712 RVA: 0x000CDF94 File Offset: 0x000CC194
		private void LoadKey()
		{
			TextAsset textAsset = Resources.Load<TextAsset>("title_data_key");
			this.titleDataKey = textAsset.text;
		}

		// Token: 0x060029D9 RID: 10713 RVA: 0x000CDFB8 File Offset: 0x000CC1B8
		private static string MD5(string value)
		{
			HashAlgorithm hashAlgorithm = new MD5CryptoServiceProvider();
			byte[] bytes = Encoding.Default.GetBytes(value);
			byte[] array = hashAlgorithm.ComputeHash(bytes);
			StringBuilder stringBuilder = new StringBuilder();
			foreach (byte b in array)
			{
				stringBuilder.Append(b.ToString("x2"));
			}
			return stringBuilder.ToString();
		}

		// Token: 0x060029DA RID: 10714 RVA: 0x000CE010 File Offset: 0x000CC210
		private void ClearRequestWithError(PlayFabError e = null)
		{
			if (e == null)
			{
				e = new PlayFabError();
			}
			foreach (PlayFabTitleDataCache.DataRequest dataRequest in this.requests)
			{
				dataRequest.ErrorCallback.SafeInvoke(e);
			}
			this.requests.Clear();
		}

		// Token: 0x04002D08 RID: 11528
		public PlayFabTitleDataCache.DataUpdate OnTitleDataUpdate;

		// Token: 0x04002D09 RID: 11529
		private const string FileName = "TitleDataCache.json";

		// Token: 0x04002D0A RID: 11530
		private readonly List<PlayFabTitleDataCache.DataRequest> requests = new List<PlayFabTitleDataCache.DataRequest>();

		// Token: 0x04002D0B RID: 11531
		private Dictionary<string, string> titleData = new Dictionary<string, string>();

		// Token: 0x04002D0C RID: 11532
		private string titleDataKey;

		// Token: 0x04002D0D RID: 11533
		private const string titleDataUrl = "https://title-data.gtag-cf.com";

		// Token: 0x04002D0E RID: 11534
		private bool isDataUpToDate;

		// Token: 0x04002D0F RID: 11535
		private Coroutine updateDataCoroutine;

		// Token: 0x020006EB RID: 1771
		[Serializable]
		public sealed class DataUpdate : UnityEvent<string>
		{
		}

		// Token: 0x020006EC RID: 1772
		private class DataRequest
		{
			// Token: 0x170004DD RID: 1245
			// (get) Token: 0x060029DE RID: 10718 RVA: 0x000CE0D5 File Offset: 0x000CC2D5
			// (set) Token: 0x060029DF RID: 10719 RVA: 0x000CE0DD File Offset: 0x000CC2DD
			public string Name { get; set; }

			// Token: 0x170004DE RID: 1246
			// (get) Token: 0x060029E0 RID: 10720 RVA: 0x000CE0E6 File Offset: 0x000CC2E6
			// (set) Token: 0x060029E1 RID: 10721 RVA: 0x000CE0EE File Offset: 0x000CC2EE
			public Action<string> Callback { get; set; }

			// Token: 0x170004DF RID: 1247
			// (get) Token: 0x060029E2 RID: 10722 RVA: 0x000CE0F7 File Offset: 0x000CC2F7
			// (set) Token: 0x060029E3 RID: 10723 RVA: 0x000CE0FF File Offset: 0x000CC2FF
			public Action<PlayFabError> ErrorCallback { get; set; }
		}
	}
}
