﻿using System;
using UnityEngine;

// Token: 0x020002FC RID: 764
public class GorillaBodyPhysics : MonoBehaviour
{
	// Token: 0x06001181 RID: 4481 RVA: 0x0005C2F8 File Offset: 0x0005A4F8
	private void FixedUpdate()
	{
		this.bodyCollider.transform.position = this.headsetTransform.position + this.bodyColliderOffset;
	}

	// Token: 0x040013D7 RID: 5079
	public GameObject bodyCollider;

	// Token: 0x040013D8 RID: 5080
	public Vector3 bodyColliderOffset;

	// Token: 0x040013D9 RID: 5081
	public Transform headsetTransform;
}
