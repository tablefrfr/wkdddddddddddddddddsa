﻿using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000474 RID: 1140
public static class FXSystem
{
	// Token: 0x06001A85 RID: 6789 RVA: 0x00087FD0 File Offset: 0x000861D0
	public static void PlayFXForRig(FXType fxType, IFXContext context, PhotonMessageInfo info = default(PhotonMessageInfo))
	{
		FXSystemSettings settings = context.settings;
		if (settings.forLocalRig)
		{
			context.OnPlayFX();
			return;
		}
		CallLimitType<CallLimiter> callLimitType = settings.callSettings[(int)fxType];
		if (callLimitType.UseNetWorkTime ? callLimitType.CallLimitSettings.CheckCallServerTime(info.SentServerTime) : callLimitType.CallLimitSettings.CheckCallTime(Time.time))
		{
			context.OnPlayFX();
		}
	}

	// Token: 0x06001A86 RID: 6790 RVA: 0x00088030 File Offset: 0x00086230
	public static void PlayFXForRigValidated(List<int> hashes, FXType fxType, IFXContext context, PhotonMessageInfo info = default(PhotonMessageInfo))
	{
		for (int i = 0; i < hashes.Count; i++)
		{
			if (!ObjectPools.instance.DoesPoolExist(hashes[i]))
			{
				return;
			}
		}
		FXSystem.PlayFXForRig(fxType, context, info);
	}

	// Token: 0x06001A87 RID: 6791 RVA: 0x0008806C File Offset: 0x0008626C
	public static void PlayFX<T>(FXType fxType, IFXContextParems<T> context, T args, PhotonMessageInfo info = default(PhotonMessageInfo)) where T : FXSArgs
	{
		FXSystemSettings settings = context.settings;
		if (settings.forLocalRig)
		{
			context.OnPlayFX(args);
			return;
		}
		CallLimitType<CallLimiter> callLimitType = settings.callSettings[(int)fxType];
		if (callLimitType.UseNetWorkTime ? callLimitType.CallLimitSettings.CheckCallServerTime(info.SentServerTime) : callLimitType.CallLimitSettings.CheckCallTime(Time.time))
		{
			context.OnPlayFX(args);
		}
	}
}
