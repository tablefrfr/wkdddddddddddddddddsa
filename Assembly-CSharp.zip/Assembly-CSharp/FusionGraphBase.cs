﻿using System;
using Fusion;
using Fusion.StatsInternal;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000210 RID: 528
[ScriptHelp(BackColor = EditorHeaderBackColor.Olive)]
public abstract class FusionGraphBase : Fusion.Behaviour, IFusionStatsView
{
	// Token: 0x1700015E RID: 350
	// (get) Token: 0x06000AF1 RID: 2801 RVA: 0x0003AED7 File Offset: 0x000390D7
	// (set) Token: 0x06000AF2 RID: 2802 RVA: 0x0003AEDF File Offset: 0x000390DF
	public Simulation.Statistics.StatSourceTypes StateSourceType
	{
		get
		{
			return this._statSourceType;
		}
		set
		{
			this._statSourceType = value;
			this.TryConnect();
		}
	}

	// Token: 0x1700015F RID: 351
	// (get) Token: 0x06000AF3 RID: 2803 RVA: 0x0003AEEF File Offset: 0x000390EF
	// (set) Token: 0x06000AF4 RID: 2804 RVA: 0x0003AEF7 File Offset: 0x000390F7
	public int StatId
	{
		get
		{
			return this._statId;
		}
		set
		{
			this._statId = value;
			this.TryConnect();
		}
	}

	// Token: 0x17000160 RID: 352
	// (get) Token: 0x06000AF5 RID: 2805 RVA: 0x0003AF07 File Offset: 0x00039107
	public IStatsBuffer StatsBuffer
	{
		get
		{
			if (this._statsBuffer == null)
			{
				this.TryConnect();
			}
			return this._statsBuffer;
		}
	}

	// Token: 0x17000161 RID: 353
	// (get) Token: 0x06000AF7 RID: 2807 RVA: 0x0003AF3D File Offset: 0x0003913D
	// (set) Token: 0x06000AF6 RID: 2806 RVA: 0x0003AF1E File Offset: 0x0003911E
	public bool IsOverlay
	{
		get
		{
			return this._isOverlay;
		}
		set
		{
			if (this._isOverlay != value)
			{
				this._isOverlay = value;
				this.CalculateLayout();
				this._layoutDirty = true;
			}
		}
	}

	// Token: 0x17000162 RID: 354
	// (get) Token: 0x06000AF8 RID: 2808 RVA: 0x0003AF45 File Offset: 0x00039145
	protected virtual Color BackColor
	{
		get
		{
			if (this._statSourceType == Simulation.Statistics.StatSourceTypes.Simulation)
			{
				return this._fusionStats.SimDataBackColor;
			}
			if (this._statSourceType == Simulation.Statistics.StatSourceTypes.NetConnection)
			{
				return this._fusionStats.NetDataBackColor;
			}
			return this._fusionStats.ObjDataBackColor;
		}
	}

	// Token: 0x17000163 RID: 355
	// (get) Token: 0x06000AF9 RID: 2809 RVA: 0x0003AF7B File Offset: 0x0003917B
	protected Type CastToStatType
	{
		get
		{
			if (this._statSourceType == Simulation.Statistics.StatSourceTypes.Simulation)
			{
				return typeof(Simulation.Statistics.SimStats);
			}
			if (this._statSourceType != Simulation.Statistics.StatSourceTypes.NetConnection)
			{
				return typeof(Simulation.Statistics.ObjStats);
			}
			return typeof(Simulation.Statistics.NetStats);
		}
	}

	// Token: 0x06000AFA RID: 2810 RVA: 0x0003AFAE File Offset: 0x000391AE
	protected FusionStats LocateParentFusionStats()
	{
		if (this._fusionStats == null)
		{
			this._fusionStats = base.GetComponentInParent<FusionStats>();
		}
		return this._fusionStats;
	}

	// Token: 0x06000AFB RID: 2811 RVA: 0x00003051 File Offset: 0x00001251
	public virtual void Initialize()
	{
	}

	// Token: 0x06000AFC RID: 2812 RVA: 0x0003AFD0 File Offset: 0x000391D0
	public virtual void CyclePer()
	{
		Simulation.Statistics.StatsPer perFlags = this.StatSourceInfo.PerFlags;
		switch (this.CurrentPer)
		{
		case Simulation.Statistics.StatsPer.Individual:
			if ((perFlags & Simulation.Statistics.StatsPer.Tick) == Simulation.Statistics.StatsPer.Tick)
			{
				this.CurrentPer = Simulation.Statistics.StatsPer.Tick;
				return;
			}
			if ((perFlags & Simulation.Statistics.StatsPer.Second) == Simulation.Statistics.StatsPer.Second)
			{
				this.CurrentPer = Simulation.Statistics.StatsPer.Second;
			}
			return;
		case Simulation.Statistics.StatsPer.Tick:
			if ((perFlags & Simulation.Statistics.StatsPer.Second) == Simulation.Statistics.StatsPer.Second)
			{
				this.CurrentPer = Simulation.Statistics.StatsPer.Second;
				return;
			}
			if ((perFlags & Simulation.Statistics.StatsPer.Individual) == Simulation.Statistics.StatsPer.Individual)
			{
				this.CurrentPer = Simulation.Statistics.StatsPer.Individual;
			}
			return;
		case Simulation.Statistics.StatsPer.Individual | Simulation.Statistics.StatsPer.Tick:
			return;
		case Simulation.Statistics.StatsPer.Second:
			if ((perFlags & Simulation.Statistics.StatsPer.Individual) == Simulation.Statistics.StatsPer.Individual)
			{
				this.CurrentPer = Simulation.Statistics.StatsPer.Individual;
				return;
			}
			if ((perFlags & Simulation.Statistics.StatsPer.Tick) == Simulation.Statistics.StatsPer.Tick)
			{
				this.CurrentPer = Simulation.Statistics.StatsPer.Tick;
			}
			return;
		default:
			return;
		}
	}

	// Token: 0x06000AFD RID: 2813
	public abstract void CalculateLayout();

	// Token: 0x06000AFE RID: 2814
	public abstract void Refresh();

	// Token: 0x06000AFF RID: 2815 RVA: 0x0003B060 File Offset: 0x00039260
	protected virtual bool TryConnect()
	{
		this.StatSourceInfo = Simulation.Statistics.GetDescription(this._statSourceType, this._statId);
		if (this.WarnThreshold == 0f && this.ErrorThreshold == 0f)
		{
			this.WarnThreshold = this.StatSourceInfo.WarnThreshold;
			this.ErrorThreshold = this.StatSourceInfo.ErrorThreshold;
		}
		if (!base.gameObject.activeInHierarchy)
		{
			return false;
		}
		if (this._fusionStats == null)
		{
			this._fusionStats = base.GetComponentInParent<FusionStats>();
		}
		FusionStats fusionStats = this._fusionStats;
		NetworkRunner networkRunner = (fusionStats != null) ? fusionStats.Runner : null;
		Simulation.Statistics statistics;
		if (networkRunner == null)
		{
			statistics = null;
		}
		else
		{
			Simulation simulation = networkRunner.Simulation;
			statistics = ((simulation != null) ? simulation.Stats : null);
		}
		Simulation.Statistics statistics2 = statistics;
		switch (this._statSourceType)
		{
		case Simulation.Statistics.StatSourceTypes.Simulation:
			this._statsBuffer = ((statistics2 != null) ? statistics2.GetStatBuffer((Simulation.Statistics.SimStats)this._statId) : null);
			break;
		case Simulation.Statistics.StatSourceTypes.NetworkObject:
			if (this._statId >= 2)
			{
				this.StatId = 0;
			}
			if (this._fusionStats.Object == null)
			{
				this._statsBuffer = null;
			}
			else
			{
				this._statsBuffer = ((statistics2 != null) ? statistics2.GetObjectBuffer(this._fusionStats.Object.Id, (Simulation.Statistics.ObjStats)this._statId, true) : null);
			}
			break;
		case Simulation.Statistics.StatSourceTypes.NetConnection:
			if (networkRunner == null)
			{
				this._statsBuffer = null;
			}
			else
			{
				this._statsBuffer = ((statistics2 != null) ? statistics2.GetStatBuffer((Simulation.Statistics.NetStats)this._statId, networkRunner) : null);
			}
			break;
		default:
			this._statsBuffer = null;
			break;
		}
		if (this.BackImage)
		{
			this.BackImage.color = this.BackColor;
		}
		if (this.LabelTitle)
		{
			this.CheckIfValidIncurrentMode(networkRunner);
			this.ApplyTitleText();
		}
		if ((this.StatSourceInfo.PerFlags & (Simulation.Statistics.StatsPer)this.StatsPerDefault) != (Simulation.Statistics.StatsPer)0)
		{
			this.CurrentPer = (Simulation.Statistics.StatsPer)this.StatsPerDefault;
		}
		else
		{
			this.CurrentPer = this.StatSourceInfo.PerDefault;
		}
		return this._statsBuffer != null;
	}

	// Token: 0x06000B00 RID: 2816 RVA: 0x0003B250 File Offset: 0x00039450
	protected void ApplyTitleText()
	{
		Simulation.Statistics.StatSourceInfo statSourceInfo = this.StatSourceInfo;
		if (statSourceInfo.LongName == null)
		{
			return;
		}
		if (statSourceInfo.InvalidReason != null)
		{
			this.LabelTitle.text = statSourceInfo.InvalidReason;
			this.BackImage.gameObject.SetActive(false);
			this.LabelTitle.color = this._fusionStats.FontColor * new Color(1f, 1f, 1f, 0.2f);
			return;
		}
		if (this.LabelTitle.rectTransform.rect.width < 100f)
		{
			this.LabelTitle.text = (statSourceInfo.ShortName ?? statSourceInfo.LongName);
		}
		else
		{
			this.LabelTitle.text = statSourceInfo.LongName;
		}
		this.BackImage.gameObject.SetActive(true);
	}

	// Token: 0x06000B01 RID: 2817 RVA: 0x0003B32C File Offset: 0x0003952C
	protected void CheckIfValidIncurrentMode(NetworkRunner runner)
	{
		if (!runner)
		{
			return;
		}
		Simulation.Statistics.StatFlags flags = this.StatSourceInfo.Flags;
		if ((flags & Simulation.Statistics.StatFlags.ValidForBuildType) == (Simulation.Statistics.StatFlags)0)
		{
			this.StatSourceInfo.InvalidReason = "DEBUG DLL ONLY";
			return;
		}
		NetworkObject networkObject;
		if (this._statSourceType != Simulation.Statistics.StatSourceTypes.NetworkObject)
		{
			networkObject = null;
		}
		else
		{
			FusionStats fusionStats = this._fusionStats;
			networkObject = ((fusionStats != null) ? fusionStats.Object : null);
		}
		NetworkObject networkObject2 = networkObject;
		if (networkObject2 && (flags & Simulation.Statistics.StatFlags.ValidOnStateAuthority) == (Simulation.Statistics.StatFlags)0 && networkObject2.HasStateAuthority)
		{
			this.StatSourceInfo.InvalidReason = "NON STATE AUTH ONLY";
			return;
		}
		if (runner)
		{
			if ((flags & Simulation.Statistics.StatFlags.ValidOnServer) == (Simulation.Statistics.StatFlags)0 && !runner.IsClient)
			{
				this.StatSourceInfo.InvalidReason = "CLIENT ONLY";
				return;
			}
			if ((flags & Simulation.Statistics.StatFlags.ValidWithDeltaSnapshot) == (Simulation.Statistics.StatFlags)0 && runner.Config.Simulation.ReplicationMode == SimulationConfig.StateReplicationModes.DeltaSnapshots)
			{
				this.StatSourceInfo.InvalidReason = "EC MODE ONLY";
				return;
			}
		}
	}

	// Token: 0x06000B03 RID: 2819 RVA: 0x0003B411 File Offset: 0x00039611
	bool IFusionStatsView.get_isActiveAndEnabled()
	{
		return base.isActiveAndEnabled;
	}

	// Token: 0x06000B04 RID: 2820 RVA: 0x0003B419 File Offset: 0x00039619
	Transform IFusionStatsView.get_transform()
	{
		return base.transform;
	}

	// Token: 0x04000C54 RID: 3156
	protected const int PAD = 10;

	// Token: 0x04000C55 RID: 3157
	protected const int MRGN = 6;

	// Token: 0x04000C56 RID: 3158
	protected const int MAX_FONT_SIZE_WITH_GRAPH = 24;

	// Token: 0x04000C57 RID: 3159
	[SerializeField]
	[HideInInspector]
	protected Text LabelTitle;

	// Token: 0x04000C58 RID: 3160
	[SerializeField]
	[HideInInspector]
	protected Image BackImage;

	// Token: 0x04000C59 RID: 3161
	[InlineHelp]
	[SerializeField]
	protected Simulation.Statistics.StatSourceTypes _statSourceType;

	// Token: 0x04000C5A RID: 3162
	[InlineHelp]
	[SerializeField]
	[CastEnum("CastToStatType")]
	protected int _statId;

	// Token: 0x04000C5B RID: 3163
	[InlineHelp]
	public FusionGraphBase.StatsPer StatsPerDefault;

	// Token: 0x04000C5C RID: 3164
	[InlineHelp]
	public float WarnThreshold;

	// Token: 0x04000C5D RID: 3165
	[InlineHelp]
	public float ErrorThreshold;

	// Token: 0x04000C5E RID: 3166
	protected IStatsBuffer _statsBuffer;

	// Token: 0x04000C5F RID: 3167
	protected bool _isOverlay;

	// Token: 0x04000C60 RID: 3168
	protected FusionStats _fusionStats;

	// Token: 0x04000C61 RID: 3169
	protected bool _layoutDirty = true;

	// Token: 0x04000C62 RID: 3170
	protected Simulation.Statistics.StatsPer CurrentPer;

	// Token: 0x04000C63 RID: 3171
	public Simulation.Statistics.StatSourceInfo StatSourceInfo;

	// Token: 0x04000C64 RID: 3172
	[SerializeField]
	[HideInInspector]
	private Simulation.Statistics.StatSourceTypes _prevStatSourceType;

	// Token: 0x04000C65 RID: 3173
	[SerializeField]
	[HideInInspector]
	private int _prevStatId;

	// Token: 0x02000211 RID: 529
	public enum StatsPer
	{
		// Token: 0x04000C67 RID: 3175
		Default,
		// Token: 0x04000C68 RID: 3176
		Individual,
		// Token: 0x04000C69 RID: 3177
		Tick,
		// Token: 0x04000C6A RID: 3178
		Second = 4
	}
}
