﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using GorillaExtensions;
using GorillaNetworking;
using GorillaNetworking.Store;
using UnityEngine;

namespace FXP
{
	// Token: 0x02000618 RID: 1560
	public class CosmeticItemPrefab : MonoBehaviour
	{
		// Token: 0x060024DB RID: 9435 RVA: 0x000B5C8D File Offset: 0x000B3E8D
		private void Awake()
		{
			this.JonsAwakeCode();
		}

		// Token: 0x060024DC RID: 9436 RVA: 0x000B5C98 File Offset: 0x000B3E98
		private void JonsAwakeCode()
		{
			this.isValid = (this.goPedestal && this.goMannequin && this.goCosmeticItem && this.goCosmeticItemNameplate && this.goClock && this.goPreviewMode && this.goAttractMode && this.goPurchaseMode);
			this.goPreviewModeSFX = this.goPreviewMode.transform.GetComponentInChildren<AudioSource>();
			this.goAttractModeSFX = this.goAttractMode.transform.FindChildRecursive("SFXAttractMode").GetComponent<AudioSource>();
			this.goPurchaseModeSFX = this.goPurchaseMode.transform.FindChildRecursive("SFXPurchaseMode").GetComponent<AudioSource>();
			this.goAttractModeVFX = this.goAttractMode.transform.FindChildRecursive("VFXAttractMode").GetComponent<ParticleSystem>();
			this.goPurchaseModeVFX = this.goPurchaseMode.transform.FindChildRecursive("VFXPurchaseMode").GetComponent<ParticleSystem>();
			this.clockTextMesh = this.goClock.GetComponent<TextMesh>();
			this.isValid = (this.goPreviewModeSFX && this.goAttractModeSFX && this.goPurchaseModeSFX);
		}

		// Token: 0x060024DD RID: 9437 RVA: 0x000B5DE9 File Offset: 0x000B3FE9
		private void OnDisable()
		{
			if (StoreUpdater.instance != null)
			{
				this.countdownTimerCoRoutine = null;
				this.StopCountdownCoroutine();
				StoreUpdater.instance.PedestalAsleep(this);
			}
		}

		// Token: 0x060024DE RID: 9438 RVA: 0x000B5E14 File Offset: 0x000B4014
		private void OnEnable()
		{
			if (this.goPreviewModeSFX == null)
			{
				this.goPreviewModeSFX = this.goPreviewMode.transform.GetComponentInChildren<AudioSource>();
			}
			if (this.goAttractModeSFX == null)
			{
				this.goAttractModeSFX = this.goAttractMode.transform.transform.GetComponentInChildren<AudioSource>();
			}
			if (this.goPurchaseModeSFX == null)
			{
				this.goPurchaseModeSFX = this.goPurchaseMode.transform.transform.GetComponentInChildren<AudioSource>();
			}
			this.isValid = (this.goPreviewModeSFX && this.goAttractModeSFX && this.goPurchaseModeSFX);
			if (StoreUpdater.instance != null)
			{
				StoreUpdater.instance.PedestalAwakened(this);
			}
		}

		// Token: 0x060024DF RID: 9439 RVA: 0x000B5EE4 File Offset: 0x000B40E4
		public void SwitchDisplayMode(CosmeticItemPrefab.EDisplayMode NewDisplayMode)
		{
			if (!this.isValid)
			{
				return;
			}
			if (NewDisplayMode.Equals(CosmeticItemPrefab.EDisplayMode.NULL))
			{
				return;
			}
			if (NewDisplayMode == this.currentDisplayMode)
			{
				return;
			}
			switch (NewDisplayMode)
			{
			case CosmeticItemPrefab.EDisplayMode.HIDDEN:
			{
				this.goPedestal.SetActive(false);
				this.goMannequin.SetActive(false);
				this.goCosmeticItem.SetActive(false);
				this.goCosmeticItemNameplate.SetActive(false);
				this.goClock.SetActive(false);
				this.goPreviewMode.SetActive(false);
				AudioSource audioSource = this.goPreviewModeSFX;
				if (audioSource != null)
				{
					audioSource.Stop();
				}
				this.goAttractMode.SetActive(false);
				AudioSource audioSource2 = this.goAttractModeSFX;
				if (audioSource2 != null)
				{
					audioSource2.Stop();
				}
				this.goPurchaseMode.SetActive(false);
				AudioSource audioSource3 = this.goPurchaseModeSFX;
				if (audioSource3 != null)
				{
					audioSource3.Stop();
				}
				this.StopPreviewTimer();
				this.StopAttractTimer();
				break;
			}
			case CosmeticItemPrefab.EDisplayMode.PREVIEW:
				this.goPedestal.SetActive(true);
				this.goMannequin.SetActive(true);
				this.goCosmeticItem.SetActive(true);
				this.goCosmeticItemNameplate.SetActive(false);
				this.goClock.SetActive(true);
				this.goAttractMode.SetActive(false);
				this.goAttractModeSFX.Stop();
				this.goPurchaseMode.SetActive(false);
				this.goPurchaseModeSFX.Stop();
				this.goPreviewMode.SetActive(true);
				this.goPreviewModeSFX.Play();
				this.StopPreviewTimer();
				this.StartPreviewTimer();
				break;
			case CosmeticItemPrefab.EDisplayMode.ATTRACT:
				this.goPedestal.SetActive(true);
				this.goMannequin.SetActive(true);
				this.goCosmeticItem.SetActive(true);
				this.goCosmeticItemNameplate.SetActive(true);
				this.goClock.SetActive(true);
				this.goPreviewMode.SetActive(false);
				this.goPreviewModeSFX.Stop();
				this.goPurchaseMode.SetActive(false);
				this.goPurchaseModeSFX.Stop();
				this.goAttractMode.SetActive(true);
				this.goAttractModeSFX.Play();
				this.StopPreviewTimer();
				this.StartAttractTimer();
				break;
			case CosmeticItemPrefab.EDisplayMode.PURCHASE:
				this.goPedestal.SetActive(true);
				this.goMannequin.SetActive(true);
				this.goCosmeticItem.SetActive(true);
				this.goCosmeticItemNameplate.SetActive(true);
				this.goClock.SetActive(false);
				this.goPreviewMode.SetActive(false);
				this.goPreviewModeSFX.Stop();
				this.goAttractMode.SetActive(false);
				this.goAttractModeSFX.Stop();
				this.goPurchaseMode.SetActive(true);
				this.goPurchaseModeSFX.Play();
				this.goCosmeticItemNameplate.GetComponent<TextMesh>().text = "Purchased!";
				this.StopPreviewTimer();
				break;
			case CosmeticItemPrefab.EDisplayMode.POSTPURCHASE:
				this.goPedestal.SetActive(true);
				this.goMannequin.SetActive(true);
				this.goCosmeticItem.SetActive(true);
				this.goCosmeticItemNameplate.SetActive(false);
				this.goClock.SetActive(false);
				this.goPreviewMode.SetActive(false);
				this.goPreviewModeSFX.Stop();
				this.goAttractMode.SetActive(false);
				this.goAttractModeSFX.Stop();
				this.goPurchaseMode.SetActive(false);
				this.goPurchaseModeSFX.Stop();
				this.StopPreviewTimer();
				break;
			}
			this.currentDisplayMode = NewDisplayMode;
		}

		// Token: 0x060024E0 RID: 9440 RVA: 0x000B6232 File Offset: 0x000B4432
		private void Update()
		{
			this.UpdateClock();
		}

		// Token: 0x060024E1 RID: 9441 RVA: 0x000B623C File Offset: 0x000B443C
		private void UpdateClock()
		{
			TimeSpan timeSpan = default(TimeSpan);
			if (this.currentUpdateEvent != null)
			{
				timeSpan = this.currentUpdateEvent.EndTimeUTC.ToUniversalTime() - StoreUpdater.instance.DateTimeNowServerAdjusted;
				if (timeSpan.Days > 0)
				{
					this.clockTextMesh.text = timeSpan.ToString("dd\\ hh\\:mm\\:ss");
					return;
				}
				if (timeSpan.Hours > 0)
				{
					this.clockTextMesh.text = timeSpan.ToString("hh\\:mm\\:ss");
					return;
				}
				this.clockTextMesh.text = timeSpan.ToString("hh\\:mm\\:ss");
			}
		}

		// Token: 0x060024E2 RID: 9442 RVA: 0x000B62D8 File Offset: 0x000B44D8
		public void SetDefaultProperties()
		{
			if (!this.isValid)
			{
				return;
			}
			this.goPedestal.GetComponent<MeshFilter>().sharedMesh = this.defaultPedestalMesh;
			this.goPedestal.GetComponent<MeshRenderer>().sharedMaterial = this.defaultPedestalMaterial;
			this.goMannequin.GetComponent<MeshFilter>().sharedMesh = this.defaultMannequinMesh;
			this.goMannequin.GetComponent<MeshRenderer>().sharedMaterial = this.defaultMannequinMaterial;
			this.goCosmeticItem.GetComponent<MeshFilter>().sharedMesh = this.defaultCosmeticMesh;
			this.goCosmeticItem.GetComponent<MeshRenderer>().sharedMaterial = this.defaultCosmeticMaterial;
			this.goCosmeticItemNameplate.GetComponent<TextMesh>().text = this.defaultItemText;
			this.goPreviewModeSFX.clip = this.defaultSFXPreviewMode;
			this.goAttractModeSFX.clip = this.defaultSFXAttractMode;
			this.goPurchaseModeSFX.clip = this.defaultSFXPurchaseMode;
		}

		// Token: 0x060024E3 RID: 9443 RVA: 0x000B63BB File Offset: 0x000B45BB
		private void ClearCosmeticMesh()
		{
			Object.Destroy(this.goCosmeticItemGameObject);
		}

		// Token: 0x060024E4 RID: 9444 RVA: 0x000B63C8 File Offset: 0x000B45C8
		private void ClearCosmeticAtlas()
		{
			if (this.goCosmeticItemMeshAtlas.IsNotNull())
			{
				Object.Destroy(this.goCosmeticItemMeshAtlas);
			}
		}

		// Token: 0x060024E5 RID: 9445 RVA: 0x000B63E4 File Offset: 0x000B45E4
		public void SetCosmeticItemFromCosmeticController(CosmeticsController.CosmeticItem item)
		{
			if (!this.isValid)
			{
				return;
			}
			this.ClearCosmeticAtlas();
			this.ClearCosmeticMesh();
			this.oldItemID = this.itemID;
			this.itemID = item.itemName;
			this.itemName = item.displayName;
			if (item.overrideDisplayName != string.Empty)
			{
				this.itemName = item.overrideDisplayName;
			}
			if (item.bUsesMeshAtlas)
			{
				this.goCosmeticItemMeshAtlas = (Object.Instantiate(Resources.Load(item.meshAtlasResourceString), this.goCosmeticItem.transform) as GameObject);
			}
			else
			{
				this.goCosmeticItemGameObject = (Object.Instantiate(Resources.Load(item.meshResourceString), this.goCosmeticItem.transform) as GameObject);
				if (item.materialResourceString != string.Empty)
				{
					Resources.Load<Material>(item.materialResourceString);
					MeshRenderer[] componentsInChildren = this.goCosmeticItemGameObject.GetComponentsInChildren<MeshRenderer>();
					for (int i = 0; i < componentsInChildren.Length; i++)
					{
						componentsInChildren[i].sharedMaterial = Resources.Load<Material>(item.materialResourceString);
					}
				}
			}
			this.SetCosmeticStand();
		}

		// Token: 0x060024E6 RID: 9446 RVA: 0x000B64F0 File Offset: 0x000B46F0
		public void SetCosmeticStand()
		{
			this.cosmeticStand.thisCosmeticName = this.itemID;
			Debug.Log("StoreUpdater - " + this.itemID);
			this.cosmeticStand.InitializeCosmetic();
			if (this.oldItemID.Length > 0)
			{
				if (this.oldItemID != this.itemID)
				{
					this.cosmeticStand.isOn = false;
				}
				this.cosmeticStand.UpdateColor();
			}
		}

		// Token: 0x060024E7 RID: 9447 RVA: 0x000B6568 File Offset: 0x000B4768
		public void SetStoreUpdateEvent(StoreUpdateEvent storeUpdateEvent, bool playFX)
		{
			if (!this.isValid)
			{
				return;
			}
			if (playFX)
			{
				this.goAttractMode.SetActive(true);
				this.goAttractModeVFX.Play();
			}
			this.currentUpdateEvent = storeUpdateEvent;
			Debug.Log("StoreUpdater - SetStoreUpdateEvent - storeUpdateEvent.ItemName: " + storeUpdateEvent.ItemName);
			this.SetCosmeticItemFromCosmeticController(CosmeticsController.instance.GetItemFromDict(storeUpdateEvent.ItemName));
			if (base.isActiveAndEnabled)
			{
				this.countdownTimerCoRoutine = base.StartCoroutine(this.PlayCountdownTimer());
			}
			this.UpdateClock();
		}

		// Token: 0x060024E8 RID: 9448 RVA: 0x000B65EC File Offset: 0x000B47EC
		private IEnumerator PlayCountdownTimer()
		{
			yield return new WaitForSeconds(Mathf.Clamp((float)((this.currentUpdateEvent.EndTimeUTC.ToUniversalTime() - StoreUpdater.instance.DateTimeNowServerAdjusted).TotalSeconds - 10.0), 0f, float.MaxValue));
			this.PlaySFX();
			yield break;
		}

		// Token: 0x060024E9 RID: 9449 RVA: 0x000B65FB File Offset: 0x000B47FB
		public void StopCountdownCoroutine()
		{
			this.CountdownSFX.Stop();
			this.goAttractModeVFX.Stop();
			if (this.countdownTimerCoRoutine != null)
			{
				base.StopCoroutine(this.countdownTimerCoRoutine);
				this.countdownTimerCoRoutine = null;
			}
		}

		// Token: 0x060024EA RID: 9450 RVA: 0x000B6630 File Offset: 0x000B4830
		private void PlaySFX()
		{
			if (this.currentUpdateEvent != null)
			{
				TimeSpan timeSpan = this.currentUpdateEvent.EndTimeUTC.ToUniversalTime() - StoreUpdater.instance.DateTimeNowServerAdjusted;
				if (timeSpan.TotalSeconds >= 10.0)
				{
					this.CountdownSFX.time = 0f;
					this.CountdownSFX.Play();
					return;
				}
				this.CountdownSFX.time = 10f - (float)timeSpan.TotalSeconds;
				this.CountdownSFX.Play();
			}
		}

		// Token: 0x060024EB RID: 9451 RVA: 0x000B66BC File Offset: 0x000B48BC
		public void SetCosmeticItemProperties(string WhichGUID, string Name, List<Transform> SocketsList, int Socket, string PedestalMesh = null, string MannequinMesh = null)
		{
			if (!this.isValid)
			{
				return;
			}
			Guid guid;
			if (!Guid.TryParse(WhichGUID, out guid))
			{
				return;
			}
			this.itemName = Name;
			this.itemSocket = Socket;
			if (this.pedestalMesh != null)
			{
				this.goPedestal.GetComponent<MeshFilter>().sharedMesh = this.pedestalMesh;
			}
		}

		// Token: 0x060024EC RID: 9452 RVA: 0x000B6710 File Offset: 0x000B4910
		private void StartPreviewTimer()
		{
			if (!this.isValid)
			{
				return;
			}
			if (this.coroutinePreviewTimer != null)
			{
				base.StopCoroutine(this.coroutinePreviewTimer);
				this.coroutinePreviewTimer = null;
			}
			this.coroutinePreviewTimer = this.DoPreviewTimer(DateTime.UtcNow + TimeSpan.FromSeconds((double)((this.hoursInPreviewMode ?? this.defaultHoursInPreviewMode) * 60 * 60)));
			base.StartCoroutine(this.coroutinePreviewTimer);
		}

		// Token: 0x060024ED RID: 9453 RVA: 0x000B678F File Offset: 0x000B498F
		private void StopPreviewTimer()
		{
			if (!this.isValid)
			{
				return;
			}
			if (this.coroutinePreviewTimer != null)
			{
				base.StopCoroutine(this.coroutinePreviewTimer);
				this.coroutinePreviewTimer = null;
			}
			this.clockTextMesh.text = "Clock";
		}

		// Token: 0x060024EE RID: 9454 RVA: 0x000B67C5 File Offset: 0x000B49C5
		private IEnumerator DoPreviewTimer(DateTime ReleaseTime)
		{
			if (this.isValid)
			{
				bool timerDone = false;
				TimeSpan remainingTime = ReleaseTime - DateTime.UtcNow;
				while (!timerDone)
				{
					string text;
					int delayTime;
					if (remainingTime.TotalSeconds <= 59.0)
					{
						text = remainingTime.Seconds.ToString() + "s";
						delayTime = 1;
					}
					else
					{
						delayTime = 60;
						text = string.Empty;
						if (remainingTime.Days > 0)
						{
							text = text + remainingTime.Days.ToString() + "d ";
						}
						if (remainingTime.Hours > 0)
						{
							text = text + remainingTime.Hours.ToString() + "h ";
						}
						if (remainingTime.Minutes > 0)
						{
							text = text + remainingTime.Minutes.ToString() + "m ";
						}
						text = text.TrimEnd();
					}
					this.clockTextMesh.text = text;
					yield return new WaitForSecondsRealtime((float)delayTime);
					remainingTime = remainingTime.Subtract(TimeSpan.FromSeconds((double)delayTime));
					if (remainingTime.TotalSeconds <= 0.0)
					{
						timerDone = true;
					}
				}
				this.SwitchDisplayMode(CosmeticItemPrefab.EDisplayMode.ATTRACT);
				yield return null;
				remainingTime = default(TimeSpan);
			}
			yield break;
		}

		// Token: 0x060024EF RID: 9455 RVA: 0x000B67DC File Offset: 0x000B49DC
		public void StartAttractTimer()
		{
			if (!this.isValid)
			{
				return;
			}
			if (this.coroutineAttractTimer != null)
			{
				base.StopCoroutine(this.coroutineAttractTimer);
				this.coroutineAttractTimer = null;
			}
			this.coroutineAttractTimer = this.DoAttractTimer(DateTime.UtcNow + TimeSpan.FromSeconds((double)((this.hoursInAttractMode ?? this.defaultHoursInAttractMode) * 60 * 60)));
			base.StartCoroutine(this.coroutineAttractTimer);
		}

		// Token: 0x060024F0 RID: 9456 RVA: 0x000B685B File Offset: 0x000B4A5B
		private void StopAttractTimer()
		{
			if (!this.isValid)
			{
				return;
			}
			if (this.coroutineAttractTimer != null)
			{
				base.StopCoroutine(this.coroutineAttractTimer);
				this.coroutineAttractTimer = null;
			}
			this.goClock.GetComponent<TextMesh>().text = "Clock";
		}

		// Token: 0x060024F1 RID: 9457 RVA: 0x000B6896 File Offset: 0x000B4A96
		private IEnumerator DoAttractTimer(DateTime ReleaseTime)
		{
			if (this.isValid)
			{
				bool timerDone = false;
				TimeSpan remainingTime = ReleaseTime - DateTime.UtcNow;
				while (!timerDone)
				{
					string text;
					int delayTime;
					if (remainingTime.TotalSeconds <= 59.0)
					{
						text = remainingTime.Seconds.ToString() + "s";
						delayTime = 1;
					}
					else
					{
						delayTime = 60;
						text = string.Empty;
						if (remainingTime.Days > 0)
						{
							text = text + remainingTime.Days.ToString() + "d ";
						}
						if (remainingTime.Hours > 0)
						{
							text = text + remainingTime.Hours.ToString() + "h ";
						}
						if (remainingTime.Minutes > 0)
						{
							text = text + remainingTime.Minutes.ToString() + "m ";
						}
						text = text.TrimEnd();
					}
					this.goClock.GetComponent<TextMesh>().text = text;
					yield return new WaitForSecondsRealtime((float)delayTime);
					remainingTime = remainingTime.Subtract(TimeSpan.FromSeconds((double)delayTime));
					if (remainingTime.TotalSeconds <= 0.0)
					{
						timerDone = true;
					}
				}
				this.SwitchDisplayMode(CosmeticItemPrefab.EDisplayMode.HIDDEN);
				yield return null;
				remainingTime = default(TimeSpan);
			}
			yield break;
		}

		// Token: 0x0400279E RID: 10142
		public string PedestalID = "";

		// Token: 0x0400279F RID: 10143
		[SerializeField]
		private Guid? itemGUID;

		// Token: 0x040027A0 RID: 10144
		[SerializeField]
		private string itemName = string.Empty;

		// Token: 0x040027A1 RID: 10145
		[SerializeField]
		private List<Transform> sockets = new List<Transform>();

		// Token: 0x040027A2 RID: 10146
		[SerializeField]
		private int itemSocket = int.MinValue;

		// Token: 0x040027A3 RID: 10147
		[SerializeField]
		private int? hoursInPreviewMode;

		// Token: 0x040027A4 RID: 10148
		[SerializeField]
		private int? hoursInAttractMode;

		// Token: 0x040027A5 RID: 10149
		[SerializeField]
		private Mesh pedestalMesh;

		// Token: 0x040027A6 RID: 10150
		[SerializeField]
		private Mesh mannequinMesh;

		// Token: 0x040027A7 RID: 10151
		[SerializeField]
		private Mesh cosmeticMesh;

		// Token: 0x040027A8 RID: 10152
		[SerializeField]
		private AudioClip sfxPreviewMode;

		// Token: 0x040027A9 RID: 10153
		[SerializeField]
		private AudioClip sfxAttractMode;

		// Token: 0x040027AA RID: 10154
		[SerializeField]
		private AudioClip sfxPurchaseMode;

		// Token: 0x040027AB RID: 10155
		[SerializeField]
		private ParticleSystem vfxPreviewMode;

		// Token: 0x040027AC RID: 10156
		[SerializeField]
		private ParticleSystem vfxAttractMode;

		// Token: 0x040027AD RID: 10157
		[SerializeField]
		private ParticleSystem vfxPurchaseMode;

		// Token: 0x040027AE RID: 10158
		[SerializeField]
		private GameObject goPedestal;

		// Token: 0x040027AF RID: 10159
		[SerializeField]
		private GameObject goMannequin;

		// Token: 0x040027B0 RID: 10160
		[SerializeField]
		private GameObject goCosmeticItem;

		// Token: 0x040027B1 RID: 10161
		[SerializeField]
		private GameObject goCosmeticItemGameObject;

		// Token: 0x040027B2 RID: 10162
		[SerializeField]
		private GameObject goCosmeticItemNameplate;

		// Token: 0x040027B3 RID: 10163
		[SerializeField]
		private GameObject goClock;

		// Token: 0x040027B4 RID: 10164
		[SerializeField]
		private GameObject goPreviewMode;

		// Token: 0x040027B5 RID: 10165
		[SerializeField]
		private GameObject goAttractMode;

		// Token: 0x040027B6 RID: 10166
		[SerializeField]
		private GameObject goPurchaseMode;

		// Token: 0x040027B7 RID: 10167
		[SerializeField]
		private Mesh defaultPedestalMesh;

		// Token: 0x040027B8 RID: 10168
		[SerializeField]
		private Material defaultPedestalMaterial;

		// Token: 0x040027B9 RID: 10169
		[SerializeField]
		private Mesh defaultMannequinMesh;

		// Token: 0x040027BA RID: 10170
		[SerializeField]
		private Material defaultMannequinMaterial;

		// Token: 0x040027BB RID: 10171
		[SerializeField]
		private Mesh defaultCosmeticMesh;

		// Token: 0x040027BC RID: 10172
		[SerializeField]
		private Material defaultCosmeticMaterial;

		// Token: 0x040027BD RID: 10173
		[SerializeField]
		private string defaultItemText;

		// Token: 0x040027BE RID: 10174
		[SerializeField]
		private int defaultHoursInPreviewMode;

		// Token: 0x040027BF RID: 10175
		[SerializeField]
		private int defaultHoursInAttractMode;

		// Token: 0x040027C0 RID: 10176
		[SerializeField]
		private AudioClip defaultSFXPreviewMode;

		// Token: 0x040027C1 RID: 10177
		[SerializeField]
		private AudioClip defaultSFXAttractMode;

		// Token: 0x040027C2 RID: 10178
		[SerializeField]
		private AudioClip defaultSFXPurchaseMode;

		// Token: 0x040027C3 RID: 10179
		private GameObject goCosmeticItemMeshAtlas;

		// Token: 0x040027C4 RID: 10180
		public AudioSource CountdownSFX;

		// Token: 0x040027C5 RID: 10181
		private CosmeticItemPrefab.EDisplayMode currentDisplayMode;

		// Token: 0x040027C6 RID: 10182
		private bool isValid;

		// Token: 0x040027C7 RID: 10183
		[Nullable(2)]
		private AudioSource goPreviewModeSFX;

		// Token: 0x040027C8 RID: 10184
		[Nullable(2)]
		private AudioSource goAttractModeSFX;

		// Token: 0x040027C9 RID: 10185
		[Nullable(2)]
		private AudioSource goPurchaseModeSFX;

		// Token: 0x040027CA RID: 10186
		[Nullable(2)]
		private ParticleSystem goAttractModeVFX;

		// Token: 0x040027CB RID: 10187
		[Nullable(2)]
		private ParticleSystem goPurchaseModeVFX;

		// Token: 0x040027CC RID: 10188
		private IEnumerator coroutinePreviewTimer;

		// Token: 0x040027CD RID: 10189
		private IEnumerator coroutineAttractTimer;

		// Token: 0x040027CE RID: 10190
		private DateTime startTime;

		// Token: 0x040027CF RID: 10191
		private TextMesh clockTextMesh;

		// Token: 0x040027D0 RID: 10192
		private StoreUpdateEvent currentUpdateEvent;

		// Token: 0x040027D1 RID: 10193
		public CosmeticStand cosmeticStand;

		// Token: 0x040027D2 RID: 10194
		public string itemID = "";

		// Token: 0x040027D3 RID: 10195
		public string oldItemID = "";

		// Token: 0x040027D4 RID: 10196
		private Coroutine countdownTimerCoRoutine;

		// Token: 0x02000619 RID: 1561
		[SerializeField]
		public enum EDisplayMode
		{
			// Token: 0x040027D6 RID: 10198
			NULL,
			// Token: 0x040027D7 RID: 10199
			HIDDEN,
			// Token: 0x040027D8 RID: 10200
			PREVIEW,
			// Token: 0x040027D9 RID: 10201
			ATTRACT,
			// Token: 0x040027DA RID: 10202
			PURCHASE,
			// Token: 0x040027DB RID: 10203
			POSTPURCHASE
		}
	}
}
