﻿using System;
using Unity.Collections;
using UnityEngine;

// Token: 0x02000328 RID: 808
public class BuilderTableDataRenderIndirectBatch
{
	// Token: 0x040014C9 RID: 5321
	public int totalInstances;

	// Token: 0x040014CA RID: 5322
	public NativeArray<Matrix4x4> instanceObjectToWorld;

	// Token: 0x040014CB RID: 5323
	public NativeArray<int> instanceTexIndex;

	// Token: 0x040014CC RID: 5324
	public NativeArray<float> instanceTint;

	// Token: 0x040014CD RID: 5325
	public NativeArray<int> instanceLodLevel;

	// Token: 0x040014CE RID: 5326
	public NativeArray<int> instanceLodLevelDirty;

	// Token: 0x040014CF RID: 5327
	public NativeList<BuilderTableMeshInstances> renderMeshes;

	// Token: 0x040014D0 RID: 5328
	public GraphicsBuffer commandBuf;

	// Token: 0x040014D1 RID: 5329
	public GraphicsBuffer matrixBuf;

	// Token: 0x040014D2 RID: 5330
	public GraphicsBuffer texIndexBuf;

	// Token: 0x040014D3 RID: 5331
	public GraphicsBuffer tintBuf;

	// Token: 0x040014D4 RID: 5332
	public NativeArray<GraphicsBuffer.IndirectDrawIndexedArgs> commandData;

	// Token: 0x040014D5 RID: 5333
	public int commandCount;
}
