﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;

namespace GorillaLocomotion.Climbing
{
	// Token: 0x020005D5 RID: 1493
	public class GorillaHandClimber : MonoBehaviour
	{
		// Token: 0x060022EF RID: 8943 RVA: 0x000AB102 File Offset: 0x000A9302
		private void Awake()
		{
			this.col = base.GetComponent<Collider>();
		}

		// Token: 0x060022F0 RID: 8944 RVA: 0x00003051 File Offset: 0x00001251
		private void OnEnable()
		{
		}

		// Token: 0x060022F1 RID: 8945 RVA: 0x000AB110 File Offset: 0x000A9310
		private void Update()
		{
			for (int i = this.potentialClimbables.Count - 1; i >= 0; i--)
			{
				if (this.potentialClimbables[i] == null || !this.potentialClimbables[i].isActiveAndEnabled)
				{
					this.potentialClimbables.RemoveAt(i);
				}
				else if (this.potentialClimbables[i].climbOnlyWhileSmall && this.player.scale > 0.99f)
				{
					this.potentialClimbables.RemoveAt(i);
				}
			}
			bool grab = ControllerInputPoller.GetGrab(this.xrNode);
			bool grabRelease = ControllerInputPoller.GetGrabRelease(this.xrNode);
			if (!this.isClimbing)
			{
				if (this.queuedToBecomeValidToGrabAgain && Vector3.Distance(this.lastAutoReleasePos, this.handRoot.localPosition) >= 0.35f)
				{
					this.queuedToBecomeValidToGrabAgain = false;
				}
				if (grabRelease)
				{
					this.queuedToBecomeValidToGrabAgain = false;
					this.dontReclimbLast = null;
				}
				GorillaClimbable closestClimbable = this.GetClosestClimbable();
				if (!this.queuedToBecomeValidToGrabAgain && closestClimbable && grab && !this.equipmentInteractor.GetIsHolding(this.xrNode) && closestClimbable != this.dontReclimbLast && !this.player.inOverlay)
				{
					GorillaClimbableRef gorillaClimbableRef = closestClimbable as GorillaClimbableRef;
					if (gorillaClimbableRef != null)
					{
						this.player.BeginClimbing(gorillaClimbableRef.climb, this, gorillaClimbableRef);
						return;
					}
					this.player.BeginClimbing(closestClimbable, this, null);
					return;
				}
			}
			else if (grabRelease)
			{
				this.player.EndClimbing(this, false, false);
			}
		}

		// Token: 0x060022F2 RID: 8946 RVA: 0x000AB288 File Offset: 0x000A9488
		public GorillaClimbable GetClosestClimbable()
		{
			if (this.potentialClimbables.Count == 0)
			{
				return null;
			}
			if (this.potentialClimbables.Count == 1)
			{
				return this.potentialClimbables[0];
			}
			Vector3 position = base.transform.position;
			float num = float.MaxValue;
			GorillaClimbable result = null;
			foreach (GorillaClimbable gorillaClimbable in this.potentialClimbables)
			{
				float num2;
				if (gorillaClimbable.colliderCache)
				{
					if (!this.col.bounds.Intersects(gorillaClimbable.colliderCache.bounds))
					{
						continue;
					}
					Vector3 b = gorillaClimbable.colliderCache.ClosestPoint(position);
					num2 = Vector3.Distance(position, b);
				}
				else
				{
					num2 = Vector3.Distance(position, gorillaClimbable.transform.position);
				}
				if (num2 < num)
				{
					result = gorillaClimbable;
					num = num2;
				}
			}
			return result;
		}

		// Token: 0x060022F3 RID: 8947 RVA: 0x000AB388 File Offset: 0x000A9588
		private void OnTriggerEnter(Collider other)
		{
			GorillaClimbable item;
			if (other.TryGetComponent<GorillaClimbable>(out item))
			{
				this.potentialClimbables.Add(item);
				return;
			}
			GorillaClimbableRef item2;
			if (other.TryGetComponent<GorillaClimbableRef>(out item2))
			{
				this.potentialClimbables.Add(item2);
			}
		}

		// Token: 0x060022F4 RID: 8948 RVA: 0x000AB3C4 File Offset: 0x000A95C4
		private void OnTriggerExit(Collider other)
		{
			GorillaClimbable item;
			if (other.TryGetComponent<GorillaClimbable>(out item))
			{
				this.potentialClimbables.Remove(item);
				return;
			}
			GorillaClimbableRef item2;
			if (other.TryGetComponent<GorillaClimbableRef>(out item2))
			{
				this.potentialClimbables.Remove(item2);
			}
		}

		// Token: 0x060022F5 RID: 8949 RVA: 0x000AB400 File Offset: 0x000A9600
		public void ForceStopClimbing(bool startingNewClimb = false, bool doDontReclimb = false)
		{
			this.player.EndClimbing(this, startingNewClimb, doDontReclimb);
		}

		// Token: 0x04002573 RID: 9587
		[SerializeField]
		private Player player;

		// Token: 0x04002574 RID: 9588
		[SerializeField]
		private EquipmentInteractor equipmentInteractor;

		// Token: 0x04002575 RID: 9589
		private List<GorillaClimbable> potentialClimbables = new List<GorillaClimbable>();

		// Token: 0x04002576 RID: 9590
		public XRNode xrNode = XRNode.LeftHand;

		// Token: 0x04002577 RID: 9591
		[NonSerialized]
		public bool isClimbing;

		// Token: 0x04002578 RID: 9592
		[NonSerialized]
		public bool queuedToBecomeValidToGrabAgain;

		// Token: 0x04002579 RID: 9593
		[NonSerialized]
		public GorillaClimbable dontReclimbLast;

		// Token: 0x0400257A RID: 9594
		[NonSerialized]
		public Vector3 lastAutoReleasePos = Vector3.zero;

		// Token: 0x0400257B RID: 9595
		public Transform handRoot;

		// Token: 0x0400257C RID: 9596
		private const float DIST_FOR_CLEAR_RELEASE = 0.35f;

		// Token: 0x0400257D RID: 9597
		private Collider col;
	}
}
