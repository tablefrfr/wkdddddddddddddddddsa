﻿using System;
using System.Linq;
using System.Reflection;

namespace BuildSafe
{
	// Token: 0x02000628 RID: 1576
	public static class Reflection
	{
		// Token: 0x17000432 RID: 1074
		// (get) Token: 0x06002521 RID: 9505 RVA: 0x000B6E98 File Offset: 0x000B5098
		public static Assembly[] AllAssemblies
		{
			get
			{
				return Reflection.PreFetchAllAssemblies();
			}
		}

		// Token: 0x17000433 RID: 1075
		// (get) Token: 0x06002522 RID: 9506 RVA: 0x000B6E9F File Offset: 0x000B509F
		public static Type[] AllTypes
		{
			get
			{
				return Reflection.PreFetchAllTypes();
			}
		}

		// Token: 0x06002523 RID: 9507 RVA: 0x000B6EA6 File Offset: 0x000B50A6
		static Reflection()
		{
			Reflection.PreFetchAllAssemblies();
			Reflection.PreFetchAllTypes();
		}

		// Token: 0x06002524 RID: 9508 RVA: 0x000B6EB4 File Offset: 0x000B50B4
		private static Assembly[] PreFetchAllAssemblies()
		{
			if (Reflection.gAssemblyCache != null)
			{
				return Reflection.gAssemblyCache;
			}
			return Reflection.gAssemblyCache = (from a in AppDomain.CurrentDomain.GetAssemblies()
			where a != null
			select a).ToArray<Assembly>();
		}

		// Token: 0x06002525 RID: 9509 RVA: 0x000B6F08 File Offset: 0x000B5108
		private static Type[] PreFetchAllTypes()
		{
			if (Reflection.gTypeCache != null)
			{
				return Reflection.gTypeCache;
			}
			return Reflection.gTypeCache = (from t in Reflection.PreFetchAllAssemblies().SelectMany((Assembly a) => a.GetTypes())
			where t != null
			select t).ToArray<Type>();
		}

		// Token: 0x06002526 RID: 9510 RVA: 0x000B6F7C File Offset: 0x000B517C
		public static MethodInfo[] GetMethodsWithAttribute<T>() where T : Attribute
		{
			return (from m in Reflection.AllTypes.SelectMany((Type t) => t.GetRuntimeMethods())
			where m.GetCustomAttributes(typeof(T), false).Length != 0
			select m).ToArray<MethodInfo>();
		}

		// Token: 0x040027F4 RID: 10228
		private static Assembly[] gAssemblyCache;

		// Token: 0x040027F5 RID: 10229
		private static Type[] gTypeCache;
	}
}
