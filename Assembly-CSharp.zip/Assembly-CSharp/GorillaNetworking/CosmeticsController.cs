﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using ExitGames.Client.Photon;
using GorillaLocomotion;
using GorillaNetworking.Store;
using GorillaTag;
using GorillaTag.CosmeticSystem;
using Photon.Pun;
using Photon.Realtime;
using PlayFab;
using PlayFab.ClientModels;
using PlayFab.CloudScriptModels;
using Steamworks;
using UnityEngine;
using UnityEngine.ResourceManagement.AsyncOperations;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace GorillaNetworking
{
	// Token: 0x02000696 RID: 1686
	public class CosmeticsController : MonoBehaviour
	{
		// Token: 0x170004AB RID: 1195
		// (get) Token: 0x0600279A RID: 10138 RVA: 0x000C0A29 File Offset: 0x000BEC29
		// (set) Token: 0x0600279B RID: 10139 RVA: 0x000C0A31 File Offset: 0x000BEC31
		public CosmeticInfoV2[] v2_allCosmetics { get; private set; }

		// Token: 0x170004AC RID: 1196
		// (get) Token: 0x0600279C RID: 10140 RVA: 0x000C0A3A File Offset: 0x000BEC3A
		// (set) Token: 0x0600279D RID: 10141 RVA: 0x000C0A42 File Offset: 0x000BEC42
		public bool v2_allCosmeticsInfoAssetRef_isLoaded { get; private set; }

		// Token: 0x170004AD RID: 1197
		// (get) Token: 0x0600279E RID: 10142 RVA: 0x000C0A4B File Offset: 0x000BEC4B
		// (set) Token: 0x0600279F RID: 10143 RVA: 0x000C0A53 File Offset: 0x000BEC53
		public bool v2_isGetCosmeticsPlayCatalogDataWaitingForCallback { get; private set; }

		// Token: 0x170004AE RID: 1198
		// (get) Token: 0x060027A0 RID: 10144 RVA: 0x000C0A5C File Offset: 0x000BEC5C
		// (set) Token: 0x060027A1 RID: 10145 RVA: 0x000C0A64 File Offset: 0x000BEC64
		public bool v2_isCosmeticPlayFabCatalogDataLoaded { get; private set; }

		// Token: 0x060027A2 RID: 10146 RVA: 0x000C0A6D File Offset: 0x000BEC6D
		private void V2Awake()
		{
			this._allCosmetics = null;
			base.StartCoroutine(this.V2_allCosmeticsInfoAssetRefSO_LoadCoroutine());
		}

		// Token: 0x060027A3 RID: 10147 RVA: 0x000C0A83 File Offset: 0x000BEC83
		private IEnumerator V2_allCosmeticsInfoAssetRefSO_LoadCoroutine()
		{
			while (!PlayFabAuthenticator.instance)
			{
				yield return new WaitForSeconds(1f);
			}
			float[] retryWaitTimes = new float[]
			{
				1f,
				2f,
				4f,
				4f,
				10f,
				10f,
				10f,
				10f,
				10f,
				10f,
				10f,
				10f,
				10f,
				10f,
				30f
			};
			int retryCount = 0;
			AsyncOperationHandle<AllCosmeticsArraySO> newSysAllCosmeticsAsyncOp;
			for (;;)
			{
				Debug.Log(string.Format("Attempting to load runtime key \"{0}\" ", this.v2_allCosmeticsInfoAssetRef.RuntimeKey) + string.Format("(Attempt: {0})", retryCount + 1));
				newSysAllCosmeticsAsyncOp = this.v2_allCosmeticsInfoAssetRef.LoadAssetAsync();
				yield return newSysAllCosmeticsAsyncOp;
				if (ApplicationQuittingState.IsQuitting)
				{
					break;
				}
				if (!newSysAllCosmeticsAsyncOp.IsValid())
				{
					Debug.LogError("`newSysAllCosmeticsAsyncOp` (should never happen) became invalid some how.");
				}
				if (newSysAllCosmeticsAsyncOp.Status == AsyncOperationStatus.Succeeded)
				{
					goto Block_4;
				}
				Debug.LogError(string.Format("Failed to load \"{0}\". ", this.v2_allCosmeticsInfoAssetRef.RuntimeKey) + "Error: " + newSysAllCosmeticsAsyncOp.OperationException.Message);
				float time = retryWaitTimes[Mathf.Min(retryCount, retryWaitTimes.Length - 1)];
				yield return new WaitForSecondsRealtime(time);
				int num = retryCount;
				retryCount = num + 1;
				newSysAllCosmeticsAsyncOp = default(AsyncOperationHandle<AllCosmeticsArraySO>);
			}
			yield break;
			Block_4:
			this.V2_allCosmeticsInfoAssetRef_LoadSucceeded(newSysAllCosmeticsAsyncOp.Result);
			yield break;
		}

		// Token: 0x060027A4 RID: 10148 RVA: 0x000C0A94 File Offset: 0x000BEC94
		private void V2_allCosmeticsInfoAssetRef_LoadSucceeded(AllCosmeticsArraySO allCosmeticsSO)
		{
			this.v2_allCosmetics = new CosmeticInfoV2[allCosmeticsSO.cosmetics.Length];
			for (int i = 0; i < allCosmeticsSO.cosmetics.Length; i++)
			{
				this.v2_allCosmetics[i] = allCosmeticsSO.cosmetics[i].info;
			}
			this._allCosmetics = new List<CosmeticsController.CosmeticItem>(allCosmeticsSO.cosmetics.Length);
			for (int j = 0; j < this.v2_allCosmetics.Length; j++)
			{
				CosmeticInfoV2 cosmeticInfoV = this.v2_allCosmetics[j];
				if (cosmeticInfoV.wardrobeParts != null)
				{
					for (int k = 0; k < cosmeticInfoV.wardrobeParts.Length; k++)
					{
						CosmeticPart cosmeticPart = cosmeticInfoV.wardrobeParts[k];
						cosmeticPart.partType = ECosmeticPartType.Wardrobe;
						cosmeticInfoV.wardrobeParts[k] = cosmeticPart;
					}
				}
				if (cosmeticInfoV.functionalParts != null)
				{
					for (int l = 0; l < cosmeticInfoV.functionalParts.Length; l++)
					{
						CosmeticPart cosmeticPart2 = cosmeticInfoV.functionalParts[l];
						cosmeticPart2.partType = ECosmeticPartType.Functional;
						cosmeticInfoV.functionalParts[l] = cosmeticPart2;
					}
				}
				if (cosmeticInfoV.firstPersonViewParts != null)
				{
					for (int m = 0; m < cosmeticInfoV.firstPersonViewParts.Length; m++)
					{
						CosmeticPart cosmeticPart3 = cosmeticInfoV.firstPersonViewParts[m];
						cosmeticPart3.partType = ECosmeticPartType.FirstPerson;
						cosmeticInfoV.firstPersonViewParts[m] = cosmeticPart3;
					}
				}
				string text = CosmeticsLegacyV1Info.AddMissingDot(cosmeticInfoV.playFabID);
				this._allCosmeticsDictV2[text] = cosmeticInfoV;
				CosmeticsController.CosmeticItem item = new CosmeticsController.CosmeticItem
				{
					itemName = text,
					itemCategory = cosmeticInfoV.category,
					isHoldable = cosmeticInfoV.isHoldable,
					displayName = text,
					itemPicture = cosmeticInfoV.icon,
					overrideDisplayName = cosmeticInfoV.displayName,
					bothHandsHoldable = cosmeticInfoV.usesBothHandSlots,
					isNullItem = false
				};
				this._allCosmetics.Add(item);
			}
			this.v2_allCosmeticsInfoAssetRef_isLoaded = true;
			Action v2_allCosmeticsInfoAssetRef_OnPostLoad = this.V2_allCosmeticsInfoAssetRef_OnPostLoad;
			if (v2_allCosmeticsInfoAssetRef_OnPostLoad == null)
			{
				return;
			}
			v2_allCosmeticsInfoAssetRef_OnPostLoad();
		}

		// Token: 0x060027A5 RID: 10149 RVA: 0x000C0C8F File Offset: 0x000BEE8F
		public bool TryGetCosmeticInfoV2(string playFabId, out CosmeticInfoV2 cosmeticInfo)
		{
			return this._allCosmeticsDictV2.TryGetValue(playFabId, out cosmeticInfo);
		}

		// Token: 0x060027A6 RID: 10150 RVA: 0x000C0C9E File Offset: 0x000BEE9E
		private void V2_ConformCosmeticItemV1DisplayName(ref CosmeticsController.CosmeticItem cosmetic)
		{
			if (cosmetic.itemName == cosmetic.displayName)
			{
				return;
			}
			cosmetic.overrideDisplayName = cosmetic.displayName;
			cosmetic.displayName = cosmetic.itemName;
		}

		// Token: 0x060027A7 RID: 10151 RVA: 0x000C0CCC File Offset: 0x000BEECC
		internal void InitializeCosmeticStands()
		{
			foreach (CosmeticStand cosmeticStand in this.cosmeticStands)
			{
				if (cosmeticStand != null)
				{
					cosmeticStand.InitializeCosmetic();
				}
			}
		}

		// Token: 0x170004AF RID: 1199
		// (get) Token: 0x060027A8 RID: 10152 RVA: 0x000C0D01 File Offset: 0x000BEF01
		// (set) Token: 0x060027A9 RID: 10153 RVA: 0x000C0D08 File Offset: 0x000BEF08
		public static bool hasInstance { get; private set; }

		// Token: 0x170004B0 RID: 1200
		// (get) Token: 0x060027AA RID: 10154 RVA: 0x000C0D10 File Offset: 0x000BEF10
		// (set) Token: 0x060027AB RID: 10155 RVA: 0x000C0D18 File Offset: 0x000BEF18
		public List<CosmeticsController.CosmeticItem> allCosmetics
		{
			get
			{
				return this._allCosmetics;
			}
			set
			{
				this._allCosmetics = value;
			}
		}

		// Token: 0x170004B1 RID: 1201
		// (get) Token: 0x060027AC RID: 10156 RVA: 0x000C0D21 File Offset: 0x000BEF21
		// (set) Token: 0x060027AD RID: 10157 RVA: 0x000C0D29 File Offset: 0x000BEF29
		public bool allCosmeticsDict_isInitialized { get; private set; }

		// Token: 0x170004B2 RID: 1202
		// (get) Token: 0x060027AE RID: 10158 RVA: 0x000C0D32 File Offset: 0x000BEF32
		public Dictionary<string, CosmeticsController.CosmeticItem> allCosmeticsDict
		{
			get
			{
				return this._allCosmeticsDict;
			}
		}

		// Token: 0x170004B3 RID: 1203
		// (get) Token: 0x060027AF RID: 10159 RVA: 0x000C0D3A File Offset: 0x000BEF3A
		// (set) Token: 0x060027B0 RID: 10160 RVA: 0x000C0D42 File Offset: 0x000BEF42
		public bool allCosmeticsItemIDsfromDisplayNamesDict_isInitialized { get; private set; }

		// Token: 0x170004B4 RID: 1204
		// (get) Token: 0x060027B1 RID: 10161 RVA: 0x000C0D4B File Offset: 0x000BEF4B
		public Dictionary<string, string> allCosmeticsItemIDsfromDisplayNamesDict
		{
			get
			{
				return this._allCosmeticsItemIDsfromDisplayNamesDict;
			}
		}

		// Token: 0x060027B2 RID: 10162 RVA: 0x000C0D53 File Offset: 0x000BEF53
		public void AddWardrobeInstance(WardrobeInstance instance)
		{
			this.wardrobes.Add(instance);
			if (CosmeticsV2Spawner_Dirty.allPartsInstantiated)
			{
				this.UpdateWardrobeModelsAndButtons();
			}
		}

		// Token: 0x060027B3 RID: 10163 RVA: 0x000C0D6E File Offset: 0x000BEF6E
		public void RemoveWardrobeInstance(WardrobeInstance instance)
		{
			this.wardrobes.Remove(instance);
		}

		// Token: 0x060027B4 RID: 10164 RVA: 0x000C0D80 File Offset: 0x000BEF80
		public void Awake()
		{
			if (CosmeticsController.instance == null)
			{
				CosmeticsController.instance = this;
				CosmeticsController.hasInstance = true;
			}
			else if (CosmeticsController.instance != this)
			{
				Object.Destroy(base.gameObject);
				return;
			}
			this.V2Awake();
			if (base.gameObject.activeSelf)
			{
				this.catalog = "DLC";
				this.currencyName = "SR";
				this.nullItem = default(CosmeticsController.CosmeticItem);
				this.nullItem.itemName = "null";
				this.nullItem.displayName = "NOTHING";
				this.nullItem.itemPicture = Resources.Load<Sprite>("CosmeticNull_Icon");
				this.nullItem.itemPictureResourceString = "";
				this.nullItem.overrideDisplayName = "NOTHING";
				this.nullItem.meshAtlasResourceString = "";
				this.nullItem.meshResourceString = "";
				this.nullItem.materialResourceString = "";
				this.nullItem.isNullItem = true;
				this._allCosmeticsDict[this.nullItem.itemName] = this.nullItem;
				this._allCosmeticsItemIDsfromDisplayNamesDict[this.nullItem.displayName] = this.nullItem.itemName;
				for (int i = 0; i < 16; i++)
				{
					this.tryOnSet.items[i] = this.nullItem;
				}
				this.cosmeticsPages[0] = 0;
				this.cosmeticsPages[1] = 0;
				this.cosmeticsPages[2] = 0;
				this.cosmeticsPages[3] = 0;
				this.cosmeticsPages[4] = 0;
				this.cosmeticsPages[5] = 0;
				this.cosmeticsPages[6] = 0;
				this.cosmeticsPages[7] = 0;
				this.cosmeticsPages[8] = 0;
				this.cosmeticsPages[9] = 0;
				this.cosmeticsPages[10] = 0;
				this.itemLists[0] = this.unlockedHats;
				this.itemLists[1] = this.unlockedFaces;
				this.itemLists[2] = this.unlockedBadges;
				this.itemLists[3] = this.unlockedPaws;
				this.itemLists[4] = this.unlockedFurs;
				this.itemLists[5] = this.unlockedShirts;
				this.itemLists[6] = this.unlockedPants;
				this.itemLists[7] = this.unlockedArms;
				this.itemLists[8] = this.unlockedBacks;
				this.itemLists[9] = this.unlockedChests;
				this.updateCosmeticsRetries = 0;
				this.maxUpdateCosmeticsRetries = 5;
				this.SwitchToStage(CosmeticsController.ATMStages.Unavailable);
				base.StartCoroutine(this.CheckCanGetDaily());
			}
		}

		// Token: 0x060027B5 RID: 10165 RVA: 0x000C1008 File Offset: 0x000BF208
		public void Start()
		{
			PlayFabTitleDataCache.Instance.GetTitleData("BundleData", delegate(string data)
			{
				this.bundleList.FromJson(data);
			}, delegate(PlayFabError e)
			{
				Debug.LogError(string.Format("Error getting bundle data: {0}", e));
			});
			this.anchorOverrides = GorillaTagger.Instance.offlineVRRig.GetComponent<VRRigAnchorOverrides>();
		}

		// Token: 0x060027B6 RID: 10166 RVA: 0x00003051 File Offset: 0x00001251
		public void Update()
		{
		}

		// Token: 0x060027B7 RID: 10167 RVA: 0x000C1064 File Offset: 0x000BF264
		public static bool CompareCategoryToSavedCosmeticSlots(CosmeticsController.CosmeticCategory category, CosmeticsController.CosmeticSlots slot)
		{
			switch (category)
			{
			case CosmeticsController.CosmeticCategory.Hat:
				return slot == CosmeticsController.CosmeticSlots.Hat;
			case CosmeticsController.CosmeticCategory.Badge:
				return CosmeticsController.CosmeticSlots.Badge == slot;
			case CosmeticsController.CosmeticCategory.Face:
				return CosmeticsController.CosmeticSlots.Face == slot;
			case CosmeticsController.CosmeticCategory.Paw:
				return slot == CosmeticsController.CosmeticSlots.HandRight || slot == CosmeticsController.CosmeticSlots.HandLeft;
			case CosmeticsController.CosmeticCategory.Chest:
				return CosmeticsController.CosmeticSlots.Chest == slot;
			case CosmeticsController.CosmeticCategory.Fur:
				return CosmeticsController.CosmeticSlots.Fur == slot;
			case CosmeticsController.CosmeticCategory.Shirt:
				return CosmeticsController.CosmeticSlots.Shirt == slot;
			case CosmeticsController.CosmeticCategory.Back:
				return slot == CosmeticsController.CosmeticSlots.BackLeft || slot == CosmeticsController.CosmeticSlots.BackRight;
			case CosmeticsController.CosmeticCategory.Arms:
				return slot == CosmeticsController.CosmeticSlots.ArmLeft || slot == CosmeticsController.CosmeticSlots.ArmRight;
			case CosmeticsController.CosmeticCategory.Pants:
				return CosmeticsController.CosmeticSlots.Pants == slot;
			case CosmeticsController.CosmeticCategory.TagEffect:
				return CosmeticsController.CosmeticSlots.TagEffect == slot;
			default:
				return false;
			}
		}

		// Token: 0x060027B8 RID: 10168 RVA: 0x000C10F8 File Offset: 0x000BF2F8
		public static CosmeticsController.CosmeticSlots CategoryToNonTransferrableSlot(CosmeticsController.CosmeticCategory category)
		{
			switch (category)
			{
			case CosmeticsController.CosmeticCategory.Hat:
				return CosmeticsController.CosmeticSlots.Hat;
			case CosmeticsController.CosmeticCategory.Badge:
				return CosmeticsController.CosmeticSlots.Badge;
			case CosmeticsController.CosmeticCategory.Face:
				return CosmeticsController.CosmeticSlots.Face;
			case CosmeticsController.CosmeticCategory.Paw:
				return CosmeticsController.CosmeticSlots.HandRight;
			case CosmeticsController.CosmeticCategory.Chest:
				return CosmeticsController.CosmeticSlots.Chest;
			case CosmeticsController.CosmeticCategory.Fur:
				return CosmeticsController.CosmeticSlots.Fur;
			case CosmeticsController.CosmeticCategory.Shirt:
				return CosmeticsController.CosmeticSlots.Shirt;
			case CosmeticsController.CosmeticCategory.Back:
				return CosmeticsController.CosmeticSlots.Back;
			case CosmeticsController.CosmeticCategory.Arms:
				return CosmeticsController.CosmeticSlots.Arms;
			case CosmeticsController.CosmeticCategory.Pants:
				return CosmeticsController.CosmeticSlots.Pants;
			case CosmeticsController.CosmeticCategory.TagEffect:
				return CosmeticsController.CosmeticSlots.TagEffect;
			default:
				return CosmeticsController.CosmeticSlots.Count;
			}
		}

		// Token: 0x060027B9 RID: 10169 RVA: 0x000C115A File Offset: 0x000BF35A
		private CosmeticsController.CosmeticSlots DropPositionToCosmeticSlot(BodyDockPositions.DropPositions pos)
		{
			switch (pos)
			{
			case BodyDockPositions.DropPositions.LeftArm:
				return CosmeticsController.CosmeticSlots.ArmLeft;
			case BodyDockPositions.DropPositions.RightArm:
				return CosmeticsController.CosmeticSlots.ArmRight;
			case BodyDockPositions.DropPositions.LeftArm | BodyDockPositions.DropPositions.RightArm:
				break;
			case BodyDockPositions.DropPositions.Chest:
				return CosmeticsController.CosmeticSlots.Chest;
			default:
				if (pos == BodyDockPositions.DropPositions.LeftBack)
				{
					return CosmeticsController.CosmeticSlots.BackLeft;
				}
				if (pos == BodyDockPositions.DropPositions.RightBack)
				{
					return CosmeticsController.CosmeticSlots.BackRight;
				}
				break;
			}
			return CosmeticsController.CosmeticSlots.Count;
		}

		// Token: 0x060027BA RID: 10170 RVA: 0x000C118C File Offset: 0x000BF38C
		private static BodyDockPositions.DropPositions CosmeticSlotToDropPosition(CosmeticsController.CosmeticSlots slot)
		{
			switch (slot)
			{
			case CosmeticsController.CosmeticSlots.ArmLeft:
				return BodyDockPositions.DropPositions.LeftArm;
			case CosmeticsController.CosmeticSlots.ArmRight:
				return BodyDockPositions.DropPositions.RightArm;
			case CosmeticsController.CosmeticSlots.BackLeft:
				return BodyDockPositions.DropPositions.LeftBack;
			case CosmeticsController.CosmeticSlots.BackRight:
				return BodyDockPositions.DropPositions.RightBack;
			case CosmeticsController.CosmeticSlots.Chest:
				return BodyDockPositions.DropPositions.Chest;
			}
			return BodyDockPositions.DropPositions.None;
		}

		// Token: 0x060027BB RID: 10171 RVA: 0x000C11C0 File Offset: 0x000BF3C0
		private void SaveItemPreference(CosmeticsController.CosmeticSlots slot, int slotIdx, CosmeticsController.CosmeticItem newItem)
		{
			PlayerPrefs.SetString(CosmeticsController.CosmeticSet.SlotPlayerPreferenceName(slot), newItem.itemName);
			PlayerPrefs.Save();
		}

		// Token: 0x060027BC RID: 10172 RVA: 0x000C11D8 File Offset: 0x000BF3D8
		public void SaveCurrentItemPreferences()
		{
			for (int i = 0; i < 16; i++)
			{
				CosmeticsController.CosmeticSlots slot = (CosmeticsController.CosmeticSlots)i;
				this.SaveItemPreference(slot, i, this.currentWornSet.items[i]);
			}
		}

		// Token: 0x060027BD RID: 10173 RVA: 0x000C1210 File Offset: 0x000BF410
		private void ApplyCosmeticToSet(CosmeticsController.CosmeticSet set, CosmeticsController.CosmeticItem newItem, int slotIdx, CosmeticsController.CosmeticSlots slot, bool applyToPlayerPrefs, List<CosmeticsController.CosmeticSlots> appliedSlots)
		{
			CosmeticsController.CosmeticItem cosmeticItem = (set.items[slotIdx].itemName == newItem.itemName) ? this.nullItem : newItem;
			set.items[slotIdx] = cosmeticItem;
			if (applyToPlayerPrefs)
			{
				this.SaveItemPreference(slot, slotIdx, cosmeticItem);
			}
			appliedSlots.Add(slot);
		}

		// Token: 0x060027BE RID: 10174 RVA: 0x000C126C File Offset: 0x000BF46C
		private void PrivApplyCosmeticItemToSet(CosmeticsController.CosmeticSet set, CosmeticsController.CosmeticItem newItem, bool isLeftHand, bool applyToPlayerPrefs, List<CosmeticsController.CosmeticSlots> appliedSlots)
		{
			if (newItem.isNullItem)
			{
				return;
			}
			if (CosmeticsController.CosmeticSet.IsHoldable(newItem))
			{
				BodyDockPositions.DockingResult dockingResult = GorillaTagger.Instance.offlineVRRig.GetComponent<BodyDockPositions>().ToggleWithHandedness(newItem.displayName, isLeftHand, newItem.bothHandsHoldable);
				foreach (BodyDockPositions.DropPositions pos in dockingResult.positionsDisabled)
				{
					CosmeticsController.CosmeticSlots cosmeticSlots = this.DropPositionToCosmeticSlot(pos);
					if (cosmeticSlots != CosmeticsController.CosmeticSlots.Count)
					{
						int num = (int)cosmeticSlots;
						set.items[num] = this.nullItem;
						if (applyToPlayerPrefs)
						{
							this.SaveItemPreference(cosmeticSlots, num, this.nullItem);
						}
					}
				}
				using (List<BodyDockPositions.DropPositions>.Enumerator enumerator = dockingResult.dockedPosition.GetEnumerator())
				{
					while (enumerator.MoveNext())
					{
						BodyDockPositions.DropPositions dropPositions = enumerator.Current;
						if (dropPositions != BodyDockPositions.DropPositions.None)
						{
							CosmeticsController.CosmeticSlots cosmeticSlots2 = this.DropPositionToCosmeticSlot(dropPositions);
							int num2 = (int)cosmeticSlots2;
							set.items[num2] = newItem;
							if (applyToPlayerPrefs)
							{
								this.SaveItemPreference(cosmeticSlots2, num2, newItem);
							}
							appliedSlots.Add(cosmeticSlots2);
						}
					}
					return;
				}
			}
			if (newItem.itemCategory == CosmeticsController.CosmeticCategory.Paw)
			{
				CosmeticsController.CosmeticSlots cosmeticSlots3 = isLeftHand ? CosmeticsController.CosmeticSlots.HandLeft : CosmeticsController.CosmeticSlots.HandRight;
				int slotIdx = (int)cosmeticSlots3;
				this.ApplyCosmeticToSet(set, newItem, slotIdx, cosmeticSlots3, applyToPlayerPrefs, appliedSlots);
				CosmeticsController.CosmeticSlots cosmeticSlots4 = CosmeticsController.CosmeticSet.OppositeSlot(cosmeticSlots3);
				int num3 = (int)cosmeticSlots4;
				if (newItem.bothHandsHoldable)
				{
					this.ApplyCosmeticToSet(set, this.nullItem, num3, cosmeticSlots4, applyToPlayerPrefs, appliedSlots);
					return;
				}
				if (set.items[num3].itemName == newItem.itemName)
				{
					this.ApplyCosmeticToSet(set, this.nullItem, num3, cosmeticSlots4, applyToPlayerPrefs, appliedSlots);
				}
				if (set.items[num3].bothHandsHoldable)
				{
					this.ApplyCosmeticToSet(set, this.nullItem, num3, cosmeticSlots4, applyToPlayerPrefs, appliedSlots);
					return;
				}
			}
			else
			{
				CosmeticsController.CosmeticSlots cosmeticSlots5 = CosmeticsController.CategoryToNonTransferrableSlot(newItem.itemCategory);
				int slotIdx2 = (int)cosmeticSlots5;
				this.ApplyCosmeticToSet(set, newItem, slotIdx2, cosmeticSlots5, applyToPlayerPrefs, appliedSlots);
			}
		}

		// Token: 0x060027BF RID: 10175 RVA: 0x000C1470 File Offset: 0x000BF670
		public List<CosmeticsController.CosmeticSlots> ApplyCosmeticItemToSet(CosmeticsController.CosmeticSet set, CosmeticsController.CosmeticItem newItem, bool isLeftHand, bool applyToPlayerPrefs)
		{
			List<CosmeticsController.CosmeticSlots> list = new List<CosmeticsController.CosmeticSlots>(2);
			if (newItem.itemCategory == CosmeticsController.CosmeticCategory.Set)
			{
				foreach (string itemID in newItem.bundledItems)
				{
					CosmeticsController.CosmeticItem itemFromDict = this.GetItemFromDict(itemID);
					this.PrivApplyCosmeticItemToSet(set, itemFromDict, isLeftHand, applyToPlayerPrefs, list);
				}
			}
			else
			{
				this.PrivApplyCosmeticItemToSet(set, newItem, isLeftHand, applyToPlayerPrefs, list);
			}
			return list;
		}

		// Token: 0x060027C0 RID: 10176 RVA: 0x000C14CC File Offset: 0x000BF6CC
		public void RemoveCosmeticItemFromSet(CosmeticsController.CosmeticSet set, string itemName, bool applyToPlayerPrefs)
		{
			this.cachedSet.CopyItems(set);
			for (int i = 0; i < 16; i++)
			{
				if (set.items[i].displayName == itemName)
				{
					set.items[i] = this.nullItem;
					if (applyToPlayerPrefs)
					{
						this.SaveItemPreference((CosmeticsController.CosmeticSlots)i, i, this.nullItem);
					}
				}
			}
			VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
			BodyDockPositions component = offlineVRRig.GetComponent<BodyDockPositions>();
			set.ActivateCosmetics(this.cachedSet, offlineVRRig, component, CosmeticsController.instance.nullItem, offlineVRRig.cosmeticsObjectRegistry);
		}

		// Token: 0x060027C1 RID: 10177 RVA: 0x000C1560 File Offset: 0x000BF760
		public void PressFittingRoomButton(FittingRoomButton pressedFittingRoomButton, bool isLeftHand)
		{
			BundleManager.instance._tryOnBundlesStand.ClearSelectedBundle();
			this.ApplyCosmeticItemToSet(this.tryOnSet, pressedFittingRoomButton.currentCosmeticItem, isLeftHand, false);
			this.UpdateShoppingCart();
			this.UpdateWornCosmetics(true);
		}

		// Token: 0x060027C2 RID: 10178 RVA: 0x000C1598 File Offset: 0x000BF798
		public CosmeticsController.EWearingCosmeticSet CheckIfCosmeticSetMatchesItemSet(CosmeticsController.CosmeticSet set, string itemName)
		{
			CosmeticsController.EWearingCosmeticSet ewearingCosmeticSet = CosmeticsController.EWearingCosmeticSet.NotASet;
			CosmeticsController.CosmeticItem cosmeticItem = this.allCosmeticsDict[itemName];
			if (cosmeticItem.bundledItems.Length != 0)
			{
				foreach (string key in cosmeticItem.bundledItems)
				{
					if (this.AnyMatch(set, this.allCosmeticsDict[key]))
					{
						if (ewearingCosmeticSet == CosmeticsController.EWearingCosmeticSet.NotASet)
						{
							ewearingCosmeticSet = CosmeticsController.EWearingCosmeticSet.Complete;
						}
						else if (ewearingCosmeticSet == CosmeticsController.EWearingCosmeticSet.NotWearing)
						{
							ewearingCosmeticSet = CosmeticsController.EWearingCosmeticSet.Partial;
						}
					}
					else if (ewearingCosmeticSet == CosmeticsController.EWearingCosmeticSet.NotASet)
					{
						ewearingCosmeticSet = CosmeticsController.EWearingCosmeticSet.NotWearing;
					}
					else if (ewearingCosmeticSet == CosmeticsController.EWearingCosmeticSet.Complete)
					{
						ewearingCosmeticSet = CosmeticsController.EWearingCosmeticSet.Partial;
					}
				}
			}
			return ewearingCosmeticSet;
		}

		// Token: 0x060027C3 RID: 10179 RVA: 0x000C160C File Offset: 0x000BF80C
		public void PressCosmeticStandButton(CosmeticStand pressedStand)
		{
			this.searchIndex = this.currentCart.IndexOf(pressedStand.thisCosmeticItem);
			if (this.searchIndex != -1)
			{
				GorillaTelemetry.PostShopEvent(GorillaTagger.Instance.offlineVRRig, GTShopEventType.cart_item_remove, pressedStand.thisCosmeticItem);
				this.currentCart.RemoveAt(this.searchIndex);
				pressedStand.isOn = false;
				for (int i = 0; i < 16; i++)
				{
					if (pressedStand.thisCosmeticItem.itemName == this.tryOnSet.items[i].itemName)
					{
						this.tryOnSet.items[i] = this.nullItem;
					}
				}
			}
			else
			{
				GorillaTelemetry.PostShopEvent(GorillaTagger.Instance.offlineVRRig, GTShopEventType.cart_item_add, pressedStand.thisCosmeticItem);
				this.currentCart.Insert(0, pressedStand.thisCosmeticItem);
				pressedStand.isOn = true;
				if (this.currentCart.Count > this.fittingRoomButtons.Length)
				{
					foreach (CosmeticStand cosmeticStand in this.cosmeticStands)
					{
						if (!(cosmeticStand == null) && cosmeticStand.thisCosmeticItem.itemName == this.currentCart[this.fittingRoomButtons.Length].itemName)
						{
							cosmeticStand.isOn = false;
							cosmeticStand.UpdateColor();
							break;
						}
					}
					this.currentCart.RemoveAt(this.fittingRoomButtons.Length);
				}
			}
			pressedStand.UpdateColor();
			this.UpdateShoppingCart();
		}

		// Token: 0x060027C4 RID: 10180 RVA: 0x000C1778 File Offset: 0x000BF978
		public void PressWardrobeItemButton(CosmeticsController.CosmeticItem cosmeticItem, bool isLeftHand)
		{
			if (cosmeticItem.isNullItem)
			{
				return;
			}
			CosmeticsController.CosmeticItem itemFromDict = this.GetItemFromDict(cosmeticItem.itemName);
			foreach (CosmeticsController.CosmeticSlots cosmeticSlots in this.ApplyCosmeticItemToSet(this.currentWornSet, itemFromDict, isLeftHand, true))
			{
				this.tryOnSet.items[(int)cosmeticSlots] = this.nullItem;
			}
			this.UpdateShoppingCart();
			this.UpdateWornCosmetics(true);
			Action onCosmeticsUpdated = this.OnCosmeticsUpdated;
			if (onCosmeticsUpdated == null)
			{
				return;
			}
			onCosmeticsUpdated();
		}

		// Token: 0x060027C5 RID: 10181 RVA: 0x000C1818 File Offset: 0x000BFA18
		public void PressWardrobeFunctionButton(string function)
		{
			uint num = <PrivateImplementationDetails>.ComputeStringHash(function);
			if (num <= 2554875734U)
			{
				if (num <= 895779448U)
				{
					if (num != 292255708U)
					{
						if (num != 306900080U)
						{
							if (num == 895779448U)
							{
								if (function == "badge")
								{
									if (this.wardrobeType == 2)
									{
										return;
									}
									this.wardrobeType = 2;
								}
							}
						}
						else if (function == "left")
						{
							this.cosmeticsPages[this.wardrobeType] = this.cosmeticsPages[this.wardrobeType] - 1;
							if (this.cosmeticsPages[this.wardrobeType] < 0)
							{
								this.cosmeticsPages[this.wardrobeType] = (this.itemLists[this.wardrobeType].Count - 1) / 3;
							}
						}
					}
					else if (function == "face")
					{
						if (this.wardrobeType == 1)
						{
							return;
						}
						this.wardrobeType = 1;
					}
				}
				else if (num != 1538531746U)
				{
					if (num != 2028154341U)
					{
						if (num == 2554875734U)
						{
							if (function == "chest")
							{
								if (this.wardrobeType == 8)
								{
									return;
								}
								this.wardrobeType = 8;
							}
						}
					}
					else if (function == "right")
					{
						this.cosmeticsPages[this.wardrobeType] = this.cosmeticsPages[this.wardrobeType] + 1;
						if (this.cosmeticsPages[this.wardrobeType] > (this.itemLists[this.wardrobeType].Count - 1) / 3)
						{
							this.cosmeticsPages[this.wardrobeType] = 0;
						}
					}
				}
				else if (function == "back")
				{
					if (this.wardrobeType == 7)
					{
						return;
					}
					this.wardrobeType = 7;
				}
			}
			else if (num <= 3034286914U)
			{
				if (num != 2633735346U)
				{
					if (num != 2953262278U)
					{
						if (num == 3034286914U)
						{
							if (function == "fur")
							{
								if (this.wardrobeType == 4)
								{
									return;
								}
								this.wardrobeType = 4;
							}
						}
					}
					else if (function == "outfit")
					{
						if (this.wardrobeType == 5)
						{
							return;
						}
						this.wardrobeType = 5;
					}
				}
				else if (function == "arms")
				{
					if (this.wardrobeType == 6)
					{
						return;
					}
					this.wardrobeType = 6;
				}
			}
			else if (num <= 3300536096U)
			{
				if (num != 3081164502U)
				{
					if (num == 3300536096U)
					{
						if (function == "hand")
						{
							if (this.wardrobeType == 3)
							{
								return;
							}
							this.wardrobeType = 3;
						}
					}
				}
				else if (function == "tagEffect")
				{
					if (this.wardrobeType == 10)
					{
						return;
					}
					this.wardrobeType = 10;
				}
			}
			else if (num != 3568683773U)
			{
				if (num == 4072609730U)
				{
					if (function == "hat")
					{
						if (this.wardrobeType == 0)
						{
							return;
						}
						this.wardrobeType = 0;
					}
				}
			}
			else if (function == "reserved")
			{
				if (this.wardrobeType == 9)
				{
					return;
				}
				this.wardrobeType = 9;
			}
			this.UpdateWardrobeModelsAndButtons();
			Action onCosmeticsUpdated = this.OnCosmeticsUpdated;
			if (onCosmeticsUpdated == null)
			{
				return;
			}
			onCosmeticsUpdated();
		}

		// Token: 0x060027C6 RID: 10182 RVA: 0x000C1BA4 File Offset: 0x000BFDA4
		public void ClearCheckout()
		{
			GorillaTelemetry.PostShopEvent(GorillaTagger.Instance.offlineVRRig, GTShopEventType.checkout_cancel, this.currentCart);
			this.itemToBuy = this.nullItem;
			this.checkoutHeadModel.SetCosmeticActive(this.itemToBuy.displayName, false);
			this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.Start;
			this.ProcessPurchaseItemState(null, false);
		}

		// Token: 0x060027C7 RID: 10183 RVA: 0x000C1BFC File Offset: 0x000BFDFC
		public bool RemoveItemFromCart(CosmeticsController.CosmeticItem cosmeticItem)
		{
			this.searchIndex = this.currentCart.IndexOf(cosmeticItem);
			if (this.searchIndex != -1)
			{
				this.currentCart.RemoveAt(this.searchIndex);
				for (int i = 0; i < 16; i++)
				{
					if (cosmeticItem.itemName == this.tryOnSet.items[i].itemName)
					{
						this.tryOnSet.items[i] = this.nullItem;
					}
				}
				return true;
			}
			return false;
		}

		// Token: 0x060027C8 RID: 10184 RVA: 0x000C1C80 File Offset: 0x000BFE80
		public void PressCheckoutCartButton(CheckoutCartButton pressedCheckoutCartButton, bool isLeftHand)
		{
			if (this.currentPurchaseItemStage != CosmeticsController.PurchaseItemStages.Buying)
			{
				this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.CheckoutButtonPressed;
				this.tryOnSet.ClearSet(this.nullItem);
				if (this.itemToBuy.displayName == pressedCheckoutCartButton.currentCosmeticItem.displayName)
				{
					this.itemToBuy = this.nullItem;
					this.checkoutHeadModel.SetCosmeticActive(this.itemToBuy.displayName, false);
				}
				else
				{
					this.itemToBuy = pressedCheckoutCartButton.currentCosmeticItem;
					this.checkoutHeadModel.SetCosmeticActive(this.itemToBuy.displayName, false);
					if (this.itemToBuy.bundledItems != null && this.itemToBuy.bundledItems.Length != 0)
					{
						List<string> list = new List<string>();
						foreach (string itemID in this.itemToBuy.bundledItems)
						{
							this.tempItem = this.GetItemFromDict(itemID);
							list.Add(this.tempItem.displayName);
						}
						this.checkoutHeadModel.SetCosmeticActiveArray(list.ToArray(), new bool[list.Count]);
					}
					this.ApplyCosmeticItemToSet(this.tryOnSet, pressedCheckoutCartButton.currentCosmeticItem, isLeftHand, false);
					this.UpdateWornCosmetics(true);
				}
				this.ProcessPurchaseItemState(null, isLeftHand);
				this.UpdateShoppingCart();
			}
		}

		// Token: 0x060027C9 RID: 10185 RVA: 0x000C1DBC File Offset: 0x000BFFBC
		public void PressPurchaseItemButton(PurchaseItemButton pressedPurchaseItemButton, bool isLeftHand)
		{
			this.ProcessPurchaseItemState(pressedPurchaseItemButton.buttonSide, isLeftHand);
		}

		// Token: 0x060027CA RID: 10186 RVA: 0x000C1DCC File Offset: 0x000BFFCC
		public void PurchaseBundle(StoreBundle bundleToPurchase)
		{
			if (bundleToPurchase.playfabBundleID != "NULL")
			{
				this.SwitchToStage(CosmeticsController.ATMStages.Begin);
				this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.Start;
				this.ProcessPurchaseItemState("left", false);
				this.itemToPurchase = bundleToPurchase.playfabBundleID;
				this.SteamPurchase();
				this.SwitchToStage(CosmeticsController.ATMStages.Purchasing);
			}
		}

		// Token: 0x060027CB RID: 10187 RVA: 0x000C1E20 File Offset: 0x000C0020
		public void PressEarlyAccessButton()
		{
			this.SwitchToStage(CosmeticsController.ATMStages.Begin);
			this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.Start;
			this.ProcessPurchaseItemState("left", false);
			this.itemToPurchase = this.BundlePlayfabItemName;
			this.shinyRocksCost = (float)this.BundleShinyRocks;
			this.SteamPurchase();
			this.SwitchToStage(CosmeticsController.ATMStages.Purchasing);
		}

		// Token: 0x060027CC RID: 10188 RVA: 0x000C1E6D File Offset: 0x000C006D
		public void PressPurchaseBundleButton(string PlayFabItemName)
		{
			BundleManager.instance.BundlePurchaseButtonPressed(PlayFabItemName);
		}

		// Token: 0x060027CD RID: 10189 RVA: 0x000C1E7C File Offset: 0x000C007C
		public void ProcessPurchaseItemState(string buttonSide, bool isLeftHand)
		{
			switch (this.currentPurchaseItemStage)
			{
			case CosmeticsController.PurchaseItemStages.Start:
				this.itemToBuy = this.nullItem;
				this.FormattedPurchaseText("SELECT AN ITEM FROM YOUR CART TO PURCHASE!");
				this.UpdateShoppingCart();
				return;
			case CosmeticsController.PurchaseItemStages.CheckoutButtonPressed:
				GorillaTelemetry.PostShopEvent(GorillaTagger.Instance.offlineVRRig, GTShopEventType.checkout_start, this.currentCart);
				this.searchIndex = this.unlockedCosmetics.FindIndex((CosmeticsController.CosmeticItem x) => this.itemToBuy.itemName == x.itemName);
				if (this.searchIndex > -1)
				{
					this.FormattedPurchaseText("YOU ALREADY OWN THIS ITEM!");
					this.leftPurchaseButton.myText.text = "-";
					this.rightPurchaseButton.myText.text = "-";
					this.leftPurchaseButton.buttonRenderer.material = this.leftPurchaseButton.pressedMaterial;
					this.rightPurchaseButton.buttonRenderer.material = this.rightPurchaseButton.pressedMaterial;
					this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.ItemOwned;
					return;
				}
				if (this.itemToBuy.cost <= this.currencyBalance)
				{
					this.FormattedPurchaseText("DO YOU WANT TO BUY THIS ITEM?");
					this.leftPurchaseButton.myText.text = "NO!";
					this.rightPurchaseButton.myText.text = "YES!";
					this.leftPurchaseButton.buttonRenderer.material = this.leftPurchaseButton.unpressedMaterial;
					this.rightPurchaseButton.buttonRenderer.material = this.rightPurchaseButton.unpressedMaterial;
					this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.ItemSelected;
					return;
				}
				this.FormattedPurchaseText("INSUFFICIENT SHINY ROCKS FOR THIS ITEM!");
				this.leftPurchaseButton.myText.text = "-";
				this.rightPurchaseButton.myText.text = "-";
				this.leftPurchaseButton.buttonRenderer.material = this.leftPurchaseButton.pressedMaterial;
				this.rightPurchaseButton.buttonRenderer.material = this.rightPurchaseButton.pressedMaterial;
				this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.Start;
				return;
			case CosmeticsController.PurchaseItemStages.ItemSelected:
				if (buttonSide == "right")
				{
					GorillaTelemetry.PostShopEvent(GorillaTagger.Instance.offlineVRRig, GTShopEventType.item_select, this.itemToBuy);
					this.FormattedPurchaseText("ARE YOU REALLY SURE?");
					this.leftPurchaseButton.myText.text = "YES! I NEED IT!";
					this.rightPurchaseButton.myText.text = "LET ME THINK ABOUT IT";
					this.leftPurchaseButton.buttonRenderer.material = this.leftPurchaseButton.unpressedMaterial;
					this.rightPurchaseButton.buttonRenderer.material = this.rightPurchaseButton.unpressedMaterial;
					this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.FinalPurchaseAcknowledgement;
					return;
				}
				this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.CheckoutButtonPressed;
				this.ProcessPurchaseItemState(null, isLeftHand);
				return;
			case CosmeticsController.PurchaseItemStages.ItemOwned:
			case CosmeticsController.PurchaseItemStages.Buying:
				break;
			case CosmeticsController.PurchaseItemStages.FinalPurchaseAcknowledgement:
				if (buttonSide == "left")
				{
					this.FormattedPurchaseText("PURCHASING ITEM...");
					this.leftPurchaseButton.myText.text = "-";
					this.rightPurchaseButton.myText.text = "-";
					this.leftPurchaseButton.buttonRenderer.material = this.leftPurchaseButton.pressedMaterial;
					this.rightPurchaseButton.buttonRenderer.material = this.rightPurchaseButton.pressedMaterial;
					this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.Buying;
					this.isLastHandTouchedLeft = isLeftHand;
					this.PurchaseItem();
					return;
				}
				this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.CheckoutButtonPressed;
				this.ProcessPurchaseItemState(null, isLeftHand);
				return;
			case CosmeticsController.PurchaseItemStages.Success:
			{
				this.FormattedPurchaseText("SUCCESS! ENJOY YOUR NEW ITEM!");
				VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
				offlineVRRig.concatStringOfCosmeticsAllowed += this.itemToBuy.itemName;
				CosmeticsController.CosmeticItem itemFromDict = this.GetItemFromDict(this.itemToBuy.itemName);
				if (itemFromDict.bundledItems != null)
				{
					foreach (string str in itemFromDict.bundledItems)
					{
						VRRig offlineVRRig2 = GorillaTagger.Instance.offlineVRRig;
						offlineVRRig2.concatStringOfCosmeticsAllowed += str;
					}
				}
				this.tryOnSet.ClearSet(this.nullItem);
				this.UpdateShoppingCart();
				this.ApplyCosmeticItemToSet(this.currentWornSet, itemFromDict, isLeftHand, true);
				this.UpdateShoppingCart();
				this.UpdateWornCosmetics(false);
				this.leftPurchaseButton.myText.text = "-";
				this.rightPurchaseButton.myText.text = "-";
				this.leftPurchaseButton.buttonRenderer.material = this.leftPurchaseButton.pressedMaterial;
				this.rightPurchaseButton.buttonRenderer.material = this.rightPurchaseButton.pressedMaterial;
				break;
			}
			case CosmeticsController.PurchaseItemStages.Failure:
				this.FormattedPurchaseText("ERROR IN PURCHASING ITEM! NO MONEY WAS SPENT. SELECT ANOTHER ITEM.");
				this.leftPurchaseButton.myText.text = "-";
				this.rightPurchaseButton.myText.text = "-";
				this.leftPurchaseButton.buttonRenderer.material = this.leftPurchaseButton.pressedMaterial;
				this.rightPurchaseButton.buttonRenderer.material = this.rightPurchaseButton.pressedMaterial;
				return;
			default:
				return;
			}
		}

		// Token: 0x060027CE RID: 10190 RVA: 0x000C2348 File Offset: 0x000C0548
		public void FormattedPurchaseText(string finalLineVar)
		{
			this.finalLine = finalLineVar;
			this.purchaseText.text = string.Concat(new string[]
			{
				"SELECTION: ",
				this.GetItemDisplayName(this.itemToBuy),
				"\nITEM COST: ",
				this.itemToBuy.cost.ToString(),
				"\nYOU HAVE: ",
				this.currencyBalance.ToString(),
				"\n\n",
				this.finalLine
			});
		}

		// Token: 0x060027CF RID: 10191 RVA: 0x000C23CC File Offset: 0x000C05CC
		public void PurchaseItem()
		{
			PlayFabClientAPI.PurchaseItem(new PurchaseItemRequest
			{
				ItemId = this.itemToBuy.itemName,
				Price = this.itemToBuy.cost,
				VirtualCurrency = this.currencyName,
				CatalogVersion = this.catalog
			}, delegate(PurchaseItemResult result)
			{
				if (result.Items.Count > 0)
				{
					foreach (ItemInstance itemInstance in result.Items)
					{
						CosmeticsController.CosmeticItem itemFromDict = this.GetItemFromDict(this.itemToBuy.itemName);
						if (itemFromDict.itemCategory == CosmeticsController.CosmeticCategory.Set)
						{
							this.UnlockItem(itemInstance.ItemId);
							foreach (string itemIdToUnlock in itemFromDict.bundledItems)
							{
								this.UnlockItem(itemIdToUnlock);
							}
						}
						else
						{
							this.UnlockItem(itemInstance.ItemId);
						}
					}
					this.UpdateMyCosmetics();
					if (PhotonNetwork.InRoom)
					{
						base.StartCoroutine(this.CheckIfMyCosmeticsUpdated(this.itemToBuy.itemName));
					}
					this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.Success;
					this.currencyBalance -= this.itemToBuy.cost;
					this.UpdateShoppingCart();
					this.ProcessPurchaseItemState(null, this.isLastHandTouchedLeft);
					return;
				}
				this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.Failure;
				this.ProcessPurchaseItemState(null, false);
			}, delegate(PlayFabError error)
			{
				this.currentPurchaseItemStage = CosmeticsController.PurchaseItemStages.Failure;
				this.ProcessPurchaseItemState(null, false);
			}, null, null);
		}

		// Token: 0x060027D0 RID: 10192 RVA: 0x000C2438 File Offset: 0x000C0638
		private void UnlockItem(string itemIdToUnlock)
		{
			int num = this.allCosmetics.FindIndex((CosmeticsController.CosmeticItem x) => itemIdToUnlock == x.itemName);
			if (num > -1)
			{
				if (!this.unlockedCosmetics.Contains(this.allCosmetics[num]))
				{
					this.unlockedCosmetics.Add(this.allCosmetics[num]);
				}
				this.concatStringCosmeticsAllowed += this.allCosmetics[num].itemName;
				switch (this.allCosmetics[num].itemCategory)
				{
				case CosmeticsController.CosmeticCategory.Hat:
					if (!this.unlockedHats.Contains(this.allCosmetics[num]))
					{
						this.unlockedHats.Add(this.allCosmetics[num]);
						return;
					}
					break;
				case CosmeticsController.CosmeticCategory.Badge:
					if (!this.unlockedBadges.Contains(this.allCosmetics[num]))
					{
						this.unlockedBadges.Add(this.allCosmetics[num]);
						return;
					}
					break;
				case CosmeticsController.CosmeticCategory.Face:
					if (!this.unlockedFaces.Contains(this.allCosmetics[num]))
					{
						this.unlockedFaces.Add(this.allCosmetics[num]);
						return;
					}
					break;
				case CosmeticsController.CosmeticCategory.Paw:
					if (!this.unlockedPaws.Contains(this.allCosmetics[num]))
					{
						this.unlockedPaws.Add(this.allCosmetics[num]);
						return;
					}
					break;
				case CosmeticsController.CosmeticCategory.Chest:
					if (!this.unlockedChests.Contains(this.allCosmetics[num]))
					{
						this.unlockedChests.Add(this.allCosmetics[num]);
						return;
					}
					break;
				case CosmeticsController.CosmeticCategory.Fur:
					if (!this.unlockedFurs.Contains(this.allCosmetics[num]))
					{
						this.unlockedFurs.Add(this.allCosmetics[num]);
						return;
					}
					break;
				case CosmeticsController.CosmeticCategory.Shirt:
					if (!this.unlockedShirts.Contains(this.allCosmetics[num]))
					{
						this.unlockedShirts.Add(this.allCosmetics[num]);
						return;
					}
					break;
				case CosmeticsController.CosmeticCategory.Back:
					if (!this.unlockedBacks.Contains(this.allCosmetics[num]))
					{
						this.unlockedBacks.Add(this.allCosmetics[num]);
						return;
					}
					break;
				case CosmeticsController.CosmeticCategory.Arms:
					if (!this.unlockedArms.Contains(this.allCosmetics[num]))
					{
						this.unlockedArms.Add(this.allCosmetics[num]);
						return;
					}
					break;
				case CosmeticsController.CosmeticCategory.Pants:
					if (!this.unlockedPants.Contains(this.allCosmetics[num]))
					{
						this.unlockedPants.Add(this.allCosmetics[num]);
					}
					break;
				case CosmeticsController.CosmeticCategory.TagEffect:
				case CosmeticsController.CosmeticCategory.Count:
				case CosmeticsController.CosmeticCategory.Set:
					break;
				default:
					return;
				}
			}
		}

		// Token: 0x060027D1 RID: 10193 RVA: 0x000C2710 File Offset: 0x000C0910
		private IEnumerator CheckIfMyCosmeticsUpdated(string itemToBuyID)
		{
			yield return new WaitForSeconds(1f);
			this.foundCosmetic = false;
			this.attempts = 0;
			while (!this.foundCosmetic && this.attempts < 10 && PhotonNetwork.InRoom)
			{
				this.playerIDList.Clear();
				if (this.UseNewCosmeticsPath())
				{
					this.playerIDList.Add("Inventory");
					PlayFabClientAPI.GetSharedGroupData(new GetSharedGroupDataRequest
					{
						Keys = this.playerIDList,
						SharedGroupId = PhotonNetwork.LocalPlayer.UserId + "Inventory"
					}, delegate(GetSharedGroupDataResult result)
					{
						this.attempts++;
						foreach (KeyValuePair<string, SharedGroupDataRecord> keyValuePair in result.Data)
						{
							if (keyValuePair.Value.Value.Contains(itemToBuyID))
							{
								PhotonNetwork.RaiseEvent(199, null, new RaiseEventOptions
								{
									Receivers = ReceiverGroup.Others
								}, SendOptions.SendReliable);
								this.foundCosmetic = true;
							}
						}
						if (this.foundCosmetic)
						{
							this.UpdateWornCosmetics(true);
						}
					}, delegate(PlayFabError error)
					{
						this.attempts++;
						this.ReauthOrBan(error);
					}, null, null);
					yield return new WaitForSeconds(1f);
				}
				else
				{
					this.playerIDList.Add(PhotonNetwork.LocalPlayer.ActorNumber.ToString());
					PlayFabClientAPI.GetSharedGroupData(new GetSharedGroupDataRequest
					{
						Keys = this.playerIDList,
						SharedGroupId = PhotonNetwork.CurrentRoom.Name + Regex.Replace(PhotonNetwork.CloudRegion, "[^a-zA-Z0-9]", "").ToUpper()
					}, delegate(GetSharedGroupDataResult result)
					{
						this.attempts++;
						foreach (KeyValuePair<string, SharedGroupDataRecord> keyValuePair in result.Data)
						{
							if (keyValuePair.Value.Value.Contains(itemToBuyID))
							{
								PhotonNetwork.RaiseEvent(199, null, new RaiseEventOptions
								{
									Receivers = ReceiverGroup.Others
								}, SendOptions.SendReliable);
								this.foundCosmetic = true;
							}
						}
						if (this.foundCosmetic)
						{
							this.UpdateWornCosmetics(true);
						}
					}, delegate(PlayFabError error)
					{
						this.attempts++;
						if (error.Error == PlayFabErrorCode.NotAuthenticated)
						{
							PlayFabAuthenticator.instance.AuthenticateWithPlayFab();
							return;
						}
						if (error.Error == PlayFabErrorCode.AccountBanned)
						{
							Application.Quit();
							PhotonNetwork.Disconnect();
							Object.DestroyImmediate(PhotonNetworkController.Instance);
							Object.DestroyImmediate(GorillaLocomotion.Player.Instance);
							GameObject[] array = Object.FindObjectsOfType<GameObject>();
							for (int i = 0; i < array.Length; i++)
							{
								Object.Destroy(array[i]);
							}
						}
					}, null, null);
					yield return new WaitForSeconds(1f);
				}
			}
			yield break;
		}

		// Token: 0x060027D2 RID: 10194 RVA: 0x000C2728 File Offset: 0x000C0928
		public void UpdateWardrobeModelsAndButtons()
		{
			if (!CosmeticsV2Spawner_Dirty.allPartsInstantiated)
			{
				return;
			}
			foreach (WardrobeInstance wardrobeInstance in this.wardrobes)
			{
				wardrobeInstance.wardrobeItemButtons[0].currentCosmeticItem = ((this.cosmeticsPages[this.wardrobeType] * 3 < this.itemLists[this.wardrobeType].Count) ? this.itemLists[this.wardrobeType][this.cosmeticsPages[this.wardrobeType] * 3] : this.nullItem);
				wardrobeInstance.wardrobeItemButtons[1].currentCosmeticItem = ((this.cosmeticsPages[this.wardrobeType] * 3 + 1 < this.itemLists[this.wardrobeType].Count) ? this.itemLists[this.wardrobeType][this.cosmeticsPages[this.wardrobeType] * 3 + 1] : this.nullItem);
				wardrobeInstance.wardrobeItemButtons[2].currentCosmeticItem = ((this.cosmeticsPages[this.wardrobeType] * 3 + 2 < this.itemLists[this.wardrobeType].Count) ? this.itemLists[this.wardrobeType][this.cosmeticsPages[this.wardrobeType] * 3 + 2] : this.nullItem);
				this.iterator = 0;
				while (this.iterator < wardrobeInstance.wardrobeItemButtons.Length)
				{
					CosmeticsController.CosmeticItem currentCosmeticItem = wardrobeInstance.wardrobeItemButtons[this.iterator].currentCosmeticItem;
					wardrobeInstance.wardrobeItemButtons[this.iterator].isOn = (!currentCosmeticItem.isNullItem && this.AnyMatch(this.currentWornSet, currentCosmeticItem));
					wardrobeInstance.wardrobeItemButtons[this.iterator].UpdateColor();
					this.iterator++;
				}
				wardrobeInstance.wardrobeItemButtons[0].controlledModel.SetCosmeticActive(wardrobeInstance.wardrobeItemButtons[0].currentCosmeticItem.displayName, false);
				wardrobeInstance.wardrobeItemButtons[1].controlledModel.SetCosmeticActive(wardrobeInstance.wardrobeItemButtons[1].currentCosmeticItem.displayName, false);
				wardrobeInstance.wardrobeItemButtons[2].controlledModel.SetCosmeticActive(wardrobeInstance.wardrobeItemButtons[2].currentCosmeticItem.displayName, false);
				wardrobeInstance.selfDoll.SetCosmeticActiveArray(this.currentWornSet.ToDisplayNameArray(), this.currentWornSet.ToOnRightSideArray());
			}
		}

		// Token: 0x060027D3 RID: 10195 RVA: 0x000C29A8 File Offset: 0x000C0BA8
		public int GetCategorySize(CosmeticsController.CosmeticCategory category)
		{
			int indexForCategory = this.GetIndexForCategory(category);
			if (indexForCategory != -1)
			{
				return this.itemLists[indexForCategory].Count;
			}
			return 0;
		}

		// Token: 0x060027D4 RID: 10196 RVA: 0x000C29D0 File Offset: 0x000C0BD0
		public CosmeticsController.CosmeticItem GetCosmetic(int category, int cosmeticIndex)
		{
			if (cosmeticIndex >= this.itemLists[category].Count || cosmeticIndex < 0)
			{
				return this.nullItem;
			}
			return this.itemLists[category][cosmeticIndex];
		}

		// Token: 0x060027D5 RID: 10197 RVA: 0x000C29FB File Offset: 0x000C0BFB
		public CosmeticsController.CosmeticItem GetCosmetic(CosmeticsController.CosmeticCategory category, int cosmeticIndex)
		{
			return this.GetCosmetic(this.GetIndexForCategory(category), cosmeticIndex);
		}

		// Token: 0x060027D6 RID: 10198 RVA: 0x000C2A0C File Offset: 0x000C0C0C
		private int GetIndexForCategory(CosmeticsController.CosmeticCategory category)
		{
			switch (category)
			{
			case CosmeticsController.CosmeticCategory.Hat:
				return 0;
			case CosmeticsController.CosmeticCategory.Badge:
				return 2;
			case CosmeticsController.CosmeticCategory.Face:
				return 1;
			case CosmeticsController.CosmeticCategory.Paw:
				return 3;
			case CosmeticsController.CosmeticCategory.Chest:
				return 9;
			case CosmeticsController.CosmeticCategory.Fur:
				return 4;
			case CosmeticsController.CosmeticCategory.Shirt:
				return 5;
			case CosmeticsController.CosmeticCategory.Back:
				return 8;
			case CosmeticsController.CosmeticCategory.Arms:
				return 7;
			case CosmeticsController.CosmeticCategory.Pants:
				return 6;
			case CosmeticsController.CosmeticCategory.TagEffect:
				return -1;
			default:
				return 0;
			}
		}

		// Token: 0x060027D7 RID: 10199 RVA: 0x000C2A67 File Offset: 0x000C0C67
		public bool IsCosmeticEquipped(CosmeticsController.CosmeticItem cosmetic)
		{
			return this.AnyMatch(this.currentWornSet, cosmetic);
		}

		// Token: 0x060027D8 RID: 10200 RVA: 0x000C2A78 File Offset: 0x000C0C78
		public CosmeticsController.CosmeticItem GetSlotItem(CosmeticsController.CosmeticSlots slot, bool checkOpposite = true)
		{
			int num = (int)slot;
			if (checkOpposite)
			{
				num = (int)CosmeticsController.CosmeticSet.OppositeSlot(slot);
			}
			return this.currentWornSet.items[num];
		}

		// Token: 0x060027D9 RID: 10201 RVA: 0x000C2AA2 File Offset: 0x000C0CA2
		public string[] GetCurrentlyWornCosmetics()
		{
			return this.currentWornSet.ToDisplayNameArray();
		}

		// Token: 0x060027DA RID: 10202 RVA: 0x000C2AAF File Offset: 0x000C0CAF
		public bool[] GetCurrentRightEquippedSided()
		{
			return this.currentWornSet.ToOnRightSideArray();
		}

		// Token: 0x060027DB RID: 10203 RVA: 0x000C2ABC File Offset: 0x000C0CBC
		public void UpdateShoppingCart()
		{
			this.iterator = 0;
			while (this.iterator < this.fittingRoomButtons.Length)
			{
				if (this.iterator < this.currentCart.Count)
				{
					this.fittingRoomButtons[this.iterator].currentCosmeticItem = this.currentCart[this.iterator];
					this.checkoutCartButtons[this.iterator].currentCosmeticItem = this.currentCart[this.iterator];
					this.checkoutCartButtons[this.iterator].isOn = (this.checkoutCartButtons[this.iterator].currentCosmeticItem.itemName == this.itemToBuy.itemName);
					this.fittingRoomButtons[this.iterator].isOn = this.AnyMatch(this.tryOnSet, this.fittingRoomButtons[this.iterator].currentCosmeticItem);
				}
				else
				{
					this.checkoutCartButtons[this.iterator].currentCosmeticItem = this.nullItem;
					this.fittingRoomButtons[this.iterator].currentCosmeticItem = this.nullItem;
					this.checkoutCartButtons[this.iterator].isOn = false;
					this.fittingRoomButtons[this.iterator].isOn = false;
				}
				this.checkoutCartButtons[this.iterator].currentImage.sprite = this.checkoutCartButtons[this.iterator].currentCosmeticItem.itemPicture;
				this.fittingRoomButtons[this.iterator].currentImage.sprite = this.fittingRoomButtons[this.iterator].currentCosmeticItem.itemPicture;
				this.checkoutCartButtons[this.iterator].UpdateColor();
				this.fittingRoomButtons[this.iterator].UpdateColor();
				this.iterator++;
			}
			if (CosmeticsV2Spawner_Dirty.allPartsInstantiated)
			{
				this.UpdateWardrobeModelsAndButtons();
			}
		}

		// Token: 0x060027DC RID: 10204 RVA: 0x000C2CA0 File Offset: 0x000C0EA0
		public void UpdateWornCosmetics(bool sync = false)
		{
			GorillaTagger.Instance.offlineVRRig.LocalUpdateCosmeticsWithTryon(this.currentWornSet, this.tryOnSet);
			if (sync && GorillaTagger.Instance.myVRRig != null)
			{
				string[] array = this.currentWornSet.ToDisplayNameArray();
				string[] array2 = this.tryOnSet.ToDisplayNameArray();
				GorillaTagger.Instance.myVRRig.RPC("UpdateCosmeticsWithTryon", RpcTarget.All, new object[]
				{
					array,
					array2
				});
			}
		}

		// Token: 0x060027DD RID: 10205 RVA: 0x000C2D18 File Offset: 0x000C0F18
		public CosmeticsController.CosmeticItem GetItemFromDict(string itemID)
		{
			if (!this.allCosmeticsDict.TryGetValue(itemID, out this.cosmeticItemVar))
			{
				return this.nullItem;
			}
			return this.cosmeticItemVar;
		}

		// Token: 0x060027DE RID: 10206 RVA: 0x000C2D3B File Offset: 0x000C0F3B
		public string GetItemNameFromDisplayName(string displayName)
		{
			if (!this.allCosmeticsItemIDsfromDisplayNamesDict.TryGetValue(displayName, out this.returnString))
			{
				return "null";
			}
			return this.returnString;
		}

		// Token: 0x060027DF RID: 10207 RVA: 0x000C2D60 File Offset: 0x000C0F60
		public bool AnyMatch(CosmeticsController.CosmeticSet set, CosmeticsController.CosmeticItem item)
		{
			if (item.itemCategory != CosmeticsController.CosmeticCategory.Set)
			{
				return set.IsActive(item.displayName);
			}
			if (item.bundledItems.Length == 1)
			{
				return this.AnyMatch(set, this.GetItemFromDict(item.bundledItems[0]));
			}
			if (item.bundledItems.Length == 2)
			{
				return this.AnyMatch(set, this.GetItemFromDict(item.bundledItems[0])) || this.AnyMatch(set, this.GetItemFromDict(item.bundledItems[1]));
			}
			return item.bundledItems.Length >= 3 && (this.AnyMatch(set, this.GetItemFromDict(item.bundledItems[0])) || this.AnyMatch(set, this.GetItemFromDict(item.bundledItems[1])) || this.AnyMatch(set, this.GetItemFromDict(item.bundledItems[2])));
		}

		// Token: 0x060027E0 RID: 10208 RVA: 0x000C2E34 File Offset: 0x000C1034
		public void Initialize()
		{
			if (!base.gameObject.activeSelf || this.v2_isCosmeticPlayFabCatalogDataLoaded || this.v2_isGetCosmeticsPlayCatalogDataWaitingForCallback)
			{
				return;
			}
			if (this.v2_allCosmeticsInfoAssetRef_isLoaded)
			{
				this.GetCosmeticsPlayFabCatalogData();
				return;
			}
			this.v2_isGetCosmeticsPlayCatalogDataWaitingForCallback = true;
			this.V2_allCosmeticsInfoAssetRef_OnPostLoad = (Action)Delegate.Combine(this.V2_allCosmeticsInfoAssetRef_OnPostLoad, new Action(this.GetCosmeticsPlayFabCatalogData));
		}

		// Token: 0x060027E1 RID: 10209 RVA: 0x000C2E97 File Offset: 0x000C1097
		public void GetLastDailyLogin()
		{
			PlayFabClientAPI.GetUserReadOnlyData(new GetUserDataRequest(), delegate(GetUserDataResult result)
			{
				if (result.Data.TryGetValue("DailyLogin", out this.userDataRecord))
				{
					this.lastDailyLogin = this.userDataRecord.Value;
					return;
				}
				this.lastDailyLogin = "NONE";
				base.StartCoroutine(this.GetMyDaily());
			}, delegate(PlayFabError error)
			{
				Debug.Log("Got error getting read-only user data:");
				Debug.Log(error.GenerateErrorReport());
				this.lastDailyLogin = "FAILED";
				if (error.Error == PlayFabErrorCode.NotAuthenticated)
				{
					PlayFabAuthenticator.instance.AuthenticateWithPlayFab();
					return;
				}
				if (error.Error == PlayFabErrorCode.AccountBanned)
				{
					Application.Quit();
					PhotonNetwork.Disconnect();
					Object.DestroyImmediate(PhotonNetworkController.Instance);
					Object.DestroyImmediate(GorillaLocomotion.Player.Instance);
					GameObject[] array = Object.FindObjectsOfType<GameObject>();
					for (int i = 0; i < array.Length; i++)
					{
						Object.Destroy(array[i]);
					}
				}
			}, null, null);
		}

		// Token: 0x060027E2 RID: 10210 RVA: 0x000C2EBD File Offset: 0x000C10BD
		private IEnumerator CheckCanGetDaily()
		{
			for (;;)
			{
				if (GorillaComputer.instance != null && GorillaComputer.instance.startupMillis != 0L)
				{
					this.currentTime = new DateTime((GorillaComputer.instance.startupMillis + (long)(Time.realtimeSinceStartup * 1000f)) * 10000L);
					this.secondsUntilTomorrow = (int)(this.currentTime.AddDays(1.0).Date - this.currentTime).TotalSeconds;
					if (this.lastDailyLogin == null || this.lastDailyLogin == "")
					{
						this.GetLastDailyLogin();
					}
					else if (this.currentTime.ToString("o").Substring(0, 10) == this.lastDailyLogin)
					{
						this.checkedDaily = true;
						this.gotMyDaily = true;
					}
					else if (this.currentTime.ToString("o").Substring(0, 10) != this.lastDailyLogin)
					{
						this.checkedDaily = true;
						this.gotMyDaily = false;
						base.StartCoroutine(this.GetMyDaily());
					}
					else if (this.lastDailyLogin == "FAILED")
					{
						this.GetLastDailyLogin();
					}
					this.secondsToWaitToCheckDaily = (this.checkedDaily ? 60f : 10f);
					this.UpdateCurrencyBoard();
					yield return new WaitForSeconds(this.secondsToWaitToCheckDaily);
				}
				else
				{
					yield return new WaitForSeconds(1f);
				}
			}
			yield break;
		}

		// Token: 0x060027E3 RID: 10211 RVA: 0x000C2ECC File Offset: 0x000C10CC
		private IEnumerator GetMyDaily()
		{
			yield return new WaitForSeconds(10f);
			GorillaServer.Instance.TryDistributeCurrency(delegate(ExecuteFunctionResult result)
			{
				this.GetCurrencyBalance();
				this.GetLastDailyLogin();
			}, delegate(PlayFabError error)
			{
				if (error.Error == PlayFabErrorCode.NotAuthenticated)
				{
					PlayFabAuthenticator.instance.AuthenticateWithPlayFab();
					return;
				}
				if (error.Error == PlayFabErrorCode.AccountBanned)
				{
					Application.Quit();
					PhotonNetwork.Disconnect();
					Object.DestroyImmediate(PhotonNetworkController.Instance);
					Object.DestroyImmediate(GorillaLocomotion.Player.Instance);
					GameObject[] array = Object.FindObjectsOfType<GameObject>();
					for (int i = 0; i < array.Length; i++)
					{
						Object.Destroy(array[i]);
					}
				}
			});
			yield break;
		}

		// Token: 0x060027E4 RID: 10212 RVA: 0x000C2EDC File Offset: 0x000C10DC
		public void GetCosmeticsPlayFabCatalogData()
		{
			this.v2_isGetCosmeticsPlayCatalogDataWaitingForCallback = false;
			if (this.v2_isCosmeticPlayFabCatalogDataLoaded)
			{
				Debug.LogError("`GetCosmeticsPlayFabCatalogData` was called after it was already successfully run. Avoid running multiple times by checking `v2_isCosmeticPlayFabCatalogDataLoaded`.", this);
				return;
			}
			if (!this.v2_allCosmeticsInfoAssetRef_isLoaded)
			{
				throw new Exception("Method `GetCosmeticsPlayFabCatalogData` was called before `v2_allCosmeticsInfoAssetRef` was loaded. Listen to callback `V2_allCosmeticsInfoAssetRef_OnPostLoad` or check `v2_allCosmeticsInfoAssetRef_isLoaded` before trying to get PlayFab catalog data.");
			}
			PlayFabClientAPI.GetUserInventory(new GetUserInventoryRequest(), delegate(GetUserInventoryResult result)
			{
				PlayFabClientAPI.GetCatalogItems(new GetCatalogItemsRequest
				{
					CatalogVersion = this.catalog
				}, delegate(GetCatalogItemsResult result2)
				{
					this.unlockedCosmetics.Clear();
					this.unlockedHats.Clear();
					this.unlockedBadges.Clear();
					this.unlockedFaces.Clear();
					this.unlockedPaws.Clear();
					this.unlockedFurs.Clear();
					this.unlockedShirts.Clear();
					this.unlockedPants.Clear();
					this.unlockedArms.Clear();
					this.unlockedBacks.Clear();
					this.unlockedChests.Clear();
					this.catalogItems = result2.Catalog;
					using (List<CatalogItem>.Enumerator enumerator = this.catalogItems.GetEnumerator())
					{
						while (enumerator.MoveNext())
						{
							CatalogItem catalogItem = enumerator.Current;
							this.searchIndex = this.allCosmetics.FindIndex((CosmeticsController.CosmeticItem x) => catalogItem.ItemId == x.itemName);
							if (this.searchIndex > -1)
							{
								this.tempStringArray = null;
								this.hasPrice = false;
								if (catalogItem.Bundle != null)
								{
									this.tempStringArray = catalogItem.Bundle.BundledItems.ToArray();
								}
								uint cost;
								if (catalogItem.VirtualCurrencyPrices.TryGetValue(this.currencyName, out cost))
								{
									this.hasPrice = true;
								}
								CosmeticsController.CosmeticItem cosmeticItem = this.allCosmetics[this.searchIndex];
								cosmeticItem.itemName = catalogItem.ItemId;
								cosmeticItem.displayName = catalogItem.DisplayName;
								cosmeticItem.cost = (int)cost;
								cosmeticItem.bundledItems = this.tempStringArray;
								cosmeticItem.canTryOn = this.hasPrice;
								if (cosmeticItem.displayName == null)
								{
									string text = "null";
									if (this.allCosmetics[this.searchIndex].itemPicture)
									{
										text = this.allCosmetics[this.searchIndex].itemPicture.name;
									}
									string debugCosmeticSOName = this.v2_allCosmetics[this.searchIndex].debugCosmeticSOName;
									Debug.LogError(string.Concat(new string[]
									{
										string.Format("Cosmetic encountered with a null displayName at index {0}! ", this.searchIndex),
										"Setting displayName to id: \"",
										this.allCosmetics[this.searchIndex].itemName,
										"\". iconName=\"",
										text,
										"\".cosmeticSOName=\"",
										debugCosmeticSOName,
										"\". "
									}));
									cosmeticItem.displayName = cosmeticItem.itemName;
								}
								this.V2_ConformCosmeticItemV1DisplayName(ref cosmeticItem);
								this._allCosmetics[this.searchIndex] = cosmeticItem;
								this._allCosmeticsDict[cosmeticItem.itemName] = cosmeticItem;
								this._allCosmeticsItemIDsfromDisplayNamesDict[cosmeticItem.displayName] = cosmeticItem.itemName;
								this._allCosmeticsItemIDsfromDisplayNamesDict[cosmeticItem.overrideDisplayName] = cosmeticItem.itemName;
							}
						}
					}
					for (int i = this._allCosmetics.Count - 1; i > -1; i--)
					{
						this.tempItem = this._allCosmetics[i];
						if (this.tempItem.itemCategory == CosmeticsController.CosmeticCategory.Set && this.tempItem.canTryOn)
						{
							string[] bundledItems = this.tempItem.bundledItems;
							for (int j = 0; j < bundledItems.Length; j++)
							{
								string setItemName = bundledItems[j];
								this.searchIndex = this._allCosmetics.FindIndex((CosmeticsController.CosmeticItem x) => setItemName == x.itemName);
								if (this.searchIndex > -1)
								{
									this.tempItem = this._allCosmetics[this.searchIndex];
									this.tempItem.canTryOn = true;
									this._allCosmetics[this.searchIndex] = this.tempItem;
									this._allCosmeticsDict[this._allCosmetics[this.searchIndex].itemName] = this.tempItem;
									this._allCosmeticsItemIDsfromDisplayNamesDict[this._allCosmetics[this.searchIndex].displayName] = this.tempItem.itemName;
								}
							}
						}
					}
					using (Dictionary<string, StoreBundle>.ValueCollection.Enumerator enumerator2 = BundleManager.instance.storeBundlesById.Values.GetEnumerator())
					{
						while (enumerator2.MoveNext())
						{
							StoreBundle bundleData = enumerator2.Current;
							int num = this._allCosmetics.FindIndex((CosmeticsController.CosmeticItem x) => bundleData.playfabBundleID == x.itemName);
							if (num > 0 && this._allCosmetics[num].bundledItems != null)
							{
								string[] bundledItems = this._allCosmetics[num].bundledItems;
								for (int j = 0; j < bundledItems.Length; j++)
								{
									string setItemName = bundledItems[j];
									this.searchIndex = this._allCosmetics.FindIndex((CosmeticsController.CosmeticItem x) => setItemName == x.itemName);
									if (this.searchIndex > -1)
									{
										this.tempItem = this._allCosmetics[this.searchIndex];
										this.tempItem.canTryOn = true;
										this._allCosmetics[this.searchIndex] = this.tempItem;
										this._allCosmeticsDict[this._allCosmetics[this.searchIndex].itemName] = this.tempItem;
										this._allCosmeticsItemIDsfromDisplayNamesDict[this._allCosmetics[this.searchIndex].displayName] = this.tempItem.itemName;
									}
								}
							}
						}
					}
					this.searchIndex = this._allCosmetics.FindIndex((CosmeticsController.CosmeticItem x) => "Slingshot" == x.itemName);
					if (this.searchIndex < 0)
					{
						throw new MissingReferenceException("CosmeticsController: Cannot find default slingshot! it is required for players that do not have another slingshot equipped and are playing Paintbrawl.");
					}
					this._allCosmeticsDict["Slingshot"] = this._allCosmetics[this.searchIndex];
					this._allCosmeticsItemIDsfromDisplayNamesDict[this._allCosmetics[this.searchIndex].displayName] = this._allCosmetics[this.searchIndex].itemName;
					this.allCosmeticsDict_isInitialized = true;
					this.allCosmeticsItemIDsfromDisplayNamesDict_isInitialized = true;
					using (List<ItemInstance>.Enumerator enumerator3 = result.Inventory.GetEnumerator())
					{
						while (enumerator3.MoveNext())
						{
							ItemInstance item = enumerator3.Current;
							if (item.ItemId == "Early Access Supporter Pack")
							{
								string key;
								CosmeticsController.CosmeticItem item2;
								if (this.allCosmeticsItemIDsfromDisplayNamesDict.TryGetValue("BANANA HAT", out key) && this.allCosmeticsDict.TryGetValue(key, out item2))
								{
									this.unlockedCosmetics.Add(item2);
								}
								if (this.allCosmeticsItemIDsfromDisplayNamesDict.TryGetValue("COCONUT", out key) && this.allCosmeticsDict.TryGetValue(key, out item2))
								{
									this.unlockedCosmetics.Add(item2);
								}
								if (this.allCosmeticsItemIDsfromDisplayNamesDict.TryGetValue("SUNHAT", out key) && this.allCosmeticsDict.TryGetValue(key, out item2))
								{
									this.unlockedCosmetics.Add(item2);
								}
								if (this.allCosmeticsItemIDsfromDisplayNamesDict.TryGetValue("CLOCHE", out key) && this.allCosmeticsDict.TryGetValue(key, out item2))
								{
									this.unlockedCosmetics.Add(this.allCosmeticsDict[key]);
								}
								if (this.allCosmeticsItemIDsfromDisplayNamesDict.TryGetValue("COWBOY HAT", out key) && this.allCosmeticsDict.TryGetValue(key, out item2))
								{
									this.unlockedCosmetics.Add(this.allCosmeticsDict[key]);
								}
								if (this.allCosmeticsItemIDsfromDisplayNamesDict.TryGetValue("FEZ", out key) && this.allCosmeticsDict.TryGetValue(key, out item2))
								{
									this.unlockedCosmetics.Add(this.allCosmeticsDict[key]);
								}
								if (this.allCosmeticsItemIDsfromDisplayNamesDict.TryGetValue("TOP HAT", out key) && this.allCosmeticsDict.TryGetValue(key, out item2))
								{
									this.unlockedCosmetics.Add(this.allCosmeticsDict[key]);
								}
								if (this.allCosmeticsItemIDsfromDisplayNamesDict.TryGetValue("TORTOISESHELL SUNGLASSES", out key) && this.allCosmeticsDict.TryGetValue(key, out item2))
								{
									this.unlockedCosmetics.Add(this.allCosmeticsDict[key]);
								}
								if (this.allCosmeticsItemIDsfromDisplayNamesDict.TryGetValue("AVIATORS", out key) && this.allCosmeticsDict.TryGetValue(key, out item2))
								{
									this.unlockedCosmetics.Add(this.allCosmeticsDict[key]);
								}
								if (this.allCosmeticsItemIDsfromDisplayNamesDict.TryGetValue("EARLY ACCESS", out key) && this.allCosmeticsDict.TryGetValue(key, out item2))
								{
									this.unlockedCosmetics.Add(this.allCosmeticsDict[key]);
								}
								if (this.allCosmeticsItemIDsfromDisplayNamesDict.TryGetValue("SUNNY SUNHAT", out key) && this.allCosmeticsDict.TryGetValue(key, out item2))
								{
									this.unlockedCosmetics.Add(this.allCosmeticsDict[key]);
								}
								if (this.allCosmeticsItemIDsfromDisplayNamesDict.TryGetValue("CHROME COWBOY HAT", out key) && this.allCosmeticsDict.TryGetValue(key, out item2))
								{
									this.unlockedCosmetics.Add(this.allCosmeticsDict[key]);
								}
							}
							else
							{
								BundleManager.instance.MarkBundleOwnedByPlayFabID(item.ItemId);
								this.searchIndex = this.allCosmetics.FindIndex((CosmeticsController.CosmeticItem x) => item.ItemId == x.itemName);
								if (this.searchIndex > -1)
								{
									this.unlockedCosmetics.Add(this.allCosmetics[this.searchIndex]);
								}
							}
						}
					}
					foreach (CosmeticsController.CosmeticItem cosmeticItem2 in this.unlockedCosmetics)
					{
						if (cosmeticItem2.itemCategory == CosmeticsController.CosmeticCategory.Hat && !this.unlockedHats.Contains(cosmeticItem2))
						{
							this.unlockedHats.Add(cosmeticItem2);
						}
						else if (cosmeticItem2.itemCategory == CosmeticsController.CosmeticCategory.Face && !this.unlockedFaces.Contains(cosmeticItem2))
						{
							this.unlockedFaces.Add(cosmeticItem2);
						}
						else if (cosmeticItem2.itemCategory == CosmeticsController.CosmeticCategory.Badge && !this.unlockedBadges.Contains(cosmeticItem2))
						{
							this.unlockedBadges.Add(cosmeticItem2);
						}
						else if (cosmeticItem2.itemCategory == CosmeticsController.CosmeticCategory.Paw && !this.unlockedPaws.Contains(cosmeticItem2))
						{
							this.unlockedPaws.Add(cosmeticItem2);
						}
						else if (cosmeticItem2.itemCategory == CosmeticsController.CosmeticCategory.Fur && !this.unlockedFurs.Contains(cosmeticItem2))
						{
							this.unlockedFurs.Add(cosmeticItem2);
						}
						else if (cosmeticItem2.itemCategory == CosmeticsController.CosmeticCategory.Shirt && !this.unlockedShirts.Contains(cosmeticItem2))
						{
							this.unlockedShirts.Add(cosmeticItem2);
						}
						else if (cosmeticItem2.itemCategory == CosmeticsController.CosmeticCategory.Arms && !this.unlockedArms.Contains(cosmeticItem2))
						{
							this.unlockedArms.Add(cosmeticItem2);
						}
						else if (cosmeticItem2.itemCategory == CosmeticsController.CosmeticCategory.Back && !this.unlockedBacks.Contains(cosmeticItem2))
						{
							this.unlockedBacks.Add(cosmeticItem2);
						}
						else if (cosmeticItem2.itemCategory == CosmeticsController.CosmeticCategory.Chest && !this.unlockedChests.Contains(cosmeticItem2))
						{
							this.unlockedChests.Add(cosmeticItem2);
						}
						else if (cosmeticItem2.itemCategory == CosmeticsController.CosmeticCategory.Pants && !this.unlockedPants.Contains(cosmeticItem2))
						{
							this.unlockedPants.Add(cosmeticItem2);
						}
						this.concatStringCosmeticsAllowed += cosmeticItem2.itemName;
					}
					this.currencyBalance = result.VirtualCurrency[this.currencyName];
					int num2;
					this.playedInBeta = (result.VirtualCurrency.TryGetValue("TC", out num2) && num2 > 0);
					BundleManager.instance.CheckIfBundlesOwned();
					this.currentWornSet.LoadFromPlayerPreferences(this);
					this.SwitchToStage(CosmeticsController.ATMStages.Begin);
					this.ProcessPurchaseItemState(null, false);
					this.UpdateShoppingCart();
					this.UpdateCurrencyBoard();
					if (this.UseNewCosmeticsPath())
					{
						this.ConfirmIndividualCosmeticsSharedGroup(result);
					}
					Action onCosmeticsUpdated = this.OnCosmeticsUpdated;
					if (onCosmeticsUpdated != null)
					{
						onCosmeticsUpdated();
					}
					this.v2_isCosmeticPlayFabCatalogDataLoaded = true;
					Action v2_OnGetCosmeticsPlayFabCatalogData_PostSuccess = this.V2_OnGetCosmeticsPlayFabCatalogData_PostSuccess;
					if (v2_OnGetCosmeticsPlayFabCatalogData_PostSuccess != null)
					{
						v2_OnGetCosmeticsPlayFabCatalogData_PostSuccess();
					}
					CosmeticsV2Spawner_Dirty.StartInstantiatingPrefabs();
				}, delegate(PlayFabError error)
				{
					if (error.Error == PlayFabErrorCode.NotAuthenticated)
					{
						PlayFabAuthenticator.instance.AuthenticateWithPlayFab();
					}
					else if (error.Error == PlayFabErrorCode.AccountBanned)
					{
						Application.Quit();
						PhotonNetwork.Disconnect();
						Object.DestroyImmediate(PhotonNetworkController.Instance);
						Object.DestroyImmediate(GorillaLocomotion.Player.Instance);
						GameObject[] array = Object.FindObjectsOfType<GameObject>();
						for (int i = 0; i < array.Length; i++)
						{
							Object.Destroy(array[i]);
						}
					}
					if (!this.tryTwice)
					{
						this.tryTwice = true;
						this.GetCosmeticsPlayFabCatalogData();
					}
				}, null, null);
			}, delegate(PlayFabError error)
			{
				if (error.Error == PlayFabErrorCode.NotAuthenticated)
				{
					PlayFabAuthenticator.instance.AuthenticateWithPlayFab();
				}
				else if (error.Error == PlayFabErrorCode.AccountBanned)
				{
					Application.Quit();
					PhotonNetwork.Disconnect();
					Object.DestroyImmediate(PhotonNetworkController.Instance);
					Object.DestroyImmediate(GorillaLocomotion.Player.Instance);
					GameObject[] array = Object.FindObjectsOfType<GameObject>();
					for (int i = 0; i < array.Length; i++)
					{
						Object.Destroy(array[i]);
					}
				}
				if (!this.tryTwice)
				{
					this.tryTwice = true;
					this.GetCosmeticsPlayFabCatalogData();
				}
			}, null, null);
		}

		// Token: 0x060027E5 RID: 10213 RVA: 0x000C2F3C File Offset: 0x000C113C
		private void SteamPurchase()
		{
			Debug.Log("attempting to purchase item through steam");
			StartPurchaseRequest startPurchaseRequest = new StartPurchaseRequest();
			startPurchaseRequest.CatalogVersion = this.catalog;
			startPurchaseRequest.Items = new List<ItemPurchaseRequest>
			{
				new ItemPurchaseRequest
				{
					ItemId = this.itemToPurchase,
					Quantity = 1U,
					Annotation = "Purchased via in-game store"
				}
			};
			PlayFabClientAPI.StartPurchase(startPurchaseRequest, delegate(StartPurchaseResult result)
			{
				Debug.Log("successfully started purchase. attempted to pay for purchase through steam");
				this.currentPurchaseID = result.OrderId;
				PlayFabClientAPI.PayForPurchase(new PayForPurchaseRequest
				{
					OrderId = this.currentPurchaseID,
					ProviderName = "Steam",
					Currency = "RM"
				}, delegate(PayForPurchaseResult result2)
				{
					Debug.Log("succeeded on sending request for paying with steam! waiting for response");
					this.buyingBundle = true;
					this.m_MicroTxnAuthorizationResponse = Callback<MicroTxnAuthorizationResponse_t>.Create(new Callback<MicroTxnAuthorizationResponse_t>.DispatchDelegate(this.OnMicroTxnAuthorizationResponse));
				}, delegate(PlayFabError error)
				{
					if (error.Error == PlayFabErrorCode.NotAuthenticated)
					{
						PlayFabAuthenticator.instance.AuthenticateWithPlayFab();
					}
					else if (error.Error == PlayFabErrorCode.AccountBanned)
					{
						Application.Quit();
						PhotonNetwork.Disconnect();
						Object.DestroyImmediate(PhotonNetworkController.Instance);
						Object.DestroyImmediate(GorillaLocomotion.Player.Instance);
						GameObject[] array = Object.FindObjectsOfType<GameObject>();
						for (int i = 0; i < array.Length; i++)
						{
							Object.Destroy(array[i]);
						}
					}
					Debug.Log("failed to send request to purchase with steam!");
					Debug.Log(error.ToString());
					this.SwitchToStage(CosmeticsController.ATMStages.Failure);
				}, null, null);
			}, delegate(PlayFabError error)
			{
				if (error.Error == PlayFabErrorCode.NotAuthenticated)
				{
					PlayFabAuthenticator.instance.AuthenticateWithPlayFab();
				}
				else if (error.Error == PlayFabErrorCode.AccountBanned)
				{
					Application.Quit();
					PhotonNetwork.Disconnect();
					Object.DestroyImmediate(PhotonNetworkController.Instance);
					Object.DestroyImmediate(GorillaLocomotion.Player.Instance);
					GameObject[] array = Object.FindObjectsOfType<GameObject>();
					for (int i = 0; i < array.Length; i++)
					{
						Object.Destroy(array[i]);
					}
				}
				Debug.Log("error in starting purchase!");
			}, null, null);
		}

		// Token: 0x060027E6 RID: 10214 RVA: 0x000C2FCC File Offset: 0x000C11CC
		public void ProcessATMState(string currencyButton)
		{
			switch (this.currentATMStage)
			{
			case CosmeticsController.ATMStages.Unavailable:
			case CosmeticsController.ATMStages.Purchasing:
				break;
			case CosmeticsController.ATMStages.Begin:
				this.SwitchToStage(CosmeticsController.ATMStages.Menu);
				return;
			case CosmeticsController.ATMStages.Menu:
				if (PlayFabAuthenticator.instance.GetSafety())
				{
					if (currencyButton == "one")
					{
						this.SwitchToStage(CosmeticsController.ATMStages.Balance);
						return;
					}
					if (!(currencyButton == "four"))
					{
						return;
					}
					this.SwitchToStage(CosmeticsController.ATMStages.Begin);
					return;
				}
				else
				{
					if (currencyButton == "one")
					{
						this.SwitchToStage(CosmeticsController.ATMStages.Balance);
						return;
					}
					if (currencyButton == "two")
					{
						this.SwitchToStage(CosmeticsController.ATMStages.Choose);
						return;
					}
					if (!(currencyButton == "back"))
					{
						return;
					}
					this.SwitchToStage(CosmeticsController.ATMStages.Begin);
					return;
				}
				break;
			case CosmeticsController.ATMStages.Balance:
				if (currencyButton == "back")
				{
					this.SwitchToStage(CosmeticsController.ATMStages.Menu);
					return;
				}
				break;
			case CosmeticsController.ATMStages.Choose:
				if (currencyButton == "one")
				{
					this.numShinyRocksToBuy = 1000;
					this.shinyRocksCost = 4.99f;
					this.itemToPurchase = "1000SHINYROCKS";
					this.SwitchToStage(CosmeticsController.ATMStages.Confirm);
					return;
				}
				if (currencyButton == "two")
				{
					this.numShinyRocksToBuy = 2200;
					this.shinyRocksCost = 9.99f;
					this.itemToPurchase = "2200SHINYROCKS";
					this.SwitchToStage(CosmeticsController.ATMStages.Confirm);
					return;
				}
				if (currencyButton == "three")
				{
					this.numShinyRocksToBuy = 5000;
					this.shinyRocksCost = 19.99f;
					this.itemToPurchase = "5000SHINYROCKS";
					this.SwitchToStage(CosmeticsController.ATMStages.Confirm);
					return;
				}
				if (currencyButton == "four")
				{
					this.numShinyRocksToBuy = 11000;
					this.shinyRocksCost = 39.99f;
					this.itemToPurchase = "11000SHINYROCKS";
					this.SwitchToStage(CosmeticsController.ATMStages.Confirm);
					return;
				}
				if (!(currencyButton == "back"))
				{
					return;
				}
				this.SwitchToStage(CosmeticsController.ATMStages.Menu);
				return;
			case CosmeticsController.ATMStages.Confirm:
				if (currencyButton == "one")
				{
					this.SteamPurchase();
					this.SwitchToStage(CosmeticsController.ATMStages.Purchasing);
					return;
				}
				if (!(currencyButton == "back"))
				{
					return;
				}
				this.SwitchToStage(CosmeticsController.ATMStages.Choose);
				return;
			default:
				this.SwitchToStage(CosmeticsController.ATMStages.Menu);
				break;
			}
		}

		// Token: 0x060027E7 RID: 10215 RVA: 0x000C31CC File Offset: 0x000C13CC
		public void SwitchToStage(CosmeticsController.ATMStages newStage)
		{
			if (!this.atmText)
			{
				return;
			}
			this.currentATMStage = newStage;
			switch (newStage)
			{
			case CosmeticsController.ATMStages.Unavailable:
				this.atmText.text = "ATM NOT AVAILABLE! PLEASE TRY AGAIN LATER!";
				this.ATM_RightColumnButtonText[0].text = "";
				this.ATM_RightColumnArrowText[0].enabled = false;
				this.ATM_RightColumnButtonText[1].text = "";
				this.ATM_RightColumnArrowText[1].enabled = false;
				this.ATM_RightColumnButtonText[2].text = "";
				this.ATM_RightColumnArrowText[2].enabled = false;
				this.ATM_RightColumnButtonText[3].text = "";
				this.ATM_RightColumnArrowText[3].enabled = false;
				return;
			case CosmeticsController.ATMStages.Begin:
				this.atmText.text = "WELCOME! PRESS ANY BUTTON TO BEGIN.";
				this.ATM_RightColumnButtonText[0].text = "";
				this.ATM_RightColumnArrowText[0].enabled = false;
				this.ATM_RightColumnButtonText[1].text = "";
				this.ATM_RightColumnArrowText[1].enabled = false;
				this.ATM_RightColumnButtonText[2].text = "";
				this.ATM_RightColumnArrowText[2].enabled = false;
				this.ATM_RightColumnButtonText[3].text = "BEGIN";
				this.ATM_RightColumnArrowText[3].enabled = true;
				return;
			case CosmeticsController.ATMStages.Menu:
				if (PlayFabAuthenticator.instance.GetSafety())
				{
					this.atmText.text = "CHECK YOUR BALANCE.";
					this.ATM_RightColumnButtonText[0].text = "BALANCE";
					this.ATM_RightColumnArrowText[0].enabled = true;
					this.ATM_RightColumnButtonText[1].text = "";
					this.ATM_RightColumnArrowText[1].enabled = false;
					this.ATM_RightColumnButtonText[2].text = "";
					this.ATM_RightColumnArrowText[2].enabled = false;
					this.ATM_RightColumnButtonText[3].text = "";
					this.ATM_RightColumnArrowText[3].enabled = false;
					return;
				}
				this.atmText.text = "CHECK YOUR BALANCE OR PURCHASE MORE SHINY ROCKS.";
				this.ATM_RightColumnButtonText[0].text = "BALANCE";
				this.ATM_RightColumnArrowText[0].enabled = true;
				this.ATM_RightColumnButtonText[1].text = "PURCHASE";
				this.ATM_RightColumnArrowText[1].enabled = true;
				this.ATM_RightColumnButtonText[2].text = "";
				this.ATM_RightColumnArrowText[2].enabled = false;
				this.ATM_RightColumnButtonText[3].text = "";
				this.ATM_RightColumnArrowText[3].enabled = false;
				return;
			case CosmeticsController.ATMStages.Balance:
				this.atmText.text = "CURRENT BALANCE:\n\n" + this.currencyBalance.ToString();
				this.ATM_RightColumnButtonText[0].text = "";
				this.ATM_RightColumnArrowText[0].enabled = false;
				this.ATM_RightColumnButtonText[1].text = "";
				this.ATM_RightColumnArrowText[1].enabled = false;
				this.ATM_RightColumnButtonText[2].text = "";
				this.ATM_RightColumnArrowText[2].enabled = false;
				this.ATM_RightColumnButtonText[3].text = "";
				this.ATM_RightColumnArrowText[3].enabled = false;
				return;
			case CosmeticsController.ATMStages.Choose:
				this.atmText.text = "CHOOSE AN AMOUNT OF SHINY ROCKS TO PURCHASE.";
				this.ATM_RightColumnButtonText[0].text = "1000 for $4.99";
				this.ATM_RightColumnArrowText[0].enabled = true;
				this.ATM_RightColumnButtonText[1].text = "2200 for $9.99\n(10% BONUS!)";
				this.ATM_RightColumnArrowText[1].enabled = true;
				this.ATM_RightColumnButtonText[2].text = "5000 for $19.99\n(25% BONUS!)";
				this.ATM_RightColumnArrowText[2].enabled = true;
				this.ATM_RightColumnButtonText[3].text = "11000 for $39.99\n(37% BONUS!)";
				this.ATM_RightColumnArrowText[3].enabled = true;
				return;
			case CosmeticsController.ATMStages.Confirm:
				this.atmText.text = string.Concat(new string[]
				{
					"YOU HAVE CHOSEN TO PURCHASE ",
					this.numShinyRocksToBuy.ToString(),
					" SHINY ROCKS FOR $",
					this.shinyRocksCost.ToString(),
					". CONFIRM TO LAUNCH A STEAM WINDOW TO COMPLETE YOUR PURCHASE."
				});
				this.ATM_RightColumnButtonText[0].text = "CONFIRM";
				this.ATM_RightColumnArrowText[0].enabled = true;
				this.ATM_RightColumnButtonText[1].text = "";
				this.ATM_RightColumnArrowText[1].enabled = false;
				this.ATM_RightColumnButtonText[2].text = "";
				this.ATM_RightColumnArrowText[2].enabled = false;
				this.ATM_RightColumnButtonText[3].text = "";
				this.ATM_RightColumnArrowText[3].enabled = false;
				return;
			case CosmeticsController.ATMStages.Purchasing:
				this.atmText.text = "PURCHASING IN STEAM...";
				return;
			case CosmeticsController.ATMStages.Success:
				this.atmText.text = "SUCCESS! NEW SHINY ROCKS BALANCE: " + (this.currencyBalance + this.numShinyRocksToBuy).ToString();
				this.ATM_RightColumnButtonText[0].text = "";
				this.ATM_RightColumnArrowText[0].enabled = false;
				this.ATM_RightColumnButtonText[1].text = "";
				this.ATM_RightColumnArrowText[1].enabled = false;
				this.ATM_RightColumnButtonText[2].text = "";
				this.ATM_RightColumnArrowText[2].enabled = false;
				this.ATM_RightColumnButtonText[3].text = "";
				this.ATM_RightColumnArrowText[3].enabled = false;
				return;
			case CosmeticsController.ATMStages.Failure:
				this.atmText.text = "PURCHASE CANCELED. NO FUNDS WERE SPENT.";
				this.ATM_RightColumnButtonText[0].text = "";
				this.ATM_RightColumnArrowText[0].enabled = false;
				this.ATM_RightColumnButtonText[1].text = "";
				this.ATM_RightColumnArrowText[1].enabled = false;
				this.ATM_RightColumnButtonText[2].text = "";
				this.ATM_RightColumnArrowText[2].enabled = false;
				this.ATM_RightColumnButtonText[3].text = "";
				this.ATM_RightColumnArrowText[3].enabled = false;
				return;
			case CosmeticsController.ATMStages.SafeAccount:
				this.atmText.text = "Out Of Order.";
				this.ATM_RightColumnButtonText[0].text = "";
				this.ATM_RightColumnArrowText[0].enabled = false;
				this.ATM_RightColumnButtonText[1].text = "";
				this.ATM_RightColumnArrowText[1].enabled = false;
				this.ATM_RightColumnButtonText[2].text = "";
				this.ATM_RightColumnArrowText[2].enabled = false;
				this.ATM_RightColumnButtonText[3].text = "";
				this.ATM_RightColumnArrowText[3].enabled = false;
				return;
			default:
				return;
			}
		}

		// Token: 0x060027E8 RID: 10216 RVA: 0x000C384C File Offset: 0x000C1A4C
		public void PressCurrencyPurchaseButton(string currencyPurchaseSize)
		{
			this.ProcessATMState(currencyPurchaseSize);
		}

		// Token: 0x060027E9 RID: 10217 RVA: 0x000C3855 File Offset: 0x000C1A55
		private void OnMicroTxnAuthorizationResponse(MicroTxnAuthorizationResponse_t pCallback)
		{
			PlayFabClientAPI.ConfirmPurchase(new ConfirmPurchaseRequest
			{
				OrderId = this.currentPurchaseID
			}, delegate(ConfirmPurchaseResult result)
			{
				if (this.buyingBundle)
				{
					this.buyingBundle = false;
					if (PhotonNetwork.InRoom)
					{
						RaiseEventOptions raiseEventOptions = new RaiseEventOptions();
						WebFlags flags = new WebFlags(1);
						raiseEventOptions.Flags = flags;
						object[] eventContent = new object[0];
						PhotonNetwork.RaiseEvent(9, eventContent, raiseEventOptions, SendOptions.SendReliable);
					}
					base.StartCoroutine(this.CheckIfMyCosmeticsUpdated(this.BundlePlayfabItemName));
				}
				this.SwitchToStage(CosmeticsController.ATMStages.Success);
				this.GetCurrencyBalance();
				this.UpdateCurrencyBoard();
				this.GetCosmeticsPlayFabCatalogData();
				GorillaTagger.Instance.offlineVRRig.GetCosmeticsPlayFabCatalogData();
			}, delegate(PlayFabError error)
			{
				this.atmText.text = "PURCHASE CANCELLED!\n\nCURRENT BALANCE IS: ";
				this.UpdateCurrencyBoard();
				this.SwitchToStage(CosmeticsController.ATMStages.Failure);
			}, null, null);
		}

		// Token: 0x060027EA RID: 10218 RVA: 0x000C3888 File Offset: 0x000C1A88
		public void UpdateCurrencyBoard()
		{
			this.FormattedPurchaseText(this.finalLine);
			this.dailyText.text = (this.checkedDaily ? (this.gotMyDaily ? "SUCCESSFULLY GOT DAILY ROCKS!" : "WAITING TO GET DAILY ROCKS...") : "CHECKING DAILY ROCKS...");
			this.currencyBoardText.text = string.Concat(new string[]
			{
				this.currencyBalance.ToString(),
				"\n\n",
				(this.secondsUntilTomorrow / 3600).ToString(),
				" HR, ",
				(this.secondsUntilTomorrow % 3600 / 60).ToString(),
				"MIN"
			});
		}

		// Token: 0x060027EB RID: 10219 RVA: 0x000C393C File Offset: 0x000C1B3C
		public void GetCurrencyBalance()
		{
			PlayFabClientAPI.GetUserInventory(new GetUserInventoryRequest(), delegate(GetUserInventoryResult result)
			{
				this.currencyBalance = result.VirtualCurrency[this.currencyName];
				this.UpdateCurrencyBoard();
			}, delegate(PlayFabError error)
			{
				if (error.Error == PlayFabErrorCode.NotAuthenticated)
				{
					PlayFabAuthenticator.instance.AuthenticateWithPlayFab();
					return;
				}
				if (error.Error == PlayFabErrorCode.AccountBanned)
				{
					Application.Quit();
					PhotonNetwork.Disconnect();
					Object.DestroyImmediate(PhotonNetworkController.Instance);
					Object.DestroyImmediate(GorillaLocomotion.Player.Instance);
					GameObject[] array = Object.FindObjectsOfType<GameObject>();
					for (int i = 0; i < array.Length; i++)
					{
						Object.Destroy(array[i]);
					}
				}
			}, null, null);
		}

		// Token: 0x060027EC RID: 10220 RVA: 0x000C3975 File Offset: 0x000C1B75
		public string GetItemDisplayName(CosmeticsController.CosmeticItem item)
		{
			if (item.overrideDisplayName != null && item.overrideDisplayName != "")
			{
				return item.overrideDisplayName;
			}
			return item.displayName;
		}

		// Token: 0x060027ED RID: 10221 RVA: 0x00003051 File Offset: 0x00001251
		public void LeaveSystemMenu()
		{
		}

		// Token: 0x060027EE RID: 10222 RVA: 0x000C399E File Offset: 0x000C1B9E
		public void UpdateMyCosmetics()
		{
			if (PhotonNetwork.InRoom)
			{
				this.UpdateMyCosmeticsForRoom();
				return;
			}
			if (this.UseNewCosmeticsPath())
			{
				this.UpdateMyCosmeticsNotInRoom();
			}
		}

		// Token: 0x060027EF RID: 10223 RVA: 0x000C39BC File Offset: 0x000C1BBC
		private void UpdateMyCosmeticsNotInRoom()
		{
			if (GorillaServer.Instance != null)
			{
				GorillaServer.Instance.UpdateUserCosmetics();
			}
		}

		// Token: 0x060027F0 RID: 10224 RVA: 0x000C39DC File Offset: 0x000C1BDC
		private void UpdateMyCosmeticsForRoom()
		{
			byte eventCode = 9;
			if (this.UseNewCosmeticsPath())
			{
				eventCode = 10;
			}
			RaiseEventOptions raiseEventOptions = new RaiseEventOptions();
			WebFlags flags = new WebFlags(1);
			raiseEventOptions.Flags = flags;
			object[] eventContent = new object[0];
			PhotonNetwork.RaiseEvent(eventCode, eventContent, raiseEventOptions, SendOptions.SendReliable);
		}

		// Token: 0x060027F1 RID: 10225 RVA: 0x000C3A20 File Offset: 0x000C1C20
		private void AlreadyOwnAllBundleButtons()
		{
			EarlyAccessButton[] array = this.earlyAccessButtons;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].AlreadyOwn();
			}
		}

		// Token: 0x060027F2 RID: 10226 RVA: 0x000C3A4A File Offset: 0x000C1C4A
		private bool UseNewCosmeticsPath()
		{
			return GorillaServer.Instance != null && GorillaServer.Instance.NewCosmeticsPath();
		}

		// Token: 0x060027F3 RID: 10227 RVA: 0x000C3A69 File Offset: 0x000C1C69
		public void CheckCosmeticsSharedGroup()
		{
			this.updateCosmeticsRetries++;
			if (this.updateCosmeticsRetries < this.maxUpdateCosmeticsRetries)
			{
				base.StartCoroutine(this.WaitForNextCosmeticsAttempt());
			}
		}

		// Token: 0x060027F4 RID: 10228 RVA: 0x000C3A94 File Offset: 0x000C1C94
		private IEnumerator WaitForNextCosmeticsAttempt()
		{
			int num = (int)Mathf.Pow(3f, (float)(this.updateCosmeticsRetries + 1));
			yield return new WaitForSeconds((float)num);
			this.ConfirmIndividualCosmeticsSharedGroup(this.latestInventory);
			yield break;
		}

		// Token: 0x060027F5 RID: 10229 RVA: 0x000C3AA4 File Offset: 0x000C1CA4
		private void ConfirmIndividualCosmeticsSharedGroup(GetUserInventoryResult inventory)
		{
			this.latestInventory = inventory;
			this.playerIDList.Clear();
			this.playerIDList.Add("Inventory");
			if (PhotonNetwork.LocalPlayer.UserId == null)
			{
				base.StartCoroutine(this.WaitForNextCosmeticsAttempt());
				return;
			}
			PlayFabClientAPI.GetSharedGroupData(new GetSharedGroupDataRequest
			{
				Keys = this.playerIDList,
				SharedGroupId = PhotonNetwork.LocalPlayer.UserId + "Inventory"
			}, delegate(GetSharedGroupDataResult result)
			{
				bool flag = true;
				foreach (KeyValuePair<string, SharedGroupDataRecord> keyValuePair in result.Data)
				{
					if (keyValuePair.Key != "Inventory")
					{
						break;
					}
					foreach (ItemInstance itemInstance in inventory.Inventory)
					{
						if (itemInstance.CatalogVersion == CosmeticsController.instance.catalog && !keyValuePair.Value.Value.Contains(itemInstance.ItemId))
						{
							flag = false;
							break;
						}
					}
				}
				if (!flag || result.Data.Count == 0)
				{
					this.UpdateMyCosmetics();
					return;
				}
				this.updateCosmeticsRetries = 0;
			}, delegate(PlayFabError error)
			{
				this.ReauthOrBan(error);
				this.CheckCosmeticsSharedGroup();
			}, null, null);
		}

		// Token: 0x060027F6 RID: 10230 RVA: 0x000C3B50 File Offset: 0x000C1D50
		public void ReauthOrBan(PlayFabError error)
		{
			if (error.Error == PlayFabErrorCode.NotAuthenticated)
			{
				PlayFabAuthenticator.instance.AuthenticateWithPlayFab();
				return;
			}
			if (error.Error == PlayFabErrorCode.AccountBanned)
			{
				Application.Quit();
				PhotonNetwork.Disconnect();
				Object.DestroyImmediate(PhotonNetworkController.Instance);
				Object.DestroyImmediate(GorillaLocomotion.Player.Instance);
				GameObject[] array = Object.FindObjectsOfType<GameObject>();
				for (int i = 0; i < array.Length; i++)
				{
					Object.Destroy(array[i]);
				}
			}
		}

		// Token: 0x04002A60 RID: 10848
		[FormerlySerializedAs("v2AllCosmeticsInfoAssetRef")]
		[FormerlySerializedAs("newSysAllCosmeticsAssetRef")]
		[SerializeField]
		public GTAssetRef<AllCosmeticsArraySO> v2_allCosmeticsInfoAssetRef;

		// Token: 0x04002A62 RID: 10850
		private readonly Dictionary<string, CosmeticInfoV2> _allCosmeticsDictV2 = new Dictionary<string, CosmeticInfoV2>();

		// Token: 0x04002A63 RID: 10851
		public Action V2_allCosmeticsInfoAssetRef_OnPostLoad;

		// Token: 0x04002A67 RID: 10855
		public const int maximumTransferrableItems = 5;

		// Token: 0x04002A68 RID: 10856
		[OnEnterPlay_SetNull]
		public static volatile CosmeticsController instance;

		// Token: 0x04002A6A RID: 10858
		public Action V2_OnGetCosmeticsPlayFabCatalogData_PostSuccess;

		// Token: 0x04002A6B RID: 10859
		[FormerlySerializedAs("allCosmetics")]
		[SerializeField]
		private List<CosmeticsController.CosmeticItem> _allCosmetics;

		// Token: 0x04002A6D RID: 10861
		public Dictionary<string, CosmeticsController.CosmeticItem> _allCosmeticsDict = new Dictionary<string, CosmeticsController.CosmeticItem>();

		// Token: 0x04002A6F RID: 10863
		public Dictionary<string, string> _allCosmeticsItemIDsfromDisplayNamesDict = new Dictionary<string, string>();

		// Token: 0x04002A70 RID: 10864
		public CosmeticsController.CosmeticItem nullItem;

		// Token: 0x04002A71 RID: 10865
		public string catalog;

		// Token: 0x04002A72 RID: 10866
		private string[] tempStringArray;

		// Token: 0x04002A73 RID: 10867
		private CosmeticsController.CosmeticItem tempItem;

		// Token: 0x04002A74 RID: 10868
		private VRRigAnchorOverrides anchorOverrides;

		// Token: 0x04002A75 RID: 10869
		public List<CatalogItem> catalogItems;

		// Token: 0x04002A76 RID: 10870
		public bool tryTwice;

		// Token: 0x04002A77 RID: 10871
		[NonSerialized]
		public CosmeticsController.CosmeticSet tryOnSet = new CosmeticsController.CosmeticSet();

		// Token: 0x04002A78 RID: 10872
		public FittingRoomButton[] fittingRoomButtons;

		// Token: 0x04002A79 RID: 10873
		public CosmeticStand[] cosmeticStands;

		// Token: 0x04002A7A RID: 10874
		public List<CosmeticsController.CosmeticItem> currentCart = new List<CosmeticsController.CosmeticItem>();

		// Token: 0x04002A7B RID: 10875
		public CosmeticsController.PurchaseItemStages currentPurchaseItemStage;

		// Token: 0x04002A7C RID: 10876
		public CheckoutCartButton[] checkoutCartButtons;

		// Token: 0x04002A7D RID: 10877
		public PurchaseItemButton leftPurchaseButton;

		// Token: 0x04002A7E RID: 10878
		public PurchaseItemButton rightPurchaseButton;

		// Token: 0x04002A7F RID: 10879
		public Text purchaseText;

		// Token: 0x04002A80 RID: 10880
		public CosmeticsController.CosmeticItem itemToBuy;

		// Token: 0x04002A81 RID: 10881
		public HeadModel checkoutHeadModel;

		// Token: 0x04002A82 RID: 10882
		private List<string> playerIDList = new List<string>();

		// Token: 0x04002A83 RID: 10883
		private bool foundCosmetic;

		// Token: 0x04002A84 RID: 10884
		private int attempts;

		// Token: 0x04002A85 RID: 10885
		private string finalLine;

		// Token: 0x04002A86 RID: 10886
		private bool isLastHandTouchedLeft;

		// Token: 0x04002A87 RID: 10887
		private CosmeticsController.CosmeticSet cachedSet = new CosmeticsController.CosmeticSet();

		// Token: 0x04002A88 RID: 10888
		public readonly List<WardrobeInstance> wardrobes = new List<WardrobeInstance>();

		// Token: 0x04002A89 RID: 10889
		public List<CosmeticsController.CosmeticItem> unlockedCosmetics = new List<CosmeticsController.CosmeticItem>();

		// Token: 0x04002A8A RID: 10890
		public List<CosmeticsController.CosmeticItem> unlockedHats = new List<CosmeticsController.CosmeticItem>();

		// Token: 0x04002A8B RID: 10891
		public List<CosmeticsController.CosmeticItem> unlockedFaces = new List<CosmeticsController.CosmeticItem>();

		// Token: 0x04002A8C RID: 10892
		public List<CosmeticsController.CosmeticItem> unlockedBadges = new List<CosmeticsController.CosmeticItem>();

		// Token: 0x04002A8D RID: 10893
		public List<CosmeticsController.CosmeticItem> unlockedPaws = new List<CosmeticsController.CosmeticItem>();

		// Token: 0x04002A8E RID: 10894
		public List<CosmeticsController.CosmeticItem> unlockedChests = new List<CosmeticsController.CosmeticItem>();

		// Token: 0x04002A8F RID: 10895
		public List<CosmeticsController.CosmeticItem> unlockedFurs = new List<CosmeticsController.CosmeticItem>();

		// Token: 0x04002A90 RID: 10896
		public List<CosmeticsController.CosmeticItem> unlockedShirts = new List<CosmeticsController.CosmeticItem>();

		// Token: 0x04002A91 RID: 10897
		public List<CosmeticsController.CosmeticItem> unlockedPants = new List<CosmeticsController.CosmeticItem>();

		// Token: 0x04002A92 RID: 10898
		public List<CosmeticsController.CosmeticItem> unlockedBacks = new List<CosmeticsController.CosmeticItem>();

		// Token: 0x04002A93 RID: 10899
		public List<CosmeticsController.CosmeticItem> unlockedArms = new List<CosmeticsController.CosmeticItem>();

		// Token: 0x04002A94 RID: 10900
		public int[] cosmeticsPages = new int[11];

		// Token: 0x04002A95 RID: 10901
		private List<CosmeticsController.CosmeticItem>[] itemLists = new List<CosmeticsController.CosmeticItem>[11];

		// Token: 0x04002A96 RID: 10902
		private int wardrobeType;

		// Token: 0x04002A97 RID: 10903
		[NonSerialized]
		public CosmeticsController.CosmeticSet currentWornSet = new CosmeticsController.CosmeticSet();

		// Token: 0x04002A98 RID: 10904
		public string concatStringCosmeticsAllowed = "";

		// Token: 0x04002A99 RID: 10905
		public Action OnCosmeticsUpdated;

		// Token: 0x04002A9A RID: 10906
		public Text atmText;

		// Token: 0x04002A9B RID: 10907
		public string currentAtmString;

		// Token: 0x04002A9C RID: 10908
		public Text infoText;

		// Token: 0x04002A9D RID: 10909
		public Text earlyAccessText;

		// Token: 0x04002A9E RID: 10910
		public Text[] purchaseButtonText;

		// Token: 0x04002A9F RID: 10911
		public Text dailyText;

		// Token: 0x04002AA0 RID: 10912
		public CosmeticsController.ATMStages currentATMStage;

		// Token: 0x04002AA1 RID: 10913
		public Text[] ATM_RightColumnButtonText;

		// Token: 0x04002AA2 RID: 10914
		public Text[] ATM_RightColumnArrowText;

		// Token: 0x04002AA3 RID: 10915
		public int currencyBalance;

		// Token: 0x04002AA4 RID: 10916
		public string currencyName;

		// Token: 0x04002AA5 RID: 10917
		public PurchaseCurrencyButton[] purchaseCurrencyButtons;

		// Token: 0x04002AA6 RID: 10918
		public Text currencyBoardText;

		// Token: 0x04002AA7 RID: 10919
		public Text currencyBoxText;

		// Token: 0x04002AA8 RID: 10920
		public string startingCurrencyBoxTextString;

		// Token: 0x04002AA9 RID: 10921
		public string successfulCurrencyPurchaseTextString;

		// Token: 0x04002AAA RID: 10922
		public int numShinyRocksToBuy;

		// Token: 0x04002AAB RID: 10923
		public float shinyRocksCost;

		// Token: 0x04002AAC RID: 10924
		public string itemToPurchase;

		// Token: 0x04002AAD RID: 10925
		public bool confirmedDidntPlayInBeta;

		// Token: 0x04002AAE RID: 10926
		public bool playedInBeta;

		// Token: 0x04002AAF RID: 10927
		public bool gotMyDaily;

		// Token: 0x04002AB0 RID: 10928
		public bool checkedDaily;

		// Token: 0x04002AB1 RID: 10929
		public string currentPurchaseID;

		// Token: 0x04002AB2 RID: 10930
		public bool hasPrice;

		// Token: 0x04002AB3 RID: 10931
		private int searchIndex;

		// Token: 0x04002AB4 RID: 10932
		private int iterator;

		// Token: 0x04002AB5 RID: 10933
		private CosmeticsController.CosmeticItem cosmeticItemVar;

		// Token: 0x04002AB6 RID: 10934
		public EarlyAccessButton[] earlyAccessButtons;

		// Token: 0x04002AB7 RID: 10935
		private BundleList bundleList = new BundleList();

		// Token: 0x04002AB8 RID: 10936
		public string BundleSkuName = "2024_i_lava_you_pack";

		// Token: 0x04002AB9 RID: 10937
		public string BundlePlayfabItemName = "LSABG.";

		// Token: 0x04002ABA RID: 10938
		public int BundleShinyRocks = 10000;

		// Token: 0x04002ABB RID: 10939
		public bool buyingBundle;

		// Token: 0x04002ABC RID: 10940
		public DateTime currentTime;

		// Token: 0x04002ABD RID: 10941
		public string lastDailyLogin;

		// Token: 0x04002ABE RID: 10942
		public UserDataRecord userDataRecord;

		// Token: 0x04002ABF RID: 10943
		public int secondsUntilTomorrow;

		// Token: 0x04002AC0 RID: 10944
		public float secondsToWaitToCheckDaily = 10f;

		// Token: 0x04002AC1 RID: 10945
		private int updateCosmeticsRetries;

		// Token: 0x04002AC2 RID: 10946
		private int maxUpdateCosmeticsRetries;

		// Token: 0x04002AC3 RID: 10947
		private GetUserInventoryResult latestInventory;

		// Token: 0x04002AC4 RID: 10948
		private string returnString;

		// Token: 0x04002AC5 RID: 10949
		protected Callback<MicroTxnAuthorizationResponse_t> m_MicroTxnAuthorizationResponse;

		// Token: 0x02000697 RID: 1687
		public enum PurchaseItemStages
		{
			// Token: 0x04002AC7 RID: 10951
			Start,
			// Token: 0x04002AC8 RID: 10952
			CheckoutButtonPressed,
			// Token: 0x04002AC9 RID: 10953
			ItemSelected,
			// Token: 0x04002ACA RID: 10954
			ItemOwned,
			// Token: 0x04002ACB RID: 10955
			FinalPurchaseAcknowledgement,
			// Token: 0x04002ACC RID: 10956
			Buying,
			// Token: 0x04002ACD RID: 10957
			Success,
			// Token: 0x04002ACE RID: 10958
			Failure
		}

		// Token: 0x02000698 RID: 1688
		public enum ATMStages
		{
			// Token: 0x04002AD0 RID: 10960
			Unavailable,
			// Token: 0x04002AD1 RID: 10961
			Begin,
			// Token: 0x04002AD2 RID: 10962
			Menu,
			// Token: 0x04002AD3 RID: 10963
			Balance,
			// Token: 0x04002AD4 RID: 10964
			Choose,
			// Token: 0x04002AD5 RID: 10965
			Confirm,
			// Token: 0x04002AD6 RID: 10966
			Purchasing,
			// Token: 0x04002AD7 RID: 10967
			Success,
			// Token: 0x04002AD8 RID: 10968
			Failure,
			// Token: 0x04002AD9 RID: 10969
			SafeAccount
		}

		// Token: 0x02000699 RID: 1689
		public enum CosmeticCategory
		{
			// Token: 0x04002ADB RID: 10971
			None,
			// Token: 0x04002ADC RID: 10972
			Hat,
			// Token: 0x04002ADD RID: 10973
			Badge,
			// Token: 0x04002ADE RID: 10974
			Face,
			// Token: 0x04002ADF RID: 10975
			Paw,
			// Token: 0x04002AE0 RID: 10976
			Chest,
			// Token: 0x04002AE1 RID: 10977
			Fur,
			// Token: 0x04002AE2 RID: 10978
			Shirt,
			// Token: 0x04002AE3 RID: 10979
			Back,
			// Token: 0x04002AE4 RID: 10980
			Arms,
			// Token: 0x04002AE5 RID: 10981
			Pants,
			// Token: 0x04002AE6 RID: 10982
			TagEffect,
			// Token: 0x04002AE7 RID: 10983
			Count,
			// Token: 0x04002AE8 RID: 10984
			Set
		}

		// Token: 0x0200069A RID: 1690
		public enum CosmeticSlots
		{
			// Token: 0x04002AEA RID: 10986
			Hat,
			// Token: 0x04002AEB RID: 10987
			Badge,
			// Token: 0x04002AEC RID: 10988
			Face,
			// Token: 0x04002AED RID: 10989
			ArmLeft,
			// Token: 0x04002AEE RID: 10990
			ArmRight,
			// Token: 0x04002AEF RID: 10991
			BackLeft,
			// Token: 0x04002AF0 RID: 10992
			BackRight,
			// Token: 0x04002AF1 RID: 10993
			HandLeft,
			// Token: 0x04002AF2 RID: 10994
			HandRight,
			// Token: 0x04002AF3 RID: 10995
			Chest,
			// Token: 0x04002AF4 RID: 10996
			Fur,
			// Token: 0x04002AF5 RID: 10997
			Shirt,
			// Token: 0x04002AF6 RID: 10998
			Pants,
			// Token: 0x04002AF7 RID: 10999
			Back,
			// Token: 0x04002AF8 RID: 11000
			Arms,
			// Token: 0x04002AF9 RID: 11001
			TagEffect,
			// Token: 0x04002AFA RID: 11002
			Count
		}

		// Token: 0x0200069B RID: 1691
		[Serializable]
		public class CosmeticSet
		{
			// Token: 0x14000042 RID: 66
			// (add) Token: 0x06002808 RID: 10248 RVA: 0x000C42AC File Offset: 0x000C24AC
			// (remove) Token: 0x06002809 RID: 10249 RVA: 0x000C42E4 File Offset: 0x000C24E4
			public event CosmeticsController.CosmeticSet.OnSetActivatedHandler onSetActivatedEvent;

			// Token: 0x0600280A RID: 10250 RVA: 0x000C4319 File Offset: 0x000C2519
			protected void OnSetActivated(CosmeticsController.CosmeticSet prevSet, CosmeticsController.CosmeticSet currentSet, NetPlayer netPlayer)
			{
				if (this.onSetActivatedEvent != null)
				{
					this.onSetActivatedEvent(prevSet, currentSet, netPlayer);
				}
			}

			// Token: 0x0600280B RID: 10251 RVA: 0x000C4331 File Offset: 0x000C2531
			public CosmeticSet()
			{
				this.items = new CosmeticsController.CosmeticItem[16];
			}

			// Token: 0x0600280C RID: 10252 RVA: 0x000C4354 File Offset: 0x000C2554
			public CosmeticSet(string[] itemNames, CosmeticsController controller)
			{
				this.items = new CosmeticsController.CosmeticItem[16];
				for (int i = 0; i < itemNames.Length; i++)
				{
					string displayName = itemNames[i];
					string itemNameFromDisplayName = controller.GetItemNameFromDisplayName(displayName);
					this.items[i] = controller.GetItemFromDict(itemNameFromDisplayName);
				}
			}

			// Token: 0x0600280D RID: 10253 RVA: 0x000C43B0 File Offset: 0x000C25B0
			public void CopyItems(CosmeticsController.CosmeticSet other)
			{
				for (int i = 0; i < this.items.Length; i++)
				{
					this.items[i] = other.items[i];
				}
			}

			// Token: 0x0600280E RID: 10254 RVA: 0x000C43E8 File Offset: 0x000C25E8
			public void MergeSets(CosmeticsController.CosmeticSet tryOn, CosmeticsController.CosmeticSet current)
			{
				for (int i = 0; i < 16; i++)
				{
					if (tryOn == null)
					{
						this.items[i] = current.items[i];
					}
					else
					{
						this.items[i] = (tryOn.items[i].isNullItem ? current.items[i] : tryOn.items[i]);
					}
				}
			}

			// Token: 0x0600280F RID: 10255 RVA: 0x000C4458 File Offset: 0x000C2658
			public void ClearSet(CosmeticsController.CosmeticItem nullItem)
			{
				for (int i = 0; i < 16; i++)
				{
					this.items[i] = nullItem;
				}
			}

			// Token: 0x06002810 RID: 10256 RVA: 0x000C4480 File Offset: 0x000C2680
			public bool IsActive(string name)
			{
				int num = 16;
				for (int i = 0; i < num; i++)
				{
					if (this.items[i].displayName == name)
					{
						return true;
					}
				}
				return false;
			}

			// Token: 0x06002811 RID: 10257 RVA: 0x000C44B8 File Offset: 0x000C26B8
			public bool HasItemOfCategory(CosmeticsController.CosmeticCategory category)
			{
				int num = 16;
				for (int i = 0; i < num; i++)
				{
					if (!this.items[i].isNullItem && this.items[i].itemCategory == category)
					{
						return true;
					}
				}
				return false;
			}

			// Token: 0x06002812 RID: 10258 RVA: 0x000C4500 File Offset: 0x000C2700
			public bool HasItem(string name)
			{
				int num = 16;
				for (int i = 0; i < num; i++)
				{
					if (!this.items[i].isNullItem && this.items[i].displayName == name)
					{
						return true;
					}
				}
				return false;
			}

			// Token: 0x06002813 RID: 10259 RVA: 0x000C454B File Offset: 0x000C274B
			public static bool IsSlotLeftHanded(CosmeticsController.CosmeticSlots slot)
			{
				return slot == CosmeticsController.CosmeticSlots.ArmLeft || slot == CosmeticsController.CosmeticSlots.BackLeft || slot == CosmeticsController.CosmeticSlots.HandLeft;
			}

			// Token: 0x06002814 RID: 10260 RVA: 0x000C455B File Offset: 0x000C275B
			public static bool IsSlotRightHanded(CosmeticsController.CosmeticSlots slot)
			{
				return slot == CosmeticsController.CosmeticSlots.ArmRight || slot == CosmeticsController.CosmeticSlots.BackRight || slot == CosmeticsController.CosmeticSlots.HandRight;
			}

			// Token: 0x06002815 RID: 10261 RVA: 0x000C456B File Offset: 0x000C276B
			public static bool IsHoldable(CosmeticsController.CosmeticItem item)
			{
				return item.isHoldable;
			}

			// Token: 0x06002816 RID: 10262 RVA: 0x000C4574 File Offset: 0x000C2774
			public static CosmeticsController.CosmeticSlots OppositeSlot(CosmeticsController.CosmeticSlots slot)
			{
				switch (slot)
				{
				case CosmeticsController.CosmeticSlots.Hat:
					return CosmeticsController.CosmeticSlots.Hat;
				case CosmeticsController.CosmeticSlots.Badge:
					return CosmeticsController.CosmeticSlots.Badge;
				case CosmeticsController.CosmeticSlots.Face:
					return CosmeticsController.CosmeticSlots.Face;
				case CosmeticsController.CosmeticSlots.ArmLeft:
					return CosmeticsController.CosmeticSlots.ArmRight;
				case CosmeticsController.CosmeticSlots.ArmRight:
					return CosmeticsController.CosmeticSlots.ArmLeft;
				case CosmeticsController.CosmeticSlots.BackLeft:
					return CosmeticsController.CosmeticSlots.BackRight;
				case CosmeticsController.CosmeticSlots.BackRight:
					return CosmeticsController.CosmeticSlots.BackLeft;
				case CosmeticsController.CosmeticSlots.HandLeft:
					return CosmeticsController.CosmeticSlots.HandRight;
				case CosmeticsController.CosmeticSlots.HandRight:
					return CosmeticsController.CosmeticSlots.HandLeft;
				case CosmeticsController.CosmeticSlots.Chest:
					return CosmeticsController.CosmeticSlots.Chest;
				case CosmeticsController.CosmeticSlots.Fur:
					return CosmeticsController.CosmeticSlots.Fur;
				case CosmeticsController.CosmeticSlots.Shirt:
					return CosmeticsController.CosmeticSlots.Shirt;
				case CosmeticsController.CosmeticSlots.Pants:
					return CosmeticsController.CosmeticSlots.Pants;
				case CosmeticsController.CosmeticSlots.Back:
					return CosmeticsController.CosmeticSlots.Back;
				case CosmeticsController.CosmeticSlots.Arms:
					return CosmeticsController.CosmeticSlots.Arms;
				case CosmeticsController.CosmeticSlots.TagEffect:
					return CosmeticsController.CosmeticSlots.TagEffect;
				default:
					return CosmeticsController.CosmeticSlots.Count;
				}
			}

			// Token: 0x06002817 RID: 10263 RVA: 0x000C45F2 File Offset: 0x000C27F2
			public static string SlotPlayerPreferenceName(CosmeticsController.CosmeticSlots slot)
			{
				return "slot_" + slot.ToString();
			}

			// Token: 0x06002818 RID: 10264 RVA: 0x000C460C File Offset: 0x000C280C
			private void ActivateHoldable(CosmeticsController.CosmeticSet prevSet, int cosmeticIdx, CosmeticItemRegistry cosmeticsObjectRegistry, BodyDockPositions bDock, CosmeticsController.CosmeticItem nullItem)
			{
				BodyDockPositions.DropPositions dropPositions = CosmeticsController.CosmeticSlotToDropPosition((CosmeticsController.CosmeticSlots)cosmeticIdx);
				if (dropPositions == BodyDockPositions.DropPositions.None)
				{
					return;
				}
				CosmeticsController.CosmeticItem cosmeticItem = this.items[cosmeticIdx];
				if (!cosmeticItem.isHoldable)
				{
					return;
				}
				if (cosmeticItem.isNullItem)
				{
					bDock.TransferrableItemDisableAtPosition(dropPositions);
					return;
				}
				if (bDock.ItemPositionInUse(dropPositions) == null)
				{
					bDock.TransferrableItemEnableAtPosition(cosmeticItem.displayName, dropPositions);
					return;
				}
				if (!bDock.TransferrableItemActiveAtPos(cosmeticItem.displayName, dropPositions))
				{
					CosmeticsController.CosmeticItem cosmeticItem2 = prevSet.items[cosmeticIdx];
					if (!cosmeticItem2.isNullItem && !cosmeticItem2.isHoldable)
					{
						CosmeticItemInstance cosmeticItemInstance = cosmeticsObjectRegistry.Cosmetic(cosmeticItem2.displayName);
						if (cosmeticItemInstance != null)
						{
							cosmeticItemInstance.DisableItem((CosmeticsController.CosmeticSlots)cosmeticIdx);
						}
					}
					else if (cosmeticItem2.isHoldable)
					{
						bDock.TransferrableItemDisableAtPosition(dropPositions);
					}
					bDock.TransferrableItemEnableAtPosition(cosmeticItem.displayName, dropPositions);
				}
			}

			// Token: 0x06002819 RID: 10265 RVA: 0x000C46D4 File Offset: 0x000C28D4
			private void ActivateCosmeticItem(CosmeticsController.CosmeticSet prevSet, VRRig rig, int cosmeticIdx, CosmeticItemRegistry cosmeticsObjectRegistry, BodyDockPositions bDock, CosmeticsController.CosmeticItem nullItem)
			{
				CosmeticsController.CosmeticItem cosmeticItem = prevSet.items[cosmeticIdx];
				CosmeticsController.CosmeticItem cosmeticItem2 = this.items[cosmeticIdx];
				if (cosmeticItem2.isHoldable)
				{
					return;
				}
				if (cosmeticItem.isHoldable && cosmeticItem2.isNullItem)
				{
					return;
				}
				CosmeticItemInstance cosmeticItemInstance = cosmeticsObjectRegistry.Cosmetic(cosmeticItem.displayName);
				CosmeticItemInstance cosmeticItemInstance2 = cosmeticsObjectRegistry.Cosmetic(cosmeticItem2.displayName);
				string itemNameFromDisplayName = CosmeticsController.instance.GetItemNameFromDisplayName(cosmeticItem2.displayName);
				string itemNameFromDisplayName2 = CosmeticsController.instance.GetItemNameFromDisplayName(cosmeticItem.displayName);
				if (!(itemNameFromDisplayName == itemNameFromDisplayName2))
				{
					if (cosmeticItem.isHoldable)
					{
						BodyDockPositions.DropPositions dropPositions = CosmeticsController.CosmeticSlotToDropPosition((CosmeticsController.CosmeticSlots)cosmeticIdx);
						bDock.TransferrableItemDisableAtPosition(dropPositions);
					}
					else
					{
						if (cosmeticItem2.isNullItem)
						{
							if (!cosmeticItem.isNullItem && cosmeticItemInstance != null)
							{
								cosmeticItemInstance.DisableItem((CosmeticsController.CosmeticSlots)cosmeticIdx);
							}
							return;
						}
						if (!cosmeticItem.isNullItem && cosmeticItemInstance != null)
						{
							cosmeticItemInstance.DisableItem((CosmeticsController.CosmeticSlots)cosmeticIdx);
						}
					}
					if (rig.IsItemAllowed(itemNameFromDisplayName) && cosmeticItemInstance2 != null)
					{
						cosmeticItemInstance2.EnableItem((CosmeticsController.CosmeticSlots)cosmeticIdx);
					}
					return;
				}
				if (cosmeticItem2.isNullItem)
				{
					return;
				}
				if (cosmeticItemInstance2 != null)
				{
					if (!rig.IsItemAllowed(itemNameFromDisplayName))
					{
						cosmeticItemInstance2.DisableItem((CosmeticsController.CosmeticSlots)cosmeticIdx);
						return;
					}
					cosmeticItemInstance2.EnableItem((CosmeticsController.CosmeticSlots)cosmeticIdx);
				}
			}

			// Token: 0x0600281A RID: 10266 RVA: 0x000C47F0 File Offset: 0x000C29F0
			public void ActivateCosmetics(CosmeticsController.CosmeticSet prevSet, VRRig rig, BodyDockPositions bDock, CosmeticsController.CosmeticItem nullItem, CosmeticItemRegistry cosmeticsObjectRegistry)
			{
				int num = 16;
				for (int i = 0; i < num; i++)
				{
					this.ActivateHoldable(prevSet, i, cosmeticsObjectRegistry, bDock, nullItem);
					this.ActivateCosmeticItem(prevSet, rig, i, cosmeticsObjectRegistry, bDock, nullItem);
				}
				this.OnSetActivated(prevSet, this, rig.creatorWrapped);
			}

			// Token: 0x0600281B RID: 10267 RVA: 0x000C4838 File Offset: 0x000C2A38
			public void DeactivateAllCosmetcs(BodyDockPositions bDock, CosmeticsController.CosmeticItem nullItem, CosmeticItemRegistry cosmeticObjectRegistry)
			{
				bDock.DisableAllTransferableItems();
				int num = 16;
				for (int i = 0; i < num; i++)
				{
					CosmeticsController.CosmeticItem cosmeticItem = this.items[i];
					if (!cosmeticItem.isNullItem)
					{
						CosmeticsController.CosmeticSlots cosmeticSlot = (CosmeticsController.CosmeticSlots)i;
						if (!cosmeticItem.isHoldable)
						{
							CosmeticItemInstance cosmeticItemInstance = cosmeticObjectRegistry.Cosmetic(cosmeticItem.displayName);
							if (cosmeticItemInstance != null)
							{
								cosmeticItemInstance.DisableItem(cosmeticSlot);
							}
						}
						this.items[i] = nullItem;
					}
				}
			}

			// Token: 0x0600281C RID: 10268 RVA: 0x000C48A0 File Offset: 0x000C2AA0
			public void LoadFromPlayerPreferences(CosmeticsController controller)
			{
				int num = 16;
				for (int i = 0; i < num; i++)
				{
					CosmeticsController.CosmeticSlots slot = (CosmeticsController.CosmeticSlots)i;
					string @string = PlayerPrefs.GetString(CosmeticsController.CosmeticSet.SlotPlayerPreferenceName(slot), "NOTHING");
					if (@string == "null" || @string == "NOTHING")
					{
						this.items[i] = controller.nullItem;
					}
					else
					{
						CosmeticsController.CosmeticItem item = controller.GetItemFromDict(@string);
						if (item.isNullItem)
						{
							Debug.LogError("LoadFromPlayerPreferences: Could not find item stored in player prefs: \"" + @string + "\"");
							this.items[i] = controller.nullItem;
						}
						else if (!CosmeticsController.CompareCategoryToSavedCosmeticSlots(item.itemCategory, slot))
						{
							this.items[i] = controller.nullItem;
						}
						else if (controller.unlockedCosmetics.FindIndex((CosmeticsController.CosmeticItem x) => item.itemName == x.itemName) >= 0)
						{
							this.items[i] = item;
						}
						else
						{
							this.items[i] = controller.nullItem;
						}
					}
				}
			}

			// Token: 0x0600281D RID: 10269 RVA: 0x000C49BC File Offset: 0x000C2BBC
			public string[] ToDisplayNameArray()
			{
				int num = 16;
				for (int i = 0; i < num; i++)
				{
					this.returnArray[i] = (string.IsNullOrEmpty(this.items[i].displayName) ? "null" : this.items[i].displayName);
				}
				return this.returnArray;
			}

			// Token: 0x0600281E RID: 10270 RVA: 0x000C4A18 File Offset: 0x000C2C18
			public string[] HoldableDisplayNames(bool leftHoldables)
			{
				int num = 16;
				int num2 = 0;
				for (int i = 0; i < num; i++)
				{
					if (this.items[i].isHoldable && this.items[i].isHoldable && this.items[i].itemCategory != CosmeticsController.CosmeticCategory.Chest)
					{
						if (leftHoldables && BodyDockPositions.IsPositionLeft(CosmeticsController.CosmeticSlotToDropPosition((CosmeticsController.CosmeticSlots)i)))
						{
							num2++;
						}
						else if (!leftHoldables && !BodyDockPositions.IsPositionLeft(CosmeticsController.CosmeticSlotToDropPosition((CosmeticsController.CosmeticSlots)i)))
						{
							num2++;
						}
					}
				}
				if (num2 == 0)
				{
					return null;
				}
				int num3 = 0;
				string[] array = new string[num2];
				for (int j = 0; j < num; j++)
				{
					if (this.items[j].isHoldable)
					{
						if (leftHoldables && BodyDockPositions.IsPositionLeft(CosmeticsController.CosmeticSlotToDropPosition((CosmeticsController.CosmeticSlots)j)))
						{
							array[num3] = this.items[j].displayName;
							num3++;
						}
						else if (!leftHoldables && !BodyDockPositions.IsPositionLeft(CosmeticsController.CosmeticSlotToDropPosition((CosmeticsController.CosmeticSlots)j)))
						{
							array[num3] = this.items[j].displayName;
							num3++;
						}
					}
				}
				return array;
			}

			// Token: 0x0600281F RID: 10271 RVA: 0x000C4B2C File Offset: 0x000C2D2C
			public bool[] ToOnRightSideArray()
			{
				int num = 16;
				bool[] array = new bool[num];
				for (int i = 0; i < num; i++)
				{
					if (this.items[i].isHoldable && this.items[i].itemCategory != CosmeticsController.CosmeticCategory.Chest)
					{
						array[i] = !BodyDockPositions.IsPositionLeft(CosmeticsController.CosmeticSlotToDropPosition((CosmeticsController.CosmeticSlots)i));
					}
					else
					{
						array[i] = false;
					}
				}
				return array;
			}

			// Token: 0x04002AFB RID: 11003
			public CosmeticsController.CosmeticItem[] items;

			// Token: 0x04002AFD RID: 11005
			public string[] returnArray = new string[16];

			// Token: 0x0200069C RID: 1692
			// (Invoke) Token: 0x06002821 RID: 10273
			public delegate void OnSetActivatedHandler(CosmeticsController.CosmeticSet prevSet, CosmeticsController.CosmeticSet currentSet, NetPlayer netPlayer);
		}

		// Token: 0x0200069E RID: 1694
		[Serializable]
		public struct CosmeticItem
		{
			// Token: 0x04002AFF RID: 11007
			[Tooltip("Should match the spreadsheet item name.")]
			public string itemName;

			// Token: 0x04002B00 RID: 11008
			[Tooltip("Determines what wardrobe section the item will show up in.")]
			public CosmeticsController.CosmeticCategory itemCategory;

			// Token: 0x04002B01 RID: 11009
			[Tooltip("If this is a holdable item.")]
			public bool isHoldable;

			// Token: 0x04002B02 RID: 11010
			[Tooltip("Icon shown in the store menus & hunt watch.")]
			public Sprite itemPicture;

			// Token: 0x04002B03 RID: 11011
			public string displayName;

			// Token: 0x04002B04 RID: 11012
			public string itemPictureResourceString;

			// Token: 0x04002B05 RID: 11013
			[Tooltip("The name shown on the store checkout screen.")]
			public string overrideDisplayName;

			// Token: 0x04002B06 RID: 11014
			[DebugReadout]
			[NonSerialized]
			public int cost;

			// Token: 0x04002B07 RID: 11015
			[DebugReadout]
			[NonSerialized]
			public string[] bundledItems;

			// Token: 0x04002B08 RID: 11016
			[DebugReadout]
			[NonSerialized]
			public bool canTryOn;

			// Token: 0x04002B09 RID: 11017
			[Tooltip("Set to true if the item takes up both left and right wearable hand slots at the same time. Used for things like mittens/gloves.")]
			public bool bothHandsHoldable;

			// Token: 0x04002B0A RID: 11018
			public bool bLoadsFromResources;

			// Token: 0x04002B0B RID: 11019
			public bool bUsesMeshAtlas;

			// Token: 0x04002B0C RID: 11020
			public Vector3 rotationOffset;

			// Token: 0x04002B0D RID: 11021
			public Vector3 positionOffset;

			// Token: 0x04002B0E RID: 11022
			public string meshAtlasResourceString;

			// Token: 0x04002B0F RID: 11023
			public string meshResourceString;

			// Token: 0x04002B10 RID: 11024
			public string materialResourceString;

			// Token: 0x04002B11 RID: 11025
			[HideInInspector]
			public bool isNullItem;
		}

		// Token: 0x0200069F RID: 1695
		[Serializable]
		public class IAPRequestBody
		{
			// Token: 0x04002B12 RID: 11026
			public string accessToken;

			// Token: 0x04002B13 RID: 11027
			public string userID;

			// Token: 0x04002B14 RID: 11028
			public string nonce;

			// Token: 0x04002B15 RID: 11029
			public string platform;

			// Token: 0x04002B16 RID: 11030
			public string sku;

			// Token: 0x04002B17 RID: 11031
			public string playFabId;

			// Token: 0x04002B18 RID: 11032
			public bool[] debugParameters;
		}

		// Token: 0x020006A0 RID: 1696
		public enum EWearingCosmeticSet
		{
			// Token: 0x04002B1A RID: 11034
			NotASet,
			// Token: 0x04002B1B RID: 11035
			NotWearing,
			// Token: 0x04002B1C RID: 11036
			Partial,
			// Token: 0x04002B1D RID: 11037
			Complete
		}
	}
}
