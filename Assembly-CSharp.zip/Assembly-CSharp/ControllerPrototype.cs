﻿using System;
using Fusion;
using UnityEngine;

// Token: 0x02000216 RID: 534
[ScriptHelp(BackColor = EditorHeaderBackColor.Steel)]
[NetworkBehaviourWeaved(3)]
public class ControllerPrototype : NetworkBehaviour
{
	// Token: 0x17000166 RID: 358
	// (get) Token: 0x06000B28 RID: 2856 RVA: 0x0003C2E8 File Offset: 0x0003A4E8
	// (set) Token: 0x06000B29 RID: 2857 RVA: 0x0003C317 File Offset: 0x0003A517
	[Networked]
	[NetworkedWeaved(0, 3)]
	public Vector3 MovementDirection
	{
		get
		{
			if (this.Ptr == null)
			{
				throw new InvalidOperationException("Error when accessing ControllerPrototype.MovementDirection. Networked properties can only be accessed when Spawned() has been called.");
			}
			return ReadWriteUtilsForWeaver.ReadVector3(this.Ptr + 0, 0.001f);
		}
		set
		{
			if (this.Ptr == null)
			{
				throw new InvalidOperationException("Error when accessing ControllerPrototype.MovementDirection. Networked properties can only be accessed when Spawned() has been called.");
			}
			ReadWriteUtilsForWeaver.WriteVector3(this.Ptr + 0, 999.99994f, value);
		}
	}

	// Token: 0x17000167 RID: 359
	// (get) Token: 0x06000B2A RID: 2858 RVA: 0x0003C348 File Offset: 0x0003A548
	private bool ShowSpeed
	{
		get
		{
			NetworkCharacterControllerPrototype networkCharacterControllerPrototype;
			return this && !base.TryGetComponent<NetworkCharacterControllerPrototype>(out networkCharacterControllerPrototype);
		}
	}

	// Token: 0x06000B2B RID: 2859 RVA: 0x0003C36A File Offset: 0x0003A56A
	public void Awake()
	{
		this.CacheComponents();
	}

	// Token: 0x06000B2C RID: 2860 RVA: 0x0003C36A File Offset: 0x0003A56A
	public override void Spawned()
	{
		this.CacheComponents();
	}

	// Token: 0x06000B2D RID: 2861 RVA: 0x0003C374 File Offset: 0x0003A574
	private void CacheComponents()
	{
		if (!this._ncc)
		{
			this._ncc = base.GetComponent<NetworkCharacterControllerPrototype>();
		}
		if (!this._nrb)
		{
			this._nrb = base.GetComponent<NetworkRigidbody>();
		}
		if (!this._nrb2d)
		{
			this._nrb2d = base.GetComponent<NetworkRigidbody2D>();
		}
		if (!this._nt)
		{
			this._nt = base.GetComponent<NetworkTransform>();
		}
	}

	// Token: 0x06000B2E RID: 2862 RVA: 0x0003C3E8 File Offset: 0x0003A5E8
	public override void FixedUpdateNetwork()
	{
		if (this.Runner.Config.PhysicsEngine == NetworkProjectConfig.PhysicsEngines.None)
		{
			return;
		}
		NetworkInputPrototype networkInputPrototype;
		Vector3 vector;
		if (base.GetInput<NetworkInputPrototype>(out networkInputPrototype))
		{
			vector = default(Vector3);
			if (networkInputPrototype.IsDown(3))
			{
				vector += (this.TransformLocal ? base.transform.forward : Vector3.forward);
			}
			if (networkInputPrototype.IsDown(4))
			{
				vector -= (this.TransformLocal ? base.transform.forward : Vector3.forward);
			}
			if (networkInputPrototype.IsDown(5))
			{
				vector -= (this.TransformLocal ? base.transform.right : Vector3.right);
			}
			if (networkInputPrototype.IsDown(6))
			{
				vector += (this.TransformLocal ? base.transform.right : Vector3.right);
			}
			vector = vector.normalized;
			this.MovementDirection = vector;
			if (networkInputPrototype.IsDown(7))
			{
				if (this._ncc)
				{
					this._ncc.Jump(false, null);
				}
				else
				{
					vector += (this.TransformLocal ? base.transform.up : Vector3.up);
				}
			}
		}
		else
		{
			vector = this.MovementDirection;
		}
		if (this._ncc)
		{
			this._ncc.Move(vector);
			return;
		}
		if (this._nrb && !this._nrb.Rigidbody.isKinematic)
		{
			this._nrb.Rigidbody.AddForce(vector * this.Speed);
			return;
		}
		if (this._nrb2d && !this._nrb2d.Rigidbody.isKinematic)
		{
			Vector2 a = new Vector2(vector.x, vector.y + vector.z);
			this._nrb2d.Rigidbody.AddForce(a * this.Speed);
			return;
		}
		base.transform.position += vector * this.Speed * this.Runner.DeltaTime;
	}

	// Token: 0x06000B30 RID: 2864 RVA: 0x0003C622 File Offset: 0x0003A822
	public override void CopyBackingFieldsToState(bool A_1)
	{
		this.MovementDirection = this._MovementDirection;
	}

	// Token: 0x06000B31 RID: 2865 RVA: 0x0003C630 File Offset: 0x0003A830
	public override void CopyStateToBackingFields()
	{
		this._MovementDirection = this.MovementDirection;
	}

	// Token: 0x04000C95 RID: 3221
	protected NetworkCharacterControllerPrototype _ncc;

	// Token: 0x04000C96 RID: 3222
	protected NetworkRigidbody _nrb;

	// Token: 0x04000C97 RID: 3223
	protected NetworkRigidbody2D _nrb2d;

	// Token: 0x04000C98 RID: 3224
	protected NetworkTransform _nt;

	// Token: 0x04000C99 RID: 3225
	[SerializeField]
	[DefaultForProperty("MovementDirection", 0, 3)]
	private Vector3 _MovementDirection;

	// Token: 0x04000C9A RID: 3226
	public bool TransformLocal;

	// Token: 0x04000C9B RID: 3227
	[DrawIf("ShowSpeed", Hide = true)]
	public float Speed = 6f;

	// Token: 0x04000C9C RID: 3228
	static Changed<ControllerPrototype> $IL2CPP_CHANGED;

	// Token: 0x04000C9D RID: 3229
	static ChangedDelegate<ControllerPrototype> $IL2CPP_CHANGED_DELEGATE;

	// Token: 0x04000C9E RID: 3230
	static NetworkBehaviourCallbacks<ControllerPrototype> $IL2CPP_NETWORK_BEHAVIOUR_CALLBACKS;
}
