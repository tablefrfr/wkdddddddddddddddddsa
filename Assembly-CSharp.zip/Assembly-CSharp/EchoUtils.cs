﻿using System;
using UnityEngine;

// Token: 0x020004BD RID: 1213
public static class EchoUtils
{
	// Token: 0x06001BA2 RID: 7074 RVA: 0x0008C470 File Offset: 0x0008A670
	public static T Echo<T>(this T message)
	{
		Debug.Log(message);
		return message;
	}

	// Token: 0x06001BA3 RID: 7075 RVA: 0x0008C47E File Offset: 0x0008A67E
	public static T Echo<T>(this T message, Object context)
	{
		Debug.Log(message, context);
		return message;
	}
}
