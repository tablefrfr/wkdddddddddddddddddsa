﻿using System;
using UnityEngine;

namespace BoingKit
{
	// Token: 0x02000831 RID: 2097
	public struct Vector3Spring
	{
		// Token: 0x060032EB RID: 13035 RVA: 0x000FF483 File Offset: 0x000FD683
		public void Reset()
		{
			this.Value = Vector3.zero;
			this.Velocity = Vector3.zero;
		}

		// Token: 0x060032EC RID: 13036 RVA: 0x000FF49B File Offset: 0x000FD69B
		public void Reset(Vector3 initValue)
		{
			this.Value = initValue;
			this.Velocity = Vector3.zero;
		}

		// Token: 0x060032ED RID: 13037 RVA: 0x000FF4AF File Offset: 0x000FD6AF
		public void Reset(Vector3 initValue, Vector3 initVelocity)
		{
			this.Value = initValue;
			this.Velocity = initVelocity;
		}

		// Token: 0x060032EE RID: 13038 RVA: 0x000FF4C0 File Offset: 0x000FD6C0
		public Vector3 TrackDampingRatio(Vector3 targetValue, float angularFrequency, float dampingRatio, float deltaTime)
		{
			if (angularFrequency < MathUtil.Epsilon)
			{
				this.Velocity = Vector3.zero;
				return this.Value;
			}
			Vector3 a = targetValue - this.Value;
			float num = 1f + 2f * deltaTime * dampingRatio * angularFrequency;
			float num2 = angularFrequency * angularFrequency;
			float num3 = deltaTime * num2;
			float num4 = deltaTime * num3;
			float d = 1f / (num + num4);
			Vector3 a2 = num * this.Value + deltaTime * this.Velocity + num4 * targetValue;
			Vector3 a3 = this.Velocity + num3 * a;
			this.Velocity = a3 * d;
			this.Value = a2 * d;
			if (this.Velocity.magnitude < MathUtil.Epsilon && a.magnitude < MathUtil.Epsilon)
			{
				this.Velocity = Vector3.zero;
				this.Value = targetValue;
			}
			return this.Value;
		}

		// Token: 0x060032EF RID: 13039 RVA: 0x000FF5BC File Offset: 0x000FD7BC
		public Vector3 TrackHalfLife(Vector3 targetValue, float frequencyHz, float halfLife, float deltaTime)
		{
			if (halfLife < MathUtil.Epsilon)
			{
				this.Velocity = Vector3.zero;
				this.Value = targetValue;
				return this.Value;
			}
			float num = frequencyHz * MathUtil.TwoPi;
			float dampingRatio = 0.6931472f / (num * halfLife);
			return this.TrackDampingRatio(targetValue, num, dampingRatio, deltaTime);
		}

		// Token: 0x060032F0 RID: 13040 RVA: 0x000FF608 File Offset: 0x000FD808
		public Vector3 TrackExponential(Vector3 targetValue, float halfLife, float deltaTime)
		{
			if (halfLife < MathUtil.Epsilon)
			{
				this.Velocity = Vector3.zero;
				this.Value = targetValue;
				return this.Value;
			}
			float angularFrequency = 0.6931472f / halfLife;
			float dampingRatio = 1f;
			return this.TrackDampingRatio(targetValue, angularFrequency, dampingRatio, deltaTime);
		}

		// Token: 0x0400354A RID: 13642
		public static readonly int Stride = 32;

		// Token: 0x0400354B RID: 13643
		public Vector3 Value;

		// Token: 0x0400354C RID: 13644
		private float m_padding0;

		// Token: 0x0400354D RID: 13645
		public Vector3 Velocity;

		// Token: 0x0400354E RID: 13646
		private float m_padding1;
	}
}
