﻿using System;
using UnityEngine;

// Token: 0x02000385 RID: 901
public class GorillaModeSelector : MonoBehaviour
{
	// Token: 0x06001492 RID: 5266 RVA: 0x00003051 File Offset: 0x00001251
	private void Start()
	{
	}

	// Token: 0x06001493 RID: 5267 RVA: 0x00003051 File Offset: 0x00001251
	private void Update()
	{
	}
}
