﻿using System;

namespace BoingKit
{
	// Token: 0x020007F8 RID: 2040
	public static class BoingKit
	{
		// Token: 0x0400341D RID: 13341
		public static readonly Version Version = new Version(1, 2, 37);
	}
}
