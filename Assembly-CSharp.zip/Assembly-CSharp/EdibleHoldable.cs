﻿using System;
using GorillaTag;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x02000294 RID: 660
public class EdibleHoldable : TransferrableObject
{
	// Token: 0x06000EBD RID: 3773 RVA: 0x0004D2D8 File Offset: 0x0004B4D8
	protected override void Start()
	{
		base.Start();
		this.itemState = TransferrableObject.ItemStates.State0;
		this.previousEdibleState = (EdibleHoldable.EdibleHoldableStates)this.itemState;
		this.lastFullyEatenTime = -this.respawnTime;
		this.iResettableItems = base.GetComponentsInChildren<IResettableItem>(true);
	}

	// Token: 0x06000EBE RID: 3774 RVA: 0x0004D30D File Offset: 0x0004B50D
	public override void OnGrab(InteractionPoint pointGrabbed, GameObject grabbingHand)
	{
		base.OnGrab(pointGrabbed, grabbingHand);
		this.lastEatTime = Time.time - this.eatMinimumCooldown;
	}

	// Token: 0x06000EBF RID: 3775 RVA: 0x0004D329 File Offset: 0x0004B529
	public override void OnActivate()
	{
		base.OnActivate();
	}

	// Token: 0x06000EC0 RID: 3776 RVA: 0x0004D331 File Offset: 0x0004B531
	public override void OnEnable()
	{
		base.OnEnable();
	}

	// Token: 0x06000EC1 RID: 3777 RVA: 0x0004D339 File Offset: 0x0004B539
	public override void OnDisable()
	{
		base.OnDisable();
	}

	// Token: 0x06000EC2 RID: 3778 RVA: 0x0004D341 File Offset: 0x0004B541
	public override void ResetToDefaultState()
	{
		base.ResetToDefaultState();
	}

	// Token: 0x06000EC3 RID: 3779 RVA: 0x0004D349 File Offset: 0x0004B549
	public override bool OnRelease(DropZone zoneReleased, GameObject releasingHand)
	{
		return base.OnRelease(zoneReleased, releasingHand) && !base.InHand();
	}

	// Token: 0x06000EC4 RID: 3780 RVA: 0x0004D364 File Offset: 0x0004B564
	protected override void LateUpdateLocal()
	{
		base.LateUpdateLocal();
		if (this.itemState == TransferrableObject.ItemStates.State3)
		{
			if (Time.time > this.lastFullyEatenTime + this.respawnTime)
			{
				this.itemState = TransferrableObject.ItemStates.State0;
				return;
			}
		}
		else if (Time.time > this.lastEatTime + this.eatMinimumCooldown)
		{
			bool flag = false;
			bool flag2 = false;
			float num = this.biteDistance * this.biteDistance;
			if (!GorillaParent.hasInstance)
			{
				return;
			}
			VRRig arg = null;
			VRRig arg2 = null;
			for (int i = 0; i < GorillaParent.instance.vrrigs.Count; i++)
			{
				VRRig vrrig = GorillaParent.instance.vrrigs[i];
				if (!vrrig.isOfflineVRRig)
				{
					if (vrrig.head == null || vrrig.head.rigTarget == null)
					{
						break;
					}
					Transform transform = vrrig.head.rigTarget.transform;
					if ((transform.position + transform.rotation * this.biteOffset - this.biteSpot.position).sqrMagnitude < num)
					{
						flag = true;
						arg2 = vrrig;
					}
				}
			}
			Transform transform2 = GorillaTagger.Instance.offlineVRRig.head.rigTarget.transform;
			if ((transform2.position + transform2.rotation * this.biteOffset - this.biteSpot.position).sqrMagnitude < num)
			{
				flag = true;
				flag2 = true;
				arg = GorillaTagger.Instance.offlineVRRig;
			}
			if (flag && !this.inBiteZone && (!flag2 || base.InHand()) && this.itemState != TransferrableObject.ItemStates.State3)
			{
				if (this.itemState == TransferrableObject.ItemStates.State0)
				{
					this.itemState = TransferrableObject.ItemStates.State1;
				}
				else if (this.itemState == TransferrableObject.ItemStates.State1)
				{
					this.itemState = TransferrableObject.ItemStates.State2;
				}
				else if (this.itemState == TransferrableObject.ItemStates.State2)
				{
					this.itemState = TransferrableObject.ItemStates.State3;
				}
				this.lastEatTime = Time.time;
				this.lastFullyEatenTime = Time.time;
			}
			if (flag)
			{
				if (flag2)
				{
					EdibleHoldable.BiteEvent biteEvent = this.onBiteView;
					if (biteEvent != null)
					{
						biteEvent.Invoke(arg, (int)this.itemState);
					}
				}
				else
				{
					EdibleHoldable.BiteEvent biteEvent2 = this.onBiteWorld;
					if (biteEvent2 != null)
					{
						biteEvent2.Invoke(arg2, (int)this.itemState);
					}
				}
			}
			this.inBiteZone = flag;
		}
	}

	// Token: 0x06000EC5 RID: 3781 RVA: 0x0004D59C File Offset: 0x0004B79C
	protected override void LateUpdateShared()
	{
		base.LateUpdateShared();
		EdibleHoldable.EdibleHoldableStates itemState = (EdibleHoldable.EdibleHoldableStates)this.itemState;
		if (itemState != this.previousEdibleState)
		{
			this.OnEdibleHoldableStateChange();
		}
		this.previousEdibleState = itemState;
	}

	// Token: 0x06000EC6 RID: 3782 RVA: 0x0004D5CC File Offset: 0x0004B7CC
	protected virtual void OnEdibleHoldableStateChange()
	{
		float amplitude = GorillaTagger.Instance.tapHapticStrength / 4f;
		float fixedDeltaTime = Time.fixedDeltaTime;
		float volumeScale = 0.08f;
		int num = 0;
		if (this.itemState == TransferrableObject.ItemStates.State0)
		{
			num = 0;
			if (this.iResettableItems != null)
			{
				foreach (IResettableItem resettableItem in this.iResettableItems)
				{
					if (resettableItem != null)
					{
						resettableItem.ResetToDefaultState();
					}
				}
			}
		}
		else if (this.itemState == TransferrableObject.ItemStates.State1)
		{
			num = 1;
		}
		else if (this.itemState == TransferrableObject.ItemStates.State2)
		{
			num = 2;
		}
		else if (this.itemState == TransferrableObject.ItemStates.State3)
		{
			num = 3;
		}
		int num2 = num - 1;
		if (num2 < 0)
		{
			num2 = this.edibleMeshObjects.Length - 1;
		}
		this.edibleMeshObjects[num2].SetActive(false);
		this.edibleMeshObjects[num].SetActive(true);
		if ((this.itemState != TransferrableObject.ItemStates.State0 && this.onBiteView != null) || this.onBiteWorld != null)
		{
			VRRig vrrig = null;
			float num3 = float.PositiveInfinity;
			for (int j = 0; j < GorillaParent.instance.vrrigs.Count; j++)
			{
				VRRig vrrig2 = GorillaParent.instance.vrrigs[j];
				if (vrrig2.head == null || vrrig2.head.rigTarget == null)
				{
					break;
				}
				Transform transform = vrrig2.head.rigTarget.transform;
				float sqrMagnitude = (transform.position + transform.rotation * this.biteOffset - this.biteSpot.position).sqrMagnitude;
				if (sqrMagnitude < num3)
				{
					num3 = sqrMagnitude;
					vrrig = vrrig2;
				}
			}
			if (vrrig != null)
			{
				EdibleHoldable.BiteEvent biteEvent = vrrig.isOfflineVRRig ? this.onBiteView : this.onBiteWorld;
				if (biteEvent != null)
				{
					biteEvent.Invoke(vrrig, (int)this.itemState);
				}
			}
		}
		this.eatSoundSource.PlayOneShot(this.eatSounds[num], volumeScale);
		if (this.IsMyItem())
		{
			if (base.InHand())
			{
				GorillaTagger.Instance.StartVibration(base.InLeftHand(), amplitude, fixedDeltaTime);
				return;
			}
			GorillaTagger.Instance.StartVibration(false, amplitude, fixedDeltaTime);
			GorillaTagger.Instance.StartVibration(true, amplitude, fixedDeltaTime);
		}
	}

	// Token: 0x06000EC7 RID: 3783 RVA: 0x0003FA0C File Offset: 0x0003DC0C
	public override bool CanActivate()
	{
		return true;
	}

	// Token: 0x06000EC8 RID: 3784 RVA: 0x0003FA0C File Offset: 0x0003DC0C
	public override bool CanDeactivate()
	{
		return true;
	}

	// Token: 0x0400109C RID: 4252
	public AudioClip[] eatSounds;

	// Token: 0x0400109D RID: 4253
	public GameObject[] edibleMeshObjects;

	// Token: 0x0400109E RID: 4254
	public EdibleHoldable.BiteEvent onBiteView;

	// Token: 0x0400109F RID: 4255
	public EdibleHoldable.BiteEvent onBiteWorld;

	// Token: 0x040010A0 RID: 4256
	[DebugReadout]
	public float lastEatTime;

	// Token: 0x040010A1 RID: 4257
	[DebugReadout]
	public float lastFullyEatenTime;

	// Token: 0x040010A2 RID: 4258
	public float eatMinimumCooldown = 1f;

	// Token: 0x040010A3 RID: 4259
	public float respawnTime = 7f;

	// Token: 0x040010A4 RID: 4260
	public float biteDistance = 0.1666667f;

	// Token: 0x040010A5 RID: 4261
	public Vector3 biteOffset = new Vector3(0f, 0.0208f, 0.171f);

	// Token: 0x040010A6 RID: 4262
	public Transform biteSpot;

	// Token: 0x040010A7 RID: 4263
	public bool inBiteZone;

	// Token: 0x040010A8 RID: 4264
	public AudioSource eatSoundSource;

	// Token: 0x040010A9 RID: 4265
	private EdibleHoldable.EdibleHoldableStates previousEdibleState;

	// Token: 0x040010AA RID: 4266
	private IResettableItem[] iResettableItems;

	// Token: 0x02000295 RID: 661
	private enum EdibleHoldableStates
	{
		// Token: 0x040010AC RID: 4268
		EatingState0 = 1,
		// Token: 0x040010AD RID: 4269
		EatingState1,
		// Token: 0x040010AE RID: 4270
		EatingState2 = 4,
		// Token: 0x040010AF RID: 4271
		EatingState3 = 8
	}

	// Token: 0x02000296 RID: 662
	[Serializable]
	public class BiteEvent : UnityEvent<VRRig, int>
	{
	}
}
