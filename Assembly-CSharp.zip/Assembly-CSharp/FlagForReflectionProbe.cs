﻿using System;
using UnityEngine;

// Token: 0x020004C2 RID: 1218
public class FlagForReflectionProbe : MonoBehaviour
{
	// Token: 0x04001F7C RID: 8060
	public bool enableSimpleReflectionProbe;
}
