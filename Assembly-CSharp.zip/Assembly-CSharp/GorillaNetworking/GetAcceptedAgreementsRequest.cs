﻿using System;

namespace GorillaNetworking
{
	// Token: 0x020006C8 RID: 1736
	public class GetAcceptedAgreementsRequest
	{
		// Token: 0x04002C41 RID: 11329
		public string[] AgreementKeys;
	}
}
