﻿using System;
using UnityEngine;

// Token: 0x0200001F RID: 31
public class ColliderEnabledManager : MonoBehaviour
{
	// Token: 0x0600005A RID: 90 RVA: 0x00004662 File Offset: 0x00002862
	private void Start()
	{
		this.floorEnabled = true;
		this.floorCollidersEnabled = true;
		ColliderEnabledManager.instance = this;
	}

	// Token: 0x0600005B RID: 91 RVA: 0x00004678 File Offset: 0x00002878
	private void OnDestroy()
	{
		ColliderEnabledManager.instance = null;
	}

	// Token: 0x0600005C RID: 92 RVA: 0x00004680 File Offset: 0x00002880
	public void DisableFloorForFrame()
	{
		this.floorEnabled = false;
	}

	// Token: 0x0600005D RID: 93 RVA: 0x0000468C File Offset: 0x0000288C
	private void LateUpdate()
	{
		if (!this.floorEnabled && this.floorCollidersEnabled)
		{
			this.DisableFloor();
		}
		if (!this.floorCollidersEnabled && Time.time > this.timeDisabled + this.disableLength)
		{
			this.floorCollidersEnabled = true;
		}
		Collider[] array = this.floorCollider;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].enabled = this.floorCollidersEnabled;
		}
		if (this.floorCollidersEnabled)
		{
			GorillaSurfaceOverride[] array2 = this.walls;
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i].overrideIndex = this.wallsBeforeMaterial;
			}
		}
		else
		{
			GorillaSurfaceOverride[] array2 = this.walls;
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i].overrideIndex = this.wallsAfterMaterial;
			}
		}
		this.floorEnabled = true;
	}

	// Token: 0x0600005E RID: 94 RVA: 0x0000474C File Offset: 0x0000294C
	private void DisableFloor()
	{
		this.floorCollidersEnabled = false;
		this.timeDisabled = Time.time;
	}

	// Token: 0x0400008D RID: 141
	public static ColliderEnabledManager instance;

	// Token: 0x0400008E RID: 142
	public Collider[] floorCollider;

	// Token: 0x0400008F RID: 143
	public bool floorEnabled;

	// Token: 0x04000090 RID: 144
	public bool wasFloorEnabled;

	// Token: 0x04000091 RID: 145
	public bool floorCollidersEnabled;

	// Token: 0x04000092 RID: 146
	[GorillaSoundLookup]
	public int wallsBeforeMaterial;

	// Token: 0x04000093 RID: 147
	[GorillaSoundLookup]
	public int wallsAfterMaterial;

	// Token: 0x04000094 RID: 148
	public GorillaSurfaceOverride[] walls;

	// Token: 0x04000095 RID: 149
	public float timeDisabled;

	// Token: 0x04000096 RID: 150
	public float disableLength;
}
