﻿using System;

// Token: 0x02000327 RID: 807
public struct BuilderTableSubMesh
{
	// Token: 0x040014C6 RID: 5318
	public int startIndex;

	// Token: 0x040014C7 RID: 5319
	public int indexCount;

	// Token: 0x040014C8 RID: 5320
	public int startVertex;
}
