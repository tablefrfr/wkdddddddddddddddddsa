﻿using System;
using System.Collections.Generic;
using GorillaTag.Rendering;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.InputSystem;

// Token: 0x02000067 RID: 103
public class AngryBeeSwarm : MonoBehaviourPunCallbacks, IInRoomCallbacks, IPunObservable, IOnPhotonViewOwnerChange, IPhotonViewCallback
{
	// Token: 0x17000014 RID: 20
	// (get) Token: 0x0600020D RID: 525 RVA: 0x0000EC58 File Offset: 0x0000CE58
	public bool isDormant
	{
		get
		{
			return this.currentState == AngryBeeSwarm.ChaseState.Dormant;
		}
	}

	// Token: 0x0600020E RID: 526 RVA: 0x0000EC63 File Offset: 0x0000CE63
	private void Awake()
	{
		AngryBeeSwarm.instance = this;
		this.targetPlayer = null;
		this.currentState = AngryBeeSwarm.ChaseState.Dormant;
		this.grabTimestamp = -this.minGrabCooldown;
	}

	// Token: 0x0600020F RID: 527 RVA: 0x0000EC88 File Offset: 0x0000CE88
	private void InitializeSwarm()
	{
		if (PhotonNetwork.InRoom && base.photonView.IsMine)
		{
			this.beeAnimator.transform.localPosition = Vector3.zero;
			this.lastSpeedIncreased = 0f;
			this.currentSpeed = 0f;
		}
	}

	// Token: 0x06000210 RID: 528 RVA: 0x0000ECD4 File Offset: 0x0000CED4
	private void LateUpdate()
	{
		if (!PhotonNetwork.InRoom)
		{
			this.currentState = AngryBeeSwarm.ChaseState.Dormant;
			this.UpdateState();
			return;
		}
		if (base.photonView.IsMine)
		{
			AngryBeeSwarm.ChaseState chaseState = this.currentState;
			switch (chaseState)
			{
			case AngryBeeSwarm.ChaseState.Dormant:
				if (Application.isEditor && Keyboard.current[Key.Space].wasPressedThisFrame)
				{
					this.currentState = AngryBeeSwarm.ChaseState.InitialEmerge;
				}
				break;
			case AngryBeeSwarm.ChaseState.InitialEmerge:
				if (Time.time > this.emergeStartedTimestamp + this.totalTimeToEmerge)
				{
					this.currentState = AngryBeeSwarm.ChaseState.Chasing;
				}
				break;
			case (AngryBeeSwarm.ChaseState)3:
				break;
			case AngryBeeSwarm.ChaseState.Chasing:
				if (this.followTarget == null || this.targetPlayer == null || Time.time > this.NextRefreshClosestPlayerTimestamp)
				{
					this.ChooseClosestTarget();
					if (this.followTarget != null)
					{
						this.BoredToDeathAtTimestamp = -1f;
					}
					else if (this.BoredToDeathAtTimestamp < 0f)
					{
						this.BoredToDeathAtTimestamp = Time.time + this.boredAfterDuration;
					}
				}
				if (this.BoredToDeathAtTimestamp >= 0f && Time.time > this.BoredToDeathAtTimestamp)
				{
					this.currentState = AngryBeeSwarm.ChaseState.Dormant;
				}
				else if (!(this.followTarget == null) && (this.followTarget.position - this.beeAnimator.transform.position).magnitude < this.catchDistance)
				{
					float num = ZoneShaderSettings.GetWaterY() + this.PlayerMinHeightAboveWater;
					if (this.followTarget.position.y > num)
					{
						this.currentState = AngryBeeSwarm.ChaseState.Grabbing;
					}
				}
				break;
			default:
				if (chaseState == AngryBeeSwarm.ChaseState.Grabbing)
				{
					if (Time.time > this.grabTimestamp + this.grabDuration)
					{
						this.currentState = AngryBeeSwarm.ChaseState.Dormant;
					}
				}
				break;
			}
		}
		if (this.lastState != this.currentState)
		{
			this.OnChangeState(this.currentState);
			this.lastState = this.currentState;
		}
		this.UpdateState();
	}

	// Token: 0x06000211 RID: 529 RVA: 0x0000EEB8 File Offset: 0x0000D0B8
	public void UpdateState()
	{
		AngryBeeSwarm.ChaseState chaseState = this.currentState;
		switch (chaseState)
		{
		case AngryBeeSwarm.ChaseState.Dormant:
		case (AngryBeeSwarm.ChaseState)3:
			break;
		case AngryBeeSwarm.ChaseState.InitialEmerge:
			if (PhotonNetwork.InRoom)
			{
				this.SwarmEmergeUpdateShared();
				return;
			}
			break;
		case AngryBeeSwarm.ChaseState.Chasing:
			if (PhotonNetwork.InRoom)
			{
				if (base.photonView.IsMine)
				{
					this.ChaseHost();
				}
				this.MoveBodyShared();
				return;
			}
			break;
		default:
			if (chaseState != AngryBeeSwarm.ChaseState.Grabbing)
			{
				return;
			}
			if (PhotonNetwork.InRoom)
			{
				if (this.targetPlayer == PhotonNetwork.LocalPlayer)
				{
					this.RiseGrabbedLocalPlayer();
				}
				this.GrabBodyShared();
			}
			break;
		}
	}

	// Token: 0x06000212 RID: 530 RVA: 0x0000EF38 File Offset: 0x0000D138
	public void Emerge(Vector3 fromPosition, Vector3 toPosition)
	{
		base.transform.position = fromPosition;
		this.emergeFromPosition = fromPosition;
		this.emergeToPosition = toPosition;
		this.currentState = AngryBeeSwarm.ChaseState.InitialEmerge;
		this.emergeStartedTimestamp = Time.time;
	}

	// Token: 0x06000213 RID: 531 RVA: 0x0000EF68 File Offset: 0x0000D168
	private void OnChangeState(AngryBeeSwarm.ChaseState newState)
	{
		switch (newState)
		{
		case AngryBeeSwarm.ChaseState.Dormant:
			if (this.beeAnimator.gameObject.activeSelf)
			{
				this.beeAnimator.gameObject.SetActive(false);
			}
			if (base.photonView.IsMine)
			{
				this.targetPlayer = null;
				base.transform.position = new Vector3(0f, -9999f, 0f);
				this.InitializeSwarm();
			}
			this.SetInitialRotations();
			return;
		case AngryBeeSwarm.ChaseState.InitialEmerge:
			this.emergeStartedTimestamp = Time.time;
			if (!this.beeAnimator.gameObject.activeSelf)
			{
				this.beeAnimator.gameObject.SetActive(true);
			}
			this.beeAnimator.SetEmergeFraction(0f);
			if (base.photonView.IsMine)
			{
				this.currentSpeed = 0f;
				this.ChooseClosestTarget();
			}
			this.SetInitialRotations();
			return;
		case (AngryBeeSwarm.ChaseState)3:
			break;
		case AngryBeeSwarm.ChaseState.Chasing:
			if (!this.beeAnimator.gameObject.activeSelf)
			{
				this.beeAnimator.gameObject.SetActive(true);
			}
			this.beeAnimator.SetEmergeFraction(1f);
			this.ResetPath();
			this.NextRefreshClosestPlayerTimestamp = Time.time + this.RefreshClosestPlayerInterval;
			this.BoredToDeathAtTimestamp = -1f;
			return;
		default:
		{
			if (newState != AngryBeeSwarm.ChaseState.Grabbing)
			{
				return;
			}
			if (!this.beeAnimator.gameObject.activeSelf)
			{
				this.beeAnimator.gameObject.SetActive(true);
			}
			this.grabTimestamp = Time.time;
			this.beeAnimator.transform.localPosition = this.ghostOffsetGrabbingLocal;
			VRRig vrrig = GorillaGameManager.StaticFindRigForPlayer(this.targetPlayer);
			if (vrrig != null)
			{
				this.followTarget = vrrig.transform;
			}
			break;
		}
		}
	}

	// Token: 0x06000214 RID: 532 RVA: 0x0000F118 File Offset: 0x0000D318
	private void ChooseClosestTarget()
	{
		float num = Mathf.Lerp(this.initialRangeLimit, this.finalRangeLimit, (Time.time + this.totalTimeToEmerge - this.emergeStartedTimestamp) / this.rangeLimitBlendDuration);
		float num2 = num * num;
		VRRig vrrig = null;
		float num3 = ZoneShaderSettings.GetWaterY() + this.PlayerMinHeightAboveWater;
		foreach (VRRig vrrig2 in GorillaParent.instance.vrrigs)
		{
			if (vrrig2.head != null && !(vrrig2.head.rigTarget == null) && vrrig2.head.rigTarget.position.y > num3)
			{
				float sqrMagnitude = (base.transform.position - vrrig2.head.rigTarget.transform.position).sqrMagnitude;
				if (sqrMagnitude < num2)
				{
					num2 = sqrMagnitude;
					vrrig = vrrig2;
				}
			}
		}
		if (vrrig != null)
		{
			this.targetPlayer = vrrig.creator;
			this.followTarget = vrrig.head.rigTarget;
			NavMeshHit navMeshHit;
			this.targetIsOnNavMesh = NavMesh.SamplePosition(this.followTarget.position, out navMeshHit, 5f, 1);
		}
		else
		{
			this.targetPlayer = null;
			this.followTarget = null;
		}
		this.NextRefreshClosestPlayerTimestamp = Time.time + this.RefreshClosestPlayerInterval;
	}

	// Token: 0x06000215 RID: 533 RVA: 0x0000F284 File Offset: 0x0000D484
	private void SetInitialRotations()
	{
		this.beeAnimator.transform.localPosition = Vector3.zero;
	}

	// Token: 0x06000216 RID: 534 RVA: 0x0000F29C File Offset: 0x0000D49C
	private void SwarmEmergeUpdateShared()
	{
		if (Time.time < this.emergeStartedTimestamp + this.totalTimeToEmerge)
		{
			float emergeFraction = (Time.time - this.emergeStartedTimestamp) / this.totalTimeToEmerge;
			if (base.photonView.IsMine)
			{
				base.transform.position = Vector3.Lerp(this.emergeFromPosition, this.emergeToPosition, (Time.time - this.emergeStartedTimestamp) / this.totalTimeToEmerge);
			}
			this.beeAnimator.SetEmergeFraction(emergeFraction);
		}
	}

	// Token: 0x06000217 RID: 535 RVA: 0x0000F31C File Offset: 0x0000D51C
	private void RiseGrabbedLocalPlayer()
	{
		if (Time.time > this.grabTimestamp + this.minGrabCooldown)
		{
			this.grabTimestamp = Time.time;
			GorillaTagger.Instance.ApplyStatusEffect(GorillaTagger.StatusEffect.Frozen, GorillaTagger.Instance.tagCooldown);
			GorillaTagger.Instance.StartVibration(true, this.hapticStrength, this.hapticDuration);
			GorillaTagger.Instance.StartVibration(false, this.hapticStrength, this.hapticDuration);
		}
		if (Time.time < this.grabTimestamp + this.grabDuration)
		{
			GorillaTagger.Instance.rigidbody.velocity = Vector3.up * this.grabSpeed;
			EquipmentInteractor.instance.ForceStopClimbing();
		}
	}

	// Token: 0x06000218 RID: 536 RVA: 0x0000F3CC File Offset: 0x0000D5CC
	public void UpdateFollowPath(Vector3 destination, float currentSpeed)
	{
		if (this.path == null)
		{
			this.GetNewPath(destination);
		}
		this.pathPoints[this.pathPoints.Count - 1] = destination;
		Vector3 vector = this.pathPoints[this.currentPathPointIdx];
		base.transform.position = Vector3.MoveTowards(base.transform.position, vector, currentSpeed * Time.deltaTime);
		Vector3 eulerAngles = Quaternion.LookRotation(vector - base.transform.position).eulerAngles;
		if (Mathf.Abs(eulerAngles.x) > 45f)
		{
			eulerAngles.x = 0f;
		}
		base.transform.rotation = Quaternion.Euler(eulerAngles);
		if (this.currentPathPointIdx + 1 < this.pathPoints.Count && (base.transform.position - vector).sqrMagnitude < 0.1f)
		{
			if (this.nextPathTimestamp <= Time.time)
			{
				this.GetNewPath(destination);
				return;
			}
			this.currentPathPointIdx++;
		}
	}

	// Token: 0x06000219 RID: 537 RVA: 0x0000F4DC File Offset: 0x0000D6DC
	private void GetNewPath(Vector3 destination)
	{
		this.path = new NavMeshPath();
		NavMeshHit navMeshHit;
		NavMesh.SamplePosition(base.transform.position, out navMeshHit, 5f, 1);
		NavMeshHit navMeshHit2;
		this.targetIsOnNavMesh = NavMesh.SamplePosition(destination, out navMeshHit2, 5f, 1);
		NavMesh.CalculatePath(navMeshHit.position, navMeshHit2.position, -1, this.path);
		this.pathPoints = new List<Vector3>();
		foreach (Vector3 a in this.path.corners)
		{
			this.pathPoints.Add(a + Vector3.up * this.heightAboveNavmesh);
		}
		this.pathPoints.Add(destination);
		this.currentPathPointIdx = 0;
		this.nextPathTimestamp = Time.time + 2f;
	}

	// Token: 0x0600021A RID: 538 RVA: 0x0000F5B0 File Offset: 0x0000D7B0
	public void ResetPath()
	{
		this.path = null;
	}

	// Token: 0x0600021B RID: 539 RVA: 0x0000F5BC File Offset: 0x0000D7BC
	private void ChaseHost()
	{
		if (this.followTarget != null)
		{
			if (Time.time > this.lastSpeedIncreased + this.velocityIncreaseInterval)
			{
				this.lastSpeedIncreased = Time.time;
				this.currentSpeed += this.velocityStep;
			}
			float num = ZoneShaderSettings.GetWaterY() + this.MinHeightAboveWater;
			Vector3 position = this.followTarget.position;
			if (position.y < num)
			{
				position.y = num;
			}
			if (this.targetIsOnNavMesh)
			{
				this.UpdateFollowPath(position, this.currentSpeed);
				return;
			}
			base.transform.position = Vector3.MoveTowards(base.transform.position, position, this.currentSpeed * Time.deltaTime);
		}
	}

	// Token: 0x0600021C RID: 540 RVA: 0x0000F674 File Offset: 0x0000D874
	private void MoveBodyShared()
	{
		this.noisyOffset = new Vector3(Mathf.PerlinNoise(Time.time, 0f) - 0.5f, Mathf.PerlinNoise(Time.time, 10f) - 0.5f, Mathf.PerlinNoise(Time.time, 20f) - 0.5f);
		this.beeAnimator.transform.localPosition = this.noisyOffset;
	}

	// Token: 0x0600021D RID: 541 RVA: 0x0000F6E1 File Offset: 0x0000D8E1
	private void GrabBodyShared()
	{
		if (this.followTarget != null)
		{
			base.transform.rotation = this.followTarget.rotation;
			base.transform.position = this.followTarget.position;
		}
	}

	// Token: 0x0600021E RID: 542 RVA: 0x0000F720 File Offset: 0x0000D920
	void IPunObservable.OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
	{
		if (info.Sender != PhotonNetwork.MasterClient)
		{
			return;
		}
		if (stream.IsWriting)
		{
			stream.SendNext(this.targetPlayer);
			stream.SendNext(this.currentState);
			stream.SendNext(this.currentSpeed);
			return;
		}
		this.targetPlayer = (Player)stream.ReceiveNext();
		this.currentState = (AngryBeeSwarm.ChaseState)stream.ReceiveNext();
		float f = (float)stream.ReceiveNext();
		if (float.IsFinite(f))
		{
			this.currentSpeed = f;
		}
	}

	// Token: 0x0600021F RID: 543 RVA: 0x0000F7AF File Offset: 0x0000D9AF
	void IOnPhotonViewOwnerChange.OnOwnerChange(Player newOwner, Player previousOwner)
	{
		if (newOwner == PhotonNetwork.LocalPlayer)
		{
			this.OnChangeState(this.currentState);
		}
	}

	// Token: 0x06000220 RID: 544 RVA: 0x0000F7C5 File Offset: 0x0000D9C5
	public override void OnJoinedRoom()
	{
		base.OnJoinedRoom();
		if (PhotonNetwork.IsMasterClient)
		{
			this.InitializeSwarm();
		}
	}

	// Token: 0x06000221 RID: 545 RVA: 0x0000F7DA File Offset: 0x0000D9DA
	private void TestEmerge()
	{
		this.Emerge(this.testEmergeFrom.transform.position, this.testEmergeTo.transform.position);
	}

	// Token: 0x040002E1 RID: 737
	public static AngryBeeSwarm instance;

	// Token: 0x040002E2 RID: 738
	public float heightAboveNavmesh = 0.5f;

	// Token: 0x040002E3 RID: 739
	public Transform followTarget;

	// Token: 0x040002E4 RID: 740
	[SerializeField]
	private float velocityStep = 1f;

	// Token: 0x040002E5 RID: 741
	private float currentSpeed;

	// Token: 0x040002E6 RID: 742
	[SerializeField]
	private float velocityIncreaseInterval = 20f;

	// Token: 0x040002E7 RID: 743
	public Vector3 noisyOffset;

	// Token: 0x040002E8 RID: 744
	public Vector3 ghostOffsetGrabbingLocal;

	// Token: 0x040002E9 RID: 745
	private float emergeStartedTimestamp;

	// Token: 0x040002EA RID: 746
	private float grabTimestamp;

	// Token: 0x040002EB RID: 747
	private float lastSpeedIncreased;

	// Token: 0x040002EC RID: 748
	[SerializeField]
	private float totalTimeToEmerge;

	// Token: 0x040002ED RID: 749
	[SerializeField]
	private float catchDistance;

	// Token: 0x040002EE RID: 750
	[SerializeField]
	private float grabDuration;

	// Token: 0x040002EF RID: 751
	[SerializeField]
	private float grabSpeed = 1f;

	// Token: 0x040002F0 RID: 752
	[SerializeField]
	private float minGrabCooldown;

	// Token: 0x040002F1 RID: 753
	[SerializeField]
	private float initialRangeLimit;

	// Token: 0x040002F2 RID: 754
	[SerializeField]
	private float finalRangeLimit;

	// Token: 0x040002F3 RID: 755
	[SerializeField]
	private float rangeLimitBlendDuration;

	// Token: 0x040002F4 RID: 756
	[SerializeField]
	private float boredAfterDuration;

	// Token: 0x040002F5 RID: 757
	public Player targetPlayer;

	// Token: 0x040002F6 RID: 758
	public AngryBeeAnimator beeAnimator;

	// Token: 0x040002F7 RID: 759
	public AngryBeeSwarm.ChaseState currentState;

	// Token: 0x040002F8 RID: 760
	public AngryBeeSwarm.ChaseState lastState;

	// Token: 0x040002F9 RID: 761
	public Player grabbedPlayer;

	// Token: 0x040002FA RID: 762
	private bool targetIsOnNavMesh;

	// Token: 0x040002FB RID: 763
	private const float navMeshSampleRange = 5f;

	// Token: 0x040002FC RID: 764
	[Tooltip("Haptic vibration when chased by lucy")]
	public float hapticStrength = 1f;

	// Token: 0x040002FD RID: 765
	public float hapticDuration = 1.5f;

	// Token: 0x040002FE RID: 766
	public float MinHeightAboveWater = 0.5f;

	// Token: 0x040002FF RID: 767
	public float PlayerMinHeightAboveWater = 0.5f;

	// Token: 0x04000300 RID: 768
	public float RefreshClosestPlayerInterval = 1f;

	// Token: 0x04000301 RID: 769
	private float NextRefreshClosestPlayerTimestamp = 1f;

	// Token: 0x04000302 RID: 770
	private float BoredToDeathAtTimestamp = -1f;

	// Token: 0x04000303 RID: 771
	[SerializeField]
	private Transform testEmergeFrom;

	// Token: 0x04000304 RID: 772
	[SerializeField]
	private Transform testEmergeTo;

	// Token: 0x04000305 RID: 773
	private Vector3 emergeFromPosition;

	// Token: 0x04000306 RID: 774
	private Vector3 emergeToPosition;

	// Token: 0x04000307 RID: 775
	private NavMeshPath path;

	// Token: 0x04000308 RID: 776
	public List<Vector3> pathPoints;

	// Token: 0x04000309 RID: 777
	public int currentPathPointIdx;

	// Token: 0x0400030A RID: 778
	private float nextPathTimestamp;

	// Token: 0x02000068 RID: 104
	public enum ChaseState
	{
		// Token: 0x0400030C RID: 780
		Dormant = 1,
		// Token: 0x0400030D RID: 781
		InitialEmerge,
		// Token: 0x0400030E RID: 782
		Chasing = 4,
		// Token: 0x0400030F RID: 783
		Grabbing = 8
	}
}
