﻿using System;

// Token: 0x02000472 RID: 1138
public class FXSArgs
{
}
