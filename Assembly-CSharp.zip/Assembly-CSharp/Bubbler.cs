﻿using System;
using System.Collections.Generic;
using GorillaLocomotion;
using UnityEngine;

// Token: 0x020002E8 RID: 744
public class Bubbler : TransferrableObject
{
	// Token: 0x0600111C RID: 4380 RVA: 0x0005A5D4 File Offset: 0x000587D4
	public override void OnSpawn()
	{
		base.OnSpawn();
		this.hasParticleSystem = (this.bubbleParticleSystem != null);
		if (this.hasParticleSystem)
		{
			this.bubbleParticleArray = new ParticleSystem.Particle[this.bubbleParticleSystem.main.maxParticles];
			this.bubbleParticleSystem.trigger.SetCollider(0, GorillaTagger.Instance.leftHandTriggerCollider.GetComponent<SphereCollider>());
			this.bubbleParticleSystem.trigger.SetCollider(1, GorillaTagger.Instance.rightHandTriggerCollider.GetComponent<SphereCollider>());
		}
		this.initialTriggerDuration = 0.05f;
		this.triggerStrength = 0.8f;
		this.itemState = TransferrableObject.ItemStates.State0;
	}

	// Token: 0x0600111D RID: 4381 RVA: 0x0005A684 File Offset: 0x00058884
	public override void OnEnable()
	{
		base.OnEnable();
		this.itemState = TransferrableObject.ItemStates.State0;
		this.hasBubblerAudio = (this.bubblerAudio != null && this.bubblerAudio.clip != null);
		this.hasPopBubbleAudio = (this.popBubbleAudio != null && this.popBubbleAudio.clip != null);
		this.hasFan = (this.fan != null);
	}

	// Token: 0x0600111E RID: 4382 RVA: 0x0005A700 File Offset: 0x00058900
	private void InitToDefault()
	{
		this.itemState = TransferrableObject.ItemStates.State0;
		if (this.hasParticleSystem && this.bubbleParticleSystem.isPlaying)
		{
			this.bubbleParticleSystem.Stop();
		}
		if (this.hasBubblerAudio && this.bubblerAudio.isPlaying)
		{
			this.bubblerAudio.Stop();
		}
	}

	// Token: 0x0600111F RID: 4383 RVA: 0x0005A754 File Offset: 0x00058954
	public override void OnDisable()
	{
		base.OnDisable();
		this.itemState = TransferrableObject.ItemStates.State0;
		if (this.hasParticleSystem && this.bubbleParticleSystem.isPlaying)
		{
			this.bubbleParticleSystem.Stop();
		}
		if (this.hasBubblerAudio && this.bubblerAudio.isPlaying)
		{
			this.bubblerAudio.Stop();
		}
		this.currentParticles.Clear();
		this.particleInfoDict.Clear();
	}

	// Token: 0x06001120 RID: 4384 RVA: 0x0005A7C4 File Offset: 0x000589C4
	public override void ResetToDefaultState()
	{
		base.ResetToDefaultState();
		this.InitToDefault();
	}

	// Token: 0x06001121 RID: 4385 RVA: 0x0005A7D2 File Offset: 0x000589D2
	protected override void LateUpdateLocal()
	{
		base.LateUpdateLocal();
		if (!this._worksInWater && Player.Instance.InWater)
		{
			this.itemState = TransferrableObject.ItemStates.State0;
		}
	}

	// Token: 0x06001122 RID: 4386 RVA: 0x0005A7F8 File Offset: 0x000589F8
	protected override void LateUpdateShared()
	{
		base.LateUpdateShared();
		if (!this.IsMyItem() && base.myOnlineRig != null && base.myOnlineRig.muted)
		{
			this.itemState = TransferrableObject.ItemStates.State0;
		}
		bool forLeftController = this.currentState == TransferrableObject.PositionState.InLeftHand;
		bool enabled = this.itemState != TransferrableObject.ItemStates.State0;
		Behaviour[] array = this.behavioursToEnableWhenTriggerPressed;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].enabled = enabled;
		}
		if (this.itemState == TransferrableObject.ItemStates.State0)
		{
			if (this.hasParticleSystem && this.bubbleParticleSystem.isPlaying)
			{
				this.bubbleParticleSystem.Stop();
			}
			if (this.hasBubblerAudio && this.bubblerAudio.isPlaying)
			{
				this.bubblerAudio.Stop();
			}
		}
		else
		{
			if (this.hasParticleSystem && !this.bubbleParticleSystem.isEmitting)
			{
				this.bubbleParticleSystem.Play();
			}
			if (this.hasBubblerAudio && !this.bubblerAudio.isPlaying)
			{
				this.bubblerAudio.Play();
			}
			if (this.IsMyItem())
			{
				this.initialTriggerPull = Time.time;
				GorillaTagger.Instance.StartVibration(forLeftController, this.triggerStrength, this.initialTriggerDuration);
				if (Time.time > this.initialTriggerPull + this.initialTriggerDuration)
				{
					GorillaTagger.Instance.StartVibration(forLeftController, this.ongoingStrength, Time.deltaTime);
				}
			}
			if (this.hasFan)
			{
				float z = this.fan.transform.localEulerAngles.z + this.rotationSpeed * Time.fixedDeltaTime;
				this.fan.transform.localEulerAngles = new Vector3(0f, 0f, z);
			}
		}
		if (this.hasParticleSystem && (!this.allBubblesPopped || this.itemState == TransferrableObject.ItemStates.State1))
		{
			int particles = this.bubbleParticleSystem.GetParticles(this.bubbleParticleArray);
			this.allBubblesPopped = (particles <= 0);
			if (!this.allBubblesPopped)
			{
				for (int j = 0; j < particles; j++)
				{
					if (this.currentParticles.Contains(this.bubbleParticleArray[j].randomSeed))
					{
						this.currentParticles.Remove(this.bubbleParticleArray[j].randomSeed);
					}
				}
				foreach (uint key in this.currentParticles)
				{
					if (this.particleInfoDict.TryGetValue(key, out this.outPosition))
					{
						if (this.hasPopBubbleAudio)
						{
							AudioSource.PlayClipAtPoint(this.popBubbleAudio.clip, this.outPosition);
						}
						this.particleInfoDict.Remove(key);
					}
				}
				this.currentParticles.Clear();
				for (int k = 0; k < particles; k++)
				{
					if (this.particleInfoDict.TryGetValue(this.bubbleParticleArray[k].randomSeed, out this.outPosition))
					{
						this.particleInfoDict[this.bubbleParticleArray[k].randomSeed] = this.bubbleParticleArray[k].position;
					}
					else
					{
						this.particleInfoDict.Add(this.bubbleParticleArray[k].randomSeed, this.bubbleParticleArray[k].position);
					}
					this.currentParticles.Add(this.bubbleParticleArray[k].randomSeed);
				}
			}
		}
	}

	// Token: 0x06001123 RID: 4387 RVA: 0x0005AB80 File Offset: 0x00058D80
	public override void OnActivate()
	{
		base.OnActivate();
		this.itemState = TransferrableObject.ItemStates.State1;
	}

	// Token: 0x06001124 RID: 4388 RVA: 0x0000E60C File Offset: 0x0000C80C
	public override void OnDeactivate()
	{
		base.OnDeactivate();
		this.itemState = TransferrableObject.ItemStates.State0;
	}

	// Token: 0x06001125 RID: 4389 RVA: 0x0005AB8F File Offset: 0x00058D8F
	public override bool CanActivate()
	{
		return !this.disableActivation;
	}

	// Token: 0x06001126 RID: 4390 RVA: 0x0005AB9A File Offset: 0x00058D9A
	public override bool CanDeactivate()
	{
		return !this.disableDeactivation;
	}

	// Token: 0x04001354 RID: 4948
	[SerializeField]
	private bool _worksInWater = true;

	// Token: 0x04001355 RID: 4949
	public ParticleSystem bubbleParticleSystem;

	// Token: 0x04001356 RID: 4950
	private ParticleSystem.Particle[] bubbleParticleArray;

	// Token: 0x04001357 RID: 4951
	public AudioSource bubblerAudio;

	// Token: 0x04001358 RID: 4952
	public AudioSource popBubbleAudio;

	// Token: 0x04001359 RID: 4953
	private List<uint> currentParticles = new List<uint>();

	// Token: 0x0400135A RID: 4954
	private Dictionary<uint, Vector3> particleInfoDict = new Dictionary<uint, Vector3>();

	// Token: 0x0400135B RID: 4955
	private Vector3 outPosition;

	// Token: 0x0400135C RID: 4956
	private bool allBubblesPopped;

	// Token: 0x0400135D RID: 4957
	public bool disableActivation;

	// Token: 0x0400135E RID: 4958
	public bool disableDeactivation;

	// Token: 0x0400135F RID: 4959
	public float rotationSpeed = 5f;

	// Token: 0x04001360 RID: 4960
	public GameObject fan;

	// Token: 0x04001361 RID: 4961
	public float ongoingStrength = 0.005f;

	// Token: 0x04001362 RID: 4962
	public float triggerStrength = 0.2f;

	// Token: 0x04001363 RID: 4963
	private float initialTriggerPull;

	// Token: 0x04001364 RID: 4964
	private float initialTriggerDuration;

	// Token: 0x04001365 RID: 4965
	private bool hasBubblerAudio;

	// Token: 0x04001366 RID: 4966
	private bool hasPopBubbleAudio;

	// Token: 0x04001367 RID: 4967
	public Behaviour[] behavioursToEnableWhenTriggerPressed;

	// Token: 0x04001368 RID: 4968
	private bool hasParticleSystem;

	// Token: 0x04001369 RID: 4969
	private bool hasFan;

	// Token: 0x020002E9 RID: 745
	private enum BubblerState
	{
		// Token: 0x0400136B RID: 4971
		None = 1,
		// Token: 0x0400136C RID: 4972
		Bubbling
	}
}
