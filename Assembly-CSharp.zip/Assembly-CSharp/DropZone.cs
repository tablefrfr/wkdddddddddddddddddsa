﻿using System;
using UnityEngine;

// Token: 0x0200023B RID: 571
public class DropZone : MonoBehaviour
{
	// Token: 0x04000D80 RID: 3456
	public BodyDockPositions forBodyDock;

	// Token: 0x04000D81 RID: 3457
	public BodyDockPositions.DropPositions dropPosition;

	// Token: 0x04000D82 RID: 3458
	public Transform anchor;
}
