﻿using System;
using GorillaExtensions;
using GorillaLocomotion;
using GorillaTagScripts;
using UnityEngine;

// Token: 0x02000288 RID: 648
public class FriendshipCharm : HoldableObject
{
	// Token: 0x06000E46 RID: 3654 RVA: 0x0004ACDB File Offset: 0x00048EDB
	private void Awake()
	{
		this.parent = base.transform.parent;
	}

	// Token: 0x06000E47 RID: 3655 RVA: 0x0004ACF0 File Offset: 0x00048EF0
	private void LateUpdate()
	{
		if (!this.isBroken && (this.lineStart.transform.position - this.lineEnd.transform.position).IsLongerThan(this.breakBraceletLength * Player.Instance.scale))
		{
			this.DestroyBracelet();
		}
	}

	// Token: 0x06000E48 RID: 3656 RVA: 0x0004AD48 File Offset: 0x00048F48
	public override void OnEnable()
	{
		this.interactionPoint.enabled = true;
		this.meshRenderer.enabled = true;
		if (this.rb)
		{
			this.rb.isKinematic = true;
			this.rb.useGravity = false;
		}
		this.isBroken = false;
		this.UpdatePosition();
		base.OnEnable();
	}

	// Token: 0x06000E49 RID: 3657 RVA: 0x0004ADA8 File Offset: 0x00048FA8
	private void DestroyBracelet()
	{
		this.interactionPoint.enabled = false;
		this.rb.isKinematic = false;
		this.rb.useGravity = true;
		this.isBroken = true;
		Debug.Log("LeaveGroup: bracelet destroyed");
		FriendshipGroupDetection.Instance.LeaveParty();
	}

	// Token: 0x06000E4A RID: 3658 RVA: 0x0004ADF4 File Offset: 0x00048FF4
	public override void OnGrab(InteractionPoint pointGrabbed, GameObject grabbingHand)
	{
		base.OnGrab(pointGrabbed, grabbingHand);
		bool flag = grabbingHand == EquipmentInteractor.instance.leftHand;
		EquipmentInteractor.instance.UpdateHandEquipment(this, flag);
		GorillaTagger.Instance.StartVibration(flag, GorillaTagger.Instance.tapHapticStrength * 2f, GorillaTagger.Instance.tapHapticDuration * 2f);
		base.transform.SetParent(flag ? this.leftHandHoldAnchor : this.rightHandHoldAnchor);
		base.transform.localPosition = Vector3.zero;
	}

	// Token: 0x06000E4B RID: 3659 RVA: 0x0004AE84 File Offset: 0x00049084
	public override bool OnRelease(DropZone zoneReleased, GameObject releasingHand)
	{
		bool forLeftHand = releasingHand == EquipmentInteractor.instance.leftHand;
		EquipmentInteractor.instance.UpdateHandEquipment(null, forLeftHand);
		this.UpdatePosition();
		return base.OnRelease(zoneReleased, releasingHand);
	}

	// Token: 0x06000E4C RID: 3660 RVA: 0x0004AEC0 File Offset: 0x000490C0
	private void UpdatePosition()
	{
		base.transform.SetParent(this.parent);
		base.transform.localPosition = this.releasePosition.localPosition;
		base.transform.localRotation = this.releasePosition.localRotation;
	}

	// Token: 0x06000E4D RID: 3661 RVA: 0x0004AF00 File Offset: 0x00049100
	private void OnCollisionEnter(Collision other)
	{
		if (!this.isBroken)
		{
			return;
		}
		if (this.breakItemLayerMask != (this.breakItemLayerMask | 1 << other.gameObject.layer))
		{
			return;
		}
		this.meshRenderer.enabled = false;
		this.rb.isKinematic = true;
		this.rb.useGravity = false;
		this.UpdatePosition();
	}

	// Token: 0x0400102A RID: 4138
	[SerializeField]
	private InteractionPoint interactionPoint;

	// Token: 0x0400102B RID: 4139
	[SerializeField]
	private Transform rightHandHoldAnchor;

	// Token: 0x0400102C RID: 4140
	[SerializeField]
	private Transform leftHandHoldAnchor;

	// Token: 0x0400102D RID: 4141
	[SerializeField]
	private Rigidbody rb;

	// Token: 0x0400102E RID: 4142
	[SerializeField]
	private MeshRenderer meshRenderer;

	// Token: 0x0400102F RID: 4143
	[SerializeField]
	private Transform lineStart;

	// Token: 0x04001030 RID: 4144
	[SerializeField]
	private Transform lineEnd;

	// Token: 0x04001031 RID: 4145
	[SerializeField]
	private Transform releasePosition;

	// Token: 0x04001032 RID: 4146
	[SerializeField]
	private float breakBraceletLength;

	// Token: 0x04001033 RID: 4147
	[SerializeField]
	private LayerMask breakItemLayerMask;

	// Token: 0x04001034 RID: 4148
	private Transform parent;

	// Token: 0x04001035 RID: 4149
	private bool isBroken;
}
