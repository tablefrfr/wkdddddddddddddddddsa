﻿using System;
using UnityEngine;

// Token: 0x020003FB RID: 1019
public class GorillaDevButton : GorillaPressableButton
{
	// Token: 0x170002EC RID: 748
	// (get) Token: 0x060017AE RID: 6062 RVA: 0x0007966D File Offset: 0x0007786D
	// (set) Token: 0x060017AF RID: 6063 RVA: 0x00079675 File Offset: 0x00077875
	public bool on
	{
		get
		{
			return this.isOn;
		}
		set
		{
			if (this.isOn != value)
			{
				this.isOn = value;
				this.UpdateColor();
			}
		}
	}

	// Token: 0x060017B0 RID: 6064 RVA: 0x0007968D File Offset: 0x0007788D
	public void OnEnable()
	{
		this.UpdateColor();
	}

	// Token: 0x04001B28 RID: 6952
	public DevButtonType Type;

	// Token: 0x04001B29 RID: 6953
	public LogType levelType;

	// Token: 0x04001B2A RID: 6954
	public DevConsoleInstance targetConsole;

	// Token: 0x04001B2B RID: 6955
	public int lineNumber;

	// Token: 0x04001B2C RID: 6956
	public bool repeatIfHeld;

	// Token: 0x04001B2D RID: 6957
	public float holdForSeconds;

	// Token: 0x04001B2E RID: 6958
	private Coroutine pressCoroutine;
}
