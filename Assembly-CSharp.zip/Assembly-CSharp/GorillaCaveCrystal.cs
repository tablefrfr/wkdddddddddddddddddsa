﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using GorillaExtensions;
using GorillaTagScripts;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000364 RID: 868
public class GorillaCaveCrystal : Tappable
{
	// Token: 0x060013C7 RID: 5063 RVA: 0x00068504 File Offset: 0x00066704
	private void Awake()
	{
		if (this.visuals == null)
		{
			Debug.LogError("GorillaCaveCrystal: Disabling because visuals are null at: " + base.transform.GetPath(), this);
			base.enabled = false;
			return;
		}
		this.visuals.UpdateAlbedo();
		this.visuals.ForceUpdate();
		this.visuals.enabled = false;
	}

	// Token: 0x060013C8 RID: 5064 RVA: 0x00068564 File Offset: 0x00066764
	[Conditional("UNITY_EDITOR")]
	private void SetUnderwaterVisuals()
	{
		GorillaCaveCrystalSetup instance = GorillaCaveCrystalSetup.Instance;
		base.TryGetComponent<GorillaCaveCrystalVisuals>(out this.visuals);
		if (this.visuals == null)
		{
			this.visuals = base.gameObject.AddComponent<GorillaCaveCrystalVisuals>();
		}
		this.visuals.crysalPreset = instance.DarkLightUnderWater.visualPreset;
		this.visuals.instanceAlbedo = instance.CrystalDarkAlbedo;
		this.visuals.Setup();
		this.visuals.UpdateAlbedo();
		this.visuals.ForceUpdate();
	}

	// Token: 0x060013C9 RID: 5065 RVA: 0x000685EC File Offset: 0x000667EC
	[Conditional("UNITY_EDITOR")]
	public void AddVisuals()
	{
		base.TryGetComponent<MeshRenderer>(out this._crystalRenderer);
		if (this._crystalRenderer == null)
		{
			return;
		}
		Material crystalMat = this._crystalRenderer.sharedMaterial;
		if (crystalMat == null)
		{
			return;
		}
		GorillaCaveCrystalSetup instance = GorillaCaveCrystalSetup.Instance;
		GorillaCaveCrystalSetup.CrystalDef crystalDef = instance.GetCrystalDefs().FirstOrDefault((GorillaCaveCrystalSetup.CrystalDef cd) => cd.keyMaterial == crystalMat);
		if (crystalDef == null)
		{
			return;
		}
		bool flag = crystalDef.keyMaterial == instance.Dark.keyMaterial || crystalDef.keyMaterial == instance.DarkLight.keyMaterial || crystalDef.keyMaterial == instance.DarkLightUnderWater.keyMaterial;
		base.TryGetComponent<GorillaCaveCrystalVisuals>(out this.visuals);
		if (this.visuals == null)
		{
			this.visuals = base.gameObject.AddComponent<GorillaCaveCrystalVisuals>();
		}
		if (crystalDef.visualPreset != null)
		{
			this.visuals.crysalPreset = crystalDef.visualPreset;
			if (instance.CrystalDarkAlbedo != null && flag)
			{
				this.visuals.instanceAlbedo = instance.CrystalDarkAlbedo;
			}
			this.visuals.Setup();
			if (flag)
			{
				this.visuals.UpdateAlbedo();
			}
		}
	}

	// Token: 0x060013CA RID: 5066 RVA: 0x0006872C File Offset: 0x0006692C
	public override void OnTapLocal(float tapStrength, float tapTime, PhotonMessageInfo info)
	{
		this._tapStrength = tapStrength;
		this.AnimateCrystal();
	}

	// Token: 0x060013CB RID: 5067 RVA: 0x0006873C File Offset: 0x0006693C
	private void AnimateCrystal()
	{
		if (!Application.isPlaying)
		{
			return;
		}
		if (this.visuals == null)
		{
			return;
		}
		if (this._animating)
		{
			return;
		}
		this._timeSinceLastTap = 0f;
		this._animating = true;
		this.visuals.enabled = true;
	}

	// Token: 0x060013CC RID: 5068 RVA: 0x0006878C File Offset: 0x0006698C
	public void InvokeUpdate()
	{
		if (!this._animating)
		{
			return;
		}
		float num = this._tapAnimLength * this._lerpMidpoint;
		if (this._timeSinceLastTap > this._tapAnimLength)
		{
			this._animating = false;
			this.visuals.lerp = 0f;
			this.visuals.enabled = false;
		}
		float a = 0f;
		float b = 0f;
		if (this._timeSinceLastTap <= num)
		{
			a = 0f;
			b = 1f;
			AnimationCurve lerpInCurve = this._lerpInCurve;
		}
		if (this._timeSinceLastTap > num)
		{
			a = 1f;
			b = 0f;
			AnimationCurve lerpOutCurve = this._lerpOutCurve;
		}
		float t = this._timeSinceLastTap / this._tapAnimLength;
		float lerp = Mathf.Lerp(a, b, t) * 2f;
		this.visuals.lerp = lerp;
	}

	// Token: 0x060013CD RID: 5069 RVA: 0x00068864 File Offset: 0x00066A64
	protected override void OnEnable()
	{
		base.OnEnable();
		GorillaCaveCrystal.GorillaCaveCrystalManager.RegisterGorillaCaveCrystal(this);
	}

	// Token: 0x060013CE RID: 5070 RVA: 0x00068872 File Offset: 0x00066A72
	protected override void OnDisable()
	{
		base.OnDisable();
		GorillaCaveCrystal.GorillaCaveCrystalManager.UnregisterGorillaCaveCrystal(this);
	}

	// Token: 0x04001698 RID: 5784
	public bool overrideSoundAndMaterial;

	// Token: 0x04001699 RID: 5785
	public CrystalOctave octave;

	// Token: 0x0400169A RID: 5786
	public CrystalNote note;

	// Token: 0x0400169B RID: 5787
	[SerializeField]
	private MeshRenderer _crystalRenderer;

	// Token: 0x0400169C RID: 5788
	public GorillaCaveCrystalVisuals visuals;

	// Token: 0x0400169D RID: 5789
	[SerializeField]
	private float _tapAnimLength = 0.5f;

	// Token: 0x0400169E RID: 5790
	[SerializeField]
	[Range(0f, 1f)]
	private float _lerpMidpoint = 0.1f;

	// Token: 0x0400169F RID: 5791
	[SerializeField]
	private AnimationCurve _lerpInCurve = AnimationCurve.Constant(0f, 1f, 1f);

	// Token: 0x040016A0 RID: 5792
	[SerializeField]
	private AnimationCurve _lerpOutCurve = AnimationCurve.Constant(0f, 1f, 1f);

	// Token: 0x040016A1 RID: 5793
	[SerializeField]
	private bool _animating;

	// Token: 0x040016A2 RID: 5794
	[SerializeField]
	[Range(0f, 1f)]
	private float _tapStrength = 1f;

	// Token: 0x040016A3 RID: 5795
	[NonSerialized]
	private TimeSince _timeSinceLastTap;

	// Token: 0x02000365 RID: 869
	public class GorillaCaveCrystalManager : MonoBehaviour
	{
		// Token: 0x060013D0 RID: 5072 RVA: 0x000688E8 File Offset: 0x00066AE8
		protected void Awake()
		{
			if (GorillaCaveCrystal.GorillaCaveCrystalManager.hasInstance && GorillaCaveCrystal.GorillaCaveCrystalManager.instance != null && GorillaCaveCrystal.GorillaCaveCrystalManager.instance != this)
			{
				Object.Destroy(this);
				return;
			}
			GorillaCaveCrystal.GorillaCaveCrystalManager.SetInstance(this);
		}

		// Token: 0x060013D1 RID: 5073 RVA: 0x00068918 File Offset: 0x00066B18
		public static void CreateManager()
		{
			GorillaCaveCrystal.GorillaCaveCrystalManager.SetInstance(new GameObject("GorillaCaveCrystalManager").AddComponent<GorillaCaveCrystal.GorillaCaveCrystalManager>());
		}

		// Token: 0x060013D2 RID: 5074 RVA: 0x0006892E File Offset: 0x00066B2E
		private static void SetInstance(GorillaCaveCrystal.GorillaCaveCrystalManager manager)
		{
			GorillaCaveCrystal.GorillaCaveCrystalManager.instance = manager;
			GorillaCaveCrystal.GorillaCaveCrystalManager.hasInstance = true;
			if (Application.isPlaying)
			{
				Object.DontDestroyOnLoad(manager);
			}
		}

		// Token: 0x060013D3 RID: 5075 RVA: 0x00068949 File Offset: 0x00066B49
		public static void RegisterGorillaCaveCrystal(GorillaCaveCrystal gCC)
		{
			if (!GorillaCaveCrystal.GorillaCaveCrystalManager.hasInstance)
			{
				GorillaCaveCrystal.GorillaCaveCrystalManager.CreateManager();
			}
			if (!GorillaCaveCrystal.GorillaCaveCrystalManager.allCrystals.Contains(gCC))
			{
				GorillaCaveCrystal.GorillaCaveCrystalManager.allCrystals.Add(gCC);
			}
		}

		// Token: 0x060013D4 RID: 5076 RVA: 0x0006896F File Offset: 0x00066B6F
		public static void UnregisterGorillaCaveCrystal(GorillaCaveCrystal gCC)
		{
			if (!GorillaCaveCrystal.GorillaCaveCrystalManager.hasInstance)
			{
				GorillaCaveCrystal.GorillaCaveCrystalManager.CreateManager();
			}
			if (GorillaCaveCrystal.GorillaCaveCrystalManager.allCrystals.Contains(gCC))
			{
				GorillaCaveCrystal.GorillaCaveCrystalManager.allCrystals.Remove(gCC);
			}
		}

		// Token: 0x060013D5 RID: 5077 RVA: 0x00068998 File Offset: 0x00066B98
		public void Update()
		{
			for (int i = 0; i < GorillaCaveCrystal.GorillaCaveCrystalManager.allCrystals.Count; i++)
			{
				GorillaCaveCrystal.GorillaCaveCrystalManager.allCrystals[i].InvokeUpdate();
			}
		}

		// Token: 0x040016A4 RID: 5796
		public static GorillaCaveCrystal.GorillaCaveCrystalManager instance;

		// Token: 0x040016A5 RID: 5797
		public static bool hasInstance = false;

		// Token: 0x040016A6 RID: 5798
		public static List<GorillaCaveCrystal> allCrystals = new List<GorillaCaveCrystal>();
	}
}
