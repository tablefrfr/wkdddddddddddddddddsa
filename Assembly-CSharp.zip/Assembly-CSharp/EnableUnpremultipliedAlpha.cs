﻿using System;
using UnityEngine;

// Token: 0x020001AD RID: 429
public class EnableUnpremultipliedAlpha : MonoBehaviour
{
	// Token: 0x060008E0 RID: 2272 RVA: 0x0002D38C File Offset: 0x0002B58C
	private void Start()
	{
		OVRManager.eyeFovPremultipliedAlphaModeEnabled = false;
	}
}
