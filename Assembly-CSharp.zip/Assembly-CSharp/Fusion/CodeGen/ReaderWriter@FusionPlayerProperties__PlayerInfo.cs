﻿using System;
using System.Runtime.CompilerServices;

namespace Fusion.CodeGen
{
	// Token: 0x0200084B RID: 2123
	internal struct ReaderWriter@FusionPlayerProperties__PlayerInfo : IElementReaderWriter<FusionPlayerProperties.PlayerInfo>
	{
		// Token: 0x06003332 RID: 13106 RVA: 0x00100584 File Offset: 0x000FE784
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public unsafe FusionPlayerProperties.PlayerInfo Read(byte* data, int index)
		{
			return *(FusionPlayerProperties.PlayerInfo*)(data + index * 896);
		}

		// Token: 0x06003333 RID: 13107 RVA: 0x00100594 File Offset: 0x000FE794
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public unsafe ref FusionPlayerProperties.PlayerInfo ReadRef(byte* data, int index)
		{
			return ref *(FusionPlayerProperties.PlayerInfo*)(data + index * 896);
		}

		// Token: 0x06003334 RID: 13108 RVA: 0x0010059F File Offset: 0x000FE79F
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public unsafe void Write(byte* data, int index, FusionPlayerProperties.PlayerInfo val)
		{
			*(FusionPlayerProperties.PlayerInfo*)(data + index * 896) = val;
		}

		// Token: 0x06003335 RID: 13109 RVA: 0x001005B0 File Offset: 0x000FE7B0
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public int GetElementWordCount()
		{
			return 224;
		}

		// Token: 0x06003336 RID: 13110 RVA: 0x001005B8 File Offset: 0x000FE7B8
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public static IElementReaderWriter<FusionPlayerProperties.PlayerInfo> GetInstance()
		{
			if (ReaderWriter@FusionPlayerProperties__PlayerInfo.Instance == null)
			{
				ReaderWriter@FusionPlayerProperties__PlayerInfo.Instance = default(ReaderWriter@FusionPlayerProperties__PlayerInfo);
			}
			return ReaderWriter@FusionPlayerProperties__PlayerInfo.Instance;
		}

		// Token: 0x04003655 RID: 13909
		public static IElementReaderWriter<FusionPlayerProperties.PlayerInfo> Instance;
	}
}
