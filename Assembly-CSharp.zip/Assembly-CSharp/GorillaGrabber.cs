﻿using System;
using GorillaLocomotion;
using GorillaLocomotion.Gameplay;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x020003BD RID: 957
public class GorillaGrabber : MonoBehaviour
{
	// Token: 0x17000239 RID: 569
	// (get) Token: 0x060015D8 RID: 5592 RVA: 0x00073990 File Offset: 0x00071B90
	public XRNode XrNode
	{
		get
		{
			return this.xrNode;
		}
	}

	// Token: 0x1700023A RID: 570
	// (get) Token: 0x060015D9 RID: 5593 RVA: 0x00073998 File Offset: 0x00071B98
	public Player Player
	{
		get
		{
			return this.player;
		}
	}

	// Token: 0x060015DA RID: 5594 RVA: 0x000739A0 File Offset: 0x00071BA0
	private void Awake()
	{
		this.audioSource = base.GetComponent<AudioSource>();
		this.player = base.GetComponentInParent<Player>();
		this.breakDistance = this.grabRadius * 2f;
	}

	// Token: 0x060015DB RID: 5595 RVA: 0x000739CC File Offset: 0x00071BCC
	private void Update()
	{
		bool grabMomentary = ControllerInputPoller.GetGrabMomentary(this.xrNode);
		bool grabRelease = ControllerInputPoller.GetGrabRelease(this.xrNode);
		if (this.currentGrabbable != null && (grabRelease || this.GrabDistanceOverCheck()))
		{
			this.Ungrab();
		}
		if (grabMomentary && this.currentGrabbable == null)
		{
			this.currentGrabbable = this.GetGrabable();
		}
		if (this.currentGrabbable != null)
		{
			GorillaTagger.Instance.DoVibration(this.xrNode, 0.2f, Time.deltaTime);
		}
	}

	// Token: 0x060015DC RID: 5596 RVA: 0x00073A41 File Offset: 0x00071C41
	private bool GrabDistanceOverCheck()
	{
		return this.currentGrabbedTransform == null || Vector3.Distance(base.transform.position, this.currentGrabbedTransform.position) > this.breakDistance;
	}

	// Token: 0x060015DD RID: 5597 RVA: 0x00073A76 File Offset: 0x00071C76
	private void Ungrab()
	{
		this.currentGrabbable.OnGrabReleased(this);
		this.currentGrabbable = null;
		this.gripEffects.Stop();
	}

	// Token: 0x060015DE RID: 5598 RVA: 0x00073A98 File Offset: 0x00071C98
	private IGorillaGrabable GetGrabable()
	{
		IGorillaGrabable gorillaGrabable = null;
		Debug.DrawRay(base.transform.position, base.transform.forward * this.grabRadius, Color.blue, 1f);
		int num = Physics.OverlapSphereNonAlloc(base.transform.position, this.grabRadius, this.grabCastResults);
		float num2 = float.MaxValue;
		for (int i = 0; i < num; i++)
		{
			IGorillaGrabable gorillaGrabable2;
			if (this.grabCastResults[i].TryGetComponent<IGorillaGrabable>(out gorillaGrabable2))
			{
				float num3 = Vector3.Distance(base.transform.position, this.grabCastResults[i].ClosestPoint(base.transform.position));
				if (num3 < num2)
				{
					num2 = num3;
					gorillaGrabable = gorillaGrabable2;
				}
			}
		}
		if (gorillaGrabable != null)
		{
			this.currentGrabbedTransform = gorillaGrabable.OnGrabbed(this);
		}
		return gorillaGrabable;
	}

	// Token: 0x04001974 RID: 6516
	private Player player;

	// Token: 0x04001975 RID: 6517
	[SerializeField]
	private XRNode xrNode = XRNode.LeftHand;

	// Token: 0x04001976 RID: 6518
	private AudioSource audioSource;

	// Token: 0x04001977 RID: 6519
	private Transform currentGrabbedTransform;

	// Token: 0x04001978 RID: 6520
	private IGorillaGrabable currentGrabbable;

	// Token: 0x04001979 RID: 6521
	[SerializeField]
	private float grabRadius = 0.015f;

	// Token: 0x0400197A RID: 6522
	private float breakDistance = 0.015f;

	// Token: 0x0400197B RID: 6523
	[SerializeField]
	private ParticleSystem gripEffects;

	// Token: 0x0400197C RID: 6524
	private Collider[] grabCastResults = new Collider[32];
}
