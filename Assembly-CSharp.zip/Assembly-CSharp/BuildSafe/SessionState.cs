﻿using System;

namespace BuildSafe
{
	// Token: 0x02000632 RID: 1586
	public class SessionState
	{
		// Token: 0x17000437 RID: 1079
		public string this[string key]
		{
			get
			{
				return null;
			}
			set
			{
			}
		}

		// Token: 0x04002806 RID: 10246
		public static readonly SessionState Shared = new SessionState();
	}
}
