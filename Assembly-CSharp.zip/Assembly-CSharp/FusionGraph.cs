﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Fusion;
using Fusion.StatsInternal;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

// Token: 0x02000209 RID: 521
public class FusionGraph : FusionGraphBase
{
	// Token: 0x17000136 RID: 310
	// (get) Token: 0x06000A83 RID: 2691 RVA: 0x00037118 File Offset: 0x00035318
	private static Shader Shader
	{
		get
		{
			return Resources.Load<Shader>("FusionGraphShader");
		}
	}

	// Token: 0x17000137 RID: 311
	// (get) Token: 0x06000A84 RID: 2692 RVA: 0x00037124 File Offset: 0x00035324
	// (set) Token: 0x06000A85 RID: 2693 RVA: 0x0003712C File Offset: 0x0003532C
	public FusionGraph.Layouts Layout
	{
		get
		{
			return this._layout;
		}
		set
		{
			this._layout = value;
			this.CalculateLayout();
		}
	}

	// Token: 0x17000138 RID: 312
	// (get) Token: 0x06000A86 RID: 2694 RVA: 0x0003713B File Offset: 0x0003533B
	// (set) Token: 0x06000A87 RID: 2695 RVA: 0x00037143 File Offset: 0x00035343
	public FusionGraph.ShowGraphOptions ShowGraph
	{
		get
		{
			return this._showGraph;
		}
		set
		{
			this._showGraph = value;
			this.CalculateLayout();
			this._layoutDirty = true;
		}
	}

	// Token: 0x17000139 RID: 313
	// (get) Token: 0x06000A88 RID: 2696 RVA: 0x00037159 File Offset: 0x00035359
	// (set) Token: 0x06000A89 RID: 2697 RVA: 0x00037161 File Offset: 0x00035361
	public bool AlwaysExpandGraph
	{
		get
		{
			return this._alwaysExpandGraph;
		}
		set
		{
			this._alwaysExpandGraph = value;
			this.CalculateLayout();
			this._layoutDirty = true;
		}
	}

	// Token: 0x06000A8A RID: 2698 RVA: 0x00037178 File Offset: 0x00035378
	protected override bool TryConnect()
	{
		if (base.TryConnect())
		{
			FusionGraphVisualization visualizationFlags = this._statsBuffer.VisualizationFlags;
			this.DropdownLookup.Clear();
			this._viewDropdown.ClearOptions();
			for (int i = 0; i < 16; i++)
			{
				if ((visualizationFlags & (FusionGraphVisualization)(1 << i)) != FusionGraphVisualization.Auto)
				{
					this.DropdownLookup.Add(1 << i);
					this._viewDropdown.options.Add(new Dropdown.OptionData(FusionStatsUtilities.CachedTelemetryNames[i + 1]));
					if ((1 << i & (int)this._statsBuffer.DefaultVisualization) != 0)
					{
						this._viewDropdown.value = i - 1;
					}
				}
			}
			this.SetPerText();
			return true;
		}
		return false;
	}

	// Token: 0x1700013A RID: 314
	// (set) Token: 0x06000A8B RID: 2699 RVA: 0x00037227 File Offset: 0x00035427
	public FusionGraphVisualization GraphVisualization
	{
		set
		{
			this._graphVisualization = value;
			this.Reset();
		}
	}

	// Token: 0x06000A8C RID: 2700 RVA: 0x00037236 File Offset: 0x00035436
	private void Reset()
	{
		this._values = null;
		this._histogram = null;
		this._intensity = null;
		this._min = 0f;
		this._max = 0f;
		this.ResetGraphShader();
	}

	// Token: 0x06000A8D RID: 2701 RVA: 0x0003726C File Offset: 0x0003546C
	public void Clear()
	{
		if (this._values != null && this._values.Length != 0)
		{
			Array.Clear(this._values, 0, this._values.Length);
			Array.Clear(this._histogram, 0, this._histogram.Length);
			for (int i = 0; i < this._intensity.Length; i++)
			{
				this._intensity[i] = -2f;
			}
			this._min = 0f;
			this._max = 0f;
			this._histoHighestUsedBucketIndex = 0;
			this._histoAvg = 0.0;
			this._histoAvgSampleCount = 0;
		}
	}

	// Token: 0x06000A8E RID: 2702 RVA: 0x00037308 File Offset: 0x00035508
	public override void Initialize()
	{
		Dropdown viewDropdown = this._viewDropdown;
		if (viewDropdown != null)
		{
			viewDropdown.onValueChanged.AddListener(new UnityAction<int>(this.OnDropdownChanged));
		}
		Button avgBttn = this._avgBttn;
		if (avgBttn == null)
		{
			return;
		}
		avgBttn.onClick.AddListener(new UnityAction(this.CyclePer));
	}

	// Token: 0x06000A8F RID: 2703 RVA: 0x00037359 File Offset: 0x00035559
	public void OnDropdownChanged(int value)
	{
		this.GraphVisualization = (FusionGraphVisualization)this.DropdownLookup[value];
		this.SetPerText();
	}

	// Token: 0x06000A90 RID: 2704 RVA: 0x00037374 File Offset: 0x00035574
	[BehaviourButtonAction("ResetShader", null, null)]
	private void ResetShaderButton()
	{
		this._intensity = new float[200];
		this._values = new float[200];
		for (int i = 0; i < this._values.Length; i++)
		{
			this._values[i] = (float)i / (float)this._values.Length;
			this._intensity[i] = (float)i / 200f;
		}
		this.GraphImg.material.SetFloat("_ZeroCenter", 0.3f);
		this.GraphImg.material.SetFloatArray("_Data", this._values);
		this.GraphImg.material.SetFloatArray("_Intensity", this._intensity);
		this.GraphImg.material.SetInt("_Count", this._values.Length);
	}

	// Token: 0x06000A91 RID: 2705 RVA: 0x00037448 File Offset: 0x00035648
	private void ResetGraphShader()
	{
		if (this.GraphImg)
		{
			FusionGraph.ShaderType shaderType = (base.LocateParentFusionStats() != null) ? ((this._fusionStats.CanvasType == FusionStats.StatCanvasTypes.GameObject) ? FusionGraph.ShaderType.GameObject : FusionGraph.ShaderType.Overlay) : FusionGraph.ShaderType.None;
			this.GraphImg.material = new Material(FusionGraph.Shader);
			this.GraphImg.material.SetColor("_GoodColor", this._fusionStats.GraphColorGood);
			this.GraphImg.material.SetColor("_WarnColor", this._fusionStats.GraphColorWarn);
			this.GraphImg.material.SetColor("_BadColor", this._fusionStats.GraphColorBad);
			this.GraphImg.material.SetColor("_FlagColor", this._fusionStats.GraphColorFlag);
			this.GraphImg.material.SetInt("_ZWrite", (shaderType == FusionGraph.ShaderType.GameObject) ? 1 : 0);
		}
	}

	// Token: 0x06000A92 RID: 2706 RVA: 0x0003753B File Offset: 0x0003573B
	public override void CyclePer()
	{
		if (this._graphVisualization != FusionGraphVisualization.CountHistogram && this._graphVisualization != FusionGraphVisualization.ValueHistogram)
		{
			base.CyclePer();
			this.SetPerText();
		}
	}

	// Token: 0x06000A93 RID: 2707 RVA: 0x0003755C File Offset: 0x0003575C
	private void SetPerText()
	{
		if (this.LabelPer == null)
		{
			RectTransform rt = this.LabelAvg.rectTransform.parent.CreateRectTransform("Per", false).SetAnchors(0.3f, 0.7f, 0f, 0.125f).SetOffsets(6f, -6f, 6f, 0f);
			this.LabelPer = rt.AddText("per sample", TextAnchor.LowerCenter, this._fusionStats.FontColor);
		}
		this.LabelPer.text = ((this._graphVisualization == FusionGraphVisualization.ValueHistogram | this._graphVisualization == FusionGraphVisualization.CountHistogram) ? "avg per Sample" : ((this.CurrentPer == Simulation.Statistics.StatsPer.Second) ? "avg per Second" : ((this.CurrentPer == Simulation.Statistics.StatsPer.Tick) ? "avg per Tick" : "avg per Sample")));
	}

	// Token: 0x06000A94 RID: 2708 RVA: 0x00037630 File Offset: 0x00035830
	public override void Refresh()
	{
		if (this._layoutDirty)
		{
			this.CalculateLayout();
		}
		IStatsBuffer statsBuffer = base.StatsBuffer;
		if (statsBuffer == null || statsBuffer.Count < 1)
		{
			return;
		}
		FusionGraphVisualization fusionGraphVisualization = (this._graphVisualization == FusionGraphVisualization.Auto) ? this._statsBuffer.DefaultVisualization : this._graphVisualization;
		if (this._values == null)
		{
			int num = (fusionGraphVisualization == FusionGraphVisualization.ContinuousTick) ? statsBuffer.Capacity : ((fusionGraphVisualization == FusionGraphVisualization.ValueHistogram) ? (this.StatSourceInfo.HistoBucketCount + 3) : 128);
			this._values = new float[num];
			this._histogram = new float[num];
			this._intensity = new float[num];
		}
		switch (fusionGraphVisualization)
		{
		case FusionGraphVisualization.ContinuousTick:
			this.UpdateContinuousTick(ref statsBuffer);
			return;
		case FusionGraphVisualization.IntermittentTick:
			this.UpdateIntermittentTick(ref statsBuffer);
			return;
		case FusionGraphVisualization.ContinuousTick | FusionGraphVisualization.IntermittentTick:
			break;
		case FusionGraphVisualization.IntermittentTime:
			this.UpdateIntermittentTime(ref statsBuffer);
			return;
		default:
			if (fusionGraphVisualization != FusionGraphVisualization.ValueHistogram)
			{
				return;
			}
			this.UpdateTickValueHistogram(ref statsBuffer);
			break;
		}
	}

	// Token: 0x06000A95 RID: 2709 RVA: 0x00037714 File Offset: 0x00035914
	private void UpdateContinuousTick(ref IStatsBuffer data)
	{
		float num = float.MaxValue;
		float num2 = float.MinValue;
		float num3 = 0f;
		float last = 0f;
		for (int i = 0; i < data.Count; i++)
		{
			float num4 = (float)(this.StatSourceInfo.Multiplier * (double)data.GetSampleAtIndex(i).FloatValue);
			num = Math.Min(num4, num);
			num2 = Math.Max(num4, num2);
			if (i >= this._values.Length)
			{
				Debug.LogWarning(string.Concat(new string[]
				{
					base.name,
					" Out of range ",
					i.ToString(),
					" ",
					this._values.Length.ToString(),
					" ",
					data.Count.ToString()
				}));
			}
			last = (this._values[i] = num4);
			num3 += num4;
		}
		num3 /= (float)data.Count;
		this.ApplyScaling(ref num, ref num2);
		this.UpdateUiText(num, num2, num3, last);
	}

	// Token: 0x06000A96 RID: 2710 RVA: 0x00037824 File Offset: 0x00035A24
	private void UpdateIntermittentTick(ref IStatsBuffer data)
	{
		if (this._cachedValues == null)
		{
			this._cachedValues = new ValueTuple<int, float>[128];
		}
		int num = this._fusionStats.Runner.Simulation.LatestServerState.Tick;
		float num2 = float.MaxValue;
		float num3 = float.MinValue;
		float num4 = 0f;
		float last = 0f;
		int num5 = num - 128 + 1;
		int num6 = (num % 128 + 1) % 128;
		int num7 = this._lastCachedTick;
		for (int i = 0; i < data.Count; i++)
		{
			ISampleData sampleAtIndex = data.GetSampleAtIndex(i);
			int tickValue = sampleAtIndex.TickValue;
			if (tickValue < num5)
			{
				num7 = tickValue;
			}
			else if (tickValue <= this._lastCachedTick)
			{
				num7 = tickValue;
			}
			else
			{
				for (int j = num7 + 1; j < tickValue; j++)
				{
					this._cachedValues[j % 128] = new ValueTuple<int, float>(j, 0f);
				}
				this._lastCachedTick = tickValue;
				this._cachedValues[tickValue % 128] = new ValueTuple<int, float>(tickValue, (float)(this.StatSourceInfo.Multiplier * (double)sampleAtIndex.FloatValue));
				num7 = tickValue;
			}
		}
		for (int k = 0; k < 128; k++)
		{
			ValueTuple<int, float> valueTuple = this._cachedValues[(k + num6) % 128];
			float num8 = valueTuple.Item2;
			if (valueTuple.Item1 < num5)
			{
				valueTuple.Item1 = num5 + k;
				num8 = (valueTuple.Item2 = 0f);
			}
			num2 = Math.Min(num8, num2);
			num3 = Math.Max(num8, num3);
			last = (this._values[k] = num8);
			num4 += num8;
		}
		float intermittentAverageInfo = this.GetIntermittentAverageInfo(ref data, num4);
		this.ApplyScaling(ref num2, ref num3);
		this.UpdateUiText(num2, num3, intermittentAverageInfo, last);
	}

	// Token: 0x06000A97 RID: 2711 RVA: 0x000379FC File Offset: 0x00035BFC
	private void UpdateIntermittentTime(ref IStatsBuffer data)
	{
		float num = float.MaxValue;
		float num2 = float.MinValue;
		float num3 = 0f;
		float last = 0f;
		for (int i = 0; i < data.Count; i++)
		{
			float num4 = (float)(this.StatSourceInfo.Multiplier * (double)data.GetSampleAtIndex(i).FloatValue);
			num = Math.Min(num4, num);
			num2 = Math.Max(num4, num2);
			last = (this._values[i] = num4);
			num3 += num4;
		}
		float intermittentAverageInfo = this.GetIntermittentAverageInfo(ref data, num3);
		this.ApplyScaling(ref num, ref num2);
		this.UpdateUiText(num, num2, intermittentAverageInfo, last);
	}

	// Token: 0x06000A98 RID: 2712 RVA: 0x00037A98 File Offset: 0x00035C98
	private void ApplyScaling(ref float min, ref float max)
	{
		if (min > 0f)
		{
			min = 0f;
		}
		if (max > this._max)
		{
			this._max = max;
		}
		if (min < this._min)
		{
			this._min = min;
		}
		float num = this._max - this._min;
		int i = 0;
		int num2 = this._values.Length;
		while (i < num2)
		{
			float num3 = this._values[i];
			float num4 = (num3 < 0f) ? -1f : ((num3 >= this.ErrorThreshold) ? 1f : ((num3 >= this.WarnThreshold) ? Mathf.Lerp(0.5f, 1f, (num3 - this.WarnThreshold) / (this.ErrorThreshold - this.WarnThreshold)) : 0f));
			this._intensity[i] = num4;
			this._values[i] = Mathf.Clamp01((num3 - this._min) / num);
			i++;
		}
	}

	// Token: 0x06000A99 RID: 2713 RVA: 0x00037B84 File Offset: 0x00035D84
	private void UpdateUiText(float min, float max, float avg, float last)
	{
		int decimals = this.StatSourceInfo.Decimals;
		if (this.LabelMin)
		{
			this.LabelMin.text = Math.Round((double)min, decimals).ToString();
		}
		if (this.LabelMax)
		{
			this.LabelMax.text = Math.Round((double)max, decimals).ToString();
		}
		if (this.LabelAvg)
		{
			this.LabelAvg.text = Math.Round((double)avg, decimals).ToString();
		}
		if (this.LabelLast)
		{
			this.LabelLast.text = Math.Round((double)last, decimals).ToString();
		}
		if (this.GraphImg && this.GraphImg.enabled)
		{
			this.GraphImg.material.SetFloatArray("_Data", this._values);
			this.GraphImg.material.SetFloatArray("_Intensity", this._intensity);
			this.GraphImg.material.SetFloat("_Count", (float)this._values.Length);
			this.GraphImg.material.SetFloat("_Height", this.Height);
			this.GraphImg.material.SetFloat("_ZeroCenter", (min < 0f) ? (min / (min - max)) : 0f);
		}
		this._min = Mathf.Lerp(this._min, 0f, Time.deltaTime);
		this._max = Mathf.Lerp(this._max, 1f, Time.deltaTime);
	}

	// Token: 0x06000A9A RID: 2714 RVA: 0x00037D2C File Offset: 0x00035F2C
	private float GetIntermittentAverageInfo(ref IStatsBuffer data, float sum)
	{
		Simulation.Statistics.StatsPer currentPer = this.CurrentPer;
		if (currentPer == Simulation.Statistics.StatsPer.Tick)
		{
			int tickValue = data.GetSampleAtIndex(0).TickValue;
			float num = (float)this._fusionStats.Runner.Simulation.LatestServerState.Tick;
			return sum / (num - (float)tickValue);
		}
		if (currentPer == Simulation.Statistics.StatsPer.Second)
		{
			float timeValue = data.GetSampleAtIndex(0).TimeValue;
			float num2 = (float)this._fusionStats.Runner.Simulation.LatestServerState.Time;
			return sum / (num2 - timeValue);
		}
		return sum / (float)this._values.Length;
	}

	// Token: 0x06000A9B RID: 2715 RVA: 0x00037DBC File Offset: 0x00035FBC
	private void UpdateTickValueHistogram(ref IStatsBuffer data)
	{
		int histoBucketCount = this.StatSourceInfo.HistoBucketCount;
		double histogMaxValue = this.StatSourceInfo.HistogMaxValue;
		if (this._histoStepInverse == 0.0)
		{
			this._histoStepInverse = (double)histoBucketCount / this.StatSourceInfo.HistogMaxValue;
		}
		int tickValue = data.GetSampleAtIndex(data.Count - 1).TickValue;
		SimulationSnapshot latestServerState = this._fusionStats.Runner.Simulation.LatestServerState;
		bool flag = tickValue > 0;
		double num;
		if (flag)
		{
			num = (double)latestServerState.Tick;
			double num2 = (double)tickValue;
			if (num2 < num)
			{
				int num3 = Math.Max((int)num2, (int)this._lastCachedTickTime);
				int num4 = (int)num - num3;
				float num5 = this._histogram[0] + (float)num4;
				this._histogram[0] = num5;
				if (num5 > this._max)
				{
					this._max = num5;
				}
			}
		}
		else
		{
			num = latestServerState.Time;
		}
		Simulation.Statistics.StatSourceInfo statSourceInfo = this.StatSourceInfo;
		double multiplier = statSourceInfo.Multiplier;
		for (int i = data.Count - 1; i >= 0; i--)
		{
			float floatValue = data.GetSampleAtIndex(i).FloatValue;
			ISampleData sampleAtIndex = data.GetSampleAtIndex(i);
			if ((double)(flag ? ((float)sampleAtIndex.TickValue) : sampleAtIndex.TimeValue) <= this._lastCachedTickTime)
			{
				break;
			}
			double num6 = (double)sampleAtIndex.FloatValue * multiplier;
			int num7;
			if (num6 == 0.0)
			{
				num7 = 0;
			}
			else if (num6 == histogMaxValue)
			{
				num7 = histoBucketCount;
			}
			else if (num6 > histogMaxValue)
			{
				num7 = histoBucketCount + 1;
			}
			else
			{
				num7 = (int)(num6 * this._histoStepInverse) + 1;
			}
			double num8 = this._histoAvg * (double)this._histoAvgSampleCount + num6;
			int num9 = this._histoAvgSampleCount + 1;
			this._histoAvgSampleCount = num9;
			this._histoAvg = num8 / (double)num9;
			float num10 = this._histogram[num7] + 1f;
			if (num10 > this._max)
			{
				this._max = num10;
			}
			this._histogram[num7] = num10;
			if (num7 > this._histoHighestUsedBucketIndex)
			{
				this._histoHighestUsedBucketIndex = num7;
			}
		}
		int num11 = 0;
		float num12 = 0f;
		float num13 = (this._max - this._min) * 1.1f;
		int j = 0;
		int num14 = this._histogram.Length;
		while (j < num14)
		{
			float num15 = this._histogram[j];
			this._intensity[j] = 0f;
			if (j != 0 && num15 > num12)
			{
				num12 = num15;
				num11 = j;
			}
			this._values[j] = Mathf.Clamp01((this._histogram[j] - this._min) / num13);
			j++;
		}
		this._intensity[num11] = 2f;
		this._lastCachedTickTime = num;
		if (this.GraphImg && this.GraphImg.enabled)
		{
			this.GraphImg.material.SetFloatArray("_Data", this._values);
			this.GraphImg.material.SetFloatArray("_Intensity", this._intensity);
			this.GraphImg.material.SetFloat("_Count", (float)(this._histoHighestUsedBucketIndex + 1));
			this.GraphImg.material.SetFloat("_Height", this.Height);
		}
		this._min = 0f;
		int decimals = statSourceInfo.Decimals;
		this.LabelMax.text = string.Format("<color=yellow>{0}</color>", Math.Ceiling((double)(num11 + 1) / this._histoStepInverse));
		this.LabelAvg.text = Math.Round(this._histoAvg, decimals).ToString();
		this.LabelMin.text = Math.Floor((double)this._min).ToString();
		this.LabelLast.text = Math.Round((double)(this._histoHighestUsedBucketIndex + 1) / this._histoStepInverse, decimals).ToString();
	}

	// Token: 0x06000A9C RID: 2716 RVA: 0x0003818C File Offset: 0x0003638C
	public static FusionGraph Create(FusionStats iFusionStats, Simulation.Statistics.StatSourceTypes statSourceType, int statId, RectTransform parentRT)
	{
		Simulation.Statistics.StatSourceInfo description = Simulation.Statistics.GetDescription(statSourceType, statId);
		RectTransform rectTransform = parentRT.CreateRectTransform(description.LongName, false);
		FusionGraph fusionGraph = rectTransform.gameObject.AddComponent<FusionGraph>();
		fusionGraph._fusionStats = iFusionStats;
		fusionGraph.Generate(statSourceType, statId, rectTransform);
		return fusionGraph;
	}

	// Token: 0x06000A9D RID: 2717 RVA: 0x000381CC File Offset: 0x000363CC
	public void Generate(Simulation.Statistics.StatSourceTypes type, int statId, RectTransform root)
	{
		this._statSourceType = type;
		base.GetComponent<RectTransform>();
		this._statId = statId;
		root.anchorMin = new Vector2(0.5f, 0.5f);
		root.anchorMax = new Vector2(0.5f, 0.5f);
		root.anchoredPosition3D = default(Vector3);
		RectTransform rectTransform = root.CreateRectTransform("Background", false).ExpandAnchor(null);
		this.BackImage = rectTransform.gameObject.AddComponent<Image>();
		this.BackImage.color = this.BackColor;
		this.BackImage.raycastTarget = false;
		RectTransform rectTransform2 = rectTransform.CreateRectTransform("Graph", false).SetAnchors(0f, 1f, 0.2f, 0.8f).SetOffsets(0f, 0f, 0f, 0f);
		this.GraphImg = rectTransform2.gameObject.AddComponent<Image>();
		this.GraphImg.raycastTarget = false;
		this.ResetGraphShader();
		Color fontColor = this._fusionStats.FontColor;
		Color fontColor2 = this._fusionStats.FontColor * new Color(1f, 1f, 1f, 0.5f);
		RectTransform rectTransform3 = root.CreateRectTransform("Title", false).ExpandAnchor(null).SetOffsets(10f, -10f, 0f, -2f);
		rectTransform3.anchoredPosition = new Vector2(0f, 0f);
		this.LabelTitle = rectTransform3.AddText(base.name, TextAnchor.UpperRight, fontColor);
		this.LabelTitle.resizeTextMaxSize = 24;
		this.LabelTitle.raycastTarget = true;
		RectTransform rt = root.CreateRectTransform("Max", false).SetAnchors(0f, 0.3f, 0.85f, 1f).SetOffsets(6f, 0f, 0f, -2f);
		this.LabelMax = rt.AddText("-", TextAnchor.UpperLeft, fontColor2);
		RectTransform rt2 = root.CreateRectTransform("Min", false).SetAnchors(0f, 0.3f, 0f, 0.15f).SetOffsets(6f, 0f, 0f, -2f);
		this.LabelMin = rt2.AddText("-", TextAnchor.LowerLeft, fontColor2);
		RectTransform rectTransform4 = root.CreateRectTransform("Avg", false).SetOffsets(0f, 0f, 0f, 0f);
		rectTransform4.anchoredPosition = new Vector2(0f, 0f);
		this.LabelAvg = rectTransform4.AddText("-", TextAnchor.LowerCenter, fontColor);
		this.LabelAvg.raycastTarget = true;
		this._avgBttn = rectTransform4.gameObject.AddComponent<Button>();
		RectTransform rt3 = root.CreateRectTransform("Per", false).SetAnchors(0.3f, 0.7f, 0f, 0.125f).SetOffsets(6f, -6f, 6f, 0f);
		this.LabelPer = rt3.AddText("avg per Sample", TextAnchor.LowerCenter, fontColor);
		RectTransform rt4 = root.CreateRectTransform("Last", false).SetAnchors(0.7f, 1f, 0f, 0.15f).SetOffsets(10f, -10f, 0f, -2f);
		this.LabelLast = rt4.AddText("-", TextAnchor.LowerRight, fontColor2);
		this._viewDropdown = rectTransform3.CreateDropdown(10f, fontColor);
		this._layoutDirty = true;
	}

	// Token: 0x06000A9E RID: 2718 RVA: 0x00038560 File Offset: 0x00036760
	[BehaviourButtonAction("Update Layout", null, null)]
	public override void CalculateLayout()
	{
		try
		{
			if (base.gameObject == null)
			{
				return;
			}
		}
		catch
		{
			return;
		}
		if (!base.gameObject.activeInHierarchy)
		{
			return;
		}
		this._layoutDirty = false;
		RectTransform component = base.GetComponent<RectTransform>();
		if (this._statsBuffer == null)
		{
			this.TryConnect();
		}
		base.ApplyTitleText();
		bool flag = this.StatSourceInfo.InvalidReason == null;
		this.LabelMin.gameObject.SetActive(flag);
		this.LabelMax.gameObject.SetActive(flag);
		this.LabelAvg.gameObject.SetActive(flag);
		this.LabelPer.gameObject.SetActive(flag);
		if (!flag)
		{
			this.LabelTitle.rectTransform.ExpandAnchor(new float?((float)10));
			this.LabelTitle.alignment = TextAnchor.MiddleCenter;
			this.LabelTitle.raycastTarget = false;
			this._viewDropdown.gameObject.SetActive(false);
			return;
		}
		this.GraphImg.material.SetInt("_ZWrite", (this._fusionStats.CanvasType == FusionStats.StatCanvasTypes.GameObject) ? 1 : 0);
		bool flag2 = this._fusionStats.CanvasType == FusionStats.StatCanvasTypes.GameObject;
		bool noGraphShader = this._fusionStats.NoGraphShader;
		float height = component.rect.height;
		float width = component.rect.width;
		FusionGraph.Layouts layouts;
		if (this._layout != FusionGraph.Layouts.Auto)
		{
			layouts = this._layout;
		}
		else if (this._fusionStats.DefaultLayout != FusionGraph.Layouts.Auto)
		{
			layouts = this._fusionStats.DefaultLayout;
		}
		else if (height < 52f)
		{
			layouts = FusionGraph.Layouts.CompactAuto;
		}
		else if (width < 200f)
		{
			layouts = FusionGraph.Layouts.CenteredAuto;
		}
		else
		{
			layouts = FusionGraph.Layouts.FullAuto;
		}
		bool flag3 = noGraphShader || layouts == FusionGraph.Layouts.CompactNoGraph || layouts == FusionGraph.Layouts.CenteredNoGraph || (this._fusionStats.NoTextOverlap && layouts == FusionGraph.Layouts.CompactAuto);
		bool flag4 = this._fusionStats.NoTextOverlap || layouts == FusionGraph.Layouts.FullNoOverlap || layouts == FusionGraph.Layouts.CenteredNoOverlap;
		bool flag5 = !flag3 && (this.ShowGraph == FusionGraph.ShowGraphOptions.Always || (this.ShowGraph == FusionGraph.ShowGraphOptions.OverlayOnly && flag2));
		bool flag6 = !flag4 && (this._alwaysExpandGraph || !flag5 || layouts == FusionGraph.Layouts.CompactAuto || (!flag4 && height < 112f));
		bool flag7 = height < 18f;
		RectTransform rectTransform = this.GraphImg.rectTransform;
		if (rectTransform)
		{
			rectTransform.gameObject.SetActive(flag5);
			if (flag6)
			{
				rectTransform.SetAnchors(0f, 1f, 0f, 1f);
			}
			else
			{
				rectTransform.SetAnchors(0f, 1f, 0.25f, 0.8f);
			}
		}
		bool flag8 = layouts == FusionGraph.Layouts.FullAuto || layouts == FusionGraph.Layouts.FullNoOverlap;
		RectTransform rectTransform2 = this.LabelTitle.rectTransform;
		RectTransform rectTransform3 = this.LabelAvg.rectTransform;
		if (this.LabelPer == null)
		{
			RectTransform rt = rectTransform3.parent.CreateRectTransform("Per", false).SetAnchors(0.3f, 0.7f, 0f, 0.125f).SetOffsets(6f, -6f, 6f, 0f);
			this.LabelPer = rt.AddText("per sample", TextAnchor.LowerCenter, this._fusionStats.FontColor);
		}
		RectTransform rectTransform4 = this.LabelPer.rectTransform;
		switch (layouts)
		{
		case FusionGraph.Layouts.FullAuto:
		case FusionGraph.Layouts.FullNoOverlap:
			rectTransform2.anchorMin = new Vector2(flag8 ? 0.3f : 0f, flag6 ? 0.5f : 0.8f);
			rectTransform2.anchorMax = new Vector2(1f, 1f);
			rectTransform2.offsetMin = new Vector2(6f, 0f);
			rectTransform2.offsetMax = new Vector2(-6f, -6f);
			this.LabelTitle.alignment = (flag8 ? TextAnchor.UpperRight : TextAnchor.UpperCenter);
			rectTransform3.anchorMin = new Vector2(flag8 ? 0.3f : 0f, flag6 ? 0.15f : 0.1f);
			rectTransform3.anchorMax = new Vector2(flag8 ? 0.7f : 1f, flag6 ? 0.5f : 0.25f);
			rectTransform3.SetOffsets(0f, 0f, 0f, 0f);
			this.LabelAvg.alignment = TextAnchor.LowerCenter;
			rectTransform4.SetAnchors(0.3f, 0.7f, 0f, flag6 ? 0.2f : 0.1f);
			this.LabelPer.alignment = TextAnchor.LowerCenter;
			break;
		case FusionGraph.Layouts.CenteredAuto:
		case FusionGraph.Layouts.CenteredNoGraph:
		case FusionGraph.Layouts.CenteredNoOverlap:
			rectTransform2.anchorMin = new Vector2(0f, flag6 ? 0.5f : 0.8f);
			rectTransform2.anchorMax = new Vector2(1f, 1f);
			rectTransform2.offsetMin = new Vector2(6f, 0f);
			rectTransform2.offsetMax = new Vector2(-6f, -6f);
			this.LabelTitle.alignment = TextAnchor.UpperCenter;
			rectTransform3.anchorMin = new Vector2(0f, flag6 ? 0.15f : 0.1f);
			rectTransform3.anchorMax = new Vector2(1f, flag6 ? 0.5f : 0.25f);
			rectTransform3.SetOffsets(6f, -6f, 0f, 0f);
			rectTransform4.SetAnchors(0f, 1f, 0f, flag6 ? 0.2f : 0.1f);
			this.LabelPer.alignment = TextAnchor.LowerCenter;
			this.LabelAvg.alignment = TextAnchor.LowerCenter;
			break;
		case FusionGraph.Layouts.CompactAuto:
		case FusionGraph.Layouts.CompactNoGraph:
			rectTransform2.anchorMin = new Vector2(0.05f, 0f);
			rectTransform2.anchorMax = new Vector2(0.5f, 1f);
			if (flag7)
			{
				rectTransform2.SetOffsets(0f, 0f, 0f, 0f);
				rectTransform3.SetOffsets(6f, 0f, 0f, 0f);
			}
			else
			{
				rectTransform2.SetOffsets(0f, 0f, 6f, -6f);
				rectTransform3.SetOffsets(6f, 0f, 6f, -6f);
			}
			this.LabelTitle.alignment = TextAnchor.MiddleLeft;
			rectTransform3.SetAnchors(0.5f, 0.95f, 0f, 1f);
			rectTransform4.SetAnchors(0.5f, 0.95f, 0f, 0.15f).SetOffsets(6f, -12f, 6f, 0f);
			this.LabelPer.alignment = TextAnchor.LowerRight;
			this.LabelAvg.alignment = TextAnchor.MiddleRight;
			break;
		}
		this.LabelMin.enabled = flag8;
		this.LabelMax.enabled = flag8;
		this.LabelLast.enabled = flag8;
	}

	// Token: 0x04000BA9 RID: 2985
	private const int GRPH_TOP_PAD = 36;

	// Token: 0x04000BAA RID: 2986
	private const int GRPH_BTM_PAD = 36;

	// Token: 0x04000BAB RID: 2987
	private const int HIDE_XTRAS_WDTH = 200;

	// Token: 0x04000BAC RID: 2988
	private const int INTERMITTENT_DATA_ARRAYSIZE = 128;

	// Token: 0x04000BAD RID: 2989
	private const int EXPAND_GRPH_THRESH = 112;

	// Token: 0x04000BAE RID: 2990
	private const int COMPACT_THRESH = 52;

	// Token: 0x04000BAF RID: 2991
	[SerializeField]
	[HideInInspector]
	public float Height = 50f;

	// Token: 0x04000BB0 RID: 2992
	[InlineHelp]
	[SerializeField]
	[Header("Graph Layout")]
	private FusionGraph.Layouts _layout;

	// Token: 0x04000BB1 RID: 2993
	[InlineHelp]
	[SerializeField]
	private FusionGraph.ShowGraphOptions _showGraph = FusionGraph.ShowGraphOptions.Always;

	// Token: 0x04000BB2 RID: 2994
	[InlineHelp]
	public float Padding = 5f;

	// Token: 0x04000BB3 RID: 2995
	[InlineHelp]
	[SerializeField]
	private bool _alwaysExpandGraph;

	// Token: 0x04000BB4 RID: 2996
	[InlineHelp]
	[SerializeField]
	private bool _showUITargets;

	// Token: 0x04000BB5 RID: 2997
	[DrawIf("_showUITargets", Hide = true)]
	public Image GraphImg;

	// Token: 0x04000BB6 RID: 2998
	[DrawIf("_showUITargets", Hide = true)]
	public Text LabelMin;

	// Token: 0x04000BB7 RID: 2999
	[DrawIf("_showUITargets", Hide = true)]
	public Text LabelMax;

	// Token: 0x04000BB8 RID: 3000
	[DrawIf("_showUITargets", Hide = true)]
	public Text LabelAvg;

	// Token: 0x04000BB9 RID: 3001
	[DrawIf("_showUITargets", Hide = true)]
	public Text LabelLast;

	// Token: 0x04000BBA RID: 3002
	[DrawIf("_showUITargets", Hide = true)]
	public Text LabelPer;

	// Token: 0x04000BBB RID: 3003
	[DrawIf("_showUITargets", Hide = true)]
	public Dropdown _viewDropdown;

	// Token: 0x04000BBC RID: 3004
	[DrawIf("_showUITargets", Hide = true)]
	public Button _avgBttn;

	// Token: 0x04000BBD RID: 3005
	private float _min;

	// Token: 0x04000BBE RID: 3006
	private float _max;

	// Token: 0x04000BBF RID: 3007
	private float[] _values;

	// Token: 0x04000BC0 RID: 3008
	private float[] _intensity;

	// Token: 0x04000BC1 RID: 3009
	private float[] _histogram;

	// Token: 0x04000BC2 RID: 3010
	private List<int> DropdownLookup = new List<int>();

	// Token: 0x04000BC3 RID: 3011
	[InlineHelp]
	private FusionGraphVisualization _graphVisualization;

	// Token: 0x04000BC4 RID: 3012
	private FusionGraph.ShaderType _currentShader;

	// Token: 0x04000BC5 RID: 3013
	[TupleElementNames(new string[]
	{
		"tick",
		"value"
	})]
	private ValueTuple<int, float>[] _cachedValues;

	// Token: 0x04000BC6 RID: 3014
	private double _lastCachedTickTime;

	// Token: 0x04000BC7 RID: 3015
	private int _lastCachedTick;

	// Token: 0x04000BC8 RID: 3016
	private int _histoHighestUsedBucketIndex;

	// Token: 0x04000BC9 RID: 3017
	private int _histoAvgSampleCount;

	// Token: 0x04000BCA RID: 3018
	private double _histoStepInverse;

	// Token: 0x04000BCB RID: 3019
	private double _histoAvg;

	// Token: 0x0200020A RID: 522
	public enum Layouts
	{
		// Token: 0x04000BCD RID: 3021
		Auto,
		// Token: 0x04000BCE RID: 3022
		FullAuto,
		// Token: 0x04000BCF RID: 3023
		FullNoOverlap,
		// Token: 0x04000BD0 RID: 3024
		CenteredAuto,
		// Token: 0x04000BD1 RID: 3025
		CenteredNoGraph,
		// Token: 0x04000BD2 RID: 3026
		CenteredNoOverlap,
		// Token: 0x04000BD3 RID: 3027
		CompactAuto,
		// Token: 0x04000BD4 RID: 3028
		CompactNoGraph
	}

	// Token: 0x0200020B RID: 523
	public enum ShowGraphOptions
	{
		// Token: 0x04000BD6 RID: 3030
		Never,
		// Token: 0x04000BD7 RID: 3031
		OverlayOnly,
		// Token: 0x04000BD8 RID: 3032
		Always
	}

	// Token: 0x0200020C RID: 524
	private enum ShaderType
	{
		// Token: 0x04000BDA RID: 3034
		None,
		// Token: 0x04000BDB RID: 3035
		Overlay,
		// Token: 0x04000BDC RID: 3036
		GameObject
	}
}
