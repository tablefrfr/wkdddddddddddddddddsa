﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000383 RID: 899
public class GorillaLevelScreen : MonoBehaviour
{
	// Token: 0x0600148D RID: 5261 RVA: 0x0006C64F File Offset: 0x0006A84F
	private void Awake()
	{
		if (this.myText != null)
		{
			this.startingText = this.myText.text;
		}
	}

	// Token: 0x0600148E RID: 5262 RVA: 0x0006C670 File Offset: 0x0006A870
	public void UpdateText(string newText, bool setToGoodMaterial)
	{
		if (this.myText != null)
		{
			this.myText.text = newText;
		}
		Material[] materials = base.GetComponent<MeshRenderer>().materials;
		materials[0] = (setToGoodMaterial ? this.goodMaterial : this.badMaterial);
		base.GetComponent<MeshRenderer>().materials = materials;
	}

	// Token: 0x04001776 RID: 6006
	public string startingText;

	// Token: 0x04001777 RID: 6007
	public Material goodMaterial;

	// Token: 0x04001778 RID: 6008
	public Material badMaterial;

	// Token: 0x04001779 RID: 6009
	public Text myText;
}
