﻿using System;

namespace Constants
{
	// Token: 0x020005A6 RID: 1446
	public static class GamePlayConfig
	{
		// Token: 0x04002312 RID: 8978
		public const float PROJECTILE_DISTANCE_THRESHOLD = 4f;

		// Token: 0x04002313 RID: 8979
		public const float TAG_DISTANCE_THRESHOLD = 6f;

		// Token: 0x04002314 RID: 8980
		public const float TAG_TIME_ROLLBACK = 0.2f;

		// Token: 0x04002315 RID: 8981
		public const int MAX_ROOM_SIZE = 10;
	}
}
