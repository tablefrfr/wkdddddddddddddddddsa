﻿using System;
using GorillaTag;
using Photon.Pun;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x0200004A RID: 74
public class FingerFlagWearable : MonoBehaviour, ISpawnable
{
	// Token: 0x1700000B RID: 11
	// (get) Token: 0x0600016E RID: 366 RVA: 0x0000BDB9 File Offset: 0x00009FB9
	// (set) Token: 0x0600016F RID: 367 RVA: 0x0000BDC1 File Offset: 0x00009FC1
	bool ISpawnable.IsSpawned { get; set; }

	// Token: 0x06000170 RID: 368 RVA: 0x0000BDCA File Offset: 0x00009FCA
	void ISpawnable.OnSpawn()
	{
		this.myRig = base.GetComponentInParent<VRRig>(true);
		if (!this.myRig)
		{
			base.gameObject.SetActive(false);
		}
	}

	// Token: 0x06000171 RID: 369 RVA: 0x00003051 File Offset: 0x00001251
	void ISpawnable.OnDespawn()
	{
	}

	// Token: 0x06000172 RID: 370 RVA: 0x0000BDF4 File Offset: 0x00009FF4
	protected void OnEnable()
	{
		int num = this.attachedToLeftHand ? 1 : 2;
		this.stateBitIndex = VRRig.WearablePackedStatesBitWriteInfos[num].index;
		this.OnExtendStateChanged(false);
	}

	// Token: 0x06000173 RID: 371 RVA: 0x0000BE2C File Offset: 0x0000A02C
	private void UpdateLocal()
	{
		int node = this.attachedToLeftHand ? 4 : 5;
		bool flag = ControllerInputPoller.GripFloat((XRNode)node) > 0.25f;
		bool flag2 = ControllerInputPoller.PrimaryButtonPress((XRNode)node);
		bool flag3 = ControllerInputPoller.SecondaryButtonPress((XRNode)node);
		bool flag4 = flag && (flag2 || flag3);
		this.networkedExtended = flag4;
		if (PhotonNetwork.InRoom && this.myRig)
		{
			this.myRig.WearablePackedStates = GTBitOps.WriteBit(this.myRig.WearablePackedStates, this.stateBitIndex, this.networkedExtended);
		}
	}

	// Token: 0x06000174 RID: 372 RVA: 0x0000BEAC File Offset: 0x0000A0AC
	private void UpdateShared()
	{
		if (this.extended != this.networkedExtended)
		{
			this.extended = this.networkedExtended;
			this.OnExtendStateChanged(true);
		}
		bool flag = this.fullyRetracted;
		this.fullyRetracted = (this.extended && this.retractExtendTime <= 0f);
		if (flag != this.fullyRetracted)
		{
			Transform[] array = this.clothRigidbodies;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].gameObject.SetActive(!this.fullyRetracted);
			}
		}
		this.UpdateAnimation();
	}

	// Token: 0x06000175 RID: 373 RVA: 0x0000BF3A File Offset: 0x0000A13A
	private void UpdateReplicated()
	{
		if (this.myRig != null && !this.myRig.isOfflineVRRig)
		{
			this.networkedExtended = GTBitOps.ReadBit(this.myRig.WearablePackedStates, this.stateBitIndex);
		}
	}

	// Token: 0x06000176 RID: 374 RVA: 0x0000BF73 File Offset: 0x0000A173
	public bool IsMyItem()
	{
		return this.myRig != null && this.myRig.isOfflineVRRig;
	}

	// Token: 0x06000177 RID: 375 RVA: 0x0000BF90 File Offset: 0x0000A190
	protected void LateUpdate()
	{
		if (this.IsMyItem())
		{
			this.UpdateLocal();
		}
		else
		{
			this.UpdateReplicated();
		}
		this.UpdateShared();
	}

	// Token: 0x06000178 RID: 376 RVA: 0x0000BFB0 File Offset: 0x0000A1B0
	private void UpdateAnimation()
	{
		float num = this.extended ? this.extendSpeed : (-this.retractSpeed);
		this.retractExtendTime = Mathf.Clamp01(this.retractExtendTime + Time.deltaTime * num);
		this.animator.SetFloat(this.retractExtendTimeAnimParam, this.retractExtendTime);
	}

	// Token: 0x06000179 RID: 377 RVA: 0x0000C008 File Offset: 0x0000A208
	private void OnExtendStateChanged(bool playAudio)
	{
		this.audioSource.clip = (this.extended ? this.extendAudioClip : this.retractAudioClip);
		if (playAudio)
		{
			this.audioSource.Play();
		}
		if (this.IsMyItem() && GorillaTagger.Instance)
		{
			GorillaTagger.Instance.StartVibration(this.attachedToLeftHand, this.extended ? this.extendVibrationDuration : this.retractVibrationDuration, this.extended ? this.extendVibrationStrength : this.retractVibrationStrength);
		}
	}

	// Token: 0x040001F7 RID: 503
	[Header("Wearable Settings")]
	public bool attachedToLeftHand = true;

	// Token: 0x040001F8 RID: 504
	[Header("Bones")]
	public Transform pinkyRingBone;

	// Token: 0x040001F9 RID: 505
	public Transform thumbRingBone;

	// Token: 0x040001FA RID: 506
	public Transform[] clothBones;

	// Token: 0x040001FB RID: 507
	public Transform[] clothRigidbodies;

	// Token: 0x040001FC RID: 508
	[Header("Animation")]
	public Animator animator;

	// Token: 0x040001FD RID: 509
	public float extendSpeed = 1.5f;

	// Token: 0x040001FE RID: 510
	public float retractSpeed = 2.25f;

	// Token: 0x040001FF RID: 511
	[Header("Audio")]
	public AudioSource audioSource;

	// Token: 0x04000200 RID: 512
	public AudioClip extendAudioClip;

	// Token: 0x04000201 RID: 513
	public AudioClip retractAudioClip;

	// Token: 0x04000202 RID: 514
	[Header("Vibration")]
	public float extendVibrationDuration = 0.05f;

	// Token: 0x04000203 RID: 515
	public float extendVibrationStrength = 0.2f;

	// Token: 0x04000204 RID: 516
	public float retractVibrationDuration = 0.05f;

	// Token: 0x04000205 RID: 517
	public float retractVibrationStrength = 0.2f;

	// Token: 0x04000206 RID: 518
	private readonly int retractExtendTimeAnimParam = Animator.StringToHash("retractExtendTime");

	// Token: 0x04000207 RID: 519
	private bool networkedExtended;

	// Token: 0x04000208 RID: 520
	private bool extended;

	// Token: 0x04000209 RID: 521
	private bool fullyRetracted;

	// Token: 0x0400020A RID: 522
	private float retractExtendTime;

	// Token: 0x0400020B RID: 523
	private InputDevice inputDevice;

	// Token: 0x0400020C RID: 524
	private VRRig myRig;

	// Token: 0x0400020D RID: 525
	private int stateBitIndex;
}
