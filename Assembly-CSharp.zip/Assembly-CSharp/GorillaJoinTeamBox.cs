﻿using System;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000382 RID: 898
public class GorillaJoinTeamBox : GorillaTriggerBox
{
	// Token: 0x0600148B RID: 5259 RVA: 0x0006C62A File Offset: 0x0006A82A
	public override void OnBoxTriggered()
	{
		base.OnBoxTriggered();
		if (GameObject.FindGameObjectWithTag("GorillaGameManager").GetComponent<GorillaGameManager>() != null)
		{
			bool inRoom = PhotonNetwork.InRoom;
		}
	}

	// Token: 0x04001775 RID: 6005
	public bool joinRedTeam;
}
