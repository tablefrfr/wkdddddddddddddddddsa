﻿using System;

namespace GorillaNetworking
{
	// Token: 0x020006C7 RID: 1735
	public class BroadcastMyRoomRequest
	{
		// Token: 0x04002C3E RID: 11326
		public string KeyToFollow;

		// Token: 0x04002C3F RID: 11327
		public string RoomToJoin;

		// Token: 0x04002C40 RID: 11328
		public bool Set;
	}
}
