﻿using System;
using UnityEngine;

namespace BoingKit
{
	// Token: 0x020007ED RID: 2029
	public class BoingBase : MonoBehaviour
	{
		// Token: 0x1700054F RID: 1359
		// (get) Token: 0x06003141 RID: 12609 RVA: 0x000F58CE File Offset: 0x000F3ACE
		public Version CurrentVersion
		{
			get
			{
				return this.m_currentVersion;
			}
		}

		// Token: 0x17000550 RID: 1360
		// (get) Token: 0x06003142 RID: 12610 RVA: 0x000F58D6 File Offset: 0x000F3AD6
		public Version PreviousVersion
		{
			get
			{
				return this.m_previousVersion;
			}
		}

		// Token: 0x17000551 RID: 1361
		// (get) Token: 0x06003143 RID: 12611 RVA: 0x000F58DE File Offset: 0x000F3ADE
		public Version InitialVersion
		{
			get
			{
				return this.m_initialVersion;
			}
		}

		// Token: 0x06003144 RID: 12612 RVA: 0x000F58E6 File Offset: 0x000F3AE6
		protected virtual void OnUpgrade(Version oldVersion, Version newVersion)
		{
			this.m_previousVersion = this.m_currentVersion;
			if (this.m_currentVersion.Revision < 33)
			{
				this.m_initialVersion = Version.Invalid;
				this.m_previousVersion = Version.Invalid;
			}
			this.m_currentVersion = newVersion;
		}

		// Token: 0x04003388 RID: 13192
		[SerializeField]
		private Version m_currentVersion;

		// Token: 0x04003389 RID: 13193
		[SerializeField]
		private Version m_previousVersion;

		// Token: 0x0400338A RID: 13194
		[SerializeField]
		private Version m_initialVersion = BoingKit.Version;
	}
}
