﻿using System;
using GorillaNetworking;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000287 RID: 647
public class FittingRoomButton : GorillaPressableButton
{
	// Token: 0x06000E42 RID: 3650 RVA: 0x0004AC1B File Offset: 0x00048E1B
	public override void Start()
	{
		this.currentCosmeticItem = CosmeticsController.instance.nullItem;
	}

	// Token: 0x06000E43 RID: 3651 RVA: 0x0004AC30 File Offset: 0x00048E30
	public override void UpdateColor()
	{
		if (this.currentCosmeticItem.itemName == "null")
		{
			this.button.material = this.unpressedMaterial;
			this.buttonText.text = this.noCosmeticText;
			return;
		}
		if (this.isOn)
		{
			this.button.material = this.pressedMaterial;
			this.buttonText.text = this.onText;
			return;
		}
		this.button.material = this.unpressedMaterial;
		this.buttonText.text = this.offText;
	}

	// Token: 0x06000E44 RID: 3652 RVA: 0x0004ACC4 File Offset: 0x00048EC4
	public override void ButtonActivationWithHand(bool isLeftHand)
	{
		base.ButtonActivationWithHand(isLeftHand);
		CosmeticsController.instance.PressFittingRoomButton(this, isLeftHand);
	}

	// Token: 0x04001024 RID: 4132
	public CosmeticsController.CosmeticItem currentCosmeticItem;

	// Token: 0x04001025 RID: 4133
	public Image currentImage;

	// Token: 0x04001026 RID: 4134
	public MeshRenderer button;

	// Token: 0x04001027 RID: 4135
	public Material blank;

	// Token: 0x04001028 RID: 4136
	public string noCosmeticText;

	// Token: 0x04001029 RID: 4137
	public Text buttonText;
}
