﻿using System;
using UnityEngine;

// Token: 0x020004BF RID: 1215
public class FlagForBaking : MonoBehaviour
{
	// Token: 0x04001F70 RID: 8048
	public bool enableForBaking;
}
