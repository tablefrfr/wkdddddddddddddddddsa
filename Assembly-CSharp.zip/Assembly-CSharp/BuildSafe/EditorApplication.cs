﻿using System;

namespace BuildSafe
{
	// Token: 0x02000621 RID: 1569
	public static class EditorApplication
	{
		// Token: 0x14000039 RID: 57
		// (add) Token: 0x0600250B RID: 9483 RVA: 0x00003051 File Offset: 0x00001251
		// (remove) Token: 0x0600250C RID: 9484 RVA: 0x00003051 File Offset: 0x00001251
		public static event Action hierarchyChanged
		{
			add
			{
			}
			remove
			{
			}
		}

		// Token: 0x1400003A RID: 58
		// (add) Token: 0x0600250D RID: 9485 RVA: 0x00003051 File Offset: 0x00001251
		// (remove) Token: 0x0600250E RID: 9486 RVA: 0x00003051 File Offset: 0x00001251
		public static event Action update
		{
			add
			{
			}
			remove
			{
			}
		}

		// Token: 0x1400003B RID: 59
		// (add) Token: 0x0600250F RID: 9487 RVA: 0x00003051 File Offset: 0x00001251
		// (remove) Token: 0x06002510 RID: 9488 RVA: 0x00003051 File Offset: 0x00001251
		public static event Action delayCall
		{
			add
			{
			}
			remove
			{
			}
		}
	}
}
