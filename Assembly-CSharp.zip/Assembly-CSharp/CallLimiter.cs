﻿using System;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200046F RID: 1135
[Serializable]
public class CallLimiter
{
	// Token: 0x06001A78 RID: 6776 RVA: 0x00002050 File Offset: 0x00000250
	public CallLimiter()
	{
	}

	// Token: 0x06001A79 RID: 6777 RVA: 0x00087E58 File Offset: 0x00086058
	public CallLimiter(int historyLength, float coolDown, float latencyMax = 0.5f)
	{
		this.callTimeHistory = new float[historyLength];
		this.callHistoryLength = historyLength;
		for (int i = 0; i < historyLength; i++)
		{
			this.callTimeHistory[i] = float.MinValue;
		}
		this.timeCooldown = coolDown;
		this.maxLatency = latencyMax;
	}

	// Token: 0x06001A7A RID: 6778 RVA: 0x00087EA5 File Offset: 0x000860A5
	public bool CheckCallServerTime(double time)
	{
		return Mathf.Abs((float)(PhotonNetwork.Time - time)) <= this.maxLatency && this.CheckCallTime((float)time);
	}

	// Token: 0x06001A7B RID: 6779 RVA: 0x00087EC8 File Offset: 0x000860C8
	public virtual bool CheckCallTime(float time)
	{
		if (this.callTimeHistory[this.oldTimeIndex] > time)
		{
			this.blockCall = true;
			this.blockStartTime = time;
			return false;
		}
		this.callTimeHistory[this.oldTimeIndex] = time + this.timeCooldown;
		int num = this.oldTimeIndex + 1;
		this.oldTimeIndex = num;
		this.oldTimeIndex = num % this.callHistoryLength;
		this.blockCall = false;
		return true;
	}

	// Token: 0x06001A7C RID: 6780 RVA: 0x00087F30 File Offset: 0x00086130
	public virtual void Reset()
	{
		if (this.callTimeHistory == null)
		{
			return;
		}
		for (int i = 0; i < this.callHistoryLength; i++)
		{
			this.callTimeHistory[i] = float.MinValue;
		}
		this.oldTimeIndex = 0;
		this.blockStartTime = 0f;
		this.blockCall = false;
	}

	// Token: 0x04001E72 RID: 7794
	[SerializeField]
	protected float[] callTimeHistory;

	// Token: 0x04001E73 RID: 7795
	[SerializeField]
	protected int callHistoryLength;

	// Token: 0x04001E74 RID: 7796
	[SerializeField]
	protected float timeCooldown;

	// Token: 0x04001E75 RID: 7797
	[SerializeField]
	protected float maxLatency;

	// Token: 0x04001E76 RID: 7798
	private int oldTimeIndex;

	// Token: 0x04001E77 RID: 7799
	protected bool blockCall;

	// Token: 0x04001E78 RID: 7800
	protected float blockStartTime;
}
