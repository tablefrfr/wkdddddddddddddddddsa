﻿using System;

namespace emotitron.Compression
{
	// Token: 0x020007B3 RID: 1971
	public enum PackedBitsSize
	{
		// Token: 0x0400325E RID: 12894
		UInt8 = 4,
		// Token: 0x0400325F RID: 12895
		UInt16,
		// Token: 0x04003260 RID: 12896
		UInt32,
		// Token: 0x04003261 RID: 12897
		UInt64
	}
}
