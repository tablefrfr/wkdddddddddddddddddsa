﻿using System;

namespace BoingKit
{
	// Token: 0x02000825 RID: 2085
	public enum ParameterMode
	{
		// Token: 0x0400351F RID: 13599
		Exponential,
		// Token: 0x04003520 RID: 13600
		OscillationByHalfLife,
		// Token: 0x04003521 RID: 13601
		OscillationByDampingRatio
	}
}
