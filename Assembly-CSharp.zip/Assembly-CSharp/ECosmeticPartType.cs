﻿using System;

// Token: 0x02000090 RID: 144
public enum ECosmeticPartType
{
	// Token: 0x04000428 RID: 1064
	Functional,
	// Token: 0x04000429 RID: 1065
	Wardrobe,
	// Token: 0x0400042A RID: 1066
	FirstPerson
}
