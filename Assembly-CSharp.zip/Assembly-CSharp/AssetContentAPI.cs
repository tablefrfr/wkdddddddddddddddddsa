﻿using System;
using UnityEngine;

// Token: 0x02000506 RID: 1286
public class AssetContentAPI : ScriptableObject
{
	// Token: 0x0400201E RID: 8222
	public string bundleName;

	// Token: 0x0400201F RID: 8223
	public LazyLoadReference<TextAsset> bundleFile;

	// Token: 0x04002020 RID: 8224
	public Object[] assets = new Object[0];
}
