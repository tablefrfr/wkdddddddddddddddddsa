﻿using System;
using Cinemachine;
using GorillaLocomotion;
using UnityEngine;

// Token: 0x020002FD RID: 765
public class GorillaCameraFollow : MonoBehaviour
{
	// Token: 0x06001183 RID: 4483 RVA: 0x0005C320 File Offset: 0x0005A520
	private void Start()
	{
		if (Application.platform == RuntimePlatform.Android)
		{
			this.cameraParent.SetActive(false);
		}
		if (this.cinemachineCamera != null)
		{
			this.cinemachineFollow = this.cinemachineCamera.GetCinemachineComponent<Cinemachine3rdPersonFollow>();
			this.baseCameraRadius = this.cinemachineFollow.CameraRadius;
			this.baseFollowDistance = this.cinemachineFollow.CameraDistance;
			this.baseVerticalArmLength = this.cinemachineFollow.VerticalArmLength;
			this.baseShoulderOffset = this.cinemachineFollow.ShoulderOffset;
		}
	}

	// Token: 0x06001184 RID: 4484 RVA: 0x0005C3A8 File Offset: 0x0005A5A8
	private void LateUpdate()
	{
		if (this.cinemachineFollow != null)
		{
			float scale = Player.Instance.scale;
			this.cinemachineFollow.CameraRadius = this.baseCameraRadius * scale;
			this.cinemachineFollow.CameraDistance = this.baseFollowDistance * scale;
			this.cinemachineFollow.VerticalArmLength = this.baseVerticalArmLength * scale;
			this.cinemachineFollow.ShoulderOffset = this.baseShoulderOffset * scale;
		}
	}

	// Token: 0x040013DA RID: 5082
	public Transform playerHead;

	// Token: 0x040013DB RID: 5083
	public GameObject cameraParent;

	// Token: 0x040013DC RID: 5084
	public Vector3 headOffset;

	// Token: 0x040013DD RID: 5085
	public Vector3 eulerRotationOffset;

	// Token: 0x040013DE RID: 5086
	public CinemachineVirtualCamera cinemachineCamera;

	// Token: 0x040013DF RID: 5087
	private Cinemachine3rdPersonFollow cinemachineFollow;

	// Token: 0x040013E0 RID: 5088
	private float baseCameraRadius = 0.2f;

	// Token: 0x040013E1 RID: 5089
	private float baseFollowDistance = 2f;

	// Token: 0x040013E2 RID: 5090
	private float baseVerticalArmLength = 0.4f;

	// Token: 0x040013E3 RID: 5091
	private Vector3 baseShoulderOffset = new Vector3(0.5f, -0.4f, 0f);
}
