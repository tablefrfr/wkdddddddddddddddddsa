﻿using System;
using UnityEngine;

// Token: 0x0200036F RID: 879
public class GorillaEyeExpressions : MonoBehaviour
{
	// Token: 0x060013FB RID: 5115 RVA: 0x00069345 File Offset: 0x00067545
	private void Start()
	{
		this.loudness = base.GetComponent<GorillaSpeakerLoudness>();
	}

	// Token: 0x060013FC RID: 5116 RVA: 0x00069353 File Offset: 0x00067553
	public void InvokeUpdate()
	{
		this.CheckEyeEffects();
		this.UpdateEyeExpression();
	}

	// Token: 0x060013FD RID: 5117 RVA: 0x00069364 File Offset: 0x00067564
	private void CheckEyeEffects()
	{
		if (this.loudness.IsSpeaking && this.loudness.Loudness > this.screamVolume)
		{
			this.IsEyeExpressionOverriden = true;
			this.overrideDuration = this.screamDuration;
			this.overrideUV = this.ScreamUV;
			return;
		}
		if (this.IsEyeExpressionOverriden)
		{
			this.overrideDuration -= Time.deltaTime;
			if (this.overrideDuration < 0f)
			{
				this.IsEyeExpressionOverriden = false;
			}
		}
	}

	// Token: 0x060013FE RID: 5118 RVA: 0x000693E0 File Offset: 0x000675E0
	private void UpdateEyeExpression()
	{
		Material material = this.targetFace.GetComponent<Renderer>().material;
		material.SetFloat(this._EyeOverrideUV, this.IsEyeExpressionOverriden ? 1f : 0f);
		material.SetVector(this._EyeOverrideUVTransform, new Vector4(1f, 1f, this.overrideUV.x, this.overrideUV.y));
	}

	// Token: 0x040016D2 RID: 5842
	public GameObject targetFace;

	// Token: 0x040016D3 RID: 5843
	[Space]
	[SerializeField]
	private float screamVolume = 0.2f;

	// Token: 0x040016D4 RID: 5844
	[SerializeField]
	private float screamDuration = 0.5f;

	// Token: 0x040016D5 RID: 5845
	[SerializeField]
	private Vector2 ScreamUV = new Vector2(0.8f, 0f);

	// Token: 0x040016D6 RID: 5846
	private GorillaSpeakerLoudness loudness;

	// Token: 0x040016D7 RID: 5847
	private bool IsEyeExpressionOverriden;

	// Token: 0x040016D8 RID: 5848
	private float overrideDuration;

	// Token: 0x040016D9 RID: 5849
	private Vector2 overrideUV;

	// Token: 0x040016DA RID: 5850
	private ShaderHashId _EyeOverrideUV = "_EyeOverrideUV";

	// Token: 0x040016DB RID: 5851
	private ShaderHashId _EyeOverrideUVTransform = "_EyeOverrideUVTransform";
}
