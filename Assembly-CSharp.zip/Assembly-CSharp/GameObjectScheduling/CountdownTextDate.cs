﻿using System;
using UnityEngine;

namespace GameObjectScheduling
{
	// Token: 0x020007C9 RID: 1993
	[CreateAssetMenu(fileName = "New CountdownText Date", menuName = "Game Object Scheduling/CountdownText Date", order = 1)]
	public class CountdownTextDate : ScriptableObject
	{
		// Token: 0x040032C4 RID: 12996
		public string CountdownTo = "1/1/0001 00:00:00";

		// Token: 0x040032C5 RID: 12997
		public string FormatString = "";

		// Token: 0x040032C6 RID: 12998
		public int DaysThreshold = 365;
	}
}
