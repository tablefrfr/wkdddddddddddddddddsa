﻿using System;
using UnityEngine;

// Token: 0x0200037D RID: 893
public class GorillaIK : MonoBehaviour
{
	// Token: 0x0600147B RID: 5243 RVA: 0x0006B824 File Offset: 0x00069A24
	private void Awake()
	{
		if (Application.isPlaying && !this.testInEditor)
		{
			this.dU = (this.leftUpperArm.position - this.leftLowerArm.position).magnitude;
			this.dL = (this.leftLowerArm.position - this.leftHand.position).magnitude;
			this.dMax = this.dU + this.dL - this.eps;
			this.initialUpperLeft = this.leftUpperArm.localRotation;
			this.initialLowerLeft = this.leftLowerArm.localRotation;
			this.initialUpperRight = this.rightUpperArm.localRotation;
			this.initialLowerRight = this.rightLowerArm.localRotation;
		}
	}

	// Token: 0x0600147C RID: 5244 RVA: 0x0006B8F6 File Offset: 0x00069AF6
	private void OnEnable()
	{
		GorillaIKMgr.Instance.RegisterIK(this);
	}

	// Token: 0x0600147D RID: 5245 RVA: 0x0006B903 File Offset: 0x00069B03
	private void OnDisable()
	{
		GorillaIKMgr.Instance.DeregisterIK(this);
	}

	// Token: 0x0600147E RID: 5246 RVA: 0x0006B910 File Offset: 0x00069B10
	private void ArmIK(ref Transform upperArm, ref Transform lowerArm, ref Transform hand, Quaternion initRotUpper, Quaternion initRotLower, Transform target)
	{
		upperArm.localRotation = initRotUpper;
		lowerArm.localRotation = initRotLower;
		float num = Mathf.Clamp((target.position - upperArm.position).magnitude, this.eps, this.dMax);
		float num2 = Mathf.Acos(Mathf.Clamp(Vector3.Dot((hand.position - upperArm.position).normalized, (lowerArm.position - upperArm.position).normalized), -1f, 1f));
		float num3 = Mathf.Acos(Mathf.Clamp(Vector3.Dot((upperArm.position - lowerArm.position).normalized, (hand.position - lowerArm.position).normalized), -1f, 1f));
		float num4 = Mathf.Acos(Mathf.Clamp(Vector3.Dot((hand.position - upperArm.position).normalized, (target.position - upperArm.position).normalized), -1f, 1f));
		float num5 = Mathf.Acos(Mathf.Clamp((this.dL * this.dL - this.dU * this.dU - num * num) / (-2f * this.dU * num), -1f, 1f));
		float num6 = Mathf.Acos(Mathf.Clamp((num * num - this.dU * this.dU - this.dL * this.dL) / (-2f * this.dU * this.dL), -1f, 1f));
		Vector3 normalized = Vector3.Cross(hand.position - upperArm.position, lowerArm.position - upperArm.position).normalized;
		Vector3 normalized2 = Vector3.Cross(hand.position - upperArm.position, target.position - upperArm.position).normalized;
		Quaternion rhs = Quaternion.AngleAxis((num5 - num2) * 57.29578f, Quaternion.Inverse(upperArm.rotation) * normalized);
		Quaternion rhs2 = Quaternion.AngleAxis((num6 - num3) * 57.29578f, Quaternion.Inverse(lowerArm.rotation) * normalized);
		Quaternion rhs3 = Quaternion.AngleAxis(num4 * 57.29578f, Quaternion.Inverse(upperArm.rotation) * normalized2);
		this.newRotationUpper = upperArm.localRotation * rhs3 * rhs;
		this.newRotationLower = lowerArm.localRotation * rhs2;
		upperArm.localRotation = this.newRotationUpper;
		lowerArm.localRotation = this.newRotationLower;
		hand.rotation = target.rotation;
	}

	// Token: 0x04001744 RID: 5956
	public Transform headBone;

	// Token: 0x04001745 RID: 5957
	public Transform leftUpperArm;

	// Token: 0x04001746 RID: 5958
	public Transform leftLowerArm;

	// Token: 0x04001747 RID: 5959
	public Transform leftHand;

	// Token: 0x04001748 RID: 5960
	public Transform rightUpperArm;

	// Token: 0x04001749 RID: 5961
	public Transform rightLowerArm;

	// Token: 0x0400174A RID: 5962
	public Transform rightHand;

	// Token: 0x0400174B RID: 5963
	public Transform targetLeft;

	// Token: 0x0400174C RID: 5964
	public Transform targetRight;

	// Token: 0x0400174D RID: 5965
	public Transform targetHead;

	// Token: 0x0400174E RID: 5966
	public Quaternion initialUpperLeft;

	// Token: 0x0400174F RID: 5967
	public Quaternion initialLowerLeft;

	// Token: 0x04001750 RID: 5968
	public Quaternion initialUpperRight;

	// Token: 0x04001751 RID: 5969
	public Quaternion initialLowerRight;

	// Token: 0x04001752 RID: 5970
	public Quaternion newRotationUpper;

	// Token: 0x04001753 RID: 5971
	public Quaternion newRotationLower;

	// Token: 0x04001754 RID: 5972
	public float dU;

	// Token: 0x04001755 RID: 5973
	public float dL;

	// Token: 0x04001756 RID: 5974
	public float dMax;

	// Token: 0x04001757 RID: 5975
	public bool testInEditor;

	// Token: 0x04001758 RID: 5976
	public bool reset;

	// Token: 0x04001759 RID: 5977
	public bool testDefineRot;

	// Token: 0x0400175A RID: 5978
	public bool moveOnce;

	// Token: 0x0400175B RID: 5979
	public float eps;

	// Token: 0x0400175C RID: 5980
	public float upperArmAngle;

	// Token: 0x0400175D RID: 5981
	public float elbowAngle;
}
