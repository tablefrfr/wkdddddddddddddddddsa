﻿using System;
using UnityEngine;

// Token: 0x0200003B RID: 59
public class GhostHuntingController : MonoBehaviour
{
	// Token: 0x0600011D RID: 285 RVA: 0x00003051 File Offset: 0x00001251
	private void Start()
	{
	}

	// Token: 0x0600011E RID: 286 RVA: 0x00003051 File Offset: 0x00001251
	private void Update()
	{
	}
}
