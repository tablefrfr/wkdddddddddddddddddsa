﻿using System;
using Photon.Pun;
using UnityEngine;

// Token: 0x0200040E RID: 1038
public class GorillaFireball : GorillaThrowable, IPunInstantiateMagicCallback
{
	// Token: 0x06001827 RID: 6183 RVA: 0x0007B972 File Offset: 0x00079B72
	public override void Start()
	{
		base.Start();
		this.canExplode = false;
		this.explosionStartTime = 0f;
	}

	// Token: 0x06001828 RID: 6184 RVA: 0x0007B98C File Offset: 0x00079B8C
	private void Update()
	{
		if (this.explosionStartTime != 0f)
		{
			float num = (Time.time - this.explosionStartTime) / this.totalExplosionTime * (this.maxExplosionScale - 0.25f) + 0.25f;
			base.gameObject.transform.localScale = new Vector3(num, num, num);
			if (base.photonView.IsMine && Time.time > this.explosionStartTime + this.totalExplosionTime)
			{
				PhotonNetwork.Destroy(PhotonView.Get(this));
			}
		}
	}

	// Token: 0x06001829 RID: 6185 RVA: 0x0007BA14 File Offset: 0x00079C14
	public override void LateUpdate()
	{
		base.LateUpdate();
		if (this.rigidbody.useGravity)
		{
			this.rigidbody.AddForce(Physics.gravity * -this.gravityStrength * this.rigidbody.mass);
		}
	}

	// Token: 0x0600182A RID: 6186 RVA: 0x0007BA60 File Offset: 0x00079C60
	public override void ThrowThisThingo()
	{
		base.ThrowThisThingo();
		this.canExplode = true;
	}

	// Token: 0x0600182B RID: 6187 RVA: 0x0007BA6F File Offset: 0x00079C6F
	private new void OnCollisionEnter(Collision collision)
	{
		if (base.photonView.IsMine && this.canExplode)
		{
			base.photonView.RPC("Explode", RpcTarget.All, null);
		}
	}

	// Token: 0x0600182C RID: 6188 RVA: 0x0007BA98 File Offset: 0x00079C98
	public void LocalExplode()
	{
		this.rigidbody.isKinematic = true;
		this.canExplode = false;
		this.explosionStartTime = Time.time;
	}

	// Token: 0x0600182D RID: 6189 RVA: 0x0007BAB8 File Offset: 0x00079CB8
	public void OnPhotonInstantiate(PhotonMessageInfo info)
	{
		if (base.photonView.IsMine)
		{
			if ((bool)base.photonView.InstantiationData[0])
			{
				base.transform.parent = GorillaPlaySpace.Instance.myVRRig.leftHandTransform;
				return;
			}
			base.transform.parent = GorillaPlaySpace.Instance.myVRRig.rightHandTransform;
		}
	}

	// Token: 0x0600182E RID: 6190 RVA: 0x0007BB1B File Offset: 0x00079D1B
	[PunRPC]
	public void Explode()
	{
		this.LocalExplode();
	}

	// Token: 0x04001BC8 RID: 7112
	public float maxExplosionScale;

	// Token: 0x04001BC9 RID: 7113
	public float totalExplosionTime;

	// Token: 0x04001BCA RID: 7114
	public float gravityStrength;

	// Token: 0x04001BCB RID: 7115
	private bool canExplode;

	// Token: 0x04001BCC RID: 7116
	private float explosionStartTime;
}
