﻿using System;

// Token: 0x020000A4 RID: 164
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public class DevInspectorShow : Attribute
{
}
