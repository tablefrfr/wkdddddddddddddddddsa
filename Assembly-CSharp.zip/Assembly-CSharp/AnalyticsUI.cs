﻿using System;
using UnityEngine;

// Token: 0x020001A0 RID: 416
public class AnalyticsUI : MonoBehaviour
{
}
