﻿using System;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000039 RID: 57
public class BlinkingText : MonoBehaviour
{
	// Token: 0x06000113 RID: 275 RVA: 0x00009B3C File Offset: 0x00007D3C
	private void Awake()
	{
		this.textComponent = base.GetComponent<Text>();
	}

	// Token: 0x06000114 RID: 276 RVA: 0x00009B4C File Offset: 0x00007D4C
	private void Update()
	{
		if (this.isOn && Time.time > this.lastTime + this.cycleTime * this.dutyCycle)
		{
			this.isOn = false;
			this.textComponent.enabled = false;
			return;
		}
		if (!this.isOn && Time.time > this.lastTime + this.cycleTime)
		{
			this.lastTime = Time.time;
			this.isOn = true;
			this.textComponent.enabled = true;
		}
	}

	// Token: 0x04000186 RID: 390
	public float cycleTime;

	// Token: 0x04000187 RID: 391
	public float dutyCycle;

	// Token: 0x04000188 RID: 392
	private bool isOn;

	// Token: 0x04000189 RID: 393
	private float lastTime;

	// Token: 0x0400018A RID: 394
	private Text textComponent;
}
