﻿using System;

namespace BuildSafe
{
	// Token: 0x02000620 RID: 1568
	public static class DevUtils
	{
	}
}
