﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

// Token: 0x0200007B RID: 123
public class ApplyMaterialProperty : MonoBehaviour
{
	// Token: 0x06000298 RID: 664 RVA: 0x000115EE File Offset: 0x0000F7EE
	private void Start()
	{
		if (this.applyOnStart)
		{
			this.Apply();
		}
	}

	// Token: 0x06000299 RID: 665 RVA: 0x00011600 File Offset: 0x0000F800
	public void Apply()
	{
		if (!this._renderer)
		{
			this._renderer = base.GetComponent<Renderer>();
		}
		ApplyMaterialProperty.ApplyMode applyMode = this.mode;
		if (applyMode == ApplyMaterialProperty.ApplyMode.MaterialInstance)
		{
			this.ApplyMaterialInstance();
			return;
		}
		if (applyMode != ApplyMaterialProperty.ApplyMode.MaterialPropertyBlock)
		{
			return;
		}
		this.ApplyMaterialPropertyBlock();
	}

	// Token: 0x0600029A RID: 666 RVA: 0x00011642 File Offset: 0x0000F842
	public void SetColor(string propertyName, Color color)
	{
		ApplyMaterialProperty.CustomMaterialData orCreateData = this.GetOrCreateData(propertyName);
		orCreateData.dataType = ApplyMaterialProperty.SuportedTypes.Color;
		orCreateData.color = color;
	}

	// Token: 0x0600029B RID: 667 RVA: 0x00011658 File Offset: 0x0000F858
	public void SetFloat(string propertyName, float value)
	{
		ApplyMaterialProperty.CustomMaterialData orCreateData = this.GetOrCreateData(propertyName);
		orCreateData.dataType = ApplyMaterialProperty.SuportedTypes.Float;
		orCreateData.@float = value;
	}

	// Token: 0x0600029C RID: 668 RVA: 0x00011670 File Offset: 0x0000F870
	private ApplyMaterialProperty.CustomMaterialData GetOrCreateData(string propertyName)
	{
		for (int i = 0; i < this.customData.Count; i++)
		{
			ApplyMaterialProperty.CustomMaterialData customMaterialData = this.customData[i];
			if (customMaterialData.name == propertyName)
			{
				return customMaterialData;
			}
		}
		ApplyMaterialProperty.CustomMaterialData customMaterialData2 = new ApplyMaterialProperty.CustomMaterialData
		{
			name = propertyName
		};
		this.customData.Add(customMaterialData2);
		return customMaterialData2;
	}

	// Token: 0x0600029D RID: 669 RVA: 0x000116CC File Offset: 0x0000F8CC
	private void ApplyMaterialInstance()
	{
		if (!this._instance)
		{
			this._instance = base.GetComponent<MaterialInstance>();
			if (this._instance == null)
			{
				this._instance = base.gameObject.AddComponent<MaterialInstance>();
			}
		}
		Material material = this.targetMaterial = this._instance.Material;
		for (int i = 0; i < this.customData.Count; i++)
		{
			ApplyMaterialProperty.CustomMaterialData customMaterialData = this.customData[i];
			switch (customMaterialData.dataType)
			{
			case ApplyMaterialProperty.SuportedTypes.Color:
				material.SetColor(customMaterialData.name, customMaterialData.color);
				break;
			case ApplyMaterialProperty.SuportedTypes.Float:
				material.SetFloat(customMaterialData.name, customMaterialData.@float);
				break;
			case ApplyMaterialProperty.SuportedTypes.Vector2:
				material.SetVector(customMaterialData.name, customMaterialData.vector2);
				break;
			case ApplyMaterialProperty.SuportedTypes.Vector3:
				material.SetVector(customMaterialData.name, customMaterialData.vector3);
				break;
			case ApplyMaterialProperty.SuportedTypes.Vector4:
				material.SetVector(customMaterialData.name, customMaterialData.vector4);
				break;
			case ApplyMaterialProperty.SuportedTypes.Texture2D:
				material.SetTexture(customMaterialData.name, customMaterialData.texture2D);
				break;
			}
		}
		this._renderer.SetPropertyBlock(this._block);
	}

	// Token: 0x0600029E RID: 670 RVA: 0x0001180C File Offset: 0x0000FA0C
	private void ApplyMaterialPropertyBlock()
	{
		if (this._block == null)
		{
			this._block = new MaterialPropertyBlock();
		}
		this._renderer.GetPropertyBlock(this._block);
		for (int i = 0; i < this.customData.Count; i++)
		{
			ApplyMaterialProperty.CustomMaterialData customMaterialData = this.customData[i];
			switch (customMaterialData.dataType)
			{
			case ApplyMaterialProperty.SuportedTypes.Color:
				this._block.SetColor(customMaterialData.name, customMaterialData.color);
				break;
			case ApplyMaterialProperty.SuportedTypes.Float:
				this._block.SetFloat(customMaterialData.name, customMaterialData.@float);
				break;
			case ApplyMaterialProperty.SuportedTypes.Vector2:
				this._block.SetVector(customMaterialData.name, customMaterialData.vector2);
				break;
			case ApplyMaterialProperty.SuportedTypes.Vector3:
				this._block.SetVector(customMaterialData.name, customMaterialData.vector3);
				break;
			case ApplyMaterialProperty.SuportedTypes.Vector4:
				this._block.SetVector(customMaterialData.name, customMaterialData.vector4);
				break;
			case ApplyMaterialProperty.SuportedTypes.Texture2D:
				this._block.SetTexture(customMaterialData.name, customMaterialData.texture2D);
				break;
			}
		}
		this._renderer.SetPropertyBlock(this._block);
	}

	// Token: 0x04000387 RID: 903
	public ApplyMaterialProperty.ApplyMode mode;

	// Token: 0x04000388 RID: 904
	[FormerlySerializedAs("materialToApplyBlock")]
	public Material targetMaterial;

	// Token: 0x04000389 RID: 905
	[SerializeField]
	private MaterialInstance _instance;

	// Token: 0x0400038A RID: 906
	[SerializeField]
	private Renderer _renderer;

	// Token: 0x0400038B RID: 907
	public List<ApplyMaterialProperty.CustomMaterialData> customData;

	// Token: 0x0400038C RID: 908
	[SerializeField]
	private bool applyOnStart;

	// Token: 0x0400038D RID: 909
	[NonSerialized]
	private MaterialPropertyBlock _block;

	// Token: 0x0200007C RID: 124
	public enum ApplyMode
	{
		// Token: 0x0400038F RID: 911
		MaterialInstance,
		// Token: 0x04000390 RID: 912
		MaterialPropertyBlock
	}

	// Token: 0x0200007D RID: 125
	public enum SuportedTypes
	{
		// Token: 0x04000392 RID: 914
		Color,
		// Token: 0x04000393 RID: 915
		Float,
		// Token: 0x04000394 RID: 916
		Vector2,
		// Token: 0x04000395 RID: 917
		Vector3,
		// Token: 0x04000396 RID: 918
		Vector4,
		// Token: 0x04000397 RID: 919
		Texture2D
	}

	// Token: 0x0200007E RID: 126
	[Serializable]
	public class CustomMaterialData
	{
		// Token: 0x060002A0 RID: 672 RVA: 0x00011944 File Offset: 0x0000FB44
		public override int GetHashCode()
		{
			return new ValueTuple<string, ApplyMaterialProperty.SuportedTypes, Color, float, Vector2, Vector3, Vector4, ValueTuple<Texture2D>>(this.name, this.dataType, this.color, this.@float, this.vector2, this.vector3, this.vector4, new ValueTuple<Texture2D>(this.texture2D)).GetHashCode();
		}

		// Token: 0x04000398 RID: 920
		public string name;

		// Token: 0x04000399 RID: 921
		public ApplyMaterialProperty.SuportedTypes dataType;

		// Token: 0x0400039A RID: 922
		public Color color;

		// Token: 0x0400039B RID: 923
		public float @float;

		// Token: 0x0400039C RID: 924
		public Vector2 vector2;

		// Token: 0x0400039D RID: 925
		public Vector3 vector3;

		// Token: 0x0400039E RID: 926
		public Vector4 vector4;

		// Token: 0x0400039F RID: 927
		public Texture2D texture2D;
	}
}
