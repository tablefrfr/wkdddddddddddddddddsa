﻿using System;
using UnityEngine;

namespace emotitron.Compression
{
	// Token: 0x020007B9 RID: 1977
	[Serializable]
	public abstract class LiteCrusher
	{
		// Token: 0x06002FCD RID: 12237 RVA: 0x000EB2EC File Offset: 0x000E94EC
		public static int GetBitsForMaxValue(uint maxvalue)
		{
			for (int i = 0; i < 32; i++)
			{
				if (maxvalue >> i == 0U)
				{
					return i;
				}
			}
			return 32;
		}

		// Token: 0x0400326A RID: 12906
		[SerializeField]
		protected int bits;
	}
}
