﻿using System;
using System.Globalization;

namespace emotitron.Compression.HalfFloat
{
	// Token: 0x020007C1 RID: 1985
	[Serializable]
	public struct Half : IConvertible, IComparable, IComparable<Half>, IEquatable<Half>, IFormattable
	{
		// Token: 0x06003008 RID: 12296 RVA: 0x000EBCDA File Offset: 0x000E9EDA
		public Half(float value)
		{
			this.value = HalfUtilities.Pack(value);
		}

		// Token: 0x1700053D RID: 1341
		// (get) Token: 0x06003009 RID: 12297 RVA: 0x000EBCE8 File Offset: 0x000E9EE8
		public ushort RawValue
		{
			get
			{
				return this.value;
			}
		}

		// Token: 0x0600300A RID: 12298 RVA: 0x000EBCF0 File Offset: 0x000E9EF0
		public static float[] ConvertToFloat(Half[] values)
		{
			float[] array = new float[values.Length];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = HalfUtilities.Unpack(values[i].RawValue);
			}
			return array;
		}

		// Token: 0x0600300B RID: 12299 RVA: 0x000EBD2C File Offset: 0x000E9F2C
		public static Half[] ConvertToHalf(float[] values)
		{
			Half[] array = new Half[values.Length];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = new Half(values[i]);
			}
			return array;
		}

		// Token: 0x0600300C RID: 12300 RVA: 0x000EBD60 File Offset: 0x000E9F60
		public static bool IsInfinity(Half half)
		{
			return half == Half.PositiveInfinity || half == Half.NegativeInfinity;
		}

		// Token: 0x0600300D RID: 12301 RVA: 0x000EBD7C File Offset: 0x000E9F7C
		public static bool IsNaN(Half half)
		{
			return half == Half.NaN;
		}

		// Token: 0x0600300E RID: 12302 RVA: 0x000EBD89 File Offset: 0x000E9F89
		public static bool IsNegativeInfinity(Half half)
		{
			return half == Half.NegativeInfinity;
		}

		// Token: 0x0600300F RID: 12303 RVA: 0x000EBD96 File Offset: 0x000E9F96
		public static bool IsPositiveInfinity(Half half)
		{
			return half == Half.PositiveInfinity;
		}

		// Token: 0x06003010 RID: 12304 RVA: 0x000EBDA3 File Offset: 0x000E9FA3
		public static bool operator <(Half left, Half right)
		{
			return left < right;
		}

		// Token: 0x06003011 RID: 12305 RVA: 0x000EBDB5 File Offset: 0x000E9FB5
		public static bool operator >(Half left, Half right)
		{
			return left > right;
		}

		// Token: 0x06003012 RID: 12306 RVA: 0x000EBDC7 File Offset: 0x000E9FC7
		public static bool operator <=(Half left, Half right)
		{
			return left <= right;
		}

		// Token: 0x06003013 RID: 12307 RVA: 0x000EBDDC File Offset: 0x000E9FDC
		public static bool operator >=(Half left, Half right)
		{
			return left >= right;
		}

		// Token: 0x06003014 RID: 12308 RVA: 0x000EBDF1 File Offset: 0x000E9FF1
		public static bool operator ==(Half left, Half right)
		{
			return left.Equals(right);
		}

		// Token: 0x06003015 RID: 12309 RVA: 0x000EBDFB File Offset: 0x000E9FFB
		public static bool operator !=(Half left, Half right)
		{
			return !left.Equals(right);
		}

		// Token: 0x06003016 RID: 12310 RVA: 0x000EBE08 File Offset: 0x000EA008
		public static explicit operator Half(float value)
		{
			return new Half(value);
		}

		// Token: 0x06003017 RID: 12311 RVA: 0x000EBE10 File Offset: 0x000EA010
		public static implicit operator float(Half value)
		{
			return HalfUtilities.Unpack(value.value);
		}

		// Token: 0x06003018 RID: 12312 RVA: 0x000EBE20 File Offset: 0x000EA020
		public override string ToString()
		{
			return string.Format(CultureInfo.CurrentCulture, this.ToString(), Array.Empty<object>());
		}

		// Token: 0x06003019 RID: 12313 RVA: 0x000EBE50 File Offset: 0x000EA050
		public string ToString(string format)
		{
			if (format == null)
			{
				return this.ToString();
			}
			return string.Format(CultureInfo.CurrentCulture, this.ToString(format, CultureInfo.CurrentCulture), Array.Empty<object>());
		}

		// Token: 0x0600301A RID: 12314 RVA: 0x000EBE98 File Offset: 0x000EA098
		public string ToString(IFormatProvider formatProvider)
		{
			return string.Format(formatProvider, this.ToString(), Array.Empty<object>());
		}

		// Token: 0x0600301B RID: 12315 RVA: 0x000EBEC4 File Offset: 0x000EA0C4
		public string ToString(string format, IFormatProvider formatProvider)
		{
			if (format == null)
			{
				this.ToString(formatProvider);
			}
			return string.Format(formatProvider, this.ToString(format, formatProvider), Array.Empty<object>());
		}

		// Token: 0x0600301C RID: 12316 RVA: 0x000EBEFD File Offset: 0x000EA0FD
		public override int GetHashCode()
		{
			return (int)(this.value * 3 / 2 ^ this.value);
		}

		// Token: 0x0600301D RID: 12317 RVA: 0x000EBF10 File Offset: 0x000EA110
		public int CompareTo(Half value)
		{
			if (this < value)
			{
				return -1;
			}
			if (this > value)
			{
				return 1;
			}
			if (this != value)
			{
				if (!Half.IsNaN(this))
				{
					return 1;
				}
				if (!Half.IsNaN(value))
				{
					return -1;
				}
			}
			return 0;
		}

		// Token: 0x0600301E RID: 12318 RVA: 0x000EBF68 File Offset: 0x000EA168
		public int CompareTo(object value)
		{
			if (value == null)
			{
				return 1;
			}
			if (!(value is Half))
			{
				throw new ArgumentException("The argument value must be a SlimMath.Half.");
			}
			Half half = (Half)value;
			if (this < half)
			{
				return -1;
			}
			if (this > half)
			{
				return 1;
			}
			if (this != half)
			{
				if (!Half.IsNaN(this))
				{
					return 1;
				}
				if (!Half.IsNaN(half))
				{
					return -1;
				}
			}
			return 0;
		}

		// Token: 0x0600301F RID: 12319 RVA: 0x000EBFDC File Offset: 0x000EA1DC
		public static bool Equals(ref Half value1, ref Half value2)
		{
			return value1.value == value2.value;
		}

		// Token: 0x06003020 RID: 12320 RVA: 0x000EBFEC File Offset: 0x000EA1EC
		public bool Equals(Half other)
		{
			return other.value == this.value;
		}

		// Token: 0x06003021 RID: 12321 RVA: 0x000EBFFC File Offset: 0x000EA1FC
		public override bool Equals(object obj)
		{
			return obj != null && !(obj.GetType() != base.GetType()) && this.Equals((Half)obj);
		}

		// Token: 0x06003022 RID: 12322 RVA: 0x000EC02E File Offset: 0x000EA22E
		public TypeCode GetTypeCode()
		{
			return Type.GetTypeCode(typeof(Half));
		}

		// Token: 0x06003023 RID: 12323 RVA: 0x000EC03F File Offset: 0x000EA23F
		bool IConvertible.ToBoolean(IFormatProvider provider)
		{
			return Convert.ToBoolean(this);
		}

		// Token: 0x06003024 RID: 12324 RVA: 0x000EC051 File Offset: 0x000EA251
		byte IConvertible.ToByte(IFormatProvider provider)
		{
			return Convert.ToByte(this);
		}

		// Token: 0x06003025 RID: 12325 RVA: 0x000EC063 File Offset: 0x000EA263
		char IConvertible.ToChar(IFormatProvider provider)
		{
			throw new InvalidCastException("Invalid cast from SlimMath.Half to System.Char.");
		}

		// Token: 0x06003026 RID: 12326 RVA: 0x000EC06F File Offset: 0x000EA26F
		DateTime IConvertible.ToDateTime(IFormatProvider provider)
		{
			throw new InvalidCastException("Invalid cast from SlimMath.Half to System.DateTime.");
		}

		// Token: 0x06003027 RID: 12327 RVA: 0x000EC07B File Offset: 0x000EA27B
		decimal IConvertible.ToDecimal(IFormatProvider provider)
		{
			return Convert.ToDecimal(this);
		}

		// Token: 0x06003028 RID: 12328 RVA: 0x000EC08D File Offset: 0x000EA28D
		double IConvertible.ToDouble(IFormatProvider provider)
		{
			return Convert.ToDouble(this);
		}

		// Token: 0x06003029 RID: 12329 RVA: 0x000EC09F File Offset: 0x000EA29F
		short IConvertible.ToInt16(IFormatProvider provider)
		{
			return Convert.ToInt16(this);
		}

		// Token: 0x0600302A RID: 12330 RVA: 0x000EC0B1 File Offset: 0x000EA2B1
		int IConvertible.ToInt32(IFormatProvider provider)
		{
			return Convert.ToInt32(this);
		}

		// Token: 0x0600302B RID: 12331 RVA: 0x000EC0C3 File Offset: 0x000EA2C3
		long IConvertible.ToInt64(IFormatProvider provider)
		{
			return Convert.ToInt64(this);
		}

		// Token: 0x0600302C RID: 12332 RVA: 0x000EC0D5 File Offset: 0x000EA2D5
		sbyte IConvertible.ToSByte(IFormatProvider provider)
		{
			return Convert.ToSByte(this);
		}

		// Token: 0x0600302D RID: 12333 RVA: 0x000EC0E7 File Offset: 0x000EA2E7
		float IConvertible.ToSingle(IFormatProvider provider)
		{
			return this;
		}

		// Token: 0x0600302E RID: 12334 RVA: 0x000EC0F4 File Offset: 0x000EA2F4
		object IConvertible.ToType(Type type, IFormatProvider provider)
		{
			return ((IConvertible)this).ToType(type, provider);
		}

		// Token: 0x0600302F RID: 12335 RVA: 0x000EC10E File Offset: 0x000EA30E
		ushort IConvertible.ToUInt16(IFormatProvider provider)
		{
			return Convert.ToUInt16(this);
		}

		// Token: 0x06003030 RID: 12336 RVA: 0x000EC120 File Offset: 0x000EA320
		uint IConvertible.ToUInt32(IFormatProvider provider)
		{
			return Convert.ToUInt32(this);
		}

		// Token: 0x06003031 RID: 12337 RVA: 0x000EC132 File Offset: 0x000EA332
		ulong IConvertible.ToUInt64(IFormatProvider provider)
		{
			return Convert.ToUInt64(this);
		}

		// Token: 0x0400329C RID: 12956
		private ushort value;

		// Token: 0x0400329D RID: 12957
		public const int PrecisionDigits = 3;

		// Token: 0x0400329E RID: 12958
		public const int MantissaBits = 11;

		// Token: 0x0400329F RID: 12959
		public const int MaximumDecimalExponent = 4;

		// Token: 0x040032A0 RID: 12960
		public const int MaximumBinaryExponent = 15;

		// Token: 0x040032A1 RID: 12961
		public const int MinimumDecimalExponent = -4;

		// Token: 0x040032A2 RID: 12962
		public const int MinimumBinaryExponent = -14;

		// Token: 0x040032A3 RID: 12963
		public const int ExponentRadix = 2;

		// Token: 0x040032A4 RID: 12964
		public const int AdditionRounding = 1;

		// Token: 0x040032A5 RID: 12965
		public static readonly Half Epsilon = new Half(0.0004887581f);

		// Token: 0x040032A6 RID: 12966
		public static readonly Half MaxValue = new Half(65504f);

		// Token: 0x040032A7 RID: 12967
		public static readonly Half MinValue = new Half(6.103516E-05f);

		// Token: 0x040032A8 RID: 12968
		public static readonly Half NaN = new Half(float.NaN);

		// Token: 0x040032A9 RID: 12969
		public static readonly Half NegativeInfinity = new Half(float.NegativeInfinity);

		// Token: 0x040032AA RID: 12970
		public static readonly Half PositiveInfinity = new Half(float.PositiveInfinity);
	}
}
