﻿using System;
using System.Collections.Generic;
using ExitGames.Client.Photon;
using GorillaGameModes;
using GorillaLocomotion;
using GorillaNetworking;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x02000370 RID: 880
public abstract class GorillaGameManager : MonoBehaviour, IInRoomCallbacks, IGorillaSerializeable, ITickSystemTick
{
	// Token: 0x14000020 RID: 32
	// (add) Token: 0x06001400 RID: 5120 RVA: 0x000694B8 File Offset: 0x000676B8
	// (remove) Token: 0x06001401 RID: 5121 RVA: 0x000694EC File Offset: 0x000676EC
	public static event GorillaGameManager.OnTouchDelegate OnTouch;

	// Token: 0x1700020E RID: 526
	// (get) Token: 0x06001402 RID: 5122 RVA: 0x0006951F File Offset: 0x0006771F
	public static GorillaGameManager instance
	{
		get
		{
			return GameMode.ActiveGameMode;
		}
	}

	// Token: 0x1700020F RID: 527
	// (get) Token: 0x06001403 RID: 5123 RVA: 0x00069526 File Offset: 0x00067726
	// (set) Token: 0x06001404 RID: 5124 RVA: 0x0006952E File Offset: 0x0006772E
	bool ITickSystemTick.TickRunning { get; set; }

	// Token: 0x06001405 RID: 5125 RVA: 0x00003051 File Offset: 0x00001251
	public virtual void Awake()
	{
	}

	// Token: 0x06001406 RID: 5126 RVA: 0x00069538 File Offset: 0x00067738
	public virtual void Tick()
	{
		if (this.lastCheck + this.checkCooldown < Time.time)
		{
			this.lastCheck = Time.time;
			if (PhotonNetwork.InRoom && PhotonNetwork.LocalPlayer.IsMasterClient)
			{
				int num = 0;
				if (PhotonNetwork.CurrentRoom.ExpectedUsers != null && PhotonNetwork.CurrentRoom.ExpectedUsers.Length != 0)
				{
					foreach (string key in PhotonNetwork.CurrentRoom.ExpectedUsers)
					{
						float num2;
						if (this.expectedUsersDecay.TryGetValue(key, out num2))
						{
							if (num2 + this.userDecayTime < Time.time)
							{
								num++;
							}
						}
						else
						{
							this.expectedUsersDecay.Add(key, Time.time);
						}
					}
					if (num >= PhotonNetwork.CurrentRoom.ExpectedUsers.Length && num != 0)
					{
						PhotonNetwork.CurrentRoom.ClearExpectedUsers();
					}
				}
			}
			if (PhotonNetwork.IsMasterClient && !this.ValidGameMode())
			{
				GameMode.ChangeGameFromProperty();
				return;
			}
			this.InfrequentUpdate();
		}
	}

	// Token: 0x06001407 RID: 5127 RVA: 0x0006962D File Offset: 0x0006782D
	public virtual void InfrequentUpdate()
	{
		GameMode.RefreshPlayers();
		this.currentPlayerArray = PhotonNetwork.PlayerList;
	}

	// Token: 0x06001408 RID: 5128 RVA: 0x0006963F File Offset: 0x0006783F
	public virtual string GameModeName()
	{
		return "NONE";
	}

	// Token: 0x06001409 RID: 5129 RVA: 0x00003051 File Offset: 0x00001251
	public virtual void ReportTag(Photon.Realtime.Player taggedPlayer, Photon.Realtime.Player taggingPlayer)
	{
	}

	// Token: 0x0600140A RID: 5130 RVA: 0x00003051 File Offset: 0x00001251
	public virtual void HitPlayer(Photon.Realtime.Player player)
	{
	}

	// Token: 0x0600140B RID: 5131 RVA: 0x00002076 File Offset: 0x00000276
	public virtual bool CanAffectPlayer(Photon.Realtime.Player player, bool thisFrame)
	{
		return false;
	}

	// Token: 0x0600140C RID: 5132 RVA: 0x00003051 File Offset: 0x00001251
	public virtual void NewVRRig(Photon.Realtime.Player player, int vrrigPhotonViewID, bool didTutorial)
	{
	}

	// Token: 0x0600140D RID: 5133 RVA: 0x00002076 File Offset: 0x00000276
	public virtual bool LocalCanTag(Photon.Realtime.Player myPlayer, Photon.Realtime.Player otherPlayer)
	{
		return false;
	}

	// Token: 0x0600140E RID: 5134 RVA: 0x00069646 File Offset: 0x00067846
	public virtual PhotonView FindVRRigForPlayer(Photon.Realtime.Player player)
	{
		VRRig vrrig = this.FindPlayerVRRig(player);
		if (vrrig == null)
		{
			return null;
		}
		return vrrig.photonView;
	}

	// Token: 0x0600140F RID: 5135 RVA: 0x0006965A File Offset: 0x0006785A
	public virtual VRRig FindPlayerVRRig(Photon.Realtime.Player player)
	{
		this.returnRig = null;
		this.outContainer = null;
		if (player == null)
		{
			return null;
		}
		if (VRRigCache.Instance.TryGetVrrig(player, out this.outContainer))
		{
			this.returnRig = this.outContainer.Rig;
		}
		return this.returnRig;
	}

	// Token: 0x06001410 RID: 5136 RVA: 0x0006969C File Offset: 0x0006789C
	public static VRRig StaticFindRigForPlayer(Photon.Realtime.Player player)
	{
		VRRig result = null;
		RigContainer rigContainer;
		if (GorillaGameManager.instance != null)
		{
			result = GorillaGameManager.instance.FindPlayerVRRig(player);
		}
		else if (VRRigCache.Instance.TryGetVrrig(player, out rigContainer))
		{
			result = rigContainer.Rig;
		}
		return result;
	}

	// Token: 0x06001411 RID: 5137 RVA: 0x000696DD File Offset: 0x000678DD
	public virtual float[] LocalPlayerSpeed()
	{
		this.playerSpeed[0] = this.slowJumpLimit;
		this.playerSpeed[1] = this.slowJumpMultiplier;
		return this.playerSpeed;
	}

	// Token: 0x06001412 RID: 5138 RVA: 0x00002076 File Offset: 0x00000276
	public virtual int MyMatIndex(Photon.Realtime.Player forPlayer)
	{
		return 0;
	}

	// Token: 0x06001413 RID: 5139 RVA: 0x00069704 File Offset: 0x00067904
	public virtual bool ValidGameMode()
	{
		if (PhotonNetwork.InRoom)
		{
			PhotonNetwork.CurrentRoom.CustomProperties.TryGetValue("gameMode", out this.obj);
			return this.obj.ToString().Contains(this.GameModeName());
		}
		return false;
	}

	// Token: 0x06001414 RID: 5140 RVA: 0x00069750 File Offset: 0x00067950
	public static void OnInstanceReady(Action action)
	{
		GorillaParent.OnReplicatedClientReady(delegate
		{
			if (GorillaGameManager.instance)
			{
				action();
				return;
			}
			GorillaGameManager.onInstanceReady = (Action)Delegate.Combine(GorillaGameManager.onInstanceReady, action);
		});
	}

	// Token: 0x06001415 RID: 5141 RVA: 0x0006976E File Offset: 0x0006796E
	public static void ReplicatedClientReady()
	{
		GorillaGameManager.replicatedClientReady = true;
	}

	// Token: 0x06001416 RID: 5142 RVA: 0x00069776 File Offset: 0x00067976
	public static void OnReplicatedClientReady(Action action)
	{
		if (GorillaGameManager.replicatedClientReady)
		{
			action();
			return;
		}
		GorillaGameManager.onReplicatedClientReady = (Action)Delegate.Combine(GorillaGameManager.onReplicatedClientReady, action);
	}

	// Token: 0x17000210 RID: 528
	// (get) Token: 0x06001417 RID: 5143 RVA: 0x0006979B File Offset: 0x0006799B
	internal GameModeSerializer Serializer
	{
		get
		{
			return this.serializer;
		}
	}

	// Token: 0x06001418 RID: 5144 RVA: 0x000697A3 File Offset: 0x000679A3
	internal virtual void NetworkLinkSetup(GameModeSerializer netSerializer)
	{
		this.serializer = netSerializer;
	}

	// Token: 0x06001419 RID: 5145 RVA: 0x000697AC File Offset: 0x000679AC
	internal virtual void NetworkLinkDestroyed(GameModeSerializer netSerializer)
	{
		if (this.serializer == netSerializer)
		{
			this.serializer = null;
		}
	}

	// Token: 0x0600141A RID: 5146
	public abstract GameModeType GameType();

	// Token: 0x0600141B RID: 5147
	public abstract void OnSerializeRead(PhotonStream stream, PhotonMessageInfo info);

	// Token: 0x0600141C RID: 5148
	public abstract void OnSerializeWrite(PhotonStream stream, PhotonMessageInfo info);

	// Token: 0x0600141D RID: 5149 RVA: 0x00003051 File Offset: 0x00001251
	public virtual void Reset()
	{
	}

	// Token: 0x0600141E RID: 5150 RVA: 0x000697C3 File Offset: 0x000679C3
	public virtual void StartPlaying()
	{
		TickSystem<object>.AddTickCallback(this);
		PhotonNetwork.AddCallbackTarget(this);
		this.currentPlayerArray = PhotonNetwork.PlayerList;
	}

	// Token: 0x0600141F RID: 5151 RVA: 0x000697DC File Offset: 0x000679DC
	public virtual void StopPlaying()
	{
		TickSystem<object>.RemoveTickCallback(this);
		PhotonNetwork.RemoveCallbackTarget(this);
		this.lastCheck = 0f;
	}

	// Token: 0x06001420 RID: 5152 RVA: 0x000697F5 File Offset: 0x000679F5
	public virtual void OnPlayerLeftRoom(Photon.Realtime.Player otherPlayer)
	{
		this.currentPlayerArray = PhotonNetwork.PlayerList;
	}

	// Token: 0x06001421 RID: 5153 RVA: 0x000697F5 File Offset: 0x000679F5
	public virtual void OnPlayerEnteredRoom(Photon.Realtime.Player newPlayer)
	{
		this.currentPlayerArray = PhotonNetwork.PlayerList;
	}

	// Token: 0x06001422 RID: 5154 RVA: 0x00003051 File Offset: 0x00001251
	public virtual void OnMasterClientSwitched(Photon.Realtime.Player newMaster)
	{
	}

	// Token: 0x06001423 RID: 5155 RVA: 0x00003051 File Offset: 0x00001251
	public virtual void OnRoomPropertiesUpdate(Hashtable propertiesThatChanged)
	{
	}

	// Token: 0x06001424 RID: 5156 RVA: 0x00069802 File Offset: 0x00067A02
	public virtual void OnPlayerPropertiesUpdate(Photon.Realtime.Player targetPlayer, Hashtable changedProps)
	{
		if (changedProps.ContainsKey(255))
		{
			GorillaScoreboardTotalUpdater.instance.UpdateActiveScoreboards();
		}
	}

	// Token: 0x06001425 RID: 5157 RVA: 0x0006981C File Offset: 0x00067A1C
	internal static void ForceStopGame_DisconnectAndDestroy()
	{
		Application.Quit();
		NetworkSystem instance = NetworkSystem.Instance;
		if (instance != null)
		{
			instance.ReturnToSinglePlayer();
		}
		Object.DestroyImmediate(PhotonNetworkController.Instance);
		Object.DestroyImmediate(GorillaLocomotion.Player.Instance);
		GameObject[] array = Object.FindObjectsOfType<GameObject>();
		for (int i = 0; i < array.Length; i++)
		{
			Object.Destroy(array[i]);
		}
	}

	// Token: 0x040016DD RID: 5853
	public Room currentRoom;

	// Token: 0x040016DE RID: 5854
	public object obj;

	// Token: 0x040016DF RID: 5855
	public float fastJumpLimit;

	// Token: 0x040016E0 RID: 5856
	public float fastJumpMultiplier;

	// Token: 0x040016E1 RID: 5857
	public float slowJumpLimit;

	// Token: 0x040016E2 RID: 5858
	public float slowJumpMultiplier;

	// Token: 0x040016E3 RID: 5859
	public float lastCheck;

	// Token: 0x040016E4 RID: 5860
	public float checkCooldown = 3f;

	// Token: 0x040016E5 RID: 5861
	public float userDecayTime = 15f;

	// Token: 0x040016E6 RID: 5862
	public Dictionary<string, float> expectedUsersDecay = new Dictionary<string, float>();

	// Token: 0x040016E7 RID: 5863
	public float startingToLookForFriend;

	// Token: 0x040016E8 RID: 5864
	public float timeToSpendLookingForFriend = 10f;

	// Token: 0x040016E9 RID: 5865
	public bool successfullyFoundFriend;

	// Token: 0x040016EA RID: 5866
	public float tagDistanceThreshold = 4f;

	// Token: 0x040016EB RID: 5867
	public bool testAssault;

	// Token: 0x040016EC RID: 5868
	public bool endGameManually;

	// Token: 0x040016ED RID: 5869
	public Photon.Realtime.Player currentMasterClient;

	// Token: 0x040016EE RID: 5870
	public PhotonView returnPhotonView;

	// Token: 0x040016EF RID: 5871
	public VRRig returnRig;

	// Token: 0x040016F0 RID: 5872
	private Photon.Realtime.Player outPlayer;

	// Token: 0x040016F1 RID: 5873
	private int outInt;

	// Token: 0x040016F2 RID: 5874
	private VRRig tempRig;

	// Token: 0x040016F3 RID: 5875
	public Photon.Realtime.Player[] currentPlayerArray;

	// Token: 0x040016F4 RID: 5876
	public float[] playerSpeed = new float[2];

	// Token: 0x040016F5 RID: 5877
	private RigContainer outContainer;

	// Token: 0x040016F7 RID: 5879
	private static Action onInstanceReady;

	// Token: 0x040016F8 RID: 5880
	private static bool replicatedClientReady;

	// Token: 0x040016F9 RID: 5881
	private static Action onReplicatedClientReady;

	// Token: 0x040016FA RID: 5882
	private GameModeSerializer serializer;

	// Token: 0x02000371 RID: 881
	// (Invoke) Token: 0x06001428 RID: 5160
	public delegate void OnTouchDelegate(Photon.Realtime.Player taggedPlayer, Photon.Realtime.Player taggingPlayer);
}
