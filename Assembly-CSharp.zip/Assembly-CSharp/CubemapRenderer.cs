﻿using System;
using UnityEngine;

// Token: 0x02000422 RID: 1058
[DisallowMultipleComponent]
public class CubemapRenderer : MonoBehaviour
{
}
