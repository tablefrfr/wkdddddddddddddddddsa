﻿using System;

namespace GorillaNetworking.Store
{
	// Token: 0x020006EE RID: 1774
	[Serializable]
	public class SpawnedBundle
	{
		// Token: 0x04002D18 RID: 11544
		public string spawnLocationPath;

		// Token: 0x04002D19 RID: 11545
		public BundleStand bundleStand;
	}
}
