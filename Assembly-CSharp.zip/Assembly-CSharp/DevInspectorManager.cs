﻿using System;
using UnityEngine;

// Token: 0x020000A9 RID: 169
public class DevInspectorManager : MonoBehaviour
{
	// Token: 0x1700004D RID: 77
	// (get) Token: 0x06000326 RID: 806 RVA: 0x0001659B File Offset: 0x0001479B
	public static DevInspectorManager instance
	{
		get
		{
			if (DevInspectorManager._instance == null)
			{
				DevInspectorManager._instance = Object.FindObjectOfType<DevInspectorManager>();
			}
			return DevInspectorManager._instance;
		}
	}

	// Token: 0x040004A0 RID: 1184
	private static DevInspectorManager _instance;
}
