﻿using System;
using System.Collections.Generic;

namespace GorillaNetworking
{
	// Token: 0x020006B2 RID: 1714
	[Serializable]
	internal class CreditsSection
	{
		// Token: 0x170004BF RID: 1215
		// (get) Token: 0x0600286D RID: 10349 RVA: 0x000C6B1F File Offset: 0x000C4D1F
		// (set) Token: 0x0600286E RID: 10350 RVA: 0x000C6B27 File Offset: 0x000C4D27
		public string Title { get; set; }

		// Token: 0x170004C0 RID: 1216
		// (get) Token: 0x0600286F RID: 10351 RVA: 0x000C6B30 File Offset: 0x000C4D30
		// (set) Token: 0x06002870 RID: 10352 RVA: 0x000C6B38 File Offset: 0x000C4D38
		public List<string> Entries { get; set; }
	}
}
