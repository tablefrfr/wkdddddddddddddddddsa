﻿using System;
using UnityEngine;

// Token: 0x0200049C RID: 1180
public class DisconnectFromRoom : MonoBehaviour
{
}
