﻿using System;
using UnityEngine;

// Token: 0x020004C0 RID: 1216
public class FlagForLighting : MonoBehaviour
{
	// Token: 0x04001F71 RID: 8049
	public FlagForLighting.TimeOfDay myTimeOfDay;

	// Token: 0x020004C1 RID: 1217
	public enum TimeOfDay
	{
		// Token: 0x04001F73 RID: 8051
		Sunrise,
		// Token: 0x04001F74 RID: 8052
		TenAM,
		// Token: 0x04001F75 RID: 8053
		Noon,
		// Token: 0x04001F76 RID: 8054
		ThreePM,
		// Token: 0x04001F77 RID: 8055
		Sunset,
		// Token: 0x04001F78 RID: 8056
		Night,
		// Token: 0x04001F79 RID: 8057
		RainingDay,
		// Token: 0x04001F7A RID: 8058
		RainingNight,
		// Token: 0x04001F7B RID: 8059
		None
	}
}
