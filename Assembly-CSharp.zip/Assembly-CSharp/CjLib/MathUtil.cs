﻿using System;
using UnityEngine;

namespace CjLib
{
	// Token: 0x020007DE RID: 2014
	public class MathUtil
	{
		// Token: 0x060030DA RID: 12506 RVA: 0x000F3A60 File Offset: 0x000F1C60
		public static float AsinSafe(float x)
		{
			return Mathf.Asin(Mathf.Clamp(x, -1f, 1f));
		}

		// Token: 0x060030DB RID: 12507 RVA: 0x000F3A77 File Offset: 0x000F1C77
		public static float AcosSafe(float x)
		{
			return Mathf.Acos(Mathf.Clamp(x, -1f, 1f));
		}

		// Token: 0x060030DC RID: 12508 RVA: 0x000F3A90 File Offset: 0x000F1C90
		public static float CatmullRom(float p0, float p1, float p2, float p3, float t)
		{
			float num = t * t;
			return 0.5f * (2f * p1 + (-p0 + p2) * t + (2f * p0 - 5f * p1 + 4f * p2 - p3) * num + (-p0 + 3f * p1 - 3f * p2 + p3) * num * t);
		}

		// Token: 0x04003329 RID: 13097
		public static readonly float Pi = 3.1415927f;

		// Token: 0x0400332A RID: 13098
		public static readonly float TwoPi = 6.2831855f;

		// Token: 0x0400332B RID: 13099
		public static readonly float HalfPi = 1.5707964f;

		// Token: 0x0400332C RID: 13100
		public static readonly float ThirdPi = 1.0471976f;

		// Token: 0x0400332D RID: 13101
		public static readonly float QuarterPi = 0.7853982f;

		// Token: 0x0400332E RID: 13102
		public static readonly float FifthPi = 0.62831855f;

		// Token: 0x0400332F RID: 13103
		public static readonly float SixthPi = 0.5235988f;

		// Token: 0x04003330 RID: 13104
		public static readonly float Sqrt2 = Mathf.Sqrt(2f);

		// Token: 0x04003331 RID: 13105
		public static readonly float Sqrt2Inv = 1f / Mathf.Sqrt(2f);

		// Token: 0x04003332 RID: 13106
		public static readonly float Sqrt3 = Mathf.Sqrt(3f);

		// Token: 0x04003333 RID: 13107
		public static readonly float Sqrt3Inv = 1f / Mathf.Sqrt(3f);

		// Token: 0x04003334 RID: 13108
		public static readonly float Epsilon = 1E-09f;

		// Token: 0x04003335 RID: 13109
		public static readonly float EpsilonComp = 1f - MathUtil.Epsilon;

		// Token: 0x04003336 RID: 13110
		public static readonly float Rad2Deg = 57.295776f;

		// Token: 0x04003337 RID: 13111
		public static readonly float Deg2Rad = 0.017453292f;
	}
}
