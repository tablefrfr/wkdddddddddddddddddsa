﻿using System;

// Token: 0x02000363 RID: 867
public enum CrystalOctave
{
	// Token: 0x04001695 RID: 5781
	Low,
	// Token: 0x04001696 RID: 5782
	Middle,
	// Token: 0x04001697 RID: 5783
	High
}
