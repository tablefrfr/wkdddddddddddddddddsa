﻿using System;
using UnityEngine;

namespace GorillaLocomotion
{
	// Token: 0x020005B0 RID: 1456
	public class Surface : MonoBehaviour
	{
		// Token: 0x0400240D RID: 9229
		public float slipPercentage;
	}
}
