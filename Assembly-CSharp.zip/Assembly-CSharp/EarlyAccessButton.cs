﻿using System;
using System.Collections;
using GorillaNetworking;
using UnityEngine;

// Token: 0x02000285 RID: 645
[Obsolete("Replaced with bundlebutton")]
public class EarlyAccessButton : GorillaPressableButton
{
	// Token: 0x06000E36 RID: 3638 RVA: 0x00003051 File Offset: 0x00001251
	private void Awake()
	{
	}

	// Token: 0x06000E37 RID: 3639 RVA: 0x0004AAC4 File Offset: 0x00048CC4
	public void Update()
	{
		if (NetworkSystem.Instance != null && NetworkSystem.Instance.WrongVersion)
		{
			base.enabled = false;
			base.GetComponent<BoxCollider>().enabled = false;
			this.buttonRenderer.material = this.pressedMaterial;
			this.myText.text = "UNAVAILABLE";
		}
	}

	// Token: 0x06000E38 RID: 3640 RVA: 0x0004AB1E File Offset: 0x00048D1E
	public override void ButtonActivation()
	{
		base.ButtonActivation();
		CosmeticsController.instance.PressEarlyAccessButton();
		base.StartCoroutine(this.ButtonColorUpdate());
	}

	// Token: 0x06000E39 RID: 3641 RVA: 0x0004AB3F File Offset: 0x00048D3F
	public void AlreadyOwn()
	{
		base.enabled = false;
		base.GetComponent<BoxCollider>().enabled = false;
		this.buttonRenderer.material = this.pressedMaterial;
		this.myText.text = "YOU OWN THE BUNDLE ALREADY! THANK YOU!";
	}

	// Token: 0x06000E3A RID: 3642 RVA: 0x0004AB75 File Offset: 0x00048D75
	private IEnumerator ButtonColorUpdate()
	{
		this.buttonRenderer.material = this.pressedMaterial;
		yield return new WaitForSeconds(this.debounceTime);
		this.buttonRenderer.material = (this.isOn ? this.pressedMaterial : this.unpressedMaterial);
		yield break;
	}
}
