﻿using System;

// Token: 0x020003FA RID: 1018
public enum DevButtonType
{
	// Token: 0x04001B18 RID: 6936
	LogLevel,
	// Token: 0x04001B19 RID: 6937
	Grow,
	// Token: 0x04001B1A RID: 6938
	Shrink,
	// Token: 0x04001B1B RID: 6939
	ScrollUp,
	// Token: 0x04001B1C RID: 6940
	Mute,
	// Token: 0x04001B1D RID: 6941
	LineExpand,
	// Token: 0x04001B1E RID: 6942
	LineForward,
	// Token: 0x04001B1F RID: 6943
	ScrollDown,
	// Token: 0x04001B20 RID: 6944
	Bottom,
	// Token: 0x04001B21 RID: 6945
	Toggle,
	// Token: 0x04001B22 RID: 6946
	Clear,
	// Token: 0x04001B23 RID: 6947
	ConsoleMode,
	// Token: 0x04001B24 RID: 6948
	InspectorMode,
	// Token: 0x04001B25 RID: 6949
	ComponentInspectorMode,
	// Token: 0x04001B26 RID: 6950
	InspectorShowAllFields,
	// Token: 0x04001B27 RID: 6951
	InspectorShowPrivateItems
}
