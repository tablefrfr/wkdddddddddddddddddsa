﻿using System;
using System.Collections.Generic;

namespace BuildSafe
{
	// Token: 0x02000625 RID: 1573
	public static class ListUtilsUnsafe<T>
	{
		// Token: 0x06002514 RID: 9492 RVA: 0x0009178D File Offset: 0x0008F98D
		public static T[] GetInternalArray(List<T> list)
		{
			return null;
		}
	}
}
