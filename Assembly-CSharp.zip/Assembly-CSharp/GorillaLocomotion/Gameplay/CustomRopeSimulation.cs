﻿using System;
using System.Collections.Generic;
using Unity.Collections;
using Unity.Jobs;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005BF RID: 1471
	public class CustomRopeSimulation : MonoBehaviour
	{
		// Token: 0x0600226A RID: 8810 RVA: 0x000A75B4 File Offset: 0x000A57B4
		private void Start()
		{
			Vector3 position = base.transform.position;
			for (int i = 0; i < this.nodeCount; i++)
			{
				GameObject gameObject = Object.Instantiate<GameObject>(this.ropeNodePrefab);
				gameObject.transform.parent = base.transform;
				gameObject.transform.position = position;
				this.nodes.Add(gameObject.transform);
				position.y -= this.nodeDistance;
			}
			this.nodes[this.nodes.Count - 1].GetComponentInChildren<Renderer>().enabled = false;
			this.burstNodes = new NativeArray<BurstRopeNode>(this.nodes.Count, Allocator.Persistent, NativeArrayOptions.ClearMemory);
		}

		// Token: 0x0600226B RID: 8811 RVA: 0x000A7664 File Offset: 0x000A5864
		private void OnDestroy()
		{
			this.burstNodes.Dispose();
		}

		// Token: 0x0600226C RID: 8812 RVA: 0x000A7674 File Offset: 0x000A5874
		private void Update()
		{
			new SolveRopeJob
			{
				fixedDeltaTime = Time.deltaTime,
				gravity = this.gravity,
				nodes = this.burstNodes,
				nodeDistance = this.nodeDistance,
				rootPos = base.transform.position
			}.Run<SolveRopeJob>();
			for (int i = 0; i < this.burstNodes.Length; i++)
			{
				this.nodes[i].position = this.burstNodes[i].curPos;
				if (i > 0)
				{
					Vector3 a = this.burstNodes[i - 1].curPos - this.burstNodes[i].curPos;
					this.nodes[i].up = -a;
				}
			}
		}

		// Token: 0x040024C2 RID: 9410
		private List<Transform> nodes = new List<Transform>();

		// Token: 0x040024C3 RID: 9411
		[SerializeField]
		private GameObject ropeNodePrefab;

		// Token: 0x040024C4 RID: 9412
		[SerializeField]
		private int nodeCount = 10;

		// Token: 0x040024C5 RID: 9413
		[SerializeField]
		private float nodeDistance = 0.4f;

		// Token: 0x040024C6 RID: 9414
		[SerializeField]
		private int applyConstraintIterations = 20;

		// Token: 0x040024C7 RID: 9415
		[SerializeField]
		private Vector3 gravity = new Vector3(0f, -9.81f, 0f);

		// Token: 0x040024C8 RID: 9416
		[SerializeField]
		private float friction = 0.1f;

		// Token: 0x040024C9 RID: 9417
		private NativeArray<BurstRopeNode> burstNodes;
	}
}
