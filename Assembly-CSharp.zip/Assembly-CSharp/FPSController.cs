﻿using System;
using UnityEngine;

// Token: 0x0200049D RID: 1181
public class FPSController : MonoBehaviour
{
	// Token: 0x14000025 RID: 37
	// (add) Token: 0x06001B30 RID: 6960 RVA: 0x0008AD34 File Offset: 0x00088F34
	// (remove) Token: 0x06001B31 RID: 6961 RVA: 0x0008AD6C File Offset: 0x00088F6C
	[HideInInspector]
	public event FPSController.OnStateChangeEventHandler OnStartEvent;

	// Token: 0x14000026 RID: 38
	// (add) Token: 0x06001B32 RID: 6962 RVA: 0x0008ADA4 File Offset: 0x00088FA4
	// (remove) Token: 0x06001B33 RID: 6963 RVA: 0x0008ADDC File Offset: 0x00088FDC
	public event FPSController.OnStateChangeEventHandler OnStopEvent;

	// Token: 0x04001F19 RID: 7961
	public float baseMoveSpeed = 4f;

	// Token: 0x04001F1A RID: 7962
	public float shiftMoveSpeed = 8f;

	// Token: 0x04001F1B RID: 7963
	public float ctrlMoveSpeed = 1f;

	// Token: 0x04001F1C RID: 7964
	public float lookHorizontal = 0.4f;

	// Token: 0x04001F1D RID: 7965
	public float lookVertical = 0.25f;

	// Token: 0x04001F1E RID: 7966
	[SerializeField]
	private Vector3 leftControllerPosOffset = new Vector3(-0.2f, -0.25f, 0.3f);

	// Token: 0x04001F1F RID: 7967
	[SerializeField]
	private Vector3 leftControllerRotationOffset = new Vector3(265f, -82f, 28f);

	// Token: 0x04001F20 RID: 7968
	[SerializeField]
	private Vector3 rightControllerPosOffset = new Vector3(0.2f, -0.25f, 0.3f);

	// Token: 0x04001F21 RID: 7969
	[SerializeField]
	private Vector3 rightControllerRotationOffset = new Vector3(263f, 318f, 485f);

	// Token: 0x04001F22 RID: 7970
	[SerializeField]
	private bool toggleGrab;

	// Token: 0x0200049E RID: 1182
	// (Invoke) Token: 0x06001B36 RID: 6966
	public delegate void OnStateChangeEventHandler();
}
