﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000279 RID: 633
public class BetaButton : GorillaPressableButton
{
	// Token: 0x06000E12 RID: 3602 RVA: 0x0004A304 File Offset: 0x00048504
	public override void ButtonActivation()
	{
		base.ButtonActivation();
		this.count++;
		base.StartCoroutine(this.ButtonColorUpdate());
		if (this.count >= 10)
		{
			this.betaParent.SetActive(false);
			PlayerPrefs.SetString("CheckedBox2", "true");
			PlayerPrefs.Save();
		}
	}

	// Token: 0x06000E13 RID: 3603 RVA: 0x0004A35C File Offset: 0x0004855C
	private IEnumerator ButtonColorUpdate()
	{
		this.buttonRenderer.material = this.pressedMaterial;
		yield return new WaitForSeconds(this.buttonFadeTime);
		this.buttonRenderer.material = this.unpressedMaterial;
		yield break;
	}

	// Token: 0x04000FF2 RID: 4082
	public GameObject betaParent;

	// Token: 0x04000FF3 RID: 4083
	public int count;

	// Token: 0x04000FF4 RID: 4084
	public float buttonFadeTime = 0.25f;

	// Token: 0x04000FF5 RID: 4085
	public Text messageText;
}
