﻿using System;

// Token: 0x02000428 RID: 1064
public static class EnumUtilExt
{
	// Token: 0x06001897 RID: 6295 RVA: 0x0007F4C8 File Offset: 0x0007D6C8
	public static string GetName<TEnum>(this TEnum e) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.EnumToName[e];
	}

	// Token: 0x06001898 RID: 6296 RVA: 0x0007F4EC File Offset: 0x0007D6EC
	public static int GetIndex<TEnum>(this TEnum e) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.EnumToIndex[e];
	}

	// Token: 0x06001899 RID: 6297 RVA: 0x0007F510 File Offset: 0x0007D710
	public static long GetLongValue<TEnum>(this TEnum e) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.EnumToLong[e];
	}
}
