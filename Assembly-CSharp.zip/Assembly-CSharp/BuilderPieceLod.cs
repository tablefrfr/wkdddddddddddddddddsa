﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200031D RID: 797
public class BuilderPieceLod
{
	// Token: 0x0400145A RID: 5210
	public float maxDistance;

	// Token: 0x0400145B RID: 5211
	public List<MeshRenderer> meshRenderers;
}
