﻿using System;
using UnityEngine;

// Token: 0x020002D0 RID: 720
public class CosmeticButton : GorillaPressableButton
{
	// Token: 0x060010A1 RID: 4257 RVA: 0x00057F8B File Offset: 0x0005618B
	public void Awake()
	{
		this.startingPos = base.transform.localPosition;
	}

	// Token: 0x060010A2 RID: 4258 RVA: 0x00057FA0 File Offset: 0x000561A0
	public override void UpdateColor()
	{
		if (!base.enabled)
		{
			this.buttonRenderer.material = this.disabledMaterial;
			if (this.myText != null)
			{
				this.myText.text = this.offText;
			}
		}
		else if (this.isOn)
		{
			this.buttonRenderer.material = this.pressedMaterial;
			if (this.myText != null)
			{
				this.myText.text = this.onText;
			}
		}
		else
		{
			this.buttonRenderer.material = this.unpressedMaterial;
			if (this.myText != null)
			{
				this.myText.text = this.offText;
			}
		}
		this.UpdatePosition();
	}

	// Token: 0x060010A3 RID: 4259 RVA: 0x00058058 File Offset: 0x00056258
	private void UpdatePosition()
	{
		Vector3 vector = this.startingPos;
		if (!base.enabled)
		{
			vector += this.disabledOffset;
		}
		else if (this.isOn)
		{
			vector += this.pressedOffset;
		}
		base.transform.localPosition = vector;
	}

	// Token: 0x040012C9 RID: 4809
	[SerializeField]
	private Vector3 pressedOffset = new Vector3(0f, 0f, 0.1f);

	// Token: 0x040012CA RID: 4810
	[SerializeField]
	private Material disabledMaterial;

	// Token: 0x040012CB RID: 4811
	[SerializeField]
	private Vector3 disabledOffset = new Vector3(0f, 0f, 0.1f);

	// Token: 0x040012CC RID: 4812
	private Vector3 startingPos;
}
