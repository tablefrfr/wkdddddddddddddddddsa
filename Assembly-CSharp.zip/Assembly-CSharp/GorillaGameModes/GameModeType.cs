﻿using System;

namespace GorillaGameModes
{
	// Token: 0x020005AA RID: 1450
	[Serializable]
	public enum GameModeType
	{
		// Token: 0x04002319 RID: 8985
		Casual,
		// Token: 0x0400231A RID: 8986
		Infection,
		// Token: 0x0400231B RID: 8987
		Hunt,
		// Token: 0x0400231C RID: 8988
		Battle
	}
}
