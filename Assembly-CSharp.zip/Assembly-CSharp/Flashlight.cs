﻿using System;
using UnityEngine;

// Token: 0x020001AE RID: 430
public class Flashlight : MonoBehaviour
{
	// Token: 0x060008E2 RID: 2274 RVA: 0x0002D394 File Offset: 0x0002B594
	private void LateUpdate()
	{
		for (int i = 0; i < this.lightVolume.transform.childCount; i++)
		{
			this.lightVolume.transform.GetChild(i).rotation = Quaternion.LookRotation((this.lightVolume.transform.GetChild(i).position - Camera.main.transform.position).normalized);
		}
	}

	// Token: 0x060008E3 RID: 2275 RVA: 0x0002D40C File Offset: 0x0002B60C
	public void ToggleFlashlight()
	{
		this.lightVolume.SetActive(!this.lightVolume.activeSelf);
		this.spotlight.enabled = !this.spotlight.enabled;
		this.bulbGlow.SetActive(this.lightVolume.activeSelf);
	}

	// Token: 0x060008E4 RID: 2276 RVA: 0x0002D461 File Offset: 0x0002B661
	public void EnableFlashlight(bool doEnable)
	{
		this.lightVolume.SetActive(doEnable);
		this.spotlight.enabled = doEnable;
		this.bulbGlow.SetActive(doEnable);
	}

	// Token: 0x040009CB RID: 2507
	public GameObject lightVolume;

	// Token: 0x040009CC RID: 2508
	public Light spotlight;

	// Token: 0x040009CD RID: 2509
	public GameObject bulbGlow;
}
