﻿using System;
using UnityEngine;

namespace BoingKit
{
	// Token: 0x02000817 RID: 2071
	public class BoingReactorFieldGPUSampler : MonoBehaviour
	{
		// Token: 0x06003238 RID: 12856 RVA: 0x000FB3AC File Offset: 0x000F95AC
		public void OnEnable()
		{
			BoingManager.Register(this);
		}

		// Token: 0x06003239 RID: 12857 RVA: 0x000FB3B4 File Offset: 0x000F95B4
		public void OnDisable()
		{
			BoingManager.Unregister(this);
		}

		// Token: 0x0600323A RID: 12858 RVA: 0x000FB3BC File Offset: 0x000F95BC
		public void Update()
		{
			if (this.ReactorField == null)
			{
				return;
			}
			BoingReactorField component = this.ReactorField.GetComponent<BoingReactorField>();
			if (component == null)
			{
				return;
			}
			if (component.HardwareMode != BoingReactorField.HardwareModeEnum.GPU)
			{
				return;
			}
			if (this.m_fieldResourceSetId != component.GpuResourceSetId)
			{
				if (this.m_matProps == null)
				{
					this.m_matProps = new MaterialPropertyBlock();
				}
				if (component.UpdateShaderConstants(this.m_matProps, this.PositionSampleMultiplier, this.RotationSampleMultiplier))
				{
					this.m_fieldResourceSetId = component.GpuResourceSetId;
					foreach (Renderer renderer in new Renderer[]
					{
						base.GetComponent<MeshRenderer>(),
						base.GetComponent<SkinnedMeshRenderer>()
					})
					{
						if (!(renderer == null))
						{
							renderer.SetPropertyBlock(this.m_matProps);
						}
					}
				}
			}
		}

		// Token: 0x040034BA RID: 13498
		public BoingReactorField ReactorField;

		// Token: 0x040034BB RID: 13499
		[Range(0f, 10f)]
		[Tooltip("Multiplier on positional samples from reactor field.\n1.0 means 100%.")]
		public float PositionSampleMultiplier = 1f;

		// Token: 0x040034BC RID: 13500
		[Range(0f, 10f)]
		[Tooltip("Multiplier on rotational samples from reactor field.\n1.0 means 100%.")]
		public float RotationSampleMultiplier = 1f;

		// Token: 0x040034BD RID: 13501
		private MaterialPropertyBlock m_matProps;

		// Token: 0x040034BE RID: 13502
		private int m_fieldResourceSetId = -1;
	}
}
