﻿using System;
using System.Collections;
using System.Collections.Generic;
using GorillaLocomotion;
using GorillaNetworking;
using UnityEngine;

// Token: 0x02000452 RID: 1106
public class GorillaFriendCollider : MonoBehaviour
{
	// Token: 0x060019BD RID: 6589 RVA: 0x000834C8 File Offset: 0x000816C8
	public void Awake()
	{
		this.thisCapsule = base.GetComponent<CapsuleCollider>();
		this.jiggleAmount = Random.Range(0f, 1f);
		base.StartCoroutine(this.UpdatePlayersInSphere());
		this.tagAndBodyLayerMask = (LayerMask.GetMask(new string[]
		{
			"Gorilla Tag Collider"
		}) | LayerMask.GetMask(new string[]
		{
			"Gorilla Body Collider"
		}));
	}

	// Token: 0x060019BE RID: 6590 RVA: 0x00083530 File Offset: 0x00081730
	private void AddUserID(in string userID)
	{
		if (this.playerIDsCurrentlyTouching.Contains(userID))
		{
			return;
		}
		this.playerIDsCurrentlyTouching.Add(userID);
	}

	// Token: 0x060019BF RID: 6591 RVA: 0x0008354F File Offset: 0x0008174F
	private IEnumerator UpdatePlayersInSphere()
	{
		yield return new WaitForSeconds(1f + this.jiggleAmount);
		WaitForSeconds wait = new WaitForSeconds(1f);
		for (;;)
		{
			this.playerIDsCurrentlyTouching.Clear();
			this.collisions = Physics.OverlapSphereNonAlloc(base.transform.position, this.thisCapsule.radius, this.overlapColliders, this.tagAndBodyLayerMask);
			this.collisions = Mathf.Min(this.collisions, this.overlapColliders.Length);
			if (this.collisions > 0)
			{
				for (int i = 0; i < this.collisions; i++)
				{
					this.otherCollider = this.overlapColliders[i];
					if (!(this.otherCollider == null))
					{
						this.otherColliderGO = this.otherCollider.attachedRigidbody.gameObject;
						this.collidingRig = this.otherColliderGO.GetComponent<VRRig>();
						if (this.collidingRig == null || this.collidingRig.creatorWrapped == null || this.collidingRig.creatorWrapped.IsNull || string.IsNullOrEmpty(this.collidingRig.creatorWrapped.UserId))
						{
							if (this.otherColliderGO.GetComponent<Player>() == null || NetworkSystem.Instance.LocalPlayer == null)
							{
								goto IL_1A9;
							}
							string userId = NetworkSystem.Instance.LocalPlayer.UserId;
							this.AddUserID(userId);
						}
						else
						{
							string userId = this.collidingRig.creatorWrapped.UserId;
							this.AddUserID(userId);
						}
						this.overlapColliders[i] = null;
					}
					IL_1A9:;
				}
				if (NetworkSystem.Instance.LocalPlayer != null && this.playerIDsCurrentlyTouching.Contains(NetworkSystem.Instance.LocalPlayer.UserId) && GorillaComputer.instance.friendJoinCollider != this)
				{
					GorillaComputer.instance.allowedMapsToJoin = this.myAllowedMapsToJoin;
					GorillaComputer.instance.friendJoinCollider = this;
					GorillaComputer.instance.UpdateScreen();
				}
				this.otherCollider = null;
				this.otherColliderGO = null;
				this.collidingRig = null;
			}
			yield return wait;
		}
		yield break;
	}

	// Token: 0x04001D75 RID: 7541
	public List<string> playerIDsCurrentlyTouching = new List<string>();

	// Token: 0x04001D76 RID: 7542
	public CapsuleCollider thisCapsule;

	// Token: 0x04001D77 RID: 7543
	public string[] myAllowedMapsToJoin;

	// Token: 0x04001D78 RID: 7544
	private readonly Collider[] overlapColliders = new Collider[20];

	// Token: 0x04001D79 RID: 7545
	private int tagAndBodyLayerMask;

	// Token: 0x04001D7A RID: 7546
	private float jiggleAmount;

	// Token: 0x04001D7B RID: 7547
	private Collider otherCollider;

	// Token: 0x04001D7C RID: 7548
	private GameObject otherColliderGO;

	// Token: 0x04001D7D RID: 7549
	private VRRig collidingRig;

	// Token: 0x04001D7E RID: 7550
	private int collisions;
}
