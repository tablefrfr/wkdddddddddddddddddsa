﻿using System;
using BoingKit;
using UnityEngine;

// Token: 0x02000014 RID: 20
public class CurveBall : MonoBehaviour
{
	// Token: 0x0600003B RID: 59 RVA: 0x000036E8 File Offset: 0x000018E8
	public void Reset()
	{
		float f = Random.Range(0f, MathUtil.TwoPi);
		float num = Mathf.Cos(f);
		float num2 = Mathf.Sin(f);
		this.m_speedX = 40f * num;
		this.m_speedZ = 40f * num2;
		this.m_timer = 0f;
		Vector3 position = base.transform.position;
		position.x = -10f * num;
		position.z = -10f * num2;
		base.transform.position = position;
	}

	// Token: 0x0600003C RID: 60 RVA: 0x0000376A File Offset: 0x0000196A
	public void Start()
	{
		this.Reset();
	}

	// Token: 0x0600003D RID: 61 RVA: 0x00003774 File Offset: 0x00001974
	public void Update()
	{
		float deltaTime = Time.deltaTime;
		if (this.m_timer > this.Interval)
		{
			this.Reset();
		}
		Vector3 position = base.transform.position;
		position.x += this.m_speedX * deltaTime;
		position.z += this.m_speedZ * deltaTime;
		base.transform.position = position;
		this.m_timer += deltaTime;
	}

	// Token: 0x0400004B RID: 75
	public float Interval = 2f;

	// Token: 0x0400004C RID: 76
	private float m_speedX;

	// Token: 0x0400004D RID: 77
	private float m_speedZ;

	// Token: 0x0400004E RID: 78
	private float m_timer;
}
