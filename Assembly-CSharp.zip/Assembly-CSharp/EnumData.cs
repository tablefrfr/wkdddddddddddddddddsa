﻿using System;
using System.Collections.Generic;

// Token: 0x02000426 RID: 1062
public class EnumData<TEnum> where TEnum : struct, Enum
{
	// Token: 0x170002F4 RID: 756
	// (get) Token: 0x06001885 RID: 6277 RVA: 0x0007F34B File Offset: 0x0007D54B
	public static EnumData<TEnum> Shared { get; } = new EnumData<TEnum>();

	// Token: 0x06001886 RID: 6278 RVA: 0x0007F354 File Offset: 0x0007D554
	public EnumData()
	{
		this.Names = Enum.GetNames(typeof(TEnum));
		int num = this.Names.Length;
		this.Values = new TEnum[num];
		this.LongValues = new long[num];
		this.EnumToName = new Dictionary<TEnum, string>(num);
		this.NameToEnum = new Dictionary<string, TEnum>(num);
		this.EnumToIndex = new Dictionary<TEnum, int>(num);
		this.IndexToEnum = new Dictionary<int, TEnum>(num);
		this.EnumToLong = new Dictionary<TEnum, long>(num);
		this.LongToEnum = new Dictionary<long, TEnum>(num);
		for (int i = 0; i < this.Names.Length; i++)
		{
			string text = this.Names[i];
			TEnum tenum = Enum.Parse<TEnum>(text);
			int num2 = i;
			long num3 = Convert.ToInt64(tenum);
			this.Values[num2] = tenum;
			this.LongValues[num2] = num3;
			this.EnumToName[tenum] = text;
			this.NameToEnum[text] = tenum;
			this.EnumToIndex[tenum] = num2;
			this.IndexToEnum[num2] = tenum;
			this.EnumToLong[tenum] = num3;
			this.LongToEnum[num3] = tenum;
		}
	}

	// Token: 0x04001C92 RID: 7314
	public readonly string[] Names;

	// Token: 0x04001C93 RID: 7315
	public readonly TEnum[] Values;

	// Token: 0x04001C94 RID: 7316
	public readonly long[] LongValues;

	// Token: 0x04001C95 RID: 7317
	public readonly Dictionary<TEnum, string> EnumToName;

	// Token: 0x04001C96 RID: 7318
	public readonly Dictionary<string, TEnum> NameToEnum;

	// Token: 0x04001C97 RID: 7319
	public readonly Dictionary<TEnum, int> EnumToIndex;

	// Token: 0x04001C98 RID: 7320
	public readonly Dictionary<int, TEnum> IndexToEnum;

	// Token: 0x04001C99 RID: 7321
	public readonly Dictionary<TEnum, long> EnumToLong;

	// Token: 0x04001C9A RID: 7322
	public readonly Dictionary<long, TEnum> LongToEnum;
}
