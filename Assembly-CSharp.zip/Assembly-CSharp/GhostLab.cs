﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200003C RID: 60
public class GhostLab : MonoBehaviour, IBuildValidation
{
	// Token: 0x06000120 RID: 288 RVA: 0x00009CC2 File Offset: 0x00007EC2
	private void Awake()
	{
		this.relState = Object.FindFirstObjectByType<GhostLabReliableState>();
		this.doorState = GhostLab.EntranceDoorsState.BothClosed;
		this.doorOpen = new bool[this.slidingDoor.Length];
		this.toggleDoorsParent.GetComponentsInChildren<GhostLabButton>();
	}

	// Token: 0x06000121 RID: 289 RVA: 0x00009CF8 File Offset: 0x00007EF8
	public bool BuildValidationCheck()
	{
		if (this.entranceDoorScanner == null)
		{
			Debug.LogError("door scanner missing", base.gameObject);
			return false;
		}
		if (this.outerDoor == null || this.innerDoor == null)
		{
			Debug.LogError("sliding doors missing", base.gameObject);
			return false;
		}
		if (this.toggleDoorsParent == null)
		{
			Debug.LogError("missing reference to parent of toggleable doors", base.gameObject);
			return false;
		}
		List<int> list = new List<int>();
		GhostLabButton[] componentsInChildren = this.toggleDoorsParent.GetComponentsInChildren<GhostLabButton>();
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			if (!list.Contains(componentsInChildren[i].buttonIndex))
			{
				list.Add(componentsInChildren[i].buttonIndex);
			}
		}
		if (list.Count != this.slidingDoor.Length)
		{
			Debug.LogError("slidingDoor array not set to the correct length", base.gameObject);
			return false;
		}
		for (int j = 0; j < list.Count; j++)
		{
			if (!list.Contains(j))
			{
				Debug.LogError("door indices not continuous", base.gameObject);
				return false;
			}
		}
		return true;
	}

	// Token: 0x06000122 RID: 290 RVA: 0x00009E00 File Offset: 0x00008000
	public void DoorButtonPress(int buttonIndex, bool forSingleDoor)
	{
		if (!forSingleDoor)
		{
			this.UpdateEntranceDoorsState(buttonIndex);
			return;
		}
		this.UpdateDoorState(buttonIndex);
		this.relState.UpdateSingleDoorState(buttonIndex);
	}

	// Token: 0x06000123 RID: 291 RVA: 0x00009E20 File Offset: 0x00008020
	public void UpdateDoorState(int buttonIndex)
	{
		if ((this.doorOpen[buttonIndex] && this.slidingDoor[buttonIndex].localPosition == this.singleDoorTravelDistance) || (!this.doorOpen[buttonIndex] && this.slidingDoor[buttonIndex].localPosition == Vector3.zero))
		{
			this.doorOpen[buttonIndex] = !this.doorOpen[buttonIndex];
		}
	}

	// Token: 0x06000124 RID: 292 RVA: 0x00009E88 File Offset: 0x00008088
	public void UpdateEntranceDoorsState(int buttonIndex)
	{
		if (this.doorState == GhostLab.EntranceDoorsState.BothClosed)
		{
			if (!(this.innerDoor.localPosition != Vector3.zero) && !(this.outerDoor.localPosition != Vector3.zero))
			{
				if (buttonIndex == 0 || buttonIndex == 1)
				{
					this.doorState = GhostLab.EntranceDoorsState.OuterDoorOpen;
				}
				if (buttonIndex == 2 || buttonIndex == 3)
				{
					this.doorState = GhostLab.EntranceDoorsState.InnerDoorOpen;
				}
			}
		}
		else if (this.innerDoor.localPosition == this.doorTravelDistance || this.outerDoor.localPosition == this.doorTravelDistance)
		{
			this.doorState = GhostLab.EntranceDoorsState.BothClosed;
		}
		this.relState.UpdateEntranceDoorsState(this.doorState);
	}

	// Token: 0x06000125 RID: 293 RVA: 0x00009F34 File Offset: 0x00008134
	public void Update()
	{
		this.SynchStates();
		Vector3 zero = Vector3.zero;
		Vector3 zero2 = Vector3.zero;
		switch (this.doorState)
		{
		case GhostLab.EntranceDoorsState.InnerDoorOpen:
			zero2 = this.doorTravelDistance;
			break;
		case GhostLab.EntranceDoorsState.OuterDoorOpen:
			zero = this.doorTravelDistance;
			break;
		}
		this.outerDoor.localPosition = Vector3.MoveTowards(this.outerDoor.localPosition, zero, this.doorMoveSpeed * Time.deltaTime);
		this.innerDoor.localPosition = Vector3.MoveTowards(this.innerDoor.localPosition, zero2, this.doorMoveSpeed * Time.deltaTime);
		Vector3 zero3 = Vector3.zero;
		for (int i = 0; i < this.slidingDoor.Length; i++)
		{
			if (this.doorOpen[i])
			{
				zero3 = this.singleDoorTravelDistance;
			}
			else
			{
				zero3 = Vector3.zero;
			}
			this.slidingDoor[i].localPosition = Vector3.MoveTowards(this.slidingDoor[i].localPosition, zero3, this.singleDoorMoveSpeed * Time.deltaTime);
		}
	}

	// Token: 0x06000126 RID: 294 RVA: 0x0000A034 File Offset: 0x00008234
	private void SynchStates()
	{
		this.doorState = this.relState.doorState;
		for (int i = 0; i < this.doorOpen.Length; i++)
		{
			this.doorOpen[i] = this.relState.singleDoorOpen[i];
		}
	}

	// Token: 0x06000127 RID: 295 RVA: 0x0000A07C File Offset: 0x0000827C
	public bool IsDoorMoving(bool singleDoor, int index)
	{
		if (singleDoor)
		{
			return (this.doorOpen[index] && this.slidingDoor[index].localPosition != this.singleDoorTravelDistance) || (!this.doorOpen[index] && this.slidingDoor[index].localPosition != Vector3.zero);
		}
		if (index == 0 || index == 1)
		{
			return (this.doorState == GhostLab.EntranceDoorsState.OuterDoorOpen && this.outerDoor.localPosition != this.doorTravelDistance) || (this.doorState != GhostLab.EntranceDoorsState.OuterDoorOpen && this.outerDoor.localPosition != Vector3.zero);
		}
		return (this.doorState == GhostLab.EntranceDoorsState.InnerDoorOpen && this.innerDoor.localPosition != this.doorTravelDistance) || (this.doorState != GhostLab.EntranceDoorsState.InnerDoorOpen && this.innerDoor.localPosition != Vector3.zero);
	}

	// Token: 0x0400018E RID: 398
	public IDCardScanner entranceDoorScanner;

	// Token: 0x0400018F RID: 399
	public Transform outerDoor;

	// Token: 0x04000190 RID: 400
	public Transform innerDoor;

	// Token: 0x04000191 RID: 401
	public Vector3 doorTravelDistance;

	// Token: 0x04000192 RID: 402
	public float doorMoveSpeed;

	// Token: 0x04000193 RID: 403
	public float singleDoorMoveSpeed;

	// Token: 0x04000194 RID: 404
	public GhostLab.EntranceDoorsState doorState;

	// Token: 0x04000195 RID: 405
	public GhostLabReliableState relState;

	// Token: 0x04000196 RID: 406
	public Transform toggleDoorsParent;

	// Token: 0x04000197 RID: 407
	public Transform[] slidingDoor;

	// Token: 0x04000198 RID: 408
	public Vector3 singleDoorTravelDistance;

	// Token: 0x04000199 RID: 409
	private bool[] doorOpen;

	// Token: 0x0200003D RID: 61
	public enum EntranceDoorsState
	{
		// Token: 0x0400019B RID: 411
		BothClosed,
		// Token: 0x0400019C RID: 412
		InnerDoorOpen,
		// Token: 0x0400019D RID: 413
		OuterDoorOpen
	}
}
