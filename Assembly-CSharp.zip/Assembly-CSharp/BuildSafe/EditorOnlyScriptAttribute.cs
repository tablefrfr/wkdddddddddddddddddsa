﻿using System;
using System.Diagnostics;

namespace BuildSafe
{
	// Token: 0x02000623 RID: 1571
	[Conditional("UNITY_EDITOR")]
	[AttributeUsage(AttributeTargets.Class)]
	public class EditorOnlyScriptAttribute : Attribute
	{
	}
}
