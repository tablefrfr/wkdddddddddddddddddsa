﻿using System;
using System.Collections.Generic;
using GorillaTagScripts;
using UnityEngine;

// Token: 0x02000320 RID: 800
public class BuilderPiece : MonoBehaviour
{
	// Token: 0x060011E8 RID: 4584 RVA: 0x0005D180 File Offset: 0x0005B380
	private void Awake()
	{
		this.materialType = -1;
		this.pieceType = -1;
		this.pieceId = -1;
		this.state = BuilderPiece.State.None;
		this.isStatic = true;
		this.parentPiece = null;
		this.firstChildPiece = null;
		this.nextSiblingPiece = null;
		this.attachIndex = -1;
		this.parentAttachIndex = -1;
		this.parentHeld = null;
		this.heldByPlayerActorNumber = -1;
		this.SetActive(this.onlyWhenPlaced, false);
		this.SetActive(this.onlyWhenNotPlaced, true);
		this.colliders = new List<Collider>(4);
		base.GetComponentsInChildren<Collider>(this.colliders);
		for (int i = 0; i < this.colliders.Count; i++)
		{
			BuilderPieceCollider builderPieceCollider = this.colliders[i].GetComponent<BuilderPieceCollider>();
			if (builderPieceCollider == null)
			{
				builderPieceCollider = this.colliders[i].AddComponent<BuilderPieceCollider>();
			}
			builderPieceCollider.piece = this;
		}
		this.gridPlanes = new List<BuilderAttachGridPlane>(8);
		base.GetComponentsInChildren<BuilderAttachGridPlane>(this.gridPlanes);
		this.pieceComponents = new List<IBuilderPieceComponent>(1);
		base.GetComponentsInChildren<IBuilderPieceComponent>(true, this.pieceComponents);
		this.pieceComponentsActive = false;
		this.SetCollidersEnabled<Collider>(this.colliders, false);
		this.SetBehavioursEnabled<Behaviour>(this.onlyWhenPlacedBehaviours, false);
		this.preventSnapUntilMoved = 0;
		this.preventSnapUntilMovedFromPos = Vector3.zero;
		this.renderingIndirect = new List<MeshRenderer>(4);
		this.materialSwapTargets = new List<MeshRenderer>(4);
	}

	// Token: 0x060011E9 RID: 4585 RVA: 0x0005D2DC File Offset: 0x0005B4DC
	public void OnReturnToPool()
	{
		BuilderTable.instance.builderRenderer.RemovePiece(this);
		this.state = BuilderPiece.State.None;
		this.isStatic = true;
		this.materialType = -1;
		this.pieceType = -1;
		this.pieceId = -1;
		this.parentPiece = null;
		this.firstChildPiece = null;
		this.nextSiblingPiece = null;
		this.attachIndex = -1;
		this.attachBounds.Clear();
		this.parentAttachIndex = -1;
		this.parentAttachBounds.Clear();
		this.parentHeld = null;
		this.heldByPlayerActorNumber = -1;
		this.SetActive(this.onlyWhenPlaced, false);
		this.SetActive(this.onlyWhenNotPlaced, true);
		this.SetCollidersEnabled<Collider>(this.colliders, false);
		this.SetBehavioursEnabled<Behaviour>(this.onlyWhenPlacedBehaviours, false);
		this.preventSnapUntilMoved = 0;
		this.preventSnapUntilMovedFromPos = Vector3.zero;
	}

	// Token: 0x060011EA RID: 4586 RVA: 0x0005D3AC File Offset: 0x0005B5AC
	public void SetupPiece(float gridSize)
	{
		for (int i = 0; i < this.gridPlanes.Count; i++)
		{
			this.gridPlanes[i].Setup(this, i, gridSize);
		}
		base.GetComponentsInChildren<MeshRenderer>(this.areMeshesToggledOnPlace, this.materialSwapTargets);
	}

	// Token: 0x060011EB RID: 4587 RVA: 0x0005D3F8 File Offset: 0x0005B5F8
	public void SetMaterial(int inMaterialType, bool force = false)
	{
		if (this.materialOptions == null || this.materialSwapTargets == null || this.materialSwapTargets.Count < 1)
		{
			return;
		}
		if (this.materialType == inMaterialType && !force)
		{
			return;
		}
		this.materialType = inMaterialType;
		Material material = null;
		if (inMaterialType == -1)
		{
			this.materialType = this.materialOptions.GetDefaultMaterialType();
			material = this.materialOptions.GetDefaultMaterial();
		}
		else
		{
			material = this.materialOptions.GetMaterialFromType(this.materialType);
			if (material == null)
			{
				this.materialType = this.materialOptions.GetDefaultMaterialType();
				material = this.materialOptions.GetDefaultMaterial();
			}
		}
		if (material == null)
		{
			Debug.LogErrorFormat("Piece {0} has no material matching Type {1}", new object[]
			{
				this.GetPieceId(),
				inMaterialType
			});
			return;
		}
		foreach (MeshRenderer meshRenderer in this.materialSwapTargets)
		{
			if (!(meshRenderer == null) && meshRenderer.enabled)
			{
				meshRenderer.material = material;
			}
		}
		if (this.renderingIndirect.Count > 0)
		{
			BuilderTable.instance.builderRenderer.ChangePieceIndirectMaterial(this, this.materialSwapTargets, material);
		}
	}

	// Token: 0x060011EC RID: 4588 RVA: 0x0005D548 File Offset: 0x0005B748
	public int GetPieceId()
	{
		return this.pieceId;
	}

	// Token: 0x060011ED RID: 4589 RVA: 0x0005D550 File Offset: 0x0005B750
	public int GetParentPieceId()
	{
		if (!(this.parentPiece == null))
		{
			return this.parentPiece.pieceId;
		}
		return -1;
	}

	// Token: 0x060011EE RID: 4590 RVA: 0x0005D56D File Offset: 0x0005B76D
	public int GetAttachIndex()
	{
		return this.attachIndex;
	}

	// Token: 0x060011EF RID: 4591 RVA: 0x0005D575 File Offset: 0x0005B775
	public int GetParentAttachIndex()
	{
		return this.parentAttachIndex;
	}

	// Token: 0x060011F0 RID: 4592 RVA: 0x0005D580 File Offset: 0x0005B780
	private void SetPieceActive(List<IBuilderPieceComponent> components, bool active)
	{
		if (components == null || active == this.pieceComponentsActive)
		{
			return;
		}
		this.pieceComponentsActive = active;
		for (int i = 0; i < components.Count; i++)
		{
			if (components[i] != null)
			{
				if (active)
				{
					components[i].OnPieceActivate();
				}
				else
				{
					components[i].OnPieceDeactivate();
				}
			}
		}
	}

	// Token: 0x060011F1 RID: 4593 RVA: 0x0005D5D8 File Offset: 0x0005B7D8
	private void SetBehavioursEnabled<T>(List<T> components, bool enabled) where T : Behaviour
	{
		if (components == null)
		{
			return;
		}
		for (int i = 0; i < components.Count; i++)
		{
			if (components[i] != null)
			{
				components[i].enabled = enabled;
			}
		}
	}

	// Token: 0x060011F2 RID: 4594 RVA: 0x0005D620 File Offset: 0x0005B820
	private void SetCollidersEnabled<T>(List<T> components, bool enabled) where T : Collider
	{
		if (components == null)
		{
			return;
		}
		for (int i = 0; i < components.Count; i++)
		{
			if (components[i] != null)
			{
				components[i].enabled = enabled;
			}
		}
	}

	// Token: 0x060011F3 RID: 4595 RVA: 0x0005D668 File Offset: 0x0005B868
	public void SetColliderLayers<T>(List<T> components, int layer) where T : Collider
	{
		if (components == null)
		{
			return;
		}
		for (int i = 0; i < components.Count; i++)
		{
			if (components[i] != null)
			{
				components[i].gameObject.layer = layer;
			}
		}
	}

	// Token: 0x060011F4 RID: 4596 RVA: 0x0005D6B8 File Offset: 0x0005B8B8
	private void SetActive(List<GameObject> gameObjects, bool active)
	{
		if (gameObjects == null)
		{
			return;
		}
		for (int i = 0; i < gameObjects.Count; i++)
		{
			if (gameObjects[i] != null)
			{
				gameObjects[i].SetActive(active);
			}
		}
	}

	// Token: 0x060011F5 RID: 4597 RVA: 0x0005D6F6 File Offset: 0x0005B8F6
	public void SetScale(float scale)
	{
		if (this.scaleRoot != null)
		{
			this.scaleRoot.localScale = Vector3.one * scale;
		}
	}

	// Token: 0x060011F6 RID: 4598 RVA: 0x0005D71C File Offset: 0x0005B91C
	private void SetTint(float tint)
	{
		if (tint == this.tint)
		{
			return;
		}
		this.tint = tint;
		BuilderTable.instance.builderRenderer.SetPieceTint(this, tint);
	}

	// Token: 0x060011F7 RID: 4599 RVA: 0x0005D740 File Offset: 0x0005B940
	public void SetParentPiece(int newAttachIndex, SnapBounds newAttachBounds, BuilderPiece newParentPiece, int newParentAttachIndex, SnapBounds newParentAttachBounds)
	{
		if (this.parentHeld != null)
		{
			Debug.LogErrorFormat(newParentPiece.gameObject, "Cannot attach to piece {0} while already held", new object[]
			{
				(newParentPiece == null) ? null : newParentPiece.gameObject.name
			});
			return;
		}
		if (this.parentPiece != null)
		{
			this.RemoveSnapFromGrid(this.attachIndex, this.attachBounds);
			this.parentPiece.RemoveSnapFromGrid(this.parentAttachIndex, this.parentAttachBounds);
		}
		BuilderPiece.RemovePieceFromParent(this);
		this.attachIndex = newAttachIndex;
		this.parentPiece = newParentPiece;
		this.parentAttachIndex = newParentAttachIndex;
		this.attachBounds = newAttachBounds;
		this.parentAttachBounds = newParentAttachBounds;
		this.AddPieceToParent(this);
		Transform parent = null;
		if (newParentPiece != null)
		{
			if (newParentAttachIndex >= 0)
			{
				parent = newParentPiece.gridPlanes[newParentAttachIndex].transform;
			}
			else
			{
				parent = newParentPiece.transform;
			}
			if (newParentPiece != null)
			{
				this.AddSnapToGrid(this.attachIndex, this.attachBounds);
				newParentPiece.AddSnapToGrid(this.parentAttachIndex, this.parentAttachBounds);
			}
		}
		base.transform.SetParent(parent, true);
		this.requestedParentPiece = null;
	}

	// Token: 0x060011F8 RID: 4600 RVA: 0x0005D864 File Offset: 0x0005BA64
	public void ClearParentPiece()
	{
		if (this.parentPiece == null)
		{
			return;
		}
		if (this.parentPiece != null)
		{
			this.RemoveSnapFromGrid(this.attachIndex, this.attachBounds);
			this.parentPiece.RemoveSnapFromGrid(this.parentAttachIndex, this.parentAttachBounds);
			this.attachBounds.Clear();
			this.parentAttachBounds.Clear();
		}
		BuilderPiece.RemovePieceFromParent(this);
		this.attachIndex = -1;
		this.parentPiece = null;
		this.parentAttachIndex = -1;
		base.transform.SetParent(null, true);
		this.requestedParentPiece = null;
	}

	// Token: 0x060011F9 RID: 4601 RVA: 0x0005D8FC File Offset: 0x0005BAFC
	private void AddSnapToGrid(int attachGridIndex, SnapBounds bounds)
	{
		this.gridPlanes[attachGridIndex].SetConnected(bounds, true);
	}

	// Token: 0x060011FA RID: 4602 RVA: 0x0005D911 File Offset: 0x0005BB11
	private void RemoveSnapFromGrid(int attachGridIndex, SnapBounds bounds)
	{
		this.gridPlanes[attachGridIndex].SetConnected(bounds, false);
	}

	// Token: 0x060011FB RID: 4603 RVA: 0x0005D928 File Offset: 0x0005BB28
	private void AddPieceToParent(BuilderPiece piece)
	{
		BuilderPiece builderPiece = piece.parentPiece;
		if (builderPiece == null)
		{
			return;
		}
		this.nextSiblingPiece = builderPiece.firstChildPiece;
		builderPiece.firstChildPiece = piece;
	}

	// Token: 0x060011FC RID: 4604 RVA: 0x0005D95C File Offset: 0x0005BB5C
	private static void RemovePieceFromParent(BuilderPiece piece)
	{
		BuilderPiece builderPiece = piece.parentPiece;
		if (builderPiece == null)
		{
			return;
		}
		BuilderPiece builderPiece2 = builderPiece.firstChildPiece;
		if (builderPiece2 == null)
		{
			Debug.LogErrorFormat("Parent {0} of piece {1} doesn't have any children", new object[]
			{
				builderPiece.name,
				piece.name
			});
		}
		bool flag = false;
		if (builderPiece2 == piece)
		{
			builderPiece.firstChildPiece = builderPiece2.nextSiblingPiece;
			flag = true;
		}
		else
		{
			while (builderPiece2 != null)
			{
				if (builderPiece2.nextSiblingPiece == piece)
				{
					builderPiece2.nextSiblingPiece = piece.nextSiblingPiece;
					piece.nextSiblingPiece = null;
					flag = true;
					break;
				}
				builderPiece2 = builderPiece2.nextSiblingPiece;
			}
		}
		if (!flag)
		{
			Debug.LogErrorFormat("Parent {0} of piece {1} doesn't have the piece a child", new object[]
			{
				builderPiece.name,
				piece.name
			});
		}
	}

	// Token: 0x060011FD RID: 4605 RVA: 0x0005DA24 File Offset: 0x0005BC24
	public void SetParentHeld(Transform parentHeld, int heldByPlayerActorNumber, bool heldInLeftHand)
	{
		if (this.parentPiece != null)
		{
			Debug.LogErrorFormat(this.parentPiece.gameObject, "Cannot hold while already attached to piece {0}", new object[]
			{
				this.parentPiece.gameObject.name
			});
			return;
		}
		this.heldByPlayerActorNumber = heldByPlayerActorNumber;
		this.parentHeld = parentHeld;
		this.heldInLeftHand = heldInLeftHand;
		base.transform.SetParent(parentHeld);
	}

	// Token: 0x060011FE RID: 4606 RVA: 0x0005DA8F File Offset: 0x0005BC8F
	public void ClearParentHeld()
	{
		if (this.parentHeld == null)
		{
			return;
		}
		this.heldByPlayerActorNumber = -1;
		this.parentHeld = null;
		this.heldInLeftHand = false;
		base.transform.SetParent(this.parentHeld);
	}

	// Token: 0x060011FF RID: 4607 RVA: 0x0005DAC8 File Offset: 0x0005BCC8
	public void SetState(BuilderPiece.State newState, bool force = false)
	{
		if (newState == this.state && !force)
		{
			return;
		}
		BuilderPiece.State state = this.state;
		this.state = newState;
		switch (this.state)
		{
		case BuilderPiece.State.AttachedAndPlaced:
			this.SetCollidersEnabled<Collider>(this.colliders, true);
			this.SetBehavioursEnabled<Behaviour>(this.onlyWhenPlacedBehaviours, true);
			this.SetActive(this.onlyWhenPlaced, true);
			this.SetActive(this.onlyWhenNotPlaced, false);
			this.SetKinematic(true);
			this.SetColliderLayers<Collider>(this.colliders, BuilderTable.placedLayer);
			this.SetChildrenState(BuilderPiece.State.AttachedAndPlaced);
			this.SetStatic(false, force || this.areMeshesToggledOnPlace);
			this.SetPieceActive(this.pieceComponents, true);
			this.SetTint(BuilderTable.instance.defaultTint);
			return;
		case BuilderPiece.State.AttachedToDropped:
			this.SetCollidersEnabled<Collider>(this.colliders, true);
			this.SetBehavioursEnabled<Behaviour>(this.onlyWhenPlacedBehaviours, false);
			this.SetActive(this.onlyWhenPlaced, false);
			this.SetActive(this.onlyWhenNotPlaced, true);
			this.SetKinematic(true);
			this.SetColliderLayers<Collider>(this.colliders, BuilderTable.droppedLayer);
			this.SetChildrenState(BuilderPiece.State.AttachedToDropped);
			this.SetStatic(false, force);
			this.SetPieceActive(this.pieceComponents, false);
			this.SetTint(BuilderTable.instance.droppedTint);
			return;
		case BuilderPiece.State.Grabbed:
		{
			this.SetCollidersEnabled<Collider>(this.colliders, true);
			this.SetBehavioursEnabled<Behaviour>(this.onlyWhenPlacedBehaviours, false);
			this.SetActive(this.onlyWhenPlaced, false);
			this.SetActive(this.onlyWhenNotPlaced, true);
			this.SetKinematic(true);
			NetPlayer netPlayer = (this.heldByPlayerActorNumber == -1) ? null : NetworkSystem.Instance.GetPlayer(this.heldByPlayerActorNumber);
			int layer = (netPlayer == null || netPlayer.IsLocal) ? BuilderTable.heldLayerLocal : BuilderTable.heldLayer;
			this.SetColliderLayers<Collider>(this.colliders, layer);
			this.SetChildrenState(BuilderPiece.State.Grabbed);
			this.SetStatic(false, force || (this.areMeshesToggledOnPlace && state == BuilderPiece.State.AttachedAndPlaced));
			this.SetPieceActive(this.pieceComponents, false);
			this.SetTint(BuilderTable.instance.grabbedTint);
			return;
		}
		case BuilderPiece.State.Dropped:
			this.SetCollidersEnabled<Collider>(this.colliders, true);
			this.SetBehavioursEnabled<Behaviour>(this.onlyWhenPlacedBehaviours, false);
			this.SetActive(this.onlyWhenPlaced, false);
			this.SetActive(this.onlyWhenNotPlaced, true);
			this.SetKinematic(false);
			this.SetColliderLayers<Collider>(this.colliders, BuilderTable.droppedLayer);
			this.SetChildrenState(BuilderPiece.State.AttachedToDropped);
			this.SetStatic(false, force);
			this.SetPieceActive(this.pieceComponents, false);
			this.SetTint(BuilderTable.instance.droppedTint);
			return;
		case BuilderPiece.State.OnShelf:
			this.SetCollidersEnabled<Collider>(this.colliders, true);
			this.SetBehavioursEnabled<Behaviour>(this.onlyWhenPlacedBehaviours, false);
			this.SetActive(this.onlyWhenPlaced, false);
			this.SetActive(this.onlyWhenNotPlaced, true);
			this.SetKinematic(true);
			this.SetColliderLayers<Collider>(this.colliders, BuilderTable.droppedLayer);
			this.SetChildrenState(BuilderPiece.State.OnShelf);
			this.SetStatic(true, force);
			this.SetPieceActive(this.pieceComponents, false);
			this.SetTint(BuilderTable.instance.shelfTint);
			return;
		case BuilderPiece.State.Displayed:
			this.SetCollidersEnabled<Collider>(this.colliders, false);
			this.SetBehavioursEnabled<Behaviour>(this.onlyWhenPlacedBehaviours, false);
			this.SetActive(this.onlyWhenPlaced, false);
			this.SetActive(this.onlyWhenNotPlaced, true);
			this.SetKinematic(true);
			this.SetChildrenState(BuilderPiece.State.Displayed);
			this.SetStatic(false, force);
			this.SetPieceActive(this.pieceComponents, false);
			this.SetTint(BuilderTable.instance.defaultTint);
			return;
		default:
			return;
		}
	}

	// Token: 0x06001200 RID: 4608 RVA: 0x0005DE2C File Offset: 0x0005C02C
	public void SetKinematic(bool kinematic)
	{
		if (kinematic && this.rigidBody != null)
		{
			Object.Destroy(this.rigidBody);
			this.rigidBody = null;
			return;
		}
		if (!kinematic && this.rigidBody == null)
		{
			this.rigidBody = base.gameObject.AddComponent<Rigidbody>();
			if (this.rigidBody == null)
			{
				this.rigidBody = base.gameObject.GetComponent<Rigidbody>();
				Debug.LogErrorFormat("We should never already have a rigid body here {0} {1}", new object[]
				{
					this.pieceId,
					this.pieceType
				});
			}
			if (this.rigidBody != null)
			{
				this.rigidBody.mass = 10000f;
			}
		}
	}

	// Token: 0x06001201 RID: 4609 RVA: 0x00003051 File Offset: 0x00001251
	public void SetStatic(bool isStatic, bool force = false)
	{
	}

	// Token: 0x06001202 RID: 4610 RVA: 0x0005DEEC File Offset: 0x0005C0EC
	private void SetChildrenState(BuilderPiece.State newState)
	{
		BuilderPiece builderPiece = this.firstChildPiece;
		while (builderPiece != null)
		{
			builderPiece.SetState(newState, false);
			builderPiece = builderPiece.nextSiblingPiece;
		}
	}

	// Token: 0x06001203 RID: 4611 RVA: 0x0005DF1C File Offset: 0x0005C11C
	public void OnCreate()
	{
		for (int i = 0; i < this.pieceComponents.Count; i++)
		{
			this.pieceComponents[i].OnPieceCreate(this.pieceType, this.pieceId);
		}
	}

	// Token: 0x06001204 RID: 4612 RVA: 0x0005DF5C File Offset: 0x0005C15C
	public void PlayPlacementFx()
	{
		if (this.placeVFX != null)
		{
			this.PlayVFX(this.placeVFX);
		}
	}

	// Token: 0x06001205 RID: 4613 RVA: 0x0005DF78 File Offset: 0x0005C178
	public void PlayDisconnectFx()
	{
		if (this.disconnectVFX != null)
		{
			this.PlayVFX(this.disconnectVFX);
		}
	}

	// Token: 0x06001206 RID: 4614 RVA: 0x0005DF94 File Offset: 0x0005C194
	public void PlayGrabbedFx()
	{
		if (this.grabbedVFX != null)
		{
			this.PlayVFX(this.grabbedVFX);
		}
	}

	// Token: 0x06001207 RID: 4615 RVA: 0x0005DFB0 File Offset: 0x0005C1B0
	public void PlayLocationLockFx()
	{
		if (this.locationLockVFX != null)
		{
			this.PlayVFX(this.locationLockVFX);
		}
	}

	// Token: 0x06001208 RID: 4616 RVA: 0x0005DFCC File Offset: 0x0005C1CC
	private void PlayVFX(GameObject vfx)
	{
		ObjectPools.instance.Instantiate(vfx, base.transform.position);
	}

	// Token: 0x06001209 RID: 4617 RVA: 0x0005DFE8 File Offset: 0x0005C1E8
	public static BuilderPiece GetBuilderPieceFromCollider(Collider collider)
	{
		if (collider == null)
		{
			return null;
		}
		BuilderPieceCollider component = collider.GetComponent<BuilderPieceCollider>();
		if (!(component == null))
		{
			return component.piece;
		}
		return null;
	}

	// Token: 0x0600120A RID: 4618 RVA: 0x0005E018 File Offset: 0x0005C218
	public static BuilderPiece GetBuilderPieceFromTransform(Transform transform)
	{
		while (transform != null)
		{
			BuilderPiece component = transform.GetComponent<BuilderPiece>();
			if (component != null)
			{
				return component;
			}
			transform = transform.parent;
		}
		return null;
	}

	// Token: 0x0600120B RID: 4619 RVA: 0x0005E04C File Offset: 0x0005C24C
	public static void MakePieceRoot(BuilderPiece piece)
	{
		if (piece == null)
		{
			return;
		}
		if (piece.parentPiece == null || piece.parentPiece.isBuiltIntoTable)
		{
			return;
		}
		BuilderPiece.MakePieceRoot(piece.parentPiece);
		int newAttachIndex = piece.parentAttachIndex;
		int newParentAttachIndex = piece.attachIndex;
		BuilderPiece builderPiece = piece.parentPiece;
		SnapBounds newAttachBounds = piece.parentAttachBounds;
		SnapBounds newParentAttachBounds = piece.attachBounds;
		piece.ClearParentPiece();
		builderPiece.SetParentPiece(newAttachIndex, newAttachBounds, piece, newParentAttachIndex, newParentAttachBounds);
	}

	// Token: 0x0600120C RID: 4620 RVA: 0x0005E0BC File Offset: 0x0005C2BC
	public BuilderPiece GetRootPiece()
	{
		BuilderPiece builderPiece = this;
		while (builderPiece.parentPiece != null && !builderPiece.parentPiece.isBuiltIntoTable)
		{
			builderPiece = builderPiece.parentPiece;
		}
		return builderPiece;
	}

	// Token: 0x04001460 RID: 5216
	public const int INVALID = -1;

	// Token: 0x04001461 RID: 5217
	public string displayName;

	// Token: 0x04001462 RID: 5218
	public BuilderMaterialOptions materialOptions;

	// Token: 0x04001463 RID: 5219
	private List<MeshRenderer> materialSwapTargets;

	// Token: 0x04001464 RID: 5220
	public Transform scaleRoot;

	// Token: 0x04001465 RID: 5221
	public GameObject placeVFX;

	// Token: 0x04001466 RID: 5222
	public GameObject disconnectVFX;

	// Token: 0x04001467 RID: 5223
	public GameObject grabbedVFX;

	// Token: 0x04001468 RID: 5224
	public GameObject locationLockVFX;

	// Token: 0x04001469 RID: 5225
	public int pieceType;

	// Token: 0x0400146A RID: 5226
	public int pieceId;

	// Token: 0x0400146B RID: 5227
	[HideInInspector]
	public int materialType = -1;

	// Token: 0x0400146C RID: 5228
	public int heldByPlayerActorNumber;

	// Token: 0x0400146D RID: 5229
	public bool heldInLeftHand;

	// Token: 0x0400146E RID: 5230
	public Transform parentHeld;

	// Token: 0x0400146F RID: 5231
	public BuilderPiece parentPiece;

	// Token: 0x04001470 RID: 5232
	public BuilderPiece firstChildPiece;

	// Token: 0x04001471 RID: 5233
	public BuilderPiece nextSiblingPiece;

	// Token: 0x04001472 RID: 5234
	public int attachIndex;

	// Token: 0x04001473 RID: 5235
	public SnapBounds attachBounds;

	// Token: 0x04001474 RID: 5236
	public int parentAttachIndex;

	// Token: 0x04001475 RID: 5237
	public SnapBounds parentAttachBounds;

	// Token: 0x04001476 RID: 5238
	public List<BuilderAttachGridPlane> gridPlanes;

	// Token: 0x04001477 RID: 5239
	public List<Collider> colliders;

	// Token: 0x04001478 RID: 5240
	public List<Behaviour> onlyWhenPlacedBehaviours;

	// Token: 0x04001479 RID: 5241
	public List<IBuilderPieceComponent> pieceComponents;

	// Token: 0x0400147A RID: 5242
	private bool pieceComponentsActive;

	// Token: 0x0400147B RID: 5243
	public List<GameObject> onlyWhenPlaced;

	// Token: 0x0400147C RID: 5244
	public List<GameObject> onlyWhenNotPlaced;

	// Token: 0x0400147D RID: 5245
	public bool areMeshesToggledOnPlace;

	// Token: 0x0400147E RID: 5246
	public List<GameObject> moveToRoot;

	// Token: 0x0400147F RID: 5247
	[NonSerialized]
	public Rigidbody rigidBody;

	// Token: 0x04001480 RID: 5248
	public BasePlatform platform;

	// Token: 0x04001481 RID: 5249
	public int preventSnapUntilMoved;

	// Token: 0x04001482 RID: 5250
	public Vector3 preventSnapUntilMovedFromPos;

	// Token: 0x04001483 RID: 5251
	public BuilderPiece requestedParentPiece;

	// Token: 0x04001484 RID: 5252
	public List<MeshRenderer> meshesToCombine;

	// Token: 0x04001485 RID: 5253
	public GameObject bumpPrefab;

	// Token: 0x04001486 RID: 5254
	public List<GameObject> bumps;

	// Token: 0x04001487 RID: 5255
	public BuilderPiece.State state;

	// Token: 0x04001488 RID: 5256
	public bool isStatic;

	// Token: 0x04001489 RID: 5257
	public bool isBuiltIntoTable;

	// Token: 0x0400148A RID: 5258
	public List<MeshRenderer> renderingIndirect;

	// Token: 0x0400148B RID: 5259
	public float tint;

	// Token: 0x02000321 RID: 801
	public enum State
	{
		// Token: 0x0400148D RID: 5261
		None = -1,
		// Token: 0x0400148E RID: 5262
		AttachedAndPlaced,
		// Token: 0x0400148F RID: 5263
		AttachedToDropped,
		// Token: 0x04001490 RID: 5264
		Grabbed,
		// Token: 0x04001491 RID: 5265
		Dropped,
		// Token: 0x04001492 RID: 5266
		OnShelf,
		// Token: 0x04001493 RID: 5267
		Displayed
	}
}
