﻿using System;
using UnityEngine;

// Token: 0x020002F9 RID: 761
public class GameModePageButton : GorillaPressableButton
{
	// Token: 0x06001170 RID: 4464 RVA: 0x0005C006 File Offset: 0x0005A206
	public override void ButtonActivation()
	{
		base.ButtonActivation();
		this.selector.ChangePage(this.left);
	}

	// Token: 0x040013CB RID: 5067
	[SerializeField]
	private GameModePages selector;

	// Token: 0x040013CC RID: 5068
	[SerializeField]
	private bool left;
}
