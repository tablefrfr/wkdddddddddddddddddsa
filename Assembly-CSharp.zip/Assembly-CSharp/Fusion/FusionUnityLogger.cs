﻿using System;
using System.Text;
using UnityEngine;

namespace Fusion
{
	// Token: 0x02000634 RID: 1588
	[Serializable]
	public class FusionUnityLogger : ILogger
	{
		// Token: 0x17000438 RID: 1080
		// (get) Token: 0x0600254F RID: 9551 RVA: 0x000B714F File Offset: 0x000B534F
		// (set) Token: 0x06002550 RID: 9552 RVA: 0x000B7157 File Offset: 0x000B5357
		public Func<object, int> GetColor { get; set; }

		// Token: 0x06002551 RID: 9553 RVA: 0x000B7160 File Offset: 0x000B5360
		public FusionUnityLogger()
		{
			bool flag = false;
			this.MinRandomColor = (flag ? new Color32(158, 158, 158, byte.MaxValue) : new Color32(30, 30, 30, byte.MaxValue));
			this.MaxRandomColor = (flag ? new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, byte.MaxValue) : new Color32(90, 90, 90, byte.MaxValue));
			this.ServerColor = (flag ? new Color32(byte.MaxValue, byte.MaxValue, 158, byte.MaxValue) : new Color32(30, 90, 200, byte.MaxValue));
			this.UseColorTags = true;
			this.UseGlobalPrefix = true;
			this.GlobalPrefixColor = FusionUnityLogger.Color32ToRGBString(flag ? new Color32(115, 172, 229, byte.MaxValue) : new Color32(20, 64, 120, byte.MaxValue));
			this.GetColor = delegate(object obj)
			{
				NetworkRunner networkRunner = obj as NetworkRunner;
				if (networkRunner != null)
				{
					int hashCodeForLogger = networkRunner.GetHashCodeForLogger();
					return this.GetRandomColor(hashCodeForLogger);
				}
				return 0;
			};
		}

		// Token: 0x06002552 RID: 9554 RVA: 0x000B727C File Offset: 0x000B547C
		public void Log<T>(LogType logType, string prefix, ref T context, string message) where T : ILogBuilder
		{
			string message2;
			try
			{
				if (logType == LogType.Debug)
				{
					this._builder.Append("[DEBUG] ");
				}
				else if (logType == LogType.Trace)
				{
					this._builder.Append("[TRACE] ");
				}
				if (this.UseGlobalPrefix)
				{
					if (this.UseColorTags)
					{
						this._builder.Append("<color=");
						this._builder.Append(this.GlobalPrefixColor);
						this._builder.Append(">");
					}
					this._builder.Append("[Fusion");
					if (!string.IsNullOrEmpty(prefix))
					{
						this._builder.Append("/");
						this._builder.Append(prefix);
					}
					this._builder.Append("]");
					if (this.UseColorTags)
					{
						this._builder.Append("</color>");
					}
					this._builder.Append(" ");
				}
				else if (!string.IsNullOrEmpty(prefix))
				{
					this._builder.Append(prefix);
					this._builder.Append(": ");
				}
				LogOptions logOptions = new LogOptions(this.UseColorTags, this.GetColor);
				context.BuildLogMessage(this._builder, message, logOptions);
				message2 = this._builder.ToString();
			}
			finally
			{
				this._builder.Clear();
			}
			Object context2 = context as Object;
			if (logType == LogType.Error)
			{
				Debug.LogError(message2, context2);
				return;
			}
			if (logType != LogType.Warn)
			{
				Debug.Log(message2, context2);
				return;
			}
			Debug.LogWarning(message2, context2);
		}

		// Token: 0x06002553 RID: 9555 RVA: 0x000B7428 File Offset: 0x000B5628
		public void LogException<T>(string prefix, ref T context, Exception ex) where T : ILogBuilder
		{
			this.Log<T>(LogType.Error, string.Empty, ref context, string.Format("{0}\n<i>See next error log entry for details.</i>", ex.GetType()));
			Object @object = context as Object;
			if (@object != null)
			{
				Debug.LogException(ex, @object);
				return;
			}
			Debug.LogException(ex);
		}

		// Token: 0x06002554 RID: 9556 RVA: 0x000B7474 File Offset: 0x000B5674
		private int GetRandomColor(int seed)
		{
			return FusionUnityLogger.GetRandomColor(seed, this.MinRandomColor, this.MaxRandomColor, this.ServerColor);
		}

		// Token: 0x06002555 RID: 9557 RVA: 0x000B7494 File Offset: 0x000B5694
		private static int GetRandomColor(int seed, Color32 min, Color32 max, Color32 svr)
		{
			NetworkRNG networkRNG = new NetworkRNG(seed);
			int num;
			int num2;
			int num3;
			if (seed == -1)
			{
				num = (int)svr.r;
				num2 = (int)svr.g;
				num3 = (int)svr.b;
			}
			else
			{
				num = networkRNG.RangeInclusive((int)min.r, (int)max.r);
				num2 = networkRNG.RangeInclusive((int)min.g, (int)max.g);
				num3 = networkRNG.RangeInclusive((int)min.b, (int)max.b);
			}
			num = Mathf.Clamp(num, 0, 255);
			num2 = Mathf.Clamp(num2, 0, 255);
			num3 = Mathf.Clamp(num3, 0, 255);
			return num << 16 | num2 << 8 | num3;
		}

		// Token: 0x06002556 RID: 9558 RVA: 0x000B7531 File Offset: 0x000B5731
		private static int Color32ToRGB24(Color32 c)
		{
			return (int)c.r << 16 | (int)c.g << 8 | (int)c.b;
		}

		// Token: 0x06002557 RID: 9559 RVA: 0x000B754C File Offset: 0x000B574C
		private static string Color32ToRGBString(Color32 c)
		{
			return string.Format("#{0:X6}", FusionUnityLogger.Color32ToRGB24(c));
		}

		// Token: 0x06002558 RID: 9560 RVA: 0x000B7564 File Offset: 0x000B5764
		[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
		private static void Initialize()
		{
			if (Fusion.Log.Initialized)
			{
				return;
			}
			FusionUnityLogger fusionUnityLogger = new FusionUnityLogger();
			if (fusionUnityLogger != null)
			{
				Fusion.Log.Init(fusionUnityLogger, LogType.Debug);
			}
		}

		// Token: 0x04002807 RID: 10247
		private StringBuilder _builder = new StringBuilder();

		// Token: 0x04002808 RID: 10248
		public bool UseGlobalPrefix;

		// Token: 0x04002809 RID: 10249
		public bool UseColorTags;

		// Token: 0x0400280A RID: 10250
		public string GlobalPrefixColor;

		// Token: 0x0400280B RID: 10251
		public Color32 MinRandomColor;

		// Token: 0x0400280C RID: 10252
		public Color32 MaxRandomColor;

		// Token: 0x0400280D RID: 10253
		public Color ServerColor;
	}
}
