﻿using System;
using GorillaNetworking;
using UnityEngine;

// Token: 0x0200027B RID: 635
public class BetaChecker : MonoBehaviour
{
	// Token: 0x06000E1B RID: 3611 RVA: 0x0004A407 File Offset: 0x00048607
	private void Start()
	{
		if (PlayerPrefs.GetString("CheckedBox2") == "true")
		{
			this.doNotEnable = true;
			base.gameObject.SetActive(false);
		}
	}

	// Token: 0x06000E1C RID: 3612 RVA: 0x0004A434 File Offset: 0x00048634
	private void Update()
	{
		if (!this.doNotEnable)
		{
			if (CosmeticsController.instance.confirmedDidntPlayInBeta)
			{
				PlayerPrefs.SetString("CheckedBox2", "true");
				PlayerPrefs.Save();
				base.gameObject.SetActive(false);
				return;
			}
			if (CosmeticsController.instance.playedInBeta)
			{
				GameObject[] array = this.objectsToEnable;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].SetActive(true);
				}
				this.doNotEnable = true;
			}
		}
	}

	// Token: 0x04000FF9 RID: 4089
	public GameObject[] objectsToEnable;

	// Token: 0x04000FFA RID: 4090
	public bool doNotEnable;
}
