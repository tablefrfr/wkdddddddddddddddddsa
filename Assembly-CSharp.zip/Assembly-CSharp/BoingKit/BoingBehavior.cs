﻿using System;
using UnityEngine;

namespace BoingKit
{
	// Token: 0x020007EE RID: 2030
	public class BoingBehavior : BoingBase
	{
		// Token: 0x17000552 RID: 1362
		// (get) Token: 0x06003146 RID: 12614 RVA: 0x000F5933 File Offset: 0x000F3B33
		// (set) Token: 0x06003147 RID: 12615 RVA: 0x000F5945 File Offset: 0x000F3B45
		public Vector3Spring PositionSpring
		{
			get
			{
				return this.Params.Instance.PositionSpring;
			}
			set
			{
				this.Params.Instance.PositionSpring = value;
				this.PositionSpringDirty = true;
			}
		}

		// Token: 0x17000553 RID: 1363
		// (get) Token: 0x06003148 RID: 12616 RVA: 0x000F595F File Offset: 0x000F3B5F
		// (set) Token: 0x06003149 RID: 12617 RVA: 0x000F5971 File Offset: 0x000F3B71
		public QuaternionSpring RotationSpring
		{
			get
			{
				return this.Params.Instance.RotationSpring;
			}
			set
			{
				this.Params.Instance.RotationSpring = value;
				this.RotationSpringDirty = true;
			}
		}

		// Token: 0x17000554 RID: 1364
		// (get) Token: 0x0600314A RID: 12618 RVA: 0x000F598B File Offset: 0x000F3B8B
		// (set) Token: 0x0600314B RID: 12619 RVA: 0x000F599D File Offset: 0x000F3B9D
		public Vector3Spring ScaleSpring
		{
			get
			{
				return this.Params.Instance.ScaleSpring;
			}
			set
			{
				this.Params.Instance.ScaleSpring = value;
				this.ScaleSpringDirty = true;
			}
		}

		// Token: 0x0600314C RID: 12620 RVA: 0x000F59B7 File Offset: 0x000F3BB7
		public BoingBehavior()
		{
			this.Params.Init();
		}

		// Token: 0x0600314D RID: 12621 RVA: 0x000F59E0 File Offset: 0x000F3BE0
		public virtual void Reboot()
		{
			this.Params.Instance.PositionSpring.Reset(base.transform.position);
			this.Params.Instance.RotationSpring.Reset(base.transform.rotation);
			this.Params.Instance.ScaleSpring.Reset(base.transform.localScale);
			this.CachedPositionLs = base.transform.localPosition;
			this.CachedRotationLs = base.transform.localRotation;
			this.CachedPositionWs = base.transform.position;
			this.CachedRotationWs = base.transform.rotation;
			this.CachedScaleLs = base.transform.localScale;
			this.CachedTransformValid = true;
		}

		// Token: 0x0600314E RID: 12622 RVA: 0x000F5AA9 File Offset: 0x000F3CA9
		public virtual void OnEnable()
		{
			this.CachedTransformValid = false;
			this.InitRebooted = false;
			this.Register();
		}

		// Token: 0x0600314F RID: 12623 RVA: 0x000F5ABF File Offset: 0x000F3CBF
		public void Start()
		{
			this.InitRebooted = false;
		}

		// Token: 0x06003150 RID: 12624 RVA: 0x000F5AC8 File Offset: 0x000F3CC8
		public virtual void OnDisable()
		{
			this.Unregister();
		}

		// Token: 0x06003151 RID: 12625 RVA: 0x000F5AD0 File Offset: 0x000F3CD0
		protected virtual void Register()
		{
			BoingManager.Register(this);
		}

		// Token: 0x06003152 RID: 12626 RVA: 0x000F5AD8 File Offset: 0x000F3CD8
		protected virtual void Unregister()
		{
			BoingManager.Unregister(this);
		}

		// Token: 0x06003153 RID: 12627 RVA: 0x000F5AE0 File Offset: 0x000F3CE0
		public void UpdateFlags()
		{
			this.Params.Bits.SetBit(0, this.TwoDDistanceCheck);
			this.Params.Bits.SetBit(1, this.TwoDPositionInfluence);
			this.Params.Bits.SetBit(2, this.TwoDRotationInfluence);
			this.Params.Bits.SetBit(3, this.EnablePositionEffect);
			this.Params.Bits.SetBit(4, this.EnableRotationEffect);
			this.Params.Bits.SetBit(5, this.EnableScaleEffect);
			this.Params.Bits.SetBit(6, this.GlobalReactionUpVector);
			this.Params.Bits.SetBit(9, this.UpdateMode == BoingManager.UpdateMode.FixedUpdate);
			this.Params.Bits.SetBit(10, this.UpdateMode == BoingManager.UpdateMode.EarlyUpdate);
			this.Params.Bits.SetBit(11, this.UpdateMode == BoingManager.UpdateMode.LateUpdate);
		}

		// Token: 0x06003154 RID: 12628 RVA: 0x000F5BDF File Offset: 0x000F3DDF
		public virtual void PrepareExecute()
		{
			this.PrepareExecute(false);
		}

		// Token: 0x06003155 RID: 12629 RVA: 0x000F5BE8 File Offset: 0x000F3DE8
		protected void PrepareExecute(bool accumulateEffectors)
		{
			if (this.SharedParams != null)
			{
				BoingWork.Params.Copy(ref this.SharedParams.Params, ref this.Params);
			}
			this.UpdateFlags();
			this.Params.InstanceID = base.GetInstanceID();
			this.Params.Instance.PrepareExecute(ref this.Params, this.CachedPositionWs, this.CachedRotationWs, base.transform.localScale, accumulateEffectors);
		}

		// Token: 0x06003156 RID: 12630 RVA: 0x000F5C5E File Offset: 0x000F3E5E
		public void Execute(float dt)
		{
			this.Params.Execute(dt);
		}

		// Token: 0x06003157 RID: 12631 RVA: 0x000F5C6C File Offset: 0x000F3E6C
		public void PullResults()
		{
			this.PullResults(ref this.Params);
		}

		// Token: 0x06003158 RID: 12632 RVA: 0x000F5C7C File Offset: 0x000F3E7C
		public void GatherOutput(ref BoingWork.Output o)
		{
			if (!BoingManager.UseAsynchronousJobs)
			{
				this.Params.Instance.PositionSpring = o.PositionSpring;
				this.Params.Instance.RotationSpring = o.RotationSpring;
				this.Params.Instance.ScaleSpring = o.ScaleSpring;
				return;
			}
			if (this.PositionSpringDirty)
			{
				this.PositionSpringDirty = false;
			}
			else
			{
				this.Params.Instance.PositionSpring = o.PositionSpring;
			}
			if (this.RotationSpringDirty)
			{
				this.RotationSpringDirty = false;
			}
			else
			{
				this.Params.Instance.RotationSpring = o.RotationSpring;
			}
			if (this.ScaleSpringDirty)
			{
				this.ScaleSpringDirty = false;
				return;
			}
			this.Params.Instance.ScaleSpring = o.ScaleSpring;
		}

		// Token: 0x06003159 RID: 12633 RVA: 0x000F5D48 File Offset: 0x000F3F48
		private void PullResults(ref BoingWork.Params p)
		{
			this.CachedPositionLs = base.transform.localPosition;
			this.CachedPositionWs = base.transform.position;
			this.RenderPositionWs = BoingWork.ComputeTranslationalResults(base.transform, base.transform.position, p.Instance.PositionSpring.Value, this);
			base.transform.position = this.RenderPositionWs;
			this.CachedRotationLs = base.transform.localRotation;
			this.CachedRotationWs = base.transform.rotation;
			this.RenderRotationWs = p.Instance.RotationSpring.ValueQuat;
			base.transform.rotation = this.RenderRotationWs;
			this.CachedScaleLs = base.transform.localScale;
			this.RenderScaleLs = p.Instance.ScaleSpring.Value;
			base.transform.localScale = this.RenderScaleLs;
			this.CachedTransformValid = true;
		}

		// Token: 0x0600315A RID: 12634 RVA: 0x000F5E40 File Offset: 0x000F4040
		public virtual void Restore()
		{
			if (!this.CachedTransformValid)
			{
				return;
			}
			if (Application.isEditor)
			{
				if ((base.transform.position - this.RenderPositionWs).sqrMagnitude < 0.0001f)
				{
					base.transform.localPosition = this.CachedPositionLs;
				}
				if (QuaternionUtil.GetAngle(base.transform.rotation * Quaternion.Inverse(this.RenderRotationWs)) < 0.01f)
				{
					base.transform.localRotation = this.CachedRotationLs;
				}
				if ((base.transform.localScale - this.RenderScaleLs).sqrMagnitude < 0.0001f)
				{
					base.transform.localScale = this.CachedScaleLs;
					return;
				}
			}
			else
			{
				base.transform.localPosition = this.CachedPositionLs;
				base.transform.localRotation = this.CachedRotationLs;
				base.transform.localScale = this.CachedScaleLs;
			}
		}

		// Token: 0x0400338B RID: 13195
		public BoingManager.UpdateMode UpdateMode = BoingManager.UpdateMode.LateUpdate;

		// Token: 0x0400338C RID: 13196
		public bool TwoDDistanceCheck;

		// Token: 0x0400338D RID: 13197
		public bool TwoDPositionInfluence;

		// Token: 0x0400338E RID: 13198
		public bool TwoDRotationInfluence;

		// Token: 0x0400338F RID: 13199
		public bool EnablePositionEffect = true;

		// Token: 0x04003390 RID: 13200
		public bool EnableRotationEffect = true;

		// Token: 0x04003391 RID: 13201
		public bool EnableScaleEffect;

		// Token: 0x04003392 RID: 13202
		public bool GlobalReactionUpVector;

		// Token: 0x04003393 RID: 13203
		public BoingManager.TranslationLockSpace TranslationLockSpace;

		// Token: 0x04003394 RID: 13204
		public bool LockTranslationX;

		// Token: 0x04003395 RID: 13205
		public bool LockTranslationY;

		// Token: 0x04003396 RID: 13206
		public bool LockTranslationZ;

		// Token: 0x04003397 RID: 13207
		public BoingWork.Params Params;

		// Token: 0x04003398 RID: 13208
		public SharedBoingParams SharedParams;

		// Token: 0x04003399 RID: 13209
		internal bool PositionSpringDirty;

		// Token: 0x0400339A RID: 13210
		internal bool RotationSpringDirty;

		// Token: 0x0400339B RID: 13211
		internal bool ScaleSpringDirty;

		// Token: 0x0400339C RID: 13212
		internal bool CachedTransformValid;

		// Token: 0x0400339D RID: 13213
		internal Vector3 CachedPositionLs;

		// Token: 0x0400339E RID: 13214
		internal Vector3 CachedPositionWs;

		// Token: 0x0400339F RID: 13215
		internal Vector3 RenderPositionWs;

		// Token: 0x040033A0 RID: 13216
		internal Quaternion CachedRotationLs;

		// Token: 0x040033A1 RID: 13217
		internal Quaternion CachedRotationWs;

		// Token: 0x040033A2 RID: 13218
		internal Quaternion RenderRotationWs;

		// Token: 0x040033A3 RID: 13219
		internal Vector3 CachedScaleLs;

		// Token: 0x040033A4 RID: 13220
		internal Vector3 RenderScaleLs;

		// Token: 0x040033A5 RID: 13221
		internal bool InitRebooted;
	}
}
