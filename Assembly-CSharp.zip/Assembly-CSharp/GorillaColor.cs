﻿using System;

// Token: 0x02000368 RID: 872
public class GorillaColor : GorillaTriggerBox
{
	// Token: 0x040016B2 RID: 5810
	public bool setRandomly;
}
