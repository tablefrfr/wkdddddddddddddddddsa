﻿using System;
using System.Collections.Generic;
using System.Linq;
using GorillaExtensions;
using GorillaLocomotion.Climbing;
using Photon.Pun;
using UnityEngine;
using UnityEngine.XR;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005C3 RID: 1475
	public class GorillaRopeSwing : MonoBehaviour, IBuilderPieceComponent
	{
		// Token: 0x06002272 RID: 8818 RVA: 0x000A79C4 File Offset: 0x000A5BC4
		private void EdRecalculateId()
		{
			this.CalculateId(true);
		}

		// Token: 0x17000408 RID: 1032
		// (get) Token: 0x06002273 RID: 8819 RVA: 0x000A79CD File Offset: 0x000A5BCD
		// (set) Token: 0x06002274 RID: 8820 RVA: 0x000A79D5 File Offset: 0x000A5BD5
		public bool isIdle { get; private set; }

		// Token: 0x17000409 RID: 1033
		// (get) Token: 0x06002275 RID: 8821 RVA: 0x000A79DE File Offset: 0x000A5BDE
		// (set) Token: 0x06002276 RID: 8822 RVA: 0x000A79E6 File Offset: 0x000A5BE6
		public bool isFullyIdle { get; private set; }

		// Token: 0x1700040A RID: 1034
		// (get) Token: 0x06002277 RID: 8823 RVA: 0x000A79EF File Offset: 0x000A5BEF
		public bool SupportsMovingAtRuntime
		{
			get
			{
				return this.supportMovingAtRuntime;
			}
		}

		// Token: 0x1700040B RID: 1035
		// (get) Token: 0x06002278 RID: 8824 RVA: 0x000A79F7 File Offset: 0x000A5BF7
		public bool hasPlayers
		{
			get
			{
				return this.localPlayerOn || this.remotePlayers.Count > 0;
			}
		}

		// Token: 0x06002279 RID: 8825 RVA: 0x000A7A14 File Offset: 0x000A5C14
		private void Awake()
		{
			base.transform.rotation = Quaternion.identity;
			this.scaleFactor = (base.transform.lossyScale.x + base.transform.lossyScale.y + base.transform.lossyScale.z) / 3f;
			this.SetIsIdle(true, false);
		}

		// Token: 0x0600227A RID: 8826 RVA: 0x000A7A77 File Offset: 0x000A5C77
		private void Start()
		{
			if (!this.useStaticId)
			{
				this.CalculateId(false);
			}
			RopeSwingManager.Register(this);
		}

		// Token: 0x0600227B RID: 8827 RVA: 0x000A7A8E File Offset: 0x000A5C8E
		private void OnDestroy()
		{
			RopeSwingManager.Unregister(this);
		}

		// Token: 0x0600227C RID: 8828 RVA: 0x000A7A98 File Offset: 0x000A5C98
		private void OnEnable()
		{
			base.transform.rotation = Quaternion.identity;
			this.scaleFactor = (base.transform.lossyScale.x + base.transform.lossyScale.y + base.transform.lossyScale.z) / 3f;
			this.SetIsIdle(true, true);
			VectorizedCustomRopeSimulation.Register(this);
			GorillaRopeSwingUpdateManager.RegisterRopeSwing(this);
		}

		// Token: 0x0600227D RID: 8829 RVA: 0x000A7B07 File Offset: 0x000A5D07
		private void OnDisable()
		{
			if (!this.isIdle)
			{
				this.SetIsIdle(true, true);
			}
			VectorizedCustomRopeSimulation.Unregister(this);
			GorillaRopeSwingUpdateManager.UnregisterRopeSwing(this);
		}

		// Token: 0x0600227E RID: 8830 RVA: 0x000A7B28 File Offset: 0x000A5D28
		internal void CalculateId(bool force = false)
		{
			Transform transform = base.transform;
			int staticHash = TransformUtils.GetScenePath(transform).GetStaticHash();
			int staticHash2 = base.GetType().Name.GetStaticHash();
			int num = StaticHash.Combine(staticHash, staticHash2);
			if (this.useStaticId)
			{
				if (string.IsNullOrEmpty(this.staticId) || force)
				{
					Vector3 position = transform.position;
					int i = StaticHash.Combine(position.x, position.y, position.z);
					int instanceID = transform.GetInstanceID();
					int num2 = StaticHash.Combine(num, i, instanceID);
					this.staticId = string.Format("#ID_{0:X8}", num2);
				}
				this.ropeId = this.staticId.GetStaticHash();
				return;
			}
			this.ropeId = (Application.isPlaying ? num : 0);
		}

		// Token: 0x0600227F RID: 8831 RVA: 0x000A7BE4 File Offset: 0x000A5DE4
		public void InvokeUpdate()
		{
			if (this.isIdle)
			{
				this.isFullyIdle = true;
			}
			if (!this.isIdle)
			{
				int num = -1;
				if (this.localPlayerOn)
				{
					num = this.localPlayerBoneIndex;
				}
				else if (this.remotePlayers.Count > 0)
				{
					num = this.remotePlayers.First<KeyValuePair<int, int>>().Value;
				}
				if (num >= 0 && VectorizedCustomRopeSimulation.instance.GetNodeVelocity(this, num).magnitude > 2f && !this.ropeCreakSFX.isPlaying && Mathf.RoundToInt(Time.time) % 5 == 0)
				{
					this.ropeCreakSFX.Play();
				}
				if (this.localPlayerOn)
				{
					float num2 = MathUtils.Linear(this.velocityTracker.GetLatestVelocity(true).magnitude / this.scaleFactor, 0f, 10f, -0.07f, 0.5f);
					if (num2 > 0f)
					{
						GorillaTagger.Instance.DoVibration(this.localPlayerXRNode, num2, Time.deltaTime);
					}
				}
				Transform bone = this.GetBone(this.lastNodeCheckIndex);
				Vector3 nodeVelocity = VectorizedCustomRopeSimulation.instance.GetNodeVelocity(this, this.lastNodeCheckIndex);
				if (Physics.SphereCastNonAlloc(bone.position, 0.2f * this.scaleFactor, nodeVelocity.normalized, this.nodeHits, 0.4f * this.scaleFactor, this.wallLayerMask, QueryTriggerInteraction.Ignore) > 0)
				{
					this.SetVelocity(this.lastNodeCheckIndex, Vector3.zero, false, default(PhotonMessageInfo));
				}
				if (nodeVelocity.magnitude <= 0.35f)
				{
					this.potentialIdleTimer += Time.deltaTime;
				}
				else
				{
					this.potentialIdleTimer = 0f;
				}
				if (this.potentialIdleTimer >= 2f)
				{
					this.SetIsIdle(true, false);
					this.potentialIdleTimer = 0f;
				}
				this.lastNodeCheckIndex++;
				if (this.lastNodeCheckIndex > this.nodes.Length)
				{
					this.lastNodeCheckIndex = 2;
				}
			}
		}

		// Token: 0x06002280 RID: 8832 RVA: 0x000A7DD0 File Offset: 0x000A5FD0
		private void SetIsIdle(bool idle, bool resetPos = false)
		{
			this.isIdle = idle;
			this.ropeCreakSFX.gameObject.SetActive(!idle);
			if (idle)
			{
				this.ToggleVelocityTracker(false, 0, default(Vector3));
				if (resetPos)
				{
					Vector3 vector = Vector3.zero;
					for (int i = 0; i < this.nodes.Length; i++)
					{
						this.nodes[i].transform.localRotation = Quaternion.identity;
						this.nodes[i].transform.localPosition = vector;
						vector += new Vector3(0f, -1f, 0f);
					}
					return;
				}
			}
			else
			{
				this.isFullyIdle = false;
			}
		}

		// Token: 0x06002281 RID: 8833 RVA: 0x000A7E75 File Offset: 0x000A6075
		public Transform GetBone(int index)
		{
			if (index >= this.nodes.Length)
			{
				return this.nodes.Last<Transform>();
			}
			return this.nodes[index];
		}

		// Token: 0x06002282 RID: 8834 RVA: 0x000A7E98 File Offset: 0x000A6098
		public int GetBoneIndex(Transform r)
		{
			for (int i = 0; i < this.nodes.Length; i++)
			{
				if (this.nodes[i] == r)
				{
					return i;
				}
			}
			return this.nodes.Length - 1;
		}

		// Token: 0x06002283 RID: 8835 RVA: 0x000A7ED4 File Offset: 0x000A60D4
		public void AttachLocalPlayer(XRNode xrNode, Transform grabbedBone, Vector3 offset, Vector3 velocity)
		{
			int boneIndex = this.GetBoneIndex(grabbedBone);
			this.localPlayerBoneIndex = boneIndex;
			velocity /= this.scaleFactor;
			velocity *= this.settings.inheritVelocityMultiplier;
			if (GorillaTagger.hasInstance && GorillaTagger.Instance.offlineVRRig)
			{
				GorillaTagger.Instance.offlineVRRig.grabbedRopeIndex = this.ropeId;
				GorillaTagger.Instance.offlineVRRig.grabbedRopeBoneIndex = boneIndex;
				GorillaTagger.Instance.offlineVRRig.grabbedRopeIsLeft = (xrNode == XRNode.LeftHand);
				GorillaTagger.Instance.offlineVRRig.grabbedRopeOffset = offset;
			}
			this.RefreshAllBonesMass();
			List<Vector3> list = new List<Vector3>();
			if (this.remotePlayers.Count <= 0)
			{
				foreach (Transform transform in this.nodes)
				{
					list.Add(transform.position);
				}
			}
			velocity.y = 0f;
			if (Time.time - this.lastGrabTime > 1f && (this.remotePlayers.Count == 0 || velocity.magnitude > 2.5f))
			{
				RopeSwingManager.instance.SendSetVelocity_RPC(this.ropeId, boneIndex, velocity, true);
			}
			this.lastGrabTime = Time.time;
			this.ropeCreakSFX.transform.parent = this.GetBone(Math.Max(0, boneIndex - 3)).transform;
			this.ropeCreakSFX.transform.localPosition = Vector3.zero;
			this.localPlayerOn = true;
			this.localPlayerXRNode = xrNode;
			this.ToggleVelocityTracker(true, boneIndex, offset);
		}

		// Token: 0x06002284 RID: 8836 RVA: 0x000A805D File Offset: 0x000A625D
		public void DetachLocalPlayer()
		{
			if (GorillaTagger.hasInstance && GorillaTagger.Instance.offlineVRRig)
			{
				GorillaTagger.Instance.offlineVRRig.grabbedRopeIndex = -1;
			}
			this.localPlayerOn = false;
			this.localPlayerBoneIndex = 0;
			this.RefreshAllBonesMass();
		}

		// Token: 0x06002285 RID: 8837 RVA: 0x000A809C File Offset: 0x000A629C
		private void ToggleVelocityTracker(bool enable, int boneIndex = 0, Vector3 offset = default(Vector3))
		{
			if (enable)
			{
				this.velocityTracker.transform.SetParent(this.GetBone(boneIndex));
				this.velocityTracker.transform.localPosition = offset;
				this.velocityTracker.ResetState();
			}
			this.velocityTracker.gameObject.SetActive(enable);
			if (enable)
			{
				this.velocityTracker.Tick();
			}
		}

		// Token: 0x06002286 RID: 8838 RVA: 0x000A8100 File Offset: 0x000A6300
		private void RefreshAllBonesMass()
		{
			int num = 0;
			foreach (KeyValuePair<int, int> keyValuePair in this.remotePlayers)
			{
				if (keyValuePair.Value > num)
				{
					num = keyValuePair.Value;
				}
			}
			if (this.localPlayerBoneIndex > num)
			{
				num = this.localPlayerBoneIndex;
			}
			VectorizedCustomRopeSimulation.instance.SetMassForPlayers(this, this.hasPlayers, num);
		}

		// Token: 0x06002287 RID: 8839 RVA: 0x000A8184 File Offset: 0x000A6384
		public bool AttachRemotePlayer(int playerId, int boneIndex, Transform offsetTransform, Vector3 offset)
		{
			Transform bone = this.GetBone(boneIndex);
			if (bone == null)
			{
				return false;
			}
			offsetTransform.SetParent(bone.transform);
			offsetTransform.localPosition = offset;
			offsetTransform.localRotation = Quaternion.identity;
			if (this.remotePlayers.ContainsKey(playerId))
			{
				Debug.LogError("already on the list!");
				return false;
			}
			this.remotePlayers.Add(playerId, boneIndex);
			this.RefreshAllBonesMass();
			return true;
		}

		// Token: 0x06002288 RID: 8840 RVA: 0x000A81F1 File Offset: 0x000A63F1
		public void DetachRemotePlayer(int playerId)
		{
			this.remotePlayers.Remove(playerId);
			this.RefreshAllBonesMass();
		}

		// Token: 0x06002289 RID: 8841 RVA: 0x000A8208 File Offset: 0x000A6408
		public void SetVelocity(int boneIndex, Vector3 velocity, bool wholeRope, PhotonMessageInfo info)
		{
			if (!base.isActiveAndEnabled)
			{
				return;
			}
			if (!velocity.IsValid())
			{
				return;
			}
			velocity.x = Mathf.Clamp(velocity.x, -100f, 100f);
			velocity.y = Mathf.Clamp(velocity.y, -100f, 100f);
			velocity.z = Mathf.Clamp(velocity.z, -100f, 100f);
			boneIndex = Mathf.Clamp(boneIndex, 0, this.nodes.Length);
			Transform bone = this.GetBone(boneIndex);
			if (!bone)
			{
				return;
			}
			if (info.Sender != null && !info.Sender.IsLocal)
			{
				VRRig vrrig = GorillaGameManager.StaticFindRigForPlayer(info.Sender);
				if (!vrrig || Vector3.Distance(bone.position, vrrig.transform.position) > 5f)
				{
					return;
				}
			}
			this.SetIsIdle(false, false);
			if (bone)
			{
				VectorizedCustomRopeSimulation.instance.SetVelocity(this, velocity, wholeRope, boneIndex);
			}
		}

		// Token: 0x0600228A RID: 8842 RVA: 0x000A8308 File Offset: 0x000A6508
		public void OnPieceCreate(int pieceType, int pieceId)
		{
			int num = StaticHash.Combine(pieceType, pieceId);
			this.staticId = string.Format("#ID_{0:X8}", num);
			this.ropeId = this.staticId.GetStaticHash();
			if (base.enabled)
			{
				base.transform.rotation = Quaternion.identity;
				this.scaleFactor = (base.transform.lossyScale.x + base.transform.lossyScale.y + base.transform.lossyScale.z) / 3f;
				this.SetIsIdle(true, true);
			}
		}

		// Token: 0x0600228B RID: 8843 RVA: 0x00003051 File Offset: 0x00001251
		public void OnPieceDestroy()
		{
		}

		// Token: 0x0600228C RID: 8844 RVA: 0x00003051 File Offset: 0x00001251
		public void OnPieceActivate()
		{
		}

		// Token: 0x0600228D RID: 8845 RVA: 0x00003051 File Offset: 0x00001251
		public void OnPieceDeactivate()
		{
		}

		// Token: 0x040024D3 RID: 9427
		public int ropeId;

		// Token: 0x040024D4 RID: 9428
		public string staticId;

		// Token: 0x040024D5 RID: 9429
		public bool useStaticId;

		// Token: 0x040024D6 RID: 9430
		public const float ropeBitGenOffset = 1f;

		// Token: 0x040024D7 RID: 9431
		[SerializeField]
		private GameObject prefabRopeBit;

		// Token: 0x040024D8 RID: 9432
		[SerializeField]
		private bool supportMovingAtRuntime;

		// Token: 0x040024D9 RID: 9433
		public Transform[] nodes = Array.Empty<Transform>();

		// Token: 0x040024DA RID: 9434
		private Dictionary<int, int> remotePlayers = new Dictionary<int, int>();

		// Token: 0x040024DB RID: 9435
		[NonSerialized]
		public float lastGrabTime;

		// Token: 0x040024DC RID: 9436
		[SerializeField]
		private AudioSource ropeCreakSFX;

		// Token: 0x040024DD RID: 9437
		public GorillaVelocityTracker velocityTracker;

		// Token: 0x040024DE RID: 9438
		private bool localPlayerOn;

		// Token: 0x040024DF RID: 9439
		private int localPlayerBoneIndex;

		// Token: 0x040024E0 RID: 9440
		private XRNode localPlayerXRNode;

		// Token: 0x040024E1 RID: 9441
		private const float MAX_VELOCITY_FOR_IDLE = 0.5f;

		// Token: 0x040024E2 RID: 9442
		private const float TIME_FOR_IDLE = 2f;

		// Token: 0x040024E5 RID: 9445
		private float potentialIdleTimer;

		// Token: 0x040024E6 RID: 9446
		[SerializeField]
		private int ropeLength = 8;

		// Token: 0x040024E7 RID: 9447
		[SerializeField]
		private GorillaRopeSwingSettings settings;

		// Token: 0x040024E8 RID: 9448
		[NonSerialized]
		public int ropeDataStartIndex;

		// Token: 0x040024E9 RID: 9449
		[NonSerialized]
		public int ropeDataIndexOffset;

		// Token: 0x040024EA RID: 9450
		[SerializeField]
		private LayerMask wallLayerMask;

		// Token: 0x040024EB RID: 9451
		private RaycastHit[] nodeHits = new RaycastHit[1];

		// Token: 0x040024EC RID: 9452
		private float scaleFactor = 1f;

		// Token: 0x040024ED RID: 9453
		private int lastNodeCheckIndex = 2;
	}
}
