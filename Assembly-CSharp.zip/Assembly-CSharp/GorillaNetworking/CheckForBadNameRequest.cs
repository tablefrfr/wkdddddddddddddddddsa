﻿using System;

namespace GorillaNetworking
{
	// Token: 0x020006CA RID: 1738
	public class CheckForBadNameRequest
	{
		// Token: 0x04002C43 RID: 11331
		public string name;

		// Token: 0x04002C44 RID: 11332
		public bool forRoom;
	}
}
