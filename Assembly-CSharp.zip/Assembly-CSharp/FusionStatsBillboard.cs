﻿using System;
using Fusion;
using UnityEngine;

// Token: 0x02000212 RID: 530
[ScriptHelp(BackColor = EditorHeaderBackColor.Olive)]
[ExecuteAlways]
public class FusionStatsBillboard : Fusion.Behaviour
{
	// Token: 0x06000B05 RID: 2821 RVA: 0x0003B421 File Offset: 0x00039621
	private void Awake()
	{
		this._fusionStats = base.GetComponent<FusionStats>();
	}

	// Token: 0x06000B06 RID: 2822 RVA: 0x0003B42F File Offset: 0x0003962F
	private void OnEnable()
	{
		this.UpdateLookAt();
	}

	// Token: 0x06000B07 RID: 2823 RVA: 0x0003B438 File Offset: 0x00039638
	private void OnDisable()
	{
		base.transform.localRotation = default(Quaternion);
	}

	// Token: 0x17000164 RID: 356
	// (get) Token: 0x06000B09 RID: 2825 RVA: 0x0003B464 File Offset: 0x00039664
	// (set) Token: 0x06000B08 RID: 2824 RVA: 0x0003B459 File Offset: 0x00039659
	private Camera MainCamera
	{
		get
		{
			float time = Time.time;
			if (time == FusionStatsBillboard._lastCameraFindTime)
			{
				return FusionStatsBillboard._currentCam;
			}
			FusionStatsBillboard._lastCameraFindTime = time;
			return FusionStatsBillboard._currentCam = Camera.main;
		}
		set
		{
			FusionStatsBillboard._currentCam = value;
		}
	}

	// Token: 0x06000B0A RID: 2826 RVA: 0x0003B42F File Offset: 0x0003962F
	private void LateUpdate()
	{
		this.UpdateLookAt();
	}

	// Token: 0x06000B0B RID: 2827 RVA: 0x0003B498 File Offset: 0x00039698
	public void UpdateLookAt()
	{
		if (this._fusionStats && this._fusionStats.CanvasType == FusionStats.StatCanvasTypes.Overlay)
		{
			return;
		}
		Camera camera = this.Camera ? this.Camera : this.MainCamera;
		if (camera && base.enabled)
		{
			base.transform.rotation = camera.transform.rotation;
		}
	}

	// Token: 0x06000B0C RID: 2828 RVA: 0x0003B502 File Offset: 0x00039702
	[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
	private static void ResetStatics()
	{
		FusionStatsBillboard._currentCam = null;
		FusionStatsBillboard._lastCameraFindTime = 0f;
	}

	// Token: 0x04000C6B RID: 3179
	[InlineHelp]
	public Camera Camera;

	// Token: 0x04000C6C RID: 3180
	private static float _lastCameraFindTime;

	// Token: 0x04000C6D RID: 3181
	private static Camera _currentCam;

	// Token: 0x04000C6E RID: 3182
	private FusionStats _fusionStats;
}
