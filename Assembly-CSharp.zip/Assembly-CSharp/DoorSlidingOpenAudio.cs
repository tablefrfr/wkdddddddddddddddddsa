﻿using System;
using UnityEngine;

// Token: 0x0200003A RID: 58
public class DoorSlidingOpenAudio : MonoBehaviour, IBuildValidation, ITickSystemTick
{
	// Token: 0x1700000A RID: 10
	// (get) Token: 0x06000116 RID: 278 RVA: 0x00009BCA File Offset: 0x00007DCA
	// (set) Token: 0x06000117 RID: 279 RVA: 0x00009BD2 File Offset: 0x00007DD2
	bool ITickSystemTick.TickRunning { get; set; }

	// Token: 0x06000118 RID: 280 RVA: 0x00009BDB File Offset: 0x00007DDB
	private void OnEnable()
	{
		TickSystem<object>.AddCallbackTarget(this);
	}

	// Token: 0x06000119 RID: 281 RVA: 0x00009BE3 File Offset: 0x00007DE3
	private void OnDisable()
	{
		TickSystem<object>.RemoveCallbackTarget(this);
	}

	// Token: 0x0600011A RID: 282 RVA: 0x00009BEC File Offset: 0x00007DEC
	public bool BuildValidationCheck()
	{
		if (this.button == null)
		{
			Debug.LogError("reference button missing for doorslidingopenaudio", base.gameObject);
			return false;
		}
		if (this.audioSource == null)
		{
			Debug.LogError("missing audio source on doorslidingopenaudio", base.gameObject);
			return false;
		}
		return true;
	}

	// Token: 0x0600011B RID: 283 RVA: 0x00009C3C File Offset: 0x00007E3C
	void ITickSystemTick.Tick()
	{
		if (this.button.ghostLab.IsDoorMoving(this.button.forSingleDoor, this.button.buttonIndex))
		{
			if (!this.audioSource.isPlaying)
			{
				this.audioSource.time = 0f;
				this.audioSource.Play();
				return;
			}
		}
		else if (this.audioSource.isPlaying)
		{
			this.audioSource.time = 0f;
			this.audioSource.Stop();
		}
	}

	// Token: 0x0400018B RID: 395
	public GhostLabButton button;

	// Token: 0x0400018C RID: 396
	public AudioSource audioSource;
}
