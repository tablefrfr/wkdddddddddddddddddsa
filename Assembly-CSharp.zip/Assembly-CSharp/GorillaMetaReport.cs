﻿using System;
using System.Collections;
using GorillaLocomotion;
using Oculus.Platform;
using Oculus.Platform.Models;
using Photon.Pun;
using UnityEngine;
using UnityEngine.UI;
using Valve.VR;

// Token: 0x02000230 RID: 560
public class GorillaMetaReport : MonoBehaviour
{
	// Token: 0x1700017B RID: 379
	// (get) Token: 0x06000BC6 RID: 3014 RVA: 0x0003EC2F File Offset: 0x0003CE2F
	private Player localPlayer
	{
		get
		{
			return Player.Instance;
		}
	}

	// Token: 0x06000BC7 RID: 3015 RVA: 0x0003EC36 File Offset: 0x0003CE36
	private void Start()
	{
		this.localPlayer.inOverlay = false;
		Core.AsyncInitialize(null).OnComplete(delegate(Message<PlatformInitialize> message)
		{
			if (!message.IsError)
			{
				AbuseReport.SetReportButtonPressedNotificationCallback(new Message<string>.Callback(this.OnReportButtonIntentNotif));
			}
		});
		base.gameObject.SetActive(false);
	}

	// Token: 0x06000BC8 RID: 3016 RVA: 0x0003EC68 File Offset: 0x0003CE68
	private void OnDisable()
	{
		if (ApplicationQuittingState.IsQuitting)
		{
			return;
		}
		this.localPlayer.inOverlay = false;
		base.StopAllCoroutines();
	}

	// Token: 0x06000BC9 RID: 3017 RVA: 0x0003EC84 File Offset: 0x0003CE84
	private void OnReportButtonIntentNotif(Message<string> message)
	{
		if (message.IsError)
		{
			AbuseReport.ReportRequestHandled(ReportRequestResponse.Unhandled);
			return;
		}
		if (!PhotonNetwork.InRoom)
		{
			this.ReportText.SetActive(true);
			AbuseReport.ReportRequestHandled(ReportRequestResponse.Handled);
			this.StartOverlay();
			return;
		}
		if (!message.IsError)
		{
			AbuseReport.ReportRequestHandled(ReportRequestResponse.Handled);
			this.StartOverlay();
		}
	}

	// Token: 0x06000BCA RID: 3018 RVA: 0x0003ECD7 File Offset: 0x0003CED7
	private IEnumerator Submitted()
	{
		yield return new WaitForSeconds(1.5f);
		this.Teardown();
		yield break;
	}

	// Token: 0x06000BCB RID: 3019 RVA: 0x0003ECE8 File Offset: 0x0003CEE8
	private void DuplicateScoreboard()
	{
		this.currentScoreboard.gameObject.SetActive(true);
		if (GorillaScoreboardTotalUpdater.instance != null)
		{
			GorillaScoreboardTotalUpdater.instance.UpdateScoreboard(this.currentScoreboard);
		}
		Vector3 position;
		Quaternion rotation;
		Vector3 vector;
		this.GetIdealScreenPositionRotation(out position, out rotation, out vector);
		this.currentScoreboard.transform.SetPositionAndRotation(position, rotation);
		this.reportScoreboard.transform.SetPositionAndRotation(position, rotation);
	}

	// Token: 0x06000BCC RID: 3020 RVA: 0x0003ED54 File Offset: 0x0003CF54
	private void ToggleLevelVisibility(bool state)
	{
		Camera component = GorillaTagger.Instance.mainCamera.GetComponent<Camera>();
		if (state)
		{
			component.cullingMask = this.savedCullingLayers;
			return;
		}
		this.savedCullingLayers = component.cullingMask;
		component.cullingMask = this.visibleLayers;
	}

	// Token: 0x06000BCD RID: 3021 RVA: 0x0003EDA0 File Offset: 0x0003CFA0
	private void Teardown()
	{
		this.ReportText.GetComponent<Text>().text = "NOT CURRENTLY CONNECTED TO A ROOM";
		this.ReportText.SetActive(false);
		this.localPlayer.inOverlay = false;
		this.localPlayer.disableMovement = false;
		this.closeButton.selected = false;
		this.closeButton.isOn = false;
		this.closeButton.UpdateColor();
		this.localPlayer.InReportMenu = false;
		this.ToggleLevelVisibility(true);
		base.gameObject.SetActive(false);
		foreach (GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine in this.currentScoreboard.lines)
		{
			gorillaPlayerScoreboardLine.doneReporting = false;
		}
		GorillaScoreboardTotalUpdater.instance.UpdateActiveScoreboards();
	}

	// Token: 0x06000BCE RID: 3022 RVA: 0x0003EE7C File Offset: 0x0003D07C
	private void CheckReportSubmit()
	{
		if (this.currentScoreboard == null)
		{
			return;
		}
		foreach (GorillaPlayerScoreboardLine gorillaPlayerScoreboardLine in this.currentScoreboard.lines)
		{
			if (gorillaPlayerScoreboardLine.doneReporting)
			{
				this.ReportText.SetActive(true);
				this.ReportText.GetComponent<Text>().text = "REPORTED " + gorillaPlayerScoreboardLine.playerNameValue;
				this.currentScoreboard.gameObject.SetActive(false);
				base.StartCoroutine(this.Submitted());
			}
		}
	}

	// Token: 0x06000BCF RID: 3023 RVA: 0x0003EF30 File Offset: 0x0003D130
	private void GetIdealScreenPositionRotation(out Vector3 position, out Quaternion rotation, out Vector3 scale)
	{
		GameObject mainCamera = GorillaTagger.Instance.mainCamera;
		rotation = Quaternion.Euler(0f, mainCamera.transform.eulerAngles.y, 0f);
		scale = this.localPlayer.turnParent.transform.localScale;
		position = mainCamera.transform.position + rotation * this.playerLocalScreenPosition * scale.x;
	}

	// Token: 0x06000BD0 RID: 3024 RVA: 0x0003EFBC File Offset: 0x0003D1BC
	private void StartOverlay()
	{
		Vector3 position;
		Quaternion rotation;
		Vector3 localScale;
		this.GetIdealScreenPositionRotation(out position, out rotation, out localScale);
		this.currentScoreboard.transform.localScale = localScale;
		this.reportScoreboard.transform.localScale = localScale;
		this.leftHandObject.transform.localScale = localScale;
		this.rightHandObject.transform.localScale = localScale;
		this.occluder.transform.localScale = localScale;
		if (this.localPlayer.InReportMenu && !PhotonNetwork.InRoom)
		{
			return;
		}
		this.localPlayer.InReportMenu = true;
		this.localPlayer.disableMovement = true;
		this.localPlayer.inOverlay = true;
		base.gameObject.SetActive(true);
		if (PhotonNetwork.InRoom)
		{
			this.DuplicateScoreboard();
		}
		else
		{
			this.ReportText.SetActive(true);
			this.reportScoreboard.transform.SetPositionAndRotation(position, rotation);
			this.currentScoreboard.transform.SetPositionAndRotation(position, rotation);
		}
		this.ToggleLevelVisibility(false);
		this.rightHandObject.transform.SetPositionAndRotation(this.localPlayer.rightControllerTransform.position, this.localPlayer.rightControllerTransform.rotation);
		this.leftHandObject.transform.SetPositionAndRotation(this.localPlayer.leftControllerTransform.position, this.localPlayer.leftControllerTransform.rotation);
	}

	// Token: 0x06000BD1 RID: 3025 RVA: 0x0003F118 File Offset: 0x0003D318
	private void CheckDistance()
	{
		Vector3 b;
		Quaternion b2;
		Vector3 vector;
		this.GetIdealScreenPositionRotation(out b, out b2, out vector);
		float num = Vector3.Distance(this.reportScoreboard.transform.position, b);
		float num2 = 1f;
		if (num > num2 && !this.isMoving)
		{
			this.isMoving = true;
			this.movementTime = 0f;
		}
		if (this.isMoving)
		{
			this.movementTime += Time.deltaTime;
			float num3 = this.movementTime;
			this.reportScoreboard.transform.SetPositionAndRotation(Vector3.Lerp(this.reportScoreboard.transform.position, b, num3), Quaternion.Lerp(this.reportScoreboard.transform.rotation, b2, num3));
			if (this.currentScoreboard != null)
			{
				this.currentScoreboard.transform.SetPositionAndRotation(Vector3.Lerp(this.currentScoreboard.transform.position, b, num3), Quaternion.Lerp(this.currentScoreboard.transform.rotation, b2, num3));
			}
			if (num3 >= 1f)
			{
				this.isMoving = false;
				this.movementTime = 0f;
			}
		}
	}

	// Token: 0x06000BD2 RID: 3026 RVA: 0x0003F238 File Offset: 0x0003D438
	private void Update()
	{
		if (this.blockButtonsUntilTimestamp > Time.time)
		{
			return;
		}
		if (SteamVR_Actions.gorillaTag_System.GetState(SteamVR_Input_Sources.LeftHand) && this.localPlayer.InReportMenu)
		{
			this.Teardown();
			this.blockButtonsUntilTimestamp = Time.time + 0.75f;
		}
		if (this.localPlayer.InReportMenu)
		{
			this.localPlayer.inOverlay = true;
			this.occluder.transform.position = GorillaTagger.Instance.mainCamera.transform.position;
			this.rightHandObject.transform.SetPositionAndRotation(this.localPlayer.rightControllerTransform.position, this.localPlayer.rightControllerTransform.rotation);
			this.leftHandObject.transform.SetPositionAndRotation(this.localPlayer.leftControllerTransform.position, this.localPlayer.leftControllerTransform.rotation);
			this.CheckDistance();
			this.CheckReportSubmit();
		}
		if (this.closeButton.selected)
		{
			this.Teardown();
		}
		if (this.testPress)
		{
			this.testPress = false;
			this.StartOverlay();
		}
	}

	// Token: 0x04000D0C RID: 3340
	[SerializeField]
	private GameObject occluder;

	// Token: 0x04000D0D RID: 3341
	[SerializeField]
	private GameObject reportScoreboard;

	// Token: 0x04000D0E RID: 3342
	[SerializeField]
	private GameObject ReportText;

	// Token: 0x04000D0F RID: 3343
	[SerializeField]
	private LayerMask visibleLayers;

	// Token: 0x04000D10 RID: 3344
	[SerializeField]
	private GorillaReportButton closeButton;

	// Token: 0x04000D11 RID: 3345
	[SerializeField]
	private GameObject leftHandObject;

	// Token: 0x04000D12 RID: 3346
	[SerializeField]
	private GameObject rightHandObject;

	// Token: 0x04000D13 RID: 3347
	[SerializeField]
	private Vector3 playerLocalScreenPosition;

	// Token: 0x04000D14 RID: 3348
	private float blockButtonsUntilTimestamp;

	// Token: 0x04000D15 RID: 3349
	[SerializeField]
	private GorillaScoreBoard currentScoreboard;

	// Token: 0x04000D16 RID: 3350
	private int savedCullingLayers;

	// Token: 0x04000D17 RID: 3351
	public bool testPress;

	// Token: 0x04000D18 RID: 3352
	public bool isMoving;

	// Token: 0x04000D19 RID: 3353
	private float movementTime;
}
