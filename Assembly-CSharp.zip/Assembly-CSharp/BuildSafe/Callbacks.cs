﻿using System;
using System.Diagnostics;

namespace BuildSafe
{
	// Token: 0x0200061E RID: 1566
	public static class Callbacks
	{
		// Token: 0x0200061F RID: 1567
		[Conditional("UNITY_EDITOR")]
		public class DidReloadScripts : Attribute
		{
			// Token: 0x0600250A RID: 9482 RVA: 0x000B6DC5 File Offset: 0x000B4FC5
			public DidReloadScripts(bool activeOnly = false)
			{
				this.activeOnly = activeOnly;
			}

			// Token: 0x040027ED RID: 10221
			public bool activeOnly;
		}
	}
}
