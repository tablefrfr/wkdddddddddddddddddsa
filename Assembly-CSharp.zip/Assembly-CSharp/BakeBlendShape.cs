﻿using System;
using UnityEngine;

// Token: 0x02000048 RID: 72
public class BakeBlendShape : MonoBehaviour
{
	// Token: 0x0600016A RID: 362 RVA: 0x0000BC58 File Offset: 0x00009E58
	private void Update()
	{
		Mesh mesh = new Mesh();
		MeshCollider component = base.GetComponent<MeshCollider>();
		base.GetComponent<SkinnedMeshRenderer>().BakeMesh(mesh);
		component.sharedMesh = null;
		component.sharedMesh = mesh;
	}
}
