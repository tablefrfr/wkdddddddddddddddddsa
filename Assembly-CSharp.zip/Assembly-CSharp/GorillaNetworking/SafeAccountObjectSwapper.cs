﻿using System;
using UnityEngine;

namespace GorillaNetworking
{
	// Token: 0x020006B1 RID: 1713
	public class SafeAccountObjectSwapper : MonoBehaviour
	{
		// Token: 0x06002869 RID: 10345 RVA: 0x000C6A1E File Offset: 0x000C4C1E
		public void Start()
		{
			if (PlayFabAuthenticator.instance.GetSafety())
			{
				this.SwitchToSafeMode();
			}
			PlayFabAuthenticator instance = PlayFabAuthenticator.instance;
			instance.OnSafetyUpdate = (Action<bool>)Delegate.Combine(instance.OnSafetyUpdate, new Action<bool>(this.SafeAccountUpdated));
		}

		// Token: 0x0600286A RID: 10346 RVA: 0x000C6A5C File Offset: 0x000C4C5C
		public void SafeAccountUpdated(bool isSafety)
		{
			if (isSafety)
			{
				this.SwitchToSafeMode();
			}
		}

		// Token: 0x0600286B RID: 10347 RVA: 0x000C6A68 File Offset: 0x000C4C68
		public void SwitchToSafeMode()
		{
			foreach (GameObject gameObject in this.UnSafeGameObjects)
			{
				if (gameObject != null)
				{
					gameObject.SetActive(false);
				}
			}
			foreach (GameObject gameObject2 in this.UnSafeTexts)
			{
				if (gameObject2 != null)
				{
					gameObject2.SetActive(false);
				}
			}
			foreach (GameObject gameObject3 in this.SafeTexts)
			{
				if (gameObject3 != null)
				{
					gameObject3.SetActive(true);
				}
			}
			foreach (GameObject gameObject4 in this.SafeModeObjects)
			{
				if (gameObject4 != null)
				{
					gameObject4.SetActive(true);
				}
			}
		}

		// Token: 0x04002B4D RID: 11085
		public GameObject[] UnSafeGameObjects;

		// Token: 0x04002B4E RID: 11086
		public GameObject[] UnSafeTexts;

		// Token: 0x04002B4F RID: 11087
		public GameObject[] SafeTexts;

		// Token: 0x04002B50 RID: 11088
		public GameObject[] SafeModeObjects;
	}
}
