﻿using System;
using System.Collections.Generic;
using GorillaTagScripts;
using Unity.Collections;
using Unity.Jobs;
using UnityEngine;

// Token: 0x02000323 RID: 803
public class BuilderPieceInteractor : MonoBehaviour
{
	// Token: 0x0600120F RID: 4623 RVA: 0x0005E100 File Offset: 0x0005C300
	private void Awake()
	{
		if (BuilderPieceInteractor.instance == null)
		{
			BuilderPieceInteractor.instance = this;
			BuilderPieceInteractor.hasInstance = true;
		}
		else if (BuilderPieceInteractor.instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		this.velocityEstimator = new List<GorillaVelocityEstimator>(2)
		{
			this.velocityEstimatorLeft,
			this.velocityEstimatorRight
		};
		this.laserSight = new List<BuilderLaserSight>(2)
		{
			this.laserSightLeft,
			this.laserSightRight
		};
		this.handState = new List<BuilderPieceInteractor.HandState>(2);
		this.heldPiece = new List<BuilderPiece>(2);
		this.potentialHeldPiece = new List<BuilderPiece>(2);
		this.potentialGrabbedOffsetDist = new List<float>(2);
		this.heldInitialRot = new List<Quaternion>(2);
		this.heldCurrentRot = new List<Quaternion>(2);
		this.heldInitialPos = new List<Vector3>(2);
		this.heldCurrentPos = new List<Vector3>(2);
		this.delayedPotentialPlacement = new List<BuilderPotentialPlacement>(2);
		this.delayedPlacementTime = new List<float>(2);
		this.prevPotentialPlacement = new List<BuilderPotentialPlacement>(2);
		this.glowBumps = new List<List<BuilderBumpGlow>>(2);
		for (int i = 0; i < 2; i++)
		{
			this.handState.Add(BuilderPieceInteractor.HandState.Empty);
			this.heldPiece.Add(null);
			this.potentialHeldPiece.Add(null);
			this.potentialGrabbedOffsetDist.Add(0f);
			this.heldInitialRot.Add(Quaternion.identity);
			this.heldCurrentRot.Add(Quaternion.identity);
			this.heldInitialPos.Add(Vector3.zero);
			this.heldCurrentPos.Add(Vector3.zero);
			this.delayedPotentialPlacement.Add(default(BuilderPotentialPlacement));
			this.delayedPlacementTime.Add(-1f);
			this.prevPotentialPlacement.Add(default(BuilderPotentialPlacement));
			this.glowBumps.Add(new List<BuilderBumpGlow>(1024));
		}
		this.checkPiecesInSphere = new NativeArray<OverlapSphereCommand>(2, Allocator.Persistent, NativeArrayOptions.ClearMemory);
		this.checkPiecesInSphereResults = new NativeArray<ColliderHit>(2048, Allocator.Persistent, NativeArrayOptions.ClearMemory);
		BuilderPieceInteractor.localGridPlanes = new List<BuilderAttachGridPlane>[2];
		for (int j = 0; j < 2; j++)
		{
			BuilderPieceInteractor.localGridPlanes[j] = new List<BuilderAttachGridPlane>(512);
		}
	}

	// Token: 0x06001210 RID: 4624 RVA: 0x0005E33C File Offset: 0x0005C53C
	private void CalcLocalGridPlanes()
	{
		this.checkNearbyPiecesHandle.Complete();
		for (int i = 0; i < 2; i++)
		{
			BuilderPieceInteractor.localGridPlanes[i].Clear();
			BuilderPieceInteractor.tempPieceSet.Clear();
			if (BuilderTable.instance.IsInBuilderZone())
			{
				for (int j = 0; j < 1024; j++)
				{
					int index = i * 1024 + j;
					if (this.checkPiecesInSphereResults[index].instanceID == 0)
					{
						break;
					}
					BuilderPiece builderPieceFromCollider = BuilderPiece.GetBuilderPieceFromCollider(this.checkPiecesInSphereResults[index].collider);
					if (builderPieceFromCollider != null && !BuilderPieceInteractor.tempPieceSet.Contains(builderPieceFromCollider))
					{
						BuilderPieceInteractor.tempPieceSet.Add(builderPieceFromCollider);
						for (int k = 0; k < builderPieceFromCollider.gridPlanes.Count; k++)
						{
							BuilderPieceInteractor.localGridPlanes[i].Add(builderPieceFromCollider.gridPlanes[k]);
						}
					}
				}
			}
		}
		VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
		QueryParameters queryParameters = new QueryParameters
		{
			layerMask = BuilderTable.instance.allPiecesMask
		};
		this.checkPiecesInSphere[0] = new OverlapSphereCommand(offlineVRRig.leftHand.overrideTarget.position, 1f, queryParameters);
		this.checkPiecesInSphere[1] = new OverlapSphereCommand(offlineVRRig.rightHand.overrideTarget.position, 1f, queryParameters);
		this.checkNearbyPiecesHandle = OverlapSphereCommand.ScheduleBatch(this.checkPiecesInSphere, this.checkPiecesInSphereResults, 1, 1024, default(JobHandle));
		JobHandle.ScheduleBatchedJobs();
	}

	// Token: 0x06001211 RID: 4625 RVA: 0x0005E4E4 File Offset: 0x0005C6E4
	private void OnDestroy()
	{
		if (BuilderPieceInteractor.instance == this)
		{
			BuilderPieceInteractor.hasInstance = false;
			BuilderPieceInteractor.instance = null;
		}
		this.checkPiecesInSphere.Dispose();
		this.checkPiecesInSphereResults.Dispose();
	}

	// Token: 0x06001212 RID: 4626 RVA: 0x0005E51C File Offset: 0x0005C71C
	public void OnLateUpdate()
	{
		if (BuilderTable.instance == null)
		{
			return;
		}
		this.CalcLocalGridPlanes();
		VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
		BodyDockPositions myBodyDockPositions = offlineVRRig.myBodyDockPositions;
		this.UpdateHandState(BuilderPieceInteractor.HandType.Left, offlineVRRig.leftHand.overrideTarget, Vector3.right, myBodyDockPositions.leftHandTransform, this.equipmentInteractor.isLeftGrabbing, this.equipmentInteractor.wasLeftGrabPressed, this.equipmentInteractor.leftHandHeldEquipment, this.equipmentInteractor.disableLeftGrab, BuilderPieceInteractor.localGridPlanes[0]);
		this.UpdateHandState(BuilderPieceInteractor.HandType.Right, offlineVRRig.rightHand.overrideTarget, -Vector3.right, myBodyDockPositions.rightHandTransform, this.equipmentInteractor.isRightGrabbing, this.equipmentInteractor.wasRightGrabPressed, this.equipmentInteractor.rightHandHeldEquipment, this.equipmentInteractor.disableRightGrab, BuilderPieceInteractor.localGridPlanes[1]);
		this.UpdatePieceDisables();
	}

	// Token: 0x06001213 RID: 4627 RVA: 0x0005E5FA File Offset: 0x0005C7FA
	private void SetHandState(int handIndex, BuilderPieceInteractor.HandState newState)
	{
		this.handState[handIndex] = newState;
	}

	// Token: 0x06001214 RID: 4628 RVA: 0x0005E60C File Offset: 0x0005C80C
	private void UpdateHandState(BuilderPieceInteractor.HandType handType, Transform handTransform, Vector3 palmForwardLocal, Transform handAttachPoint, bool isGrabbing, bool wasGrabPressed, HoldableObject heldEquipment, bool grabDisabled, List<BuilderAttachGridPlane> gridPlanes)
	{
		int num = (int)((handType + 1) % (BuilderPieceInteractor.HandType)2);
		bool flag = GorillaTagger.Instance.offlineVRRig.scaleFactor < 1f;
		bool flag2 = isGrabbing && !wasGrabPressed;
		bool flag3 = this.heldPiece[(int)handType] != null && ((!isGrabbing && wasGrabPressed) || flag);
		bool flag4 = heldEquipment != null;
		bool flag5 = this.heldPiece[(int)handType] != null;
		bool flag6 = !flag4 && !flag5 && !grabDisabled && !flag && BuilderTable.instance.IsInBuilderZone();
		BuilderPiece builderPiece = null;
		Vector3 position = handTransform.position;
		Vector3 direction = handTransform.rotation * palmForwardLocal;
		Vector3 zero = Vector3.zero;
		switch (this.handState[(int)handType])
		{
		case BuilderPieceInteractor.HandState.Empty:
			if (flag6 && flag2)
			{
				float num2 = float.MaxValue;
				int num3 = Physics.SphereCastNonAlloc(position, 0.05f, direction, BuilderPieceInteractor.tempHitResults, 0.25f, BuilderTable.instance.allPiecesMask);
				for (int i = 0; i < num3; i++)
				{
					RaycastHit raycastHit = BuilderPieceInteractor.tempHitResults[i];
					BuilderPiece builderPieceFromCollider = BuilderPiece.GetBuilderPieceFromCollider(raycastHit.collider);
					if (builderPieceFromCollider != null && !builderPieceFromCollider.isBuiltIntoTable && (builderPiece == null || raycastHit.distance < num2))
					{
						builderPiece = builderPieceFromCollider;
						num2 = raycastHit.distance;
					}
				}
				if (builderPiece != null)
				{
					Vector3 vector;
					Quaternion quaternion;
					this.CalcPieceLocalPosAndRot(builderPiece.transform.position, builderPiece.transform.rotation, handAttachPoint, out vector, out quaternion);
					if (builderPiece.state == BuilderPiece.State.AttachedToDropped || builderPiece.state == BuilderPiece.State.Dropped || builderPiece.state == BuilderPiece.State.OnShelf || this.heldPiece[num] == builderPiece)
					{
						builderPiece.PlayGrabbedFx();
						BuilderTable.instance.RequestGrabPiece(builderPiece, handType == BuilderPieceInteractor.HandType.Left, vector, quaternion);
						this.SetHandState((int)handType, BuilderPieceInteractor.HandState.Grabbed);
						if (this.heldPiece[num] == builderPiece)
						{
							this.heldPiece[num] = null;
							this.SetHandState(num, BuilderPieceInteractor.HandState.Empty);
						}
					}
					else
					{
						builderPiece.PlayGrabbedFx();
						this.SetHandState((int)handType, BuilderPieceInteractor.HandState.PotentialGrabbed);
						this.potentialGrabbedOffsetDist[(int)handType] = 0f;
					}
					this.heldPiece[(int)handType] = builderPiece;
					this.heldInitialRot[(int)handType] = quaternion;
					this.heldCurrentRot[(int)handType] = quaternion;
					this.heldInitialPos[(int)handType] = vector;
					this.heldCurrentPos[(int)handType] = vector;
					return;
				}
			}
			break;
		case BuilderPieceInteractor.HandState.Grabbed:
		{
			if (flag3)
			{
				Vector3 b = Vector3.zero;
				if (this.prevPotentialPlacement[(int)handType].attachPiece == this.heldPiece[(int)handType] && this.prevPotentialPlacement[(int)handType].parentPiece != null)
				{
					b = this.prevPotentialPlacement[(int)handType].parentPiece.gridPlanes[this.prevPotentialPlacement[(int)handType].parentAttachIndex].transform.TransformDirection(this.prevPotentialPlacement[(int)handType].attachPlaneNormal) * 1f;
				}
				BuilderTable.instance.TryDropPiece(handType == BuilderPieceInteractor.HandType.Left, this.heldPiece[(int)handType], this.velocityEstimator[(int)handType].linearVelocity + b, this.velocityEstimator[(int)handType].angularVelocity);
				this.heldPiece[(int)handType] = null;
				this.SetHandState((int)handType, BuilderPieceInteractor.HandState.Empty);
				this.ClearGlowBumps((int)handType);
				return;
			}
			BuilderPiece builderPiece2 = this.heldPiece[(int)handType];
			if (builderPiece2 != null)
			{
				builderPiece2.transform.localRotation = this.heldInitialRot[(int)handType];
				builderPiece2.transform.localPosition = this.heldInitialPos[(int)handType];
				Quaternion quaternion2 = this.heldCurrentRot[(int)handType];
				Vector3 vector2 = this.heldCurrentPos[(int)handType];
				BuilderPotentialPlacement builderPotentialPlacement;
				bool flag7 = BuilderTable.instance.TryPlacePieceOnTableNoDrop(handType == BuilderPieceInteractor.HandType.Left, builderPiece2, gridPlanes, out builderPotentialPlacement);
				if (flag7)
				{
					int state = (int)builderPotentialPlacement.attachPiece.state;
					BuilderPiece.State state2 = (builderPotentialPlacement.parentPiece == null) ? BuilderPiece.State.None : builderPotentialPlacement.parentPiece.state;
					bool flag8 = state == 2 && state2 == BuilderPiece.State.Grabbed;
					int index = (int)((handType + 1) % (BuilderPieceInteractor.HandType)2);
					BuilderPieceInteractor.HandState handState = this.handState[index];
					if (flag8 && builderPotentialPlacement.attachPiece.gridPlanes[builderPotentialPlacement.attachIndex].male)
					{
						flag7 = false;
					}
					else if (flag8 && handState == BuilderPieceInteractor.HandState.WaitingForSnap)
					{
						flag7 = false;
					}
				}
				if (flag7)
				{
					BuilderAttachGridPlane builderAttachGridPlane = builderPotentialPlacement.attachPiece.gridPlanes[builderPotentialPlacement.attachIndex];
					BuilderAttachGridPlane builderAttachGridPlane2 = (builderPotentialPlacement.parentPiece == null) ? null : builderPotentialPlacement.parentPiece.gridPlanes[builderPotentialPlacement.parentAttachIndex];
					bool flag9 = builderAttachGridPlane.IsConnected(builderPotentialPlacement.attachBounds);
					if (!flag9)
					{
						flag9 = builderAttachGridPlane2.IsConnected(builderPotentialPlacement.parentAttachBounds);
					}
					if (flag9)
					{
						flag7 = false;
					}
				}
				if (flag7)
				{
					Vector3 position2 = builderPotentialPlacement.localPosition;
					Quaternion rhs = builderPotentialPlacement.localRotation;
					Vector3 vector3 = builderPotentialPlacement.attachPlaneNormal;
					if (builderPotentialPlacement.parentPiece != null)
					{
						BuilderAttachGridPlane builderAttachGridPlane3 = builderPotentialPlacement.parentPiece.gridPlanes[builderPotentialPlacement.parentAttachIndex];
						position2 = builderAttachGridPlane3.transform.TransformPoint(builderPotentialPlacement.localPosition);
						rhs = builderAttachGridPlane3.transform.rotation * builderPotentialPlacement.localRotation;
						vector3 = builderAttachGridPlane3.transform.TransformDirection(builderPotentialPlacement.attachPlaneNormal);
					}
					Vector3 a = handAttachPoint.transform.InverseTransformPoint(position2);
					Quaternion a2 = Quaternion.Inverse(handAttachPoint.transform.rotation) * rhs;
					float attachDistance = builderPotentialPlacement.attachDistance;
					float num4 = Mathf.InverseLerp(BuilderTable.instance.pushAndEaseParams.snapDelayOffsetDist, BuilderTable.instance.pushAndEaseParams.maxOffsetY, attachDistance);
					num4 = Mathf.Clamp(num4, 0f, 1f);
					bool flag10 = builderPotentialPlacement.attachPiece == builderPiece2;
					bool flag11 = builderPotentialPlacement.attachPiece == builderPiece2;
					if (flag10)
					{
						Quaternion b2 = this.heldInitialRot[(int)handType];
						Quaternion b3 = Quaternion.Slerp(a2, b2, num4);
						quaternion2 = Quaternion.Slerp(quaternion2, b3, 0.1f);
					}
					if (flag11)
					{
						Vector3 vector4 = this.heldInitialPos[(int)handType];
						Vector3 vector5 = handAttachPoint.transform.InverseTransformDirection(vector3);
						Vector3 vector6 = a + vector5 * BuilderTable.instance.pushAndEaseParams.snapDelayOffsetDist - vector4;
						float num5 = Vector3.Dot(vector6, vector5);
						num5 = Mathf.Min(0f, num5);
						Vector3 b4 = vector5 * num5;
						Vector3 a3 = vector6 - b4;
						Vector3 b5 = vector4 + Vector3.Lerp(a3, Vector3.zero, num4);
						vector2 = Vector3.Lerp(vector2, b5, 0.5f);
					}
					this.heldCurrentRot[(int)handType] = quaternion2;
					this.heldCurrentPos[(int)handType] = vector2;
					builderPiece2.transform.localRotation = quaternion2;
					builderPiece2.transform.localPosition = vector2;
					bool flag12 = Vector3.Dot(this.velocityEstimator[(int)handType].linearVelocity, vector3) > 0f;
					float snapAttachDistance = BuilderTable.instance.pushAndEaseParams.snapAttachDistance;
					if (builderPotentialPlacement.attachDistance < snapAttachDistance && !flag12)
					{
						GorillaTagger.Instance.StartVibration(handType == BuilderPieceInteractor.HandType.Left, GorillaTagger.Instance.tapHapticStrength, BuilderTable.instance.pushAndEaseParams.snapDelayTime * 2f);
						this.delayedPotentialPlacement[(int)handType] = builderPotentialPlacement;
						this.delayedPlacementTime[(int)handType] = 0f;
						this.SetHandState((int)handType, BuilderPieceInteractor.HandState.WaitingForSnap);
					}
					else
					{
						float num6 = BuilderTable.instance.gridSize * 0.5f * (BuilderTable.instance.gridSize * 0.5f);
						if (this.prevPotentialPlacement[(int)handType].attachPiece != builderPotentialPlacement.attachPiece || this.prevPotentialPlacement[(int)handType].parentPiece != builderPotentialPlacement.parentPiece || this.prevPotentialPlacement[(int)handType].attachIndex != builderPotentialPlacement.attachIndex || this.prevPotentialPlacement[(int)handType].parentAttachIndex != builderPotentialPlacement.parentAttachIndex || Vector3.SqrMagnitude(this.prevPotentialPlacement[(int)handType].localPosition - builderPotentialPlacement.localPosition) > num6)
						{
							GorillaTagger.Instance.StartVibration(handType == BuilderPieceInteractor.HandType.Left, GorillaTagger.Instance.tapHapticStrength * 0.15f, BuilderTable.instance.pushAndEaseParams.snapDelayTime);
							this.ClearGlowBumps((int)handType);
							this.AddGlowBumps((int)handType, builderPotentialPlacement);
						}
					}
					this.UpdateGlowBumps((int)handType, 1f - num4);
					this.prevPotentialPlacement[(int)handType] = builderPotentialPlacement;
					return;
				}
				this.ClearGlowBumps((int)handType);
				Quaternion b6 = this.heldInitialRot[(int)handType];
				quaternion2 = Quaternion.Slerp(quaternion2, b6, 0.1f);
				Vector3 b7 = this.heldInitialPos[(int)handType];
				vector2 = Vector3.Lerp(vector2, b7, 0.1f);
				this.heldCurrentRot[(int)handType] = quaternion2;
				this.heldCurrentPos[(int)handType] = vector2;
				builderPiece2.transform.localRotation = quaternion2;
				builderPiece2.transform.localPosition = vector2;
				this.prevPotentialPlacement[(int)handType] = default(BuilderPotentialPlacement);
				return;
			}
			break;
		}
		case BuilderPieceInteractor.HandState.PotentialGrabbed:
		{
			if (flag3)
			{
				BuilderPiece potentialGrabPiece = this.heldPiece[(int)handType];
				this.ClearUnSnapOffset((int)handType, potentialGrabPiece);
				this.heldPiece[(int)handType] = null;
				this.SetHandState((int)handType, BuilderPieceInteractor.HandState.Empty);
				return;
			}
			BuilderPiece builderPiece3 = this.heldPiece[(int)handType];
			Vector3 b8;
			Quaternion quaternion3;
			this.CalcPieceLocalPosAndRot(builderPiece3.transform.position, builderPiece3.transform.rotation, handAttachPoint, out b8, out quaternion3);
			if (builderPiece3.state == BuilderPiece.State.Dropped || builderPiece3.state == BuilderPiece.State.AttachedToDropped || builderPiece3.state == BuilderPiece.State.OnShelf)
			{
				BuilderTable.instance.RequestGrabPiece(builderPiece3, handType == BuilderPieceInteractor.HandType.Left, this.heldInitialPos[(int)handType], this.heldInitialRot[(int)handType]);
				this.SetHandState((int)handType, BuilderPieceInteractor.HandState.Grabbed);
				return;
			}
			Vector3 vector7 = this.heldInitialPos[(int)handType] - b8;
			this.UpdatePullApartOffset((int)handType, builderPiece3, handAttachPoint.TransformVector(vector7));
			float num7 = BuilderTable.instance.pushAndEaseParams.unSnapDelayDist * BuilderTable.instance.pushAndEaseParams.unSnapDelayDist;
			if (vector7.sqrMagnitude > num7)
			{
				GorillaTagger.Instance.StartVibration(handType == BuilderPieceInteractor.HandType.Left, GorillaTagger.Instance.tapHapticStrength * 0.15f, BuilderTable.instance.pushAndEaseParams.unSnapDelayTime * 2f);
				this.SetHandState((int)handType, BuilderPieceInteractor.HandState.WaitingForUnSnap);
				this.delayedPlacementTime[(int)handType] = 0f;
				return;
			}
			break;
		}
		case BuilderPieceInteractor.HandState.WaitingForSnap:
		{
			BuilderPiece builderPiece4 = this.heldPiece[(int)handType];
			if (builderPiece4 != null)
			{
				builderPiece4.transform.localRotation = this.heldInitialRot[(int)handType];
				builderPiece4.transform.localPosition = this.heldInitialPos[(int)handType];
				Quaternion quaternion4 = this.heldCurrentRot[(int)handType];
				Vector3 vector8 = this.heldCurrentPos[(int)handType];
				if (this.delayedPlacementTime[(int)handType] >= 0f)
				{
					BuilderPotentialPlacement builderPotentialPlacement2 = this.delayedPotentialPlacement[(int)handType];
					if (this.delayedPlacementTime[(int)handType] > BuilderTable.instance.pushAndEaseParams.snapDelayTime)
					{
						Vector3 localPosition = builderPotentialPlacement2.localPosition;
						Quaternion localRotation = builderPotentialPlacement2.localRotation;
						builderPotentialPlacement2.attachPiece.PlayPlacementFx();
						BuilderAttachGridPlane builderAttachGridPlane4 = builderPotentialPlacement2.attachPiece.gridPlanes[builderPotentialPlacement2.attachIndex];
						BuilderAttachGridPlane builderAttachGridPlane5 = (builderPotentialPlacement2.parentPiece == null) ? null : builderPotentialPlacement2.parentPiece.gridPlanes[builderPotentialPlacement2.parentAttachIndex];
						bool flag13 = builderAttachGridPlane4.IsConnected(builderPotentialPlacement2.attachBounds);
						if (!flag13)
						{
							flag13 = builderAttachGridPlane5.IsConnected(builderPotentialPlacement2.parentAttachBounds);
						}
						if (flag13)
						{
							Debug.LogError("Snap Overlapping Why are we doing this!!??");
						}
						BuilderTable.instance.RequestPlacePiece(builderPiece4, builderPotentialPlacement2.attachPiece, localPosition, localRotation, builderPotentialPlacement2.parentPiece, builderPotentialPlacement2.attachIndex, builderPotentialPlacement2.attachBounds, builderPotentialPlacement2.parentAttachIndex, builderPotentialPlacement2.parentAttachBounds);
						this.heldPiece[(int)handType] = null;
						this.delayedPlacementTime[(int)handType] = -1f;
						this.SetHandState((int)handType, BuilderPieceInteractor.HandState.Empty);
						this.ClearGlowBumps((int)handType);
						return;
					}
					this.delayedPlacementTime[(int)handType] = this.delayedPlacementTime[(int)handType] + Time.deltaTime;
					Transform parent = builderPiece4.transform.parent;
					Vector3 position3 = builderPotentialPlacement2.localPosition;
					Quaternion rhs2 = builderPotentialPlacement2.localRotation;
					Vector3 direction2 = builderPotentialPlacement2.attachPlaneNormal;
					if (builderPotentialPlacement2.parentPiece != null)
					{
						BuilderAttachGridPlane builderAttachGridPlane6 = builderPotentialPlacement2.parentPiece.gridPlanes[builderPotentialPlacement2.parentAttachIndex];
						position3 = builderAttachGridPlane6.transform.TransformPoint(builderPotentialPlacement2.localPosition);
						rhs2 = builderAttachGridPlane6.transform.rotation * builderPotentialPlacement2.localRotation;
						direction2 = builderAttachGridPlane6.transform.TransformDirection(builderPotentialPlacement2.attachPlaneNormal);
					}
					Vector3 a4 = parent.transform.InverseTransformPoint(position3);
					Quaternion quaternion5 = Quaternion.Inverse(parent.transform.rotation) * rhs2;
					bool flag14 = builderPotentialPlacement2.attachPiece == builderPiece4;
					bool flag15 = builderPotentialPlacement2.attachPiece == builderPiece4;
					if (flag14)
					{
						quaternion4 = quaternion5;
					}
					if (flag15)
					{
						Vector3 a5 = parent.transform.InverseTransformDirection(direction2);
						vector8 = a4 + a5 * BuilderTable.instance.pushAndEaseParams.snapDelayOffsetDist;
					}
					this.heldCurrentRot[(int)handType] = quaternion4;
					this.heldCurrentPos[(int)handType] = vector8;
					builderPiece4.transform.localRotation = quaternion4;
					builderPiece4.transform.localPosition = vector8;
				}
			}
			break;
		}
		case BuilderPieceInteractor.HandState.WaitingForUnSnap:
		{
			BuilderPiece builderPiece5 = this.heldPiece[(int)handType];
			if (builderPiece5.state == BuilderPiece.State.Dropped || builderPiece5.state == BuilderPiece.State.AttachedToDropped || builderPiece5.state == BuilderPiece.State.OnShelf)
			{
				BuilderTable.instance.RequestGrabPiece(builderPiece5, handType == BuilderPieceInteractor.HandType.Left, this.heldInitialPos[(int)handType], this.heldInitialRot[(int)handType]);
				this.SetHandState((int)handType, BuilderPieceInteractor.HandState.Grabbed);
				return;
			}
			if (this.delayedPlacementTime[(int)handType] > BuilderTable.instance.pushAndEaseParams.unSnapDelayTime)
			{
				builderPiece5.PlayDisconnectFx();
				BuilderTable.instance.RequestGrabPiece(builderPiece5, handType == BuilderPieceInteractor.HandType.Left, this.heldInitialPos[(int)handType], this.heldInitialRot[(int)handType]);
				this.SetHandState((int)handType, BuilderPieceInteractor.HandState.Grabbed);
				this.delayedPlacementTime[(int)handType] = -1f;
				return;
			}
			Vector3 b9;
			Quaternion quaternion6;
			this.CalcPieceLocalPosAndRot(builderPiece5.transform.position, builderPiece5.transform.rotation, handAttachPoint, out b9, out quaternion6);
			Vector3 vector9 = this.heldInitialPos[(int)handType] - b9;
			this.UpdatePullApartOffset((int)handType, builderPiece5, handAttachPoint.TransformVector(vector9));
			this.delayedPlacementTime[(int)handType] = this.delayedPlacementTime[(int)handType] + Time.deltaTime;
			return;
		}
		default:
			return;
		}
	}

	// Token: 0x06001215 RID: 4629 RVA: 0x0005F51C File Offset: 0x0005D71C
	private void ClearGlowBumps(int handIndex)
	{
		BuilderPool builderPool = BuilderTable.instance.builderPool;
		List<BuilderBumpGlow> list = this.glowBumps[handIndex];
		if (builderPool != null)
		{
			for (int i = 0; i < list.Count; i++)
			{
				builderPool.DestroyBumpGlow(list[i]);
			}
		}
		else
		{
			Debug.LogError("BuilderPieceInteractor could not find Builderpool");
		}
		list.Clear();
	}

	// Token: 0x06001216 RID: 4630 RVA: 0x0005F57C File Offset: 0x0005D77C
	private void AddGlowBumps(int handIndex, BuilderPotentialPlacement potentialPlacement)
	{
		this.ClearGlowBumps(handIndex);
		BuilderPool builderPool = BuilderTable.instance.builderPool;
		float gridSize = BuilderTable.instance.gridSize;
		if (potentialPlacement.parentPiece != null)
		{
			BuilderAttachGridPlane builderAttachGridPlane = potentialPlacement.attachPiece.gridPlanes[potentialPlacement.attachIndex];
			BuilderAttachGridPlane builderAttachGridPlane2 = potentialPlacement.parentPiece.gridPlanes[potentialPlacement.parentAttachIndex];
			Vector2Int min = potentialPlacement.parentAttachBounds.min;
			Vector2Int max = potentialPlacement.parentAttachBounds.max;
			for (int i = min.x; i <= max.x; i++)
			{
				for (int j = min.y; j <= max.y; j++)
				{
					Vector3 gridPosition = builderAttachGridPlane2.GetGridPosition(i, j, gridSize);
					BuilderBumpGlow builderBumpGlow = builderPool.CreateGlowBump();
					builderBumpGlow.transform.SetPositionAndRotation(gridPosition, builderAttachGridPlane2.transform.rotation);
					builderBumpGlow.transform.SetParent(builderAttachGridPlane2.transform, true);
					builderBumpGlow.transform.localScale = Vector3.one;
					builderBumpGlow.gameObject.SetActive(true);
					this.glowBumps[handIndex].Add(builderBumpGlow);
				}
			}
		}
		if (builderPool != null)
		{
			BuilderAttachGridPlane builderAttachGridPlane3 = potentialPlacement.attachPiece.gridPlanes[potentialPlacement.attachIndex];
			Vector2Int min2 = potentialPlacement.attachBounds.min;
			Vector2Int max2 = potentialPlacement.attachBounds.max;
			potentialPlacement.parentPiece.gridPlanes[potentialPlacement.parentAttachIndex] != null;
			for (int k = min2.x; k <= max2.x; k++)
			{
				for (int l = min2.y; l <= max2.y; l++)
				{
					Vector3 gridPosition2 = builderAttachGridPlane3.GetGridPosition(k, l, gridSize);
					BuilderBumpGlow builderBumpGlow2 = builderPool.CreateGlowBump();
					Quaternion rhs = Quaternion.Euler(180f, 0f, 0f);
					builderBumpGlow2.transform.SetPositionAndRotation(gridPosition2, builderAttachGridPlane3.transform.rotation * rhs);
					builderBumpGlow2.transform.SetParent(builderAttachGridPlane3.transform, true);
					builderBumpGlow2.transform.localScale = Vector3.one;
					builderBumpGlow2.gameObject.SetActive(true);
					this.glowBumps[handIndex].Add(builderBumpGlow2);
				}
			}
		}
	}

	// Token: 0x06001217 RID: 4631 RVA: 0x0005F7E4 File Offset: 0x0005D9E4
	private void UpdateGlowBumps(int handIndex, float intensity)
	{
		List<BuilderBumpGlow> list = this.glowBumps[handIndex];
		for (int i = 0; i < list.Count; i++)
		{
			list[i].SetIntensity(intensity);
		}
	}

	// Token: 0x06001218 RID: 4632 RVA: 0x0005F81C File Offset: 0x0005DA1C
	private void UpdatePullApartOffset(int handIndex, BuilderPiece potentialGrabPiece, Vector3 pullApartDiff)
	{
		BuilderPiece parentPiece = potentialGrabPiece.parentPiece;
		BuilderAttachGridPlane builderAttachGridPlane = null;
		if (parentPiece != null)
		{
			builderAttachGridPlane = parentPiece.gridPlanes[potentialGrabPiece.parentAttachIndex];
		}
		Vector3 vector = Vector3.up;
		if (builderAttachGridPlane != null)
		{
			vector = builderAttachGridPlane.transform.TransformDirection(vector);
			if (!builderAttachGridPlane.male)
			{
				vector *= -1f;
			}
		}
		float num = Vector3.Dot(pullApartDiff, vector);
		num = Mathf.Max(num, 0f);
		float num2 = 0.0025f;
		float num3 = num / num2;
		num3 = 1f - 1f / (1f + num3);
		num = num3 * num2;
		Vector3 vector2 = vector * this.potentialGrabbedOffsetDist[handIndex];
		this.potentialGrabbedOffsetDist[handIndex] = num;
		Vector3 vector3 = vector * this.potentialGrabbedOffsetDist[handIndex];
		if (builderAttachGridPlane != null)
		{
			vector2 = builderAttachGridPlane.transform.InverseTransformVector(vector2);
			vector3 = builderAttachGridPlane.transform.InverseTransformVector(vector3);
		}
		Vector3 a = potentialGrabPiece.transform.localPosition - vector2;
		potentialGrabPiece.transform.localPosition = a + vector3;
	}

	// Token: 0x06001219 RID: 4633 RVA: 0x0005F93E File Offset: 0x0005DB3E
	private void ClearUnSnapOffset(int handIndex, BuilderPiece potentialGrabPiece)
	{
		this.UpdatePullApartOffset(handIndex, potentialGrabPiece, Vector3.zero);
	}

	// Token: 0x0600121A RID: 4634 RVA: 0x0005F950 File Offset: 0x0005DB50
	public void RemovePieceFromHeld(BuilderPiece piece)
	{
		for (int i = 0; i < 2; i++)
		{
			if (this.heldPiece[i] == piece)
			{
				this.heldPiece[i] = null;
				this.delayedPlacementTime[i] = -1f;
				this.handState[i] = BuilderPieceInteractor.HandState.Empty;
				this.ClearGlowBumps(i);
			}
		}
	}

	// Token: 0x0600121B RID: 4635 RVA: 0x0005F9B0 File Offset: 0x0005DBB0
	private void CalcPieceLocalPosAndRot(Vector3 worldPosition, Quaternion worldRotation, Transform attachPoint, out Vector3 localPosition, out Quaternion localRotation)
	{
		Quaternion rotation = attachPoint.transform.rotation;
		Vector3 position = attachPoint.transform.position;
		localRotation = Quaternion.Inverse(rotation) * worldRotation;
		localPosition = Quaternion.Inverse(rotation) * (worldPosition - position);
	}

	// Token: 0x0600121C RID: 4636 RVA: 0x0005FA05 File Offset: 0x0005DC05
	public void DisableCollisionsWithHands()
	{
		this.DisableCollisionsWithHand(true);
		this.DisableCollisionsWithHand(false);
	}

	// Token: 0x0600121D RID: 4637 RVA: 0x0005FA18 File Offset: 0x0005DC18
	private void DisableCollisionsWithHand(bool leftHand)
	{
		VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
		Transform transform = leftHand ? offlineVRRig.leftHand.overrideTarget : offlineVRRig.rightHand.overrideTarget;
		List<GameObject> list = leftHand ? this.collisionDisabledPiecesLeft : this.collisionDisabledPiecesRight;
		int num = Physics.OverlapSphereNonAlloc(transform.position, 0.15f, BuilderPieceInteractor.tempDisableColliders, BuilderTable.instance.allPiecesMask);
		for (int i = 0; i < num; i++)
		{
			GameObject gameObject = BuilderPieceInteractor.tempDisableColliders[i].gameObject;
			BuilderPiece builderPieceFromCollider = BuilderPiece.GetBuilderPieceFromCollider(BuilderPieceInteractor.tempDisableColliders[i]);
			if (builderPieceFromCollider != null && builderPieceFromCollider.state == BuilderPiece.State.AttachedAndPlaced && !list.Contains(gameObject))
			{
				gameObject.layer = BuilderTable.heldLayer;
				list.Add(gameObject);
			}
		}
	}

	// Token: 0x0600121E RID: 4638 RVA: 0x0005FADA File Offset: 0x0005DCDA
	public void UpdatePieceDisables()
	{
		this.UpdatePieceDisablesForHand(true);
		this.UpdatePieceDisablesForHand(false);
	}

	// Token: 0x0600121F RID: 4639 RVA: 0x0005FAEC File Offset: 0x0005DCEC
	public void UpdatePieceDisablesForHand(bool leftHand)
	{
		VRRig offlineVRRig = GorillaTagger.Instance.offlineVRRig;
		Transform transform = leftHand ? offlineVRRig.leftHand.overrideTarget : offlineVRRig.rightHand.overrideTarget;
		List<GameObject> list = leftHand ? this.collisionDisabledPiecesLeft : this.collisionDisabledPiecesRight;
		List<GameObject> list2 = (!leftHand) ? this.collisionDisabledPiecesLeft : this.collisionDisabledPiecesRight;
		Vector3 position = transform.position;
		float num = 0.040000003f;
		for (int i = 0; i < list.Count; i++)
		{
			GameObject gameObject = list[i];
			if (gameObject == null)
			{
				list.RemoveAt(i);
				i--;
			}
			else if ((gameObject.transform.position - position).sqrMagnitude > num)
			{
				BuilderPiece builderPieceFromTransform = BuilderPiece.GetBuilderPieceFromTransform(gameObject.transform);
				if (builderPieceFromTransform.state == BuilderPiece.State.AttachedAndPlaced && !list2.Contains(gameObject))
				{
					builderPieceFromTransform.SetColliderLayers<Collider>(builderPieceFromTransform.colliders, BuilderTable.placedLayer);
				}
				list.RemoveAt(i);
				i--;
			}
		}
	}

	// Token: 0x04001495 RID: 5269
	[OnEnterPlay_SetNull]
	public static volatile BuilderPieceInteractor instance;

	// Token: 0x04001496 RID: 5270
	[OnEnterPlay_Set(false)]
	public static bool hasInstance;

	// Token: 0x04001497 RID: 5271
	public EquipmentInteractor equipmentInteractor;

	// Token: 0x04001498 RID: 5272
	private const int NUM_HANDS = 2;

	// Token: 0x04001499 RID: 5273
	public GorillaVelocityEstimator velocityEstimatorLeft;

	// Token: 0x0400149A RID: 5274
	public GorillaVelocityEstimator velocityEstimatorRight;

	// Token: 0x0400149B RID: 5275
	public BuilderLaserSight laserSightLeft;

	// Token: 0x0400149C RID: 5276
	public BuilderLaserSight laserSightRight;

	// Token: 0x0400149D RID: 5277
	public List<GorillaVelocityEstimator> velocityEstimator;

	// Token: 0x0400149E RID: 5278
	public List<BuilderPieceInteractor.HandState> handState;

	// Token: 0x0400149F RID: 5279
	public List<BuilderPiece> heldPiece;

	// Token: 0x040014A0 RID: 5280
	public List<BuilderPiece> potentialHeldPiece;

	// Token: 0x040014A1 RID: 5281
	public List<float> potentialGrabbedOffsetDist;

	// Token: 0x040014A2 RID: 5282
	public List<Quaternion> heldInitialRot;

	// Token: 0x040014A3 RID: 5283
	public List<Quaternion> heldCurrentRot;

	// Token: 0x040014A4 RID: 5284
	public List<Vector3> heldInitialPos;

	// Token: 0x040014A5 RID: 5285
	public List<Vector3> heldCurrentPos;

	// Token: 0x040014A6 RID: 5286
	public List<BuilderPotentialPlacement> delayedPotentialPlacement;

	// Token: 0x040014A7 RID: 5287
	public List<float> delayedPlacementTime;

	// Token: 0x040014A8 RID: 5288
	public List<BuilderPotentialPlacement> prevPotentialPlacement;

	// Token: 0x040014A9 RID: 5289
	public List<BuilderLaserSight> laserSight;

	// Token: 0x040014AA RID: 5290
	private static List<BuilderAttachGridPlane>[] localGridPlanes;

	// Token: 0x040014AB RID: 5291
	public List<GameObject> collisionDisabledPiecesLeft = new List<GameObject>();

	// Token: 0x040014AC RID: 5292
	public List<GameObject> collisionDisabledPiecesRight = new List<GameObject>();

	// Token: 0x040014AD RID: 5293
	private const int MAX_SPHERE_CHECK_RESULTS = 1024;

	// Token: 0x040014AE RID: 5294
	public NativeArray<OverlapSphereCommand> checkPiecesInSphere;

	// Token: 0x040014AF RID: 5295
	public NativeArray<ColliderHit> checkPiecesInSphereResults;

	// Token: 0x040014B0 RID: 5296
	public JobHandle checkNearbyPiecesHandle;

	// Token: 0x040014B1 RID: 5297
	public BuilderBumpGlow glowBumpPrefab;

	// Token: 0x040014B2 RID: 5298
	public List<List<BuilderBumpGlow>> glowBumps;

	// Token: 0x040014B3 RID: 5299
	private static HashSet<BuilderPiece> tempPieceSet = new HashSet<BuilderPiece>(512);

	// Token: 0x040014B4 RID: 5300
	private static RaycastHit[] tempHitResults = new RaycastHit[64];

	// Token: 0x040014B5 RID: 5301
	private const float PIECE_DISTANCE_DISABLE = 0.15f;

	// Token: 0x040014B6 RID: 5302
	private const float PIECE_DISTANCE_ENABLE = 0.2f;

	// Token: 0x040014B7 RID: 5303
	private static Collider[] tempDisableColliders = new Collider[128];

	// Token: 0x02000324 RID: 804
	public enum HandType
	{
		// Token: 0x040014B9 RID: 5305
		Invalid = -1,
		// Token: 0x040014BA RID: 5306
		Left,
		// Token: 0x040014BB RID: 5307
		Right
	}

	// Token: 0x02000325 RID: 805
	public enum HandState
	{
		// Token: 0x040014BD RID: 5309
		Invalid = -1,
		// Token: 0x040014BE RID: 5310
		Empty,
		// Token: 0x040014BF RID: 5311
		Grabbed,
		// Token: 0x040014C0 RID: 5312
		PotentialGrabbed,
		// Token: 0x040014C1 RID: 5313
		WaitingForSnap,
		// Token: 0x040014C2 RID: 5314
		WaitingForUnSnap
	}
}
