﻿using System;
using GorillaTagScripts;
using UnityEngine;

namespace GorillaNetworking
{
	// Token: 0x020006C4 RID: 1732
	public class GorillaNetworkJoinTrigger : GorillaTriggerBox
	{
		// Token: 0x06002918 RID: 10520 RVA: 0x000CA690 File Offset: 0x000C8890
		private void Start()
		{
			if (this.primaryTriggerForMyZone == null)
			{
				this.primaryTriggerForMyZone = this;
			}
			PhotonNetworkController.Instance.RegisterJoinTrigger(this);
			if (!this.didRegisterForCallbacks && this.ui != null)
			{
				this.didRegisterForCallbacks = true;
				FriendshipGroupDetection.Instance.AddGroupZoneCallback(new Action<GroupJoinZone>(this.OnGroupPositionsChanged));
			}
		}

		// Token: 0x06002919 RID: 10521 RVA: 0x000CA6F4 File Offset: 0x000C88F4
		public void RegisterUI(JoinTriggerUI ui)
		{
			this.ui = ui;
			if (!this.didRegisterForCallbacks && FriendshipGroupDetection.Instance != null)
			{
				this.didRegisterForCallbacks = true;
				FriendshipGroupDetection.Instance.AddGroupZoneCallback(new Action<GroupJoinZone>(this.OnGroupPositionsChanged));
			}
			this.UpdateUI();
		}

		// Token: 0x0600291A RID: 10522 RVA: 0x000CA740 File Offset: 0x000C8940
		public void UnregisterUI(JoinTriggerUI ui)
		{
			this.ui = null;
		}

		// Token: 0x0600291B RID: 10523 RVA: 0x000CA749 File Offset: 0x000C8949
		private void OnDestroy()
		{
			if (this.didRegisterForCallbacks)
			{
				FriendshipGroupDetection.Instance.RemoveGroupZoneCallback(new Action<GroupJoinZone>(this.OnGroupPositionsChanged));
			}
		}

		// Token: 0x0600291C RID: 10524 RVA: 0x000CA769 File Offset: 0x000C8969
		private void OnGroupPositionsChanged(GroupJoinZone groupZone)
		{
			this.UpdateUI();
		}

		// Token: 0x0600291D RID: 10525 RVA: 0x000CA774 File Offset: 0x000C8974
		public void UpdateUI()
		{
			if (this.ui == null)
			{
				return;
			}
			if (GorillaScoreboardTotalUpdater.instance.offlineTextErrorString != null)
			{
				this.ui.SetState(JoinTriggerVisualState.ConnectionError, new Func<string>(this.GetCurrentRoomName), new Func<string>(this.GetRoomName));
				return;
			}
			if (PhotonNetworkController.Instance.currentJoinTrigger == this.primaryTriggerForMyZone)
			{
				this.ui.SetState(JoinTriggerVisualState.AlreadyInRoom, new Func<string>(this.GetCurrentRoomName), new Func<string>(this.GetRoomName));
				return;
			}
			if (NetworkSystem.Instance.SessionIsPrivate)
			{
				this.ui.SetState(JoinTriggerVisualState.InPrivateRoom, new Func<string>(this.GetCurrentRoomName), new Func<string>(this.GetRoomName));
				return;
			}
			if (FriendshipGroupDetection.Instance.IsInParty)
			{
				this.ui.SetState(this.CanPartyJoin() ? JoinTriggerVisualState.LeaveRoomAndPartyJoin : JoinTriggerVisualState.AbandonPartyAndSoloJoin, new Func<string>(this.GetCurrentRoomName), new Func<string>(this.GetRoomName));
				return;
			}
			if (!NetworkSystem.Instance.InRoom)
			{
				this.ui.SetState(JoinTriggerVisualState.NotConnectedSoloJoin, new Func<string>(this.GetCurrentRoomName), new Func<string>(this.GetRoomName));
				return;
			}
			this.ui.SetState(JoinTriggerVisualState.LeaveRoomAndSoloJoin, new Func<string>(this.GetCurrentRoomName), new Func<string>(this.GetRoomName));
		}

		// Token: 0x0600291E RID: 10526 RVA: 0x000CA8C1 File Offset: 0x000C8AC1
		private string GetCurrentRoomName()
		{
			return PhotonNetworkController.Instance.currentJoinTrigger.gameModeName.ToUpper();
		}

		// Token: 0x0600291F RID: 10527 RVA: 0x000CA8D9 File Offset: 0x000C8AD9
		private string GetRoomName()
		{
			return this.gameModeName.ToUpper();
		}

		// Token: 0x06002920 RID: 10528 RVA: 0x000CA8E6 File Offset: 0x000C8AE6
		public bool CanPartyJoin()
		{
			return this.CanPartyJoin(FriendshipGroupDetection.Instance.partyZone);
		}

		// Token: 0x06002921 RID: 10529 RVA: 0x000CA8F8 File Offset: 0x000C8AF8
		public bool CanPartyJoin(GroupJoinZone zone)
		{
			return (this.groupJoinRequiredZones & zone) == zone;
		}

		// Token: 0x06002922 RID: 10530 RVA: 0x000CA908 File Offset: 0x000C8B08
		public override void OnBoxTriggered()
		{
			base.OnBoxTriggered();
			GorillaComputer.instance.allowedMapsToJoin = this.myCollider.myAllowedMapsToJoin;
			if (NetworkSystem.Instance.groupJoinInProgress)
			{
				return;
			}
			if (FriendshipGroupDetection.Instance.IsInParty)
			{
				if (this.ignoredIfInParty)
				{
					return;
				}
				if (NetworkSystem.Instance.netState == NetSystemState.Connecting || NetworkSystem.Instance.netState == NetSystemState.Disconnecting || NetworkSystem.Instance.netState == NetSystemState.Initialization || NetworkSystem.Instance.netState == NetSystemState.PingRecon)
				{
					return;
				}
				if (NetworkSystem.Instance.InRoom)
				{
					if (NetworkSystem.Instance.GameModeString.Contains(this.gameModeName))
					{
						Debug.Log("JoinTrigger: Ignoring party join/leave because " + this.gameModeName + " is already the game mode");
						return;
					}
					if (NetworkSystem.Instance.SessionIsPrivate)
					{
						Debug.Log("JoinTrigger: Ignoring party join/leave because we're in a private room");
						return;
					}
				}
				if (this.CanPartyJoin())
				{
					Debug.Log(string.Format("JoinTrigger: Attempting party join in 1 second! <{0}> accepts <{1}>", this.groupJoinRequiredZones, FriendshipGroupDetection.Instance.partyZone));
					PhotonNetworkController.Instance.DeferJoining(1f);
					FriendshipGroupDetection.Instance.SendAboutToGroupJoin();
					PhotonNetworkController.Instance.AttemptToJoinPublicRoom(this, JoinType.JoinWithParty);
					return;
				}
				Debug.Log(string.Format("JoinTrigger: LeaveGroup: Leaving party and will solo join, wanted <{0}> but got <{1}>", this.groupJoinRequiredZones, FriendshipGroupDetection.Instance.partyZone));
				FriendshipGroupDetection.Instance.LeaveParty();
				PhotonNetworkController.Instance.DeferJoining(1f);
			}
			else
			{
				Debug.Log("JoinTrigger: Solo join (not in a group)");
				PhotonNetworkController.Instance.ClearDeferredJoin();
			}
			PhotonNetworkController.Instance.AttemptToJoinPublicRoom(this, JoinType.Solo);
		}

		// Token: 0x04002C26 RID: 11302
		public GameObject[] makeSureThisIsDisabled;

		// Token: 0x04002C27 RID: 11303
		public GameObject[] makeSureThisIsEnabled;

		// Token: 0x04002C28 RID: 11304
		public GTZone zone;

		// Token: 0x04002C29 RID: 11305
		public GroupJoinZone groupJoinRequiredZones;

		// Token: 0x04002C2A RID: 11306
		public string gameModeName;

		// Token: 0x04002C2B RID: 11307
		public string componentTypeToAdd;

		// Token: 0x04002C2C RID: 11308
		public GameObject componentTarget;

		// Token: 0x04002C2D RID: 11309
		public GorillaFriendCollider myCollider;

		// Token: 0x04002C2E RID: 11310
		public GorillaNetworkJoinTrigger primaryTriggerForMyZone;

		// Token: 0x04002C2F RID: 11311
		public bool ignoredIfInParty;

		// Token: 0x04002C30 RID: 11312
		private JoinTriggerUI ui;

		// Token: 0x04002C31 RID: 11313
		private bool didRegisterForCallbacks;
	}
}
