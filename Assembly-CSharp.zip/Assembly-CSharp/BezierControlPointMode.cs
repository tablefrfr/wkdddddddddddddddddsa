﻿using System;

// Token: 0x020004E7 RID: 1255
public enum BezierControlPointMode
{
	// Token: 0x04001FC1 RID: 8129
	Free,
	// Token: 0x04001FC2 RID: 8130
	Aligned,
	// Token: 0x04001FC3 RID: 8131
	Mirrored
}
