﻿using System;
using System.Collections;
using System.Collections.Generic;
using GorillaGameModes;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x0200037A RID: 890
public class GorillaHuntManager : GorillaGameManager
{
	// Token: 0x0600144E RID: 5198 RVA: 0x0006A6B7 File Offset: 0x000688B7
	public override GameModeType GameType()
	{
		return GameModeType.Hunt;
	}

	// Token: 0x0600144F RID: 5199 RVA: 0x0006A6BA File Offset: 0x000688BA
	public override string GameModeName()
	{
		return "HUNT";
	}

	// Token: 0x06001450 RID: 5200 RVA: 0x0006A6C1 File Offset: 0x000688C1
	public override void Awake()
	{
		base.Awake();
	}

	// Token: 0x06001451 RID: 5201 RVA: 0x0006A6CC File Offset: 0x000688CC
	public override void StartPlaying()
	{
		base.StartPlaying();
		GorillaTagger.Instance.offlineVRRig.huntComputer.SetActive(true);
		if (PhotonNetwork.IsMasterClient)
		{
			for (int i = 0; i < this.currentHunted.Count; i++)
			{
				this.tempPlayer = this.currentHunted[i];
				if (this.tempPlayer == null || !this.tempPlayer.InRoom())
				{
					this.currentHunted.RemoveAt(i);
					i--;
				}
			}
			for (int i = 0; i < this.currentTarget.Count; i++)
			{
				this.tempPlayer = this.currentTarget[i];
				if (this.tempPlayer == null || !this.tempPlayer.InRoom())
				{
					this.currentTarget.RemoveAt(i);
					i--;
				}
			}
			this.CopyHuntDataListToArray();
			this.UpdateState();
		}
	}

	// Token: 0x06001452 RID: 5202 RVA: 0x0006A7A4 File Offset: 0x000689A4
	public override void StopPlaying()
	{
		base.StopPlaying();
		GorillaTagger.Instance.offlineVRRig.huntComputer.SetActive(false);
		base.StopAllCoroutines();
	}

	// Token: 0x06001453 RID: 5203 RVA: 0x0006A7C8 File Offset: 0x000689C8
	public override void Reset()
	{
		base.Reset();
		this.currentHunted.Clear();
		this.currentTarget.Clear();
		for (int i = 0; i < this.currentHuntedArray.Length; i++)
		{
			this.currentHuntedArray[i] = 0;
			this.currentTargetArray[i] = 0;
		}
		this.huntStarted = false;
		this.waitingToStartNextHuntGame = false;
		this.inStartCountdown = false;
		this.timeHuntGameEnded = 0.0;
		this.countDownTime = 0;
		this.timeLastSlowTagged = 0f;
	}

	// Token: 0x06001454 RID: 5204 RVA: 0x0006A84C File Offset: 0x00068A4C
	public void UpdateState()
	{
		if (PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			if (PhotonNetwork.CurrentRoom.PlayerCount <= 3)
			{
				this.CleanUpHunt();
				this.huntStarted = false;
				this.waitingToStartNextHuntGame = false;
				this.iterator1 = 0;
				while (this.iterator1 < RoomSystem.PlayersInRoom.Count)
				{
					RoomSystem.SendSoundEffectToPlayer(0, 0.25f, RoomSystem.PlayersInRoom[this.iterator1]);
					this.iterator1++;
				}
				return;
			}
			if (PhotonNetwork.CurrentRoom.PlayerCount > 3 && !this.huntStarted && !this.waitingToStartNextHuntGame && !this.inStartCountdown)
			{
				base.StartCoroutine(this.StartHuntCountdown());
				return;
			}
			this.UpdateHuntState();
		}
	}

	// Token: 0x06001455 RID: 5205 RVA: 0x0006A907 File Offset: 0x00068B07
	public void CleanUpHunt()
	{
		if (PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			this.currentHunted.Clear();
			this.currentTarget.Clear();
			this.CopyHuntDataListToArray();
		}
	}

	// Token: 0x06001456 RID: 5206 RVA: 0x0006A931 File Offset: 0x00068B31
	public IEnumerator StartHuntCountdown()
	{
		if (PhotonNetwork.LocalPlayer.IsMasterClient && !this.inStartCountdown)
		{
			this.inStartCountdown = true;
			this.countDownTime = 5;
			this.CleanUpHunt();
			while (this.countDownTime > 0)
			{
				yield return new WaitForSeconds(1f);
				this.countDownTime--;
			}
			this.StartHunt();
		}
		yield return null;
		yield break;
	}

	// Token: 0x06001457 RID: 5207 RVA: 0x0006A940 File Offset: 0x00068B40
	public void StartHunt()
	{
		if (PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			this.huntStarted = true;
			this.waitingToStartNextHuntGame = false;
			this.countDownTime = 0;
			this.inStartCountdown = false;
			this.CleanUpHunt();
			this.iterator1 = 0;
			while (this.iterator1 < RoomSystem.PlayersInRoom.Count)
			{
				if (this.currentTarget.Count < 10)
				{
					this.currentTarget.Add(RoomSystem.PlayersInRoom[this.iterator1]);
					RoomSystem.SendSoundEffectToPlayer(0, 0.25f, RoomSystem.PlayersInRoom[this.iterator1]);
				}
				this.iterator1++;
			}
			this.RandomizePlayerList(ref this.currentTarget);
			this.CopyHuntDataListToArray();
		}
	}

	// Token: 0x06001458 RID: 5208 RVA: 0x0006AA00 File Offset: 0x00068C00
	public void RandomizePlayerList(ref List<Player> listToRandomize)
	{
		for (int i = 0; i < listToRandomize.Count - 1; i++)
		{
			this.tempRandIndex = Random.Range(i, listToRandomize.Count);
			this.tempRandPlayer = listToRandomize[i];
			listToRandomize[i] = listToRandomize[this.tempRandIndex];
			listToRandomize[this.tempRandIndex] = this.tempRandPlayer;
		}
	}

	// Token: 0x06001459 RID: 5209 RVA: 0x0006AA6A File Offset: 0x00068C6A
	public IEnumerator HuntEnd()
	{
		if (PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			while ((double)Time.time < this.timeHuntGameEnded + (double)this.tagCoolDown)
			{
				yield return new WaitForSeconds(0.1f);
			}
			if (this.waitingToStartNextHuntGame)
			{
				base.StartCoroutine(this.StartHuntCountdown());
			}
			yield return null;
		}
		yield return null;
		yield break;
	}

	// Token: 0x0600145A RID: 5210 RVA: 0x0006AA7C File Offset: 0x00068C7C
	public void UpdateHuntState()
	{
		if (PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			this.CopyHuntDataListToArray();
			this.notHuntedCount = 0;
			foreach (Player item in RoomSystem.PlayersInRoom)
			{
				if (this.currentTarget.Contains(item) && !this.currentHunted.Contains(item))
				{
					this.notHuntedCount++;
				}
			}
			if (this.notHuntedCount <= 2 && this.huntStarted)
			{
				this.EndHuntGame();
			}
		}
	}

	// Token: 0x0600145B RID: 5211 RVA: 0x0006AB24 File Offset: 0x00068D24
	private void EndHuntGame()
	{
		if (PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			foreach (Player player in RoomSystem.PlayersInRoom)
			{
				this.FindVRRigForPlayer(player);
				RoomSystem.SendStatusEffectToPlayer(RoomSystem.StatusEffects.TaggedTime, player);
				RoomSystem.SendSoundEffectToPlayer(2, 0.25f, player);
			}
			this.huntStarted = false;
			this.timeHuntGameEnded = (double)Time.time;
			this.waitingToStartNextHuntGame = true;
			base.StartCoroutine(this.HuntEnd());
		}
	}

	// Token: 0x0600145C RID: 5212 RVA: 0x0006ABC0 File Offset: 0x00068DC0
	public override bool LocalCanTag(Player myPlayer, Player otherPlayer)
	{
		if (this.waitingToStartNextHuntGame || this.countDownTime > 0 || GorillaTagger.Instance.currentStatus == GorillaTagger.StatusEffect.Frozen)
		{
			return false;
		}
		if (this.currentHunted.Contains(myPlayer) && !this.currentHunted.Contains(otherPlayer) && Time.time > this.timeLastSlowTagged + 1f)
		{
			this.timeLastSlowTagged = Time.time;
			return true;
		}
		return this.IsTargetOf(myPlayer, otherPlayer);
	}

	// Token: 0x0600145D RID: 5213 RVA: 0x0006AC38 File Offset: 0x00068E38
	public override void ReportTag(Player taggedPlayer, Player taggingPlayer)
	{
		if (PhotonNetwork.LocalPlayer.IsMasterClient && !this.waitingToStartNextHuntGame)
		{
			this.FindVRRigForPlayer(taggedPlayer);
			if ((this.currentHunted.Contains(taggingPlayer) || !this.currentTarget.Contains(taggingPlayer)) && !this.currentHunted.Contains(taggedPlayer) && this.currentTarget.Contains(taggedPlayer))
			{
				RoomSystem.SendStatusEffectToPlayer(RoomSystem.StatusEffects.SetSlowedTime, taggedPlayer);
				RoomSystem.SendSoundEffectOnOther(5, 0.125f, taggedPlayer);
				return;
			}
			if (this.IsTargetOf(taggingPlayer, taggedPlayer))
			{
				RoomSystem.SendStatusEffectToPlayer(RoomSystem.StatusEffects.TaggedTime, taggedPlayer);
				RoomSystem.SendSoundEffectOnOther(0, 0.25f, taggedPlayer);
				this.currentHunted.Add(taggedPlayer);
				this.CopyHuntDataListToArray();
				this.UpdateHuntState();
			}
		}
	}

	// Token: 0x0600145E RID: 5214 RVA: 0x0006ACE8 File Offset: 0x00068EE8
	public bool IsTargetOf(Player huntingPlayer, Player huntedPlayer)
	{
		return !this.currentHunted.Contains(huntingPlayer) && !this.currentHunted.Contains(huntedPlayer) && this.currentTarget.Contains(huntingPlayer) && this.currentTarget.Contains(huntedPlayer) && huntedPlayer == this.GetTargetOf(huntingPlayer);
	}

	// Token: 0x0600145F RID: 5215 RVA: 0x0006AD3C File Offset: 0x00068F3C
	public Player GetTargetOf(Player player)
	{
		if (this.currentHunted.Contains(player) || !this.currentTarget.Contains(player))
		{
			return null;
		}
		this.tempTargetIndex = this.currentTarget.IndexOf(player);
		for (int num = (this.tempTargetIndex + 1) % this.currentTarget.Count; num != this.tempTargetIndex; num = (num + 1) % this.currentTarget.Count)
		{
			if (this.currentTarget[num] == player)
			{
				return null;
			}
			if (!this.currentHunted.Contains(this.currentTarget[num]) && this.currentTarget[num] != null)
			{
				return this.currentTarget[num];
			}
		}
		return null;
	}

	// Token: 0x06001460 RID: 5216 RVA: 0x0006ADF0 File Offset: 0x00068FF0
	public override void HitPlayer(Player taggedPlayer)
	{
		if (PhotonNetwork.LocalPlayer.IsMasterClient && !this.waitingToStartNextHuntGame)
		{
			this.FindVRRigForPlayer(taggedPlayer);
			if (!this.currentHunted.Contains(taggedPlayer) && this.currentTarget.Contains(taggedPlayer))
			{
				RoomSystem.SendStatusEffectToPlayer(RoomSystem.StatusEffects.TaggedTime, taggedPlayer);
				RoomSystem.SendSoundEffectOnOther(0, 0.25f, taggedPlayer);
				this.currentHunted.Add(taggedPlayer);
				this.CopyHuntDataListToArray();
				this.UpdateHuntState();
			}
		}
	}

	// Token: 0x06001461 RID: 5217 RVA: 0x0006AE60 File Offset: 0x00069060
	public override bool CanAffectPlayer(Player player, bool thisFrame)
	{
		return !this.waitingToStartNextHuntGame && !this.currentHunted.Contains(player) && this.currentTarget.Contains(player);
	}

	// Token: 0x06001462 RID: 5218 RVA: 0x0006AE86 File Offset: 0x00069086
	public override void OnPlayerEnteredRoom(Player newPlayer)
	{
		bool isMasterClient = PhotonNetwork.LocalPlayer.IsMasterClient;
	}

	// Token: 0x06001463 RID: 5219 RVA: 0x0006AE93 File Offset: 0x00069093
	public override void NewVRRig(Player player, int vrrigPhotonViewID, bool didntDoTutorial)
	{
		base.NewVRRig(player, vrrigPhotonViewID, didntDoTutorial);
		if (PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			if (!this.waitingToStartNextHuntGame && this.huntStarted)
			{
				this.currentHunted.Add(player);
				this.CopyHuntDataListToArray();
			}
			this.UpdateState();
		}
	}

	// Token: 0x06001464 RID: 5220 RVA: 0x0006AED4 File Offset: 0x000690D4
	public override void OnPlayerLeftRoom(Player otherPlayer)
	{
		base.OnPlayerLeftRoom(otherPlayer);
		if (PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			if (this.currentTarget.Contains(otherPlayer))
			{
				this.currentTarget.Remove(otherPlayer);
				this.CopyHuntDataListToArray();
			}
			if (this.currentHunted.Contains(otherPlayer))
			{
				this.currentHunted.Remove(otherPlayer);
				this.CopyHuntDataListToArray();
			}
			this.UpdateState();
		}
	}

	// Token: 0x06001465 RID: 5221 RVA: 0x0006AF3C File Offset: 0x0006913C
	private void CopyHuntDataListToArray()
	{
		this.copyListToArrayIndex = 0;
		while (this.copyListToArrayIndex < 10)
		{
			this.currentHuntedArray[this.copyListToArrayIndex] = 0;
			this.currentTargetArray[this.copyListToArrayIndex] = 0;
			this.copyListToArrayIndex++;
		}
		this.copyListToArrayIndex = this.currentHunted.Count - 1;
		while (this.copyListToArrayIndex >= 0)
		{
			if (this.currentHunted[this.copyListToArrayIndex] == null)
			{
				this.currentHunted.RemoveAt(this.copyListToArrayIndex);
			}
			this.copyListToArrayIndex--;
		}
		this.copyListToArrayIndex = this.currentTarget.Count - 1;
		while (this.copyListToArrayIndex >= 0)
		{
			if (this.currentTarget[this.copyListToArrayIndex] == null)
			{
				this.currentTarget.RemoveAt(this.copyListToArrayIndex);
			}
			this.copyListToArrayIndex--;
		}
		this.copyListToArrayIndex = 0;
		while (this.copyListToArrayIndex < this.currentHunted.Count)
		{
			this.currentHuntedArray[this.copyListToArrayIndex] = this.currentHunted[this.copyListToArrayIndex].ActorNumber;
			this.copyListToArrayIndex++;
		}
		this.copyListToArrayIndex = 0;
		while (this.copyListToArrayIndex < this.currentTarget.Count)
		{
			this.currentTargetArray[this.copyListToArrayIndex] = this.currentTarget[this.copyListToArrayIndex].ActorNumber;
			this.copyListToArrayIndex++;
		}
	}

	// Token: 0x06001466 RID: 5222 RVA: 0x0006B0C0 File Offset: 0x000692C0
	private void CopyHuntDataArrayToList()
	{
		this.currentTarget.Clear();
		this.copyArrayToListIndex = 0;
		while (this.copyArrayToListIndex < this.currentTargetArray.Length)
		{
			if (this.currentTargetArray[this.copyArrayToListIndex] != 0)
			{
				this.tempPlayer = PhotonNetwork.LocalPlayer.Get(this.currentTargetArray[this.copyArrayToListIndex]);
				if (this.tempPlayer != null)
				{
					this.currentTarget.Add(this.tempPlayer);
				}
			}
			this.copyArrayToListIndex++;
		}
		this.currentHunted.Clear();
		this.copyArrayToListIndex = 0;
		while (this.copyArrayToListIndex < this.currentHuntedArray.Length)
		{
			if (this.currentHuntedArray[this.copyArrayToListIndex] != 0)
			{
				this.tempPlayer = PhotonNetwork.LocalPlayer.Get(this.currentHuntedArray[this.copyArrayToListIndex]);
				if (this.tempPlayer != null)
				{
					this.currentHunted.Add(this.tempPlayer);
				}
			}
			this.copyArrayToListIndex++;
		}
	}

	// Token: 0x06001467 RID: 5223 RVA: 0x0006B1BB File Offset: 0x000693BB
	public override void OnMasterClientSwitched(Player newMasterClient)
	{
		base.OnMasterClientSwitched(newMasterClient);
		if (PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			this.CopyRoomDataToLocalData();
			this.UpdateState();
		}
	}

	// Token: 0x06001468 RID: 5224 RVA: 0x0006B1DC File Offset: 0x000693DC
	public void CopyRoomDataToLocalData()
	{
		this.waitingToStartNextHuntGame = false;
		this.UpdateHuntState();
	}

	// Token: 0x06001469 RID: 5225 RVA: 0x0006B1EC File Offset: 0x000693EC
	public override void OnSerializeWrite(PhotonStream stream, PhotonMessageInfo info)
	{
		stream.SendNext(this.currentHuntedArray[0]);
		stream.SendNext(this.currentHuntedArray[1]);
		stream.SendNext(this.currentHuntedArray[2]);
		stream.SendNext(this.currentHuntedArray[3]);
		stream.SendNext(this.currentHuntedArray[4]);
		stream.SendNext(this.currentHuntedArray[5]);
		stream.SendNext(this.currentHuntedArray[6]);
		stream.SendNext(this.currentHuntedArray[7]);
		stream.SendNext(this.currentHuntedArray[8]);
		stream.SendNext(this.currentHuntedArray[9]);
		stream.SendNext(this.currentTargetArray[0]);
		stream.SendNext(this.currentTargetArray[1]);
		stream.SendNext(this.currentTargetArray[2]);
		stream.SendNext(this.currentTargetArray[3]);
		stream.SendNext(this.currentTargetArray[4]);
		stream.SendNext(this.currentTargetArray[5]);
		stream.SendNext(this.currentTargetArray[6]);
		stream.SendNext(this.currentTargetArray[7]);
		stream.SendNext(this.currentTargetArray[8]);
		stream.SendNext(this.currentTargetArray[9]);
		stream.SendNext(this.huntStarted);
		stream.SendNext(this.waitingToStartNextHuntGame);
		stream.SendNext(this.countDownTime);
	}

	// Token: 0x0600146A RID: 5226 RVA: 0x0006B3AC File Offset: 0x000695AC
	public override void OnSerializeRead(PhotonStream stream, PhotonMessageInfo info)
	{
		this.currentHuntedArray[0] = (int)stream.ReceiveNext();
		this.currentHuntedArray[1] = (int)stream.ReceiveNext();
		this.currentHuntedArray[2] = (int)stream.ReceiveNext();
		this.currentHuntedArray[3] = (int)stream.ReceiveNext();
		this.currentHuntedArray[4] = (int)stream.ReceiveNext();
		this.currentHuntedArray[5] = (int)stream.ReceiveNext();
		this.currentHuntedArray[6] = (int)stream.ReceiveNext();
		this.currentHuntedArray[7] = (int)stream.ReceiveNext();
		this.currentHuntedArray[8] = (int)stream.ReceiveNext();
		this.currentHuntedArray[9] = (int)stream.ReceiveNext();
		this.currentTargetArray[0] = (int)stream.ReceiveNext();
		this.currentTargetArray[1] = (int)stream.ReceiveNext();
		this.currentTargetArray[2] = (int)stream.ReceiveNext();
		this.currentTargetArray[3] = (int)stream.ReceiveNext();
		this.currentTargetArray[4] = (int)stream.ReceiveNext();
		this.currentTargetArray[5] = (int)stream.ReceiveNext();
		this.currentTargetArray[6] = (int)stream.ReceiveNext();
		this.currentTargetArray[7] = (int)stream.ReceiveNext();
		this.currentTargetArray[8] = (int)stream.ReceiveNext();
		this.currentTargetArray[9] = (int)stream.ReceiveNext();
		this.huntStarted = (bool)stream.ReceiveNext();
		this.waitingToStartNextHuntGame = (bool)stream.ReceiveNext();
		this.countDownTime = (int)stream.ReceiveNext();
		this.CopyHuntDataArrayToList();
	}

	// Token: 0x0600146B RID: 5227 RVA: 0x0006B570 File Offset: 0x00069770
	public override int MyMatIndex(Player forPlayer)
	{
		if (this.currentHunted.Contains(forPlayer) || (this.huntStarted && this.GetTargetOf(forPlayer) == null))
		{
			return 3;
		}
		return 0;
	}

	// Token: 0x0600146C RID: 5228 RVA: 0x0006B594 File Offset: 0x00069794
	public override float[] LocalPlayerSpeed()
	{
		if (this.currentHunted.Contains(PhotonNetwork.LocalPlayer) || (this.huntStarted && this.GetTargetOf(PhotonNetwork.LocalPlayer) == null))
		{
			return new float[]
			{
				8.5f,
				1.3f
			};
		}
		if (GorillaTagger.Instance.currentStatus == GorillaTagger.StatusEffect.Slowed)
		{
			return new float[]
			{
				5.5f,
				0.9f
			};
		}
		return new float[]
		{
			6.5f,
			1.1f
		};
	}

	// Token: 0x0600146D RID: 5229 RVA: 0x0006B619 File Offset: 0x00069819
	public override void InfrequentUpdate()
	{
		base.InfrequentUpdate();
	}

	// Token: 0x0400172A RID: 5930
	public float tagCoolDown = 5f;

	// Token: 0x0400172B RID: 5931
	public int[] currentHuntedArray = new int[10];

	// Token: 0x0400172C RID: 5932
	public List<Player> currentHunted = new List<Player>(10);

	// Token: 0x0400172D RID: 5933
	public int[] currentTargetArray = new int[10];

	// Token: 0x0400172E RID: 5934
	public List<Player> currentTarget = new List<Player>(10);

	// Token: 0x0400172F RID: 5935
	public bool huntStarted;

	// Token: 0x04001730 RID: 5936
	public bool waitingToStartNextHuntGame;

	// Token: 0x04001731 RID: 5937
	public bool inStartCountdown;

	// Token: 0x04001732 RID: 5938
	public int countDownTime;

	// Token: 0x04001733 RID: 5939
	public double timeHuntGameEnded;

	// Token: 0x04001734 RID: 5940
	public float timeLastSlowTagged;

	// Token: 0x04001735 RID: 5941
	public object objRef;

	// Token: 0x04001736 RID: 5942
	private int iterator1;

	// Token: 0x04001737 RID: 5943
	private Player tempRandPlayer;

	// Token: 0x04001738 RID: 5944
	private int tempRandIndex;

	// Token: 0x04001739 RID: 5945
	private int notHuntedCount;

	// Token: 0x0400173A RID: 5946
	private int tempTargetIndex;

	// Token: 0x0400173B RID: 5947
	private Player tempPlayer;

	// Token: 0x0400173C RID: 5948
	private int copyListToArrayIndex;

	// Token: 0x0400173D RID: 5949
	private int copyArrayToListIndex;
}
