﻿using System;
using System.Collections.Generic;
using System.Linq;
using GorillaLocomotion;
using UnityEngine;

// Token: 0x020002F2 RID: 754
public class DebugSpawnPointChanger : MonoBehaviour
{
	// Token: 0x0600115E RID: 4446 RVA: 0x0005BC6C File Offset: 0x00059E6C
	private void AttachSpawnPoint(VRRig rig, Transform[] spawnPts, int locationIndex)
	{
		if (spawnPts == null)
		{
			return;
		}
		Player player = Object.FindObjectOfType<Player>();
		if (player == null)
		{
			return;
		}
		this.lastLocationIndex = locationIndex;
		int i = 0;
		while (i < spawnPts.Length)
		{
			Transform transform = spawnPts[i];
			if (transform.name == this.levelTriggers[locationIndex].levelName)
			{
				rig.transform.position = transform.position;
				rig.transform.rotation = transform.rotation;
				player.transform.position = transform.position;
				player.transform.rotation = transform.rotation;
				player.InitializeValues();
				SpawnPoint component = transform.GetComponent<SpawnPoint>();
				if (component != null)
				{
					player.scale = component.startSize;
					ZoneManagement.SetActiveZone(component.startZone);
					return;
				}
				Debug.LogWarning("Attempt to spawn at transform that does not have SpawnPoint component will be ignored: " + transform.name);
				return;
			}
			else
			{
				i++;
			}
		}
	}

	// Token: 0x0600115F RID: 4447 RVA: 0x0005BD60 File Offset: 0x00059F60
	private void ChangePoint(int index)
	{
		SpawnManager spawnManager = Object.FindObjectOfType<SpawnManager>();
		if (spawnManager != null)
		{
			Transform[] spawnPts = spawnManager.ChildrenXfs();
			foreach (VRRig rig in (VRRig[])Object.FindObjectsOfType(typeof(VRRig)))
			{
				this.AttachSpawnPoint(rig, spawnPts, index);
			}
		}
	}

	// Token: 0x06001160 RID: 4448 RVA: 0x0005BDB5 File Offset: 0x00059FB5
	public List<string> GetPlausibleJumpLocation()
	{
		return (from index in this.levelTriggers[this.lastLocationIndex].canJumpToIndex
		select this.levelTriggers[index].levelName).ToList<string>();
	}

	// Token: 0x06001161 RID: 4449 RVA: 0x0005BDE4 File Offset: 0x00059FE4
	public void JumpTo(int canJumpIndex)
	{
		DebugSpawnPointChanger.GeoTriggersGroup geoTriggersGroup = this.levelTriggers[this.lastLocationIndex];
		this.ChangePoint(geoTriggersGroup.canJumpToIndex[canJumpIndex]);
	}

	// Token: 0x06001162 RID: 4450 RVA: 0x0005BE14 File Offset: 0x0005A014
	public void SetLastLocation(string levelName)
	{
		for (int i = 0; i < this.levelTriggers.Length; i++)
		{
			if (!(this.levelTriggers[i].levelName != levelName))
			{
				this.lastLocationIndex = i;
				return;
			}
		}
	}

	// Token: 0x040013A9 RID: 5033
	[SerializeField]
	private DebugSpawnPointChanger.GeoTriggersGroup[] levelTriggers;

	// Token: 0x040013AA RID: 5034
	private int lastLocationIndex;

	// Token: 0x020002F3 RID: 755
	[Serializable]
	private struct GeoTriggersGroup
	{
		// Token: 0x040013AB RID: 5035
		public string levelName;

		// Token: 0x040013AC RID: 5036
		public GorillaGeoHideShowTrigger enterTrigger;

		// Token: 0x040013AD RID: 5037
		public GorillaGeoHideShowTrigger[] leaveTrigger;

		// Token: 0x040013AE RID: 5038
		public int[] canJumpToIndex;
	}
}
