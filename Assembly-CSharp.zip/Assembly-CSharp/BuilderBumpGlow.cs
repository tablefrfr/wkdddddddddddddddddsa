﻿using System;
using UnityEngine;

// Token: 0x02000317 RID: 791
public class BuilderBumpGlow : MonoBehaviour
{
	// Token: 0x060011CD RID: 4557 RVA: 0x0005CF0B File Offset: 0x0005B10B
	public void Awake()
	{
		this.blendIn = 1f;
		this.intensity = 0f;
		this.UpdateRender();
	}

	// Token: 0x060011CE RID: 4558 RVA: 0x0005CF29 File Offset: 0x0005B129
	public void SetIntensity(float intensity)
	{
		this.intensity = intensity;
		this.UpdateRender();
	}

	// Token: 0x060011CF RID: 4559 RVA: 0x0005CF38 File Offset: 0x0005B138
	public void SetBlendIn(float blendIn)
	{
		this.blendIn = blendIn;
		this.UpdateRender();
	}

	// Token: 0x060011D0 RID: 4560 RVA: 0x00003051 File Offset: 0x00001251
	private void UpdateRender()
	{
	}

	// Token: 0x04001452 RID: 5202
	public MeshRenderer glowRenderer;

	// Token: 0x04001453 RID: 5203
	private float blendIn;

	// Token: 0x04001454 RID: 5204
	private float intensity;
}
