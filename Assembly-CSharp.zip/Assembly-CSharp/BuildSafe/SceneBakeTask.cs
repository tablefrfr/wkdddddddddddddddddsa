﻿using System;
using System.Diagnostics;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace BuildSafe
{
	// Token: 0x0200062D RID: 1581
	public abstract class SceneBakeTask : MonoBehaviour
	{
		// Token: 0x17000434 RID: 1076
		// (get) Token: 0x06002533 RID: 9523 RVA: 0x000B70D3 File Offset: 0x000B52D3
		// (set) Token: 0x06002534 RID: 9524 RVA: 0x000B70DB File Offset: 0x000B52DB
		public SceneBakeMode bakeMode
		{
			get
			{
				return this.m_bakeMode;
			}
			set
			{
				this.m_bakeMode = value;
			}
		}

		// Token: 0x17000435 RID: 1077
		// (get) Token: 0x06002535 RID: 9525 RVA: 0x000B70E4 File Offset: 0x000B52E4
		// (set) Token: 0x06002536 RID: 9526 RVA: 0x000B70EC File Offset: 0x000B52EC
		public virtual int callbackOrder
		{
			get
			{
				return this.m_callbackOrder;
			}
			set
			{
				this.m_callbackOrder = value;
			}
		}

		// Token: 0x17000436 RID: 1078
		// (get) Token: 0x06002537 RID: 9527 RVA: 0x000B70F5 File Offset: 0x000B52F5
		// (set) Token: 0x06002538 RID: 9528 RVA: 0x000B70FD File Offset: 0x000B52FD
		public bool runIfInactive
		{
			get
			{
				return this.m_runIfInactive;
			}
			set
			{
				this.m_runIfInactive = value;
			}
		}

		// Token: 0x06002539 RID: 9529
		[Conditional("UNITY_EDITOR")]
		public abstract void OnSceneBake(Scene scene, SceneBakeMode mode);

		// Token: 0x0600253A RID: 9530 RVA: 0x00003051 File Offset: 0x00001251
		[Conditional("UNITY_EDITOR")]
		private void ForceRun()
		{
		}

		// Token: 0x04002802 RID: 10242
		[SerializeField]
		private SceneBakeMode m_bakeMode;

		// Token: 0x04002803 RID: 10243
		[SerializeField]
		private int m_callbackOrder;

		// Token: 0x04002804 RID: 10244
		[Space]
		[SerializeField]
		private bool m_runIfInactive = true;
	}
}
