﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using AA;
using GorillaLocomotion.Climbing;
using GorillaLocomotion.Gameplay;
using GorillaLocomotion.Swimming;
using GorillaTag;
using Photon.Pun;
using UnityEngine;
using UnityEngine.XR;

namespace GorillaLocomotion
{
	// Token: 0x020005AC RID: 1452
	public class Player : MonoBehaviour
	{
		// Token: 0x170003EB RID: 1003
		// (get) Token: 0x060021BE RID: 8638 RVA: 0x0009ECF1 File Offset: 0x0009CEF1
		public static Player Instance
		{
			get
			{
				return Player._instance;
			}
		}

		// Token: 0x170003EC RID: 1004
		// (get) Token: 0x060021BF RID: 8639 RVA: 0x0009ECF8 File Offset: 0x0009CEF8
		public bool IsDefaultScale
		{
			get
			{
				return Mathf.Abs(1f - this.scale) < 0.001f;
			}
		}

		// Token: 0x170003ED RID: 1005
		// (get) Token: 0x060021C0 RID: 8640 RVA: 0x0009ED12 File Offset: 0x0009CF12
		public bool turnedThisFrame
		{
			get
			{
				return this.degreesTurnedThisFrame != 0f;
			}
		}

		// Token: 0x170003EE RID: 1006
		// (get) Token: 0x060021C1 RID: 8641 RVA: 0x0009ED24 File Offset: 0x0009CF24
		public List<Player.MaterialData> materialData
		{
			get
			{
				return this.materialDatasSO.datas;
			}
		}

		// Token: 0x170003EF RID: 1007
		// (get) Token: 0x060021C2 RID: 8642 RVA: 0x0009ED31 File Offset: 0x0009CF31
		public List<WaterVolume> HeadOverlappingWaterVolumes
		{
			get
			{
				return this.headOverlappingWaterVolumes;
			}
		}

		// Token: 0x170003F0 RID: 1008
		// (get) Token: 0x060021C3 RID: 8643 RVA: 0x0009ED39 File Offset: 0x0009CF39
		public bool InWater
		{
			get
			{
				return this.bodyInWater;
			}
		}

		// Token: 0x170003F1 RID: 1009
		// (get) Token: 0x060021C4 RID: 8644 RVA: 0x0009ED41 File Offset: 0x0009CF41
		public bool HeadInWater
		{
			get
			{
				return this.headInWater;
			}
		}

		// Token: 0x170003F2 RID: 1010
		// (get) Token: 0x060021C5 RID: 8645 RVA: 0x0009ED49 File Offset: 0x0009CF49
		public WaterVolume CurrentWaterVolume
		{
			get
			{
				if (this.bodyOverlappingWaterVolumes.Count <= 0)
				{
					return null;
				}
				return this.bodyOverlappingWaterVolumes[0];
			}
		}

		// Token: 0x170003F3 RID: 1011
		// (get) Token: 0x060021C6 RID: 8646 RVA: 0x0009ED67 File Offset: 0x0009CF67
		public WaterVolume.SurfaceQuery WaterSurfaceForHead
		{
			get
			{
				return this.waterSurfaceForHead;
			}
		}

		// Token: 0x170003F4 RID: 1012
		// (get) Token: 0x060021C7 RID: 8647 RVA: 0x0009ED6F File Offset: 0x0009CF6F
		public WaterVolume LeftHandWaterVolume
		{
			get
			{
				return this.leftHandWaterVolume;
			}
		}

		// Token: 0x170003F5 RID: 1013
		// (get) Token: 0x060021C8 RID: 8648 RVA: 0x0009ED77 File Offset: 0x0009CF77
		public WaterVolume RightHandWaterVolume
		{
			get
			{
				return this.rightHandWaterVolume;
			}
		}

		// Token: 0x170003F6 RID: 1014
		// (get) Token: 0x060021C9 RID: 8649 RVA: 0x0009ED7F File Offset: 0x0009CF7F
		public WaterVolume.SurfaceQuery LeftHandWaterSurface
		{
			get
			{
				return this.leftHandWaterSurface;
			}
		}

		// Token: 0x170003F7 RID: 1015
		// (get) Token: 0x060021CA RID: 8650 RVA: 0x0009ED87 File Offset: 0x0009CF87
		public WaterVolume.SurfaceQuery RightHandWaterSurface
		{
			get
			{
				return this.rightHandWaterSurface;
			}
		}

		// Token: 0x170003F8 RID: 1016
		// (get) Token: 0x060021CB RID: 8651 RVA: 0x0009ED8F File Offset: 0x0009CF8F
		public Vector3 LastLeftHandPosition
		{
			get
			{
				return this.lastLeftHandPosition;
			}
		}

		// Token: 0x170003F9 RID: 1017
		// (get) Token: 0x060021CC RID: 8652 RVA: 0x0009ED97 File Offset: 0x0009CF97
		public Vector3 LastRightHandPosition
		{
			get
			{
				return this.lastRightHandPosition;
			}
		}

		// Token: 0x170003FA RID: 1018
		// (get) Token: 0x060021CD RID: 8653 RVA: 0x0009ED9F File Offset: 0x0009CF9F
		public Vector3 Velocity
		{
			get
			{
				return this.playerRigidBody.velocity;
			}
		}

		// Token: 0x170003FB RID: 1019
		// (get) Token: 0x060021CE RID: 8654 RVA: 0x0009EDAC File Offset: 0x0009CFAC
		public Vector3 HeadCenterPosition
		{
			get
			{
				return this.headCollider.transform.position + this.headCollider.transform.rotation * new Vector3(0f, 0f, -0.11f);
			}
		}

		// Token: 0x170003FC RID: 1020
		// (get) Token: 0x060021CF RID: 8655 RVA: 0x0009EDEC File Offset: 0x0009CFEC
		public bool HandContactingSurface
		{
			get
			{
				return this.leftHandColliding || this.rightHandColliding;
			}
		}

		// Token: 0x170003FD RID: 1021
		// (get) Token: 0x060021D0 RID: 8656 RVA: 0x0009EDFE File Offset: 0x0009CFFE
		public bool BodyOnGround
		{
			get
			{
				return this.bodyGroundContactTime >= Time.time - 0.05f;
			}
		}

		// Token: 0x170003FE RID: 1022
		// (set) Token: 0x060021D1 RID: 8657 RVA: 0x0009EE16 File Offset: 0x0009D016
		public Quaternion PlayerRotationOverride
		{
			set
			{
				this.playerRotationOverride = value;
				this.playerRotationOverrideFrame = Time.frameCount;
			}
		}

		// Token: 0x060021D2 RID: 8658 RVA: 0x0009EE2C File Offset: 0x0009D02C
		private void Awake()
		{
			if (Player._instance != null && Player._instance != this)
			{
				Object.Destroy(base.gameObject);
			}
			else
			{
				Player._instance = this;
				Player.hasInstance = true;
			}
			this.InitializeValues();
			this.playerRigidBody.maxAngularVelocity = 0f;
			this.bodyOffsetVector = new Vector3(0f, -this.bodyCollider.height / 2f, 0f);
			this.bodyInitialHeight = this.bodyCollider.height;
			this.bodyInitialRadius = this.bodyCollider.radius;
			this.rayCastNonAllocColliders = new RaycastHit[5];
			this.crazyCheckVectors = new Vector3[7];
			this.emptyHit = default(RaycastHit);
			this.crazyCheckVectors[0] = Vector3.up;
			this.crazyCheckVectors[1] = Vector3.down;
			this.crazyCheckVectors[2] = Vector3.left;
			this.crazyCheckVectors[3] = Vector3.right;
			this.crazyCheckVectors[4] = Vector3.forward;
			this.crazyCheckVectors[5] = Vector3.back;
			this.crazyCheckVectors[6] = Vector3.zero;
			if (this.controllerState == null)
			{
				this.controllerState = base.GetComponent<ConnectedControllerHandler>();
			}
		}

		// Token: 0x060021D3 RID: 8659 RVA: 0x0009EF80 File Offset: 0x0009D180
		protected void Start()
		{
			if (this.mainCamera == null)
			{
				this.mainCamera = Camera.main;
			}
			this.mainCamera.farClipPlane = 500f;
			this.lastScale = this.scale;
			float degrees = Quaternion.Angle(Quaternion.identity, GorillaTagger.Instance.offlineVRRig.transform.rotation) * Mathf.Sign(Vector3.Dot(Vector3.up, GorillaTagger.Instance.offlineVRRig.transform.right));
			this.Turn(degrees);
		}

		// Token: 0x060021D4 RID: 8660 RVA: 0x0009F00C File Offset: 0x0009D20C
		protected void OnDestroy()
		{
			if (Player._instance == this)
			{
				Player._instance = null;
				Player.hasInstance = false;
			}
			if (this.climbHelper)
			{
				Object.Destroy(this.climbHelper.gameObject);
			}
		}

		// Token: 0x060021D5 RID: 8661 RVA: 0x0009F044 File Offset: 0x0009D244
		public void InitializeValues()
		{
			Physics.SyncTransforms();
			this.playerRigidBody = base.GetComponent<Rigidbody>();
			this.velocityHistory = new Vector3[this.velocityHistorySize];
			this.slideAverageHistory = new Vector3[this.velocityHistorySize];
			for (int i = 0; i < this.velocityHistory.Length; i++)
			{
				this.velocityHistory[i] = Vector3.zero;
				this.slideAverageHistory[i] = Vector3.zero;
			}
			this.leftHandFollower.transform.position = this.leftControllerTransform.position;
			this.rightHandFollower.transform.position = this.rightControllerTransform.position;
			this.lastLeftHandPosition = this.leftHandFollower.transform.position;
			this.lastRightHandPosition = this.rightHandFollower.transform.position;
			this.lastHeadPosition = this.headCollider.transform.position;
			this.wasLeftHandTouching = false;
			this.wasRightHandTouching = false;
			this.velocityIndex = 0;
			this.denormalizedVelocityAverage = Vector3.zero;
			this.slideAverage = Vector3.zero;
			this.lastPosition = base.transform.position;
			this.lastRealTime = Time.realtimeSinceStartup;
			this.lastOpenHeadPosition = this.headCollider.transform.position;
			this.bodyCollider.transform.position = this.PositionWithOffset(this.headCollider.transform, this.bodyOffset) + this.bodyOffsetVector;
			this.bodyCollider.transform.eulerAngles = new Vector3(0f, this.headCollider.transform.eulerAngles.y, 0f);
		}

		// Token: 0x060021D6 RID: 8662 RVA: 0x0009F1F4 File Offset: 0x0009D3F4
		public void SetHalloweenLevitation(float levitateStrength, float levitateDuration, float levitateBlendOutDuration, float levitateBonusStrength, float levitateBonusOffAtYSpeed, float levitateBonusFullAtYSpeed)
		{
			this.halloweenLevitationStrength = levitateStrength;
			this.halloweenLevitationFullStrengthDuration = levitateDuration;
			this.halloweenLevitationTotalDuration = levitateDuration + levitateBlendOutDuration;
			this.halloweenLevitateBonusFullAtYSpeed = levitateBonusFullAtYSpeed;
			this.halloweenLevitateBonusOffAtYSpeed = levitateBonusFullAtYSpeed;
			this.halloweenLevitationBonusStrength = levitateBonusStrength;
		}

		// Token: 0x060021D7 RID: 8663 RVA: 0x0009F225 File Offset: 0x0009D425
		public void TeleportToTrain(bool enable)
		{
			this.teleportToTrain = enable;
		}

		// Token: 0x060021D8 RID: 8664 RVA: 0x0009F22E File Offset: 0x0009D42E
		public void AddForce(Vector3 force, ForceMode mode)
		{
			this.playerRigidBody.AddForce(force, mode);
		}

		// Token: 0x060021D9 RID: 8665 RVA: 0x0009F240 File Offset: 0x0009D440
		public void FixedUpdate()
		{
			this.AntiTeleportTechnology();
			bool isDefaultScale = this.IsDefaultScale;
			if (!isDefaultScale && !this.isClimbing)
			{
				this.playerRigidBody.AddForce(-Physics.gravity * (1f - this.scale), ForceMode.Acceleration);
			}
			if (this.halloweenLevitationBonusStrength > 0f || this.halloweenLevitationStrength > 0f)
			{
				float num = Time.time - this.lastTouchedGroundTimestamp;
				if (num < this.halloweenLevitationTotalDuration)
				{
					this.playerRigidBody.AddForce(Vector3.up * this.halloweenLevitationStrength * Mathf.InverseLerp(this.halloweenLevitationFullStrengthDuration, this.halloweenLevitationTotalDuration, num), ForceMode.Acceleration);
				}
				float y = this.playerRigidBody.velocity.y;
				if (y <= this.halloweenLevitateBonusFullAtYSpeed)
				{
					this.playerRigidBody.AddForce(Vector3.up * this.halloweenLevitationBonusStrength, ForceMode.Acceleration);
				}
				else if (y <= this.halloweenLevitateBonusOffAtYSpeed)
				{
					Mathf.InverseLerp(this.halloweenLevitateBonusOffAtYSpeed, this.halloweenLevitateBonusFullAtYSpeed, this.playerRigidBody.velocity.y);
					this.playerRigidBody.AddForce(Vector3.up * this.halloweenLevitationBonusStrength * Mathf.InverseLerp(this.halloweenLevitateBonusOffAtYSpeed, this.halloweenLevitateBonusFullAtYSpeed, this.playerRigidBody.velocity.y), ForceMode.Acceleration);
				}
			}
			float fixedDeltaTime = Time.fixedDeltaTime;
			this.bodyInWater = false;
			Vector3 lhs = this.swimmingVelocity;
			this.swimmingVelocity = Vector3.MoveTowards(this.swimmingVelocity, Vector3.zero, this.swimmingParams.swimmingVelocityOutOfWaterDrainRate * fixedDeltaTime);
			this.leftHandNonDiveHapticsAmount = 0f;
			this.rightHandNonDiveHapticsAmount = 0f;
			if (this.bodyOverlappingWaterVolumes.Count > 0)
			{
				WaterVolume waterVolume = null;
				float num2 = float.MinValue;
				Vector3 vector = this.headCollider.transform.position + Vector3.down * this.swimmingParams.floatingWaterLevelBelowHead * this.scale;
				this.activeWaterCurrents.Clear();
				for (int i = 0; i < this.bodyOverlappingWaterVolumes.Count; i++)
				{
					WaterVolume.SurfaceQuery surfaceQuery;
					if (this.bodyOverlappingWaterVolumes[i].GetSurfaceQueryForPoint(vector, out surfaceQuery, false))
					{
						float num3 = Vector3.Dot(surfaceQuery.surfacePoint - vector, surfaceQuery.surfaceNormal);
						if (num3 > num2)
						{
							num2 = num3;
							waterVolume = this.bodyOverlappingWaterVolumes[i];
							this.waterSurfaceForHead = surfaceQuery;
						}
						WaterCurrent waterCurrent = this.bodyOverlappingWaterVolumes[i].Current;
						if (waterCurrent != null && num3 > 0f && !this.activeWaterCurrents.Contains(waterCurrent))
						{
							this.activeWaterCurrents.Add(waterCurrent);
						}
					}
				}
				if (waterVolume != null)
				{
					Vector3 velocity = this.playerRigidBody.velocity;
					float magnitude = velocity.magnitude;
					bool flag = this.headInWater;
					this.headInWater = (this.headCollider.transform.position.y < this.waterSurfaceForHead.surfacePoint.y && this.headCollider.transform.position.y > this.waterSurfaceForHead.surfacePoint.y - this.waterSurfaceForHead.maxDepth);
					if (this.headInWater && !flag)
					{
						this.audioManager.SetMixerSnapshot(this.audioManager.underwaterSnapshot, 0.1f);
					}
					else if (!this.headInWater && flag)
					{
						this.audioManager.UnsetMixerSnapshot(0.1f);
					}
					this.bodyInWater = (vector.y < this.waterSurfaceForHead.surfacePoint.y && vector.y > this.waterSurfaceForHead.surfacePoint.y - this.waterSurfaceForHead.maxDepth);
					if (this.bodyInWater)
					{
						Player.LiquidProperties liquidProperties = this.liquidPropertiesList[(int)waterVolume.LiquidType];
						if (waterVolume != null)
						{
							float d;
							if (this.swimmingParams.extendBouyancyFromSpeed)
							{
								float time = Mathf.Clamp(Vector3.Dot(velocity / this.scale, this.waterSurfaceForHead.surfaceNormal), this.swimmingParams.speedToBouyancyExtensionMinMax.x, this.swimmingParams.speedToBouyancyExtensionMinMax.y);
								float b = this.swimmingParams.speedToBouyancyExtension.Evaluate(time);
								this.buoyancyExtension = Mathf.Max(this.buoyancyExtension, b);
								float num4 = Mathf.InverseLerp(0f, this.swimmingParams.buoyancyFadeDist + this.buoyancyExtension, num2 / this.scale + this.buoyancyExtension);
								this.buoyancyExtension = Spring.DamperDecayExact(this.buoyancyExtension, this.swimmingParams.buoyancyExtensionDecayHalflife, fixedDeltaTime, 1E-05f);
								d = num4;
							}
							else
							{
								d = Mathf.InverseLerp(0f, this.swimmingParams.buoyancyFadeDist, num2 / this.scale);
							}
							Vector3 a = Physics.gravity * this.scale;
							Vector3 force = liquidProperties.buoyancy * -a * d;
							this.playerRigidBody.AddForce(force, ForceMode.Acceleration);
						}
						Vector3 vector2 = Vector3.zero;
						Vector3 vector3 = Vector3.zero;
						for (int j = 0; j < this.activeWaterCurrents.Count; j++)
						{
							WaterCurrent waterCurrent2 = this.activeWaterCurrents[j];
							Vector3 startingVelocity = velocity + vector2;
							Vector3 b2;
							Vector3 b3;
							if (waterCurrent2.GetCurrentAtPoint(this.bodyCollider.transform.position, startingVelocity, fixedDeltaTime, out b2, out b3))
							{
								vector3 += b2;
								vector2 += b3;
							}
						}
						if (magnitude > Mathf.Epsilon)
						{
							float num5 = 0.01f;
							Vector3 vector4 = velocity / magnitude;
							Vector3 right = this.leftHandFollower.right;
							Vector3 dir = -this.rightHandFollower.right;
							Vector3 forward = this.leftHandFollower.forward;
							Vector3 forward2 = this.rightHandFollower.forward;
							Vector3 a2 = vector4;
							float num6 = 0f;
							float num7 = 0f;
							float num8 = 0f;
							if (this.swimmingParams.applyDiveSteering && !this.disableMovement && isDefaultScale)
							{
								float value = Vector3.Dot(velocity - vector3, vector4);
								float time2 = Mathf.Clamp(value, this.swimmingParams.swimSpeedToRedirectAmountMinMax.x, this.swimmingParams.swimSpeedToRedirectAmountMinMax.y);
								float b4 = this.swimmingParams.swimSpeedToRedirectAmount.Evaluate(time2);
								time2 = Mathf.Clamp(value, this.swimmingParams.swimSpeedToMaxRedirectAngleMinMax.x, this.swimmingParams.swimSpeedToMaxRedirectAngleMinMax.y);
								float num9 = this.swimmingParams.swimSpeedToMaxRedirectAngle.Evaluate(time2);
								float value2 = Mathf.Acos(Vector3.Dot(vector4, forward)) / 3.1415927f * -2f + 1f;
								float value3 = Mathf.Acos(Vector3.Dot(vector4, forward2)) / 3.1415927f * -2f + 1f;
								float num10 = Mathf.Clamp(value2, this.swimmingParams.palmFacingToRedirectAmountMinMax.x, this.swimmingParams.palmFacingToRedirectAmountMinMax.y);
								float num11 = Mathf.Clamp(value3, this.swimmingParams.palmFacingToRedirectAmountMinMax.x, this.swimmingParams.palmFacingToRedirectAmountMinMax.y);
								float a3 = (!float.IsNaN(num10)) ? this.swimmingParams.palmFacingToRedirectAmount.Evaluate(num10) : 0f;
								float a4 = (!float.IsNaN(num11)) ? this.swimmingParams.palmFacingToRedirectAmount.Evaluate(num11) : 0f;
								Vector3 a5 = Vector3.ProjectOnPlane(vector4, right);
								Vector3 a6 = Vector3.ProjectOnPlane(vector4, right);
								float num12 = Mathf.Min(a5.magnitude, 1f);
								float num13 = Mathf.Min(a6.magnitude, 1f);
								float magnitude2 = this.leftHandCenterVelocityTracker.GetAverageVelocity(false, this.swimmingParams.diveVelocityAveragingWindow, false).magnitude;
								float magnitude3 = this.rightHandCenterVelocityTracker.GetAverageVelocity(false, this.swimmingParams.diveVelocityAveragingWindow, false).magnitude;
								float time3 = Mathf.Clamp(magnitude2, this.swimmingParams.handSpeedToRedirectAmountMinMax.x, this.swimmingParams.handSpeedToRedirectAmountMinMax.y);
								float time4 = Mathf.Clamp(magnitude3, this.swimmingParams.handSpeedToRedirectAmountMinMax.x, this.swimmingParams.handSpeedToRedirectAmountMinMax.y);
								float a7 = this.swimmingParams.handSpeedToRedirectAmount.Evaluate(time3);
								float a8 = this.swimmingParams.handSpeedToRedirectAmount.Evaluate(time4);
								float averageSpeedChangeMagnitudeInDirection = this.leftHandCenterVelocityTracker.GetAverageSpeedChangeMagnitudeInDirection(right, false, this.swimmingParams.diveVelocityAveragingWindow);
								float averageSpeedChangeMagnitudeInDirection2 = this.rightHandCenterVelocityTracker.GetAverageSpeedChangeMagnitudeInDirection(dir, false, this.swimmingParams.diveVelocityAveragingWindow);
								float time5 = Mathf.Clamp(averageSpeedChangeMagnitudeInDirection, this.swimmingParams.handAccelToRedirectAmountMinMax.x, this.swimmingParams.handAccelToRedirectAmountMinMax.y);
								float time6 = Mathf.Clamp(averageSpeedChangeMagnitudeInDirection2, this.swimmingParams.handAccelToRedirectAmountMinMax.x, this.swimmingParams.handAccelToRedirectAmountMinMax.y);
								float b5 = this.swimmingParams.handAccelToRedirectAmount.Evaluate(time5);
								float b6 = this.swimmingParams.handAccelToRedirectAmount.Evaluate(time6);
								num6 = Mathf.Min(a3, Mathf.Min(a7, b5));
								float num14 = (Vector3.Dot(vector4, forward) > 0f) ? (Mathf.Min(num6, b4) * num12) : 0f;
								num7 = Mathf.Min(a4, Mathf.Min(a8, b6));
								float num15 = (Vector3.Dot(vector4, forward2) > 0f) ? (Mathf.Min(num7, b4) * num13) : 0f;
								if (this.swimmingParams.reduceDiveSteeringBelowVelocityPlane)
								{
									Vector3 rhs;
									if (Vector3.Dot(this.headCollider.transform.up, vector4) > 0.95f)
									{
										rhs = -this.headCollider.transform.forward;
									}
									else
									{
										rhs = Vector3.Cross(Vector3.Cross(vector4, this.headCollider.transform.up), vector4).normalized;
									}
									Vector3 position = this.headCollider.transform.position;
									Vector3 lhs2 = position - this.leftHandFollower.position;
									Vector3 lhs3 = position - this.rightHandFollower.position;
									float reduceDiveSteeringBelowPlaneFadeStartDist = this.swimmingParams.reduceDiveSteeringBelowPlaneFadeStartDist;
									float reduceDiveSteeringBelowPlaneFadeEndDist = this.swimmingParams.reduceDiveSteeringBelowPlaneFadeEndDist;
									float f = Vector3.Dot(lhs2, Vector3.up);
									float f2 = Vector3.Dot(lhs3, Vector3.up);
									float f3 = Vector3.Dot(lhs2, rhs);
									float f4 = Vector3.Dot(lhs3, rhs);
									float num16 = 1f - Mathf.InverseLerp(reduceDiveSteeringBelowPlaneFadeStartDist, reduceDiveSteeringBelowPlaneFadeEndDist, Mathf.Min(Mathf.Abs(f), Mathf.Abs(f3)));
									float num17 = 1f - Mathf.InverseLerp(reduceDiveSteeringBelowPlaneFadeStartDist, reduceDiveSteeringBelowPlaneFadeEndDist, Mathf.Min(Mathf.Abs(f2), Mathf.Abs(f4)));
									num14 *= num16;
									num15 *= num17;
								}
								float num18 = num15 + num14;
								Vector3 vector5 = Vector3.zero;
								if (this.swimmingParams.applyDiveSteering && num18 > num5)
								{
									vector5 = ((num14 * a5 + num15 * a6) / num18).normalized;
									vector5 = Vector3.Lerp(vector4, vector5, num18);
									a2 = Vector3.RotateTowards(vector4, vector5, 0.017453292f * num9 * fixedDeltaTime, 0f);
								}
								else
								{
									a2 = vector4;
								}
								num8 = Mathf.Clamp01((num6 + num7) * 0.5f);
							}
							float num19 = Mathf.Clamp(Vector3.Dot(lhs, vector4), 0f, magnitude);
							float num20 = magnitude - num19;
							if (this.swimmingParams.applyDiveSwimVelocityConversion && !this.disableMovement && num8 > num5 && num19 < this.swimmingParams.diveMaxSwimVelocityConversion)
							{
								float num21 = Mathf.Min(this.swimmingParams.diveSwimVelocityConversionRate * fixedDeltaTime, num20) * num8;
								num19 += num21;
								num20 -= num21;
							}
							float halflife = this.swimmingParams.swimUnderWaterDampingHalfLife * liquidProperties.dampingFactor;
							float halflife2 = this.swimmingParams.baseUnderWaterDampingHalfLife * liquidProperties.dampingFactor;
							float num22 = Spring.DamperDecayExact(num19 / this.scale, halflife, fixedDeltaTime, 1E-05f) * this.scale;
							float num23 = Spring.DamperDecayExact(num20 / this.scale, halflife2, fixedDeltaTime, 1E-05f) * this.scale;
							if (this.swimmingParams.applyDiveDampingMultiplier && !this.disableMovement)
							{
								float t = Mathf.Lerp(1f, this.swimmingParams.diveDampingMultiplier, num8);
								num22 = Mathf.Lerp(num19, num22, t);
								num23 = Mathf.Lerp(num20, num23, t);
								float time7 = Mathf.Clamp((1f - num6) * (num19 + num20), this.swimmingParams.nonDiveDampingHapticsAmountMinMax.x + num5, this.swimmingParams.nonDiveDampingHapticsAmountMinMax.y - num5);
								float time8 = Mathf.Clamp((1f - num7) * (num19 + num20), this.swimmingParams.nonDiveDampingHapticsAmountMinMax.x + num5, this.swimmingParams.nonDiveDampingHapticsAmountMinMax.y - num5);
								this.leftHandNonDiveHapticsAmount = this.swimmingParams.nonDiveDampingHapticsAmount.Evaluate(time7);
								this.rightHandNonDiveHapticsAmount = this.swimmingParams.nonDiveDampingHapticsAmount.Evaluate(time8);
							}
							this.swimmingVelocity = num22 * a2 + vector2 * this.scale;
							this.playerRigidBody.velocity = this.swimmingVelocity + num23 * a2;
						}
					}
				}
			}
			this.handleClimbing(Time.fixedDeltaTime);
			this.stuckHandsCheckFixedUpdate();
			this.FixedUpdate_HandHolds(Time.fixedDeltaTime);
		}

		// Token: 0x060021DA RID: 8666 RVA: 0x0009FFD8 File Offset: 0x0009E1D8
		private void BodyCollider()
		{
			if (this.MaxSphereSizeForNoOverlap(this.bodyInitialRadius * this.scale, this.PositionWithOffset(this.headCollider.transform, this.bodyOffset), false, out this.bodyMaxRadius))
			{
				if (this.scale > 0f)
				{
					this.bodyCollider.radius = this.bodyMaxRadius / this.scale;
				}
				if (Physics.SphereCast(this.PositionWithOffset(this.headCollider.transform, this.bodyOffset), this.bodyMaxRadius, Vector3.down, out this.bodyHitInfo, this.bodyInitialHeight * this.scale - this.bodyMaxRadius, this.locomotionEnabledLayers))
				{
					this.bodyCollider.height = (this.bodyHitInfo.distance + this.bodyMaxRadius) / this.scale;
				}
				else
				{
					this.bodyCollider.height = this.bodyInitialHeight;
				}
				if (!this.bodyCollider.gameObject.activeSelf)
				{
					this.bodyCollider.gameObject.SetActive(true);
				}
			}
			else
			{
				this.bodyCollider.gameObject.SetActive(false);
			}
			this.bodyCollider.height = Mathf.Lerp(this.bodyCollider.height, this.bodyInitialHeight, this.bodyLerp);
			this.bodyCollider.radius = Mathf.Lerp(this.bodyCollider.radius, this.bodyInitialRadius, this.bodyLerp);
			this.bodyOffsetVector = Vector3.down * this.bodyCollider.height / 2f;
			this.bodyCollider.transform.position = this.PositionWithOffset(this.headCollider.transform, this.bodyOffset) + this.bodyOffsetVector * this.scale;
			this.bodyCollider.transform.eulerAngles = new Vector3(0f, this.headCollider.transform.eulerAngles.y, 0f);
		}

		// Token: 0x060021DB RID: 8667 RVA: 0x000A01E0 File Offset: 0x0009E3E0
		private Vector3 GetCurrentHandPosition(Transform handTransform, Vector3 handOffset)
		{
			if (this.inOverlay)
			{
				return this.headCollider.transform.position + this.headCollider.transform.up * -0.5f * this.scale;
			}
			if ((this.PositionWithOffset(handTransform, handOffset) - this.headCollider.transform.position).magnitude < this.maxArmLength * this.scale)
			{
				return this.PositionWithOffset(handTransform, handOffset);
			}
			return this.headCollider.transform.position + (this.PositionWithOffset(handTransform, handOffset) - this.headCollider.transform.position).normalized * this.maxArmLength * this.scale;
		}

		// Token: 0x060021DC RID: 8668 RVA: 0x000A02BD File Offset: 0x0009E4BD
		private Vector3 GetLastLeftHandPosition()
		{
			return this.lastLeftHandPosition + this.MovingSurfaceMovement();
		}

		// Token: 0x060021DD RID: 8669 RVA: 0x000A02D0 File Offset: 0x0009E4D0
		private Vector3 GetLastRightHandPosition()
		{
			return this.lastRightHandPosition + this.MovingSurfaceMovement();
		}

		// Token: 0x060021DE RID: 8670 RVA: 0x000A02E4 File Offset: 0x0009E4E4
		private Vector3 GetCurrentLeftHandPosition()
		{
			if (this.inOverlay)
			{
				return this.headCollider.transform.position + this.headCollider.transform.up * -0.5f * this.scale;
			}
			if ((this.PositionWithOffset(this.leftControllerTransform, this.leftHandOffset) - this.headCollider.transform.position).magnitude < this.maxArmLength * this.scale)
			{
				return this.PositionWithOffset(this.leftControllerTransform, this.leftHandOffset);
			}
			return this.headCollider.transform.position + (this.PositionWithOffset(this.leftControllerTransform, this.leftHandOffset) - this.headCollider.transform.position).normalized * this.maxArmLength * this.scale;
		}

		// Token: 0x060021DF RID: 8671 RVA: 0x000A03E0 File Offset: 0x0009E5E0
		private Vector3 GetCurrentRightHandPosition()
		{
			if (this.inOverlay)
			{
				return this.headCollider.transform.position + this.headCollider.transform.up * -0.5f * this.scale;
			}
			if ((this.PositionWithOffset(this.rightControllerTransform, this.rightHandOffset) - this.headCollider.transform.position).magnitude < this.maxArmLength * this.scale)
			{
				return this.PositionWithOffset(this.rightControllerTransform, this.rightHandOffset);
			}
			return this.headCollider.transform.position + (this.PositionWithOffset(this.rightControllerTransform, this.rightHandOffset) - this.headCollider.transform.position).normalized * this.maxArmLength * this.scale;
		}

		// Token: 0x060021E0 RID: 8672 RVA: 0x000A04DB File Offset: 0x0009E6DB
		private Vector3 PositionWithOffset(Transform transformToModify, Vector3 offsetVector)
		{
			return transformToModify.position + transformToModify.rotation * offsetVector * this.scale;
		}

		// Token: 0x060021E1 RID: 8673 RVA: 0x000A0500 File Offset: 0x0009E700
		private void LateUpdate()
		{
			if (this.playerRigidBody.isKinematic)
			{
				return;
			}
			float time = Time.time;
			Vector3 position = this.headCollider.transform.position;
			if (this.playerRotationOverrideFrame < Time.frameCount - 1)
			{
				this.playerRotationOverride = Quaternion.Slerp(Quaternion.identity, this.playerRotationOverride, Mathf.Exp(-this.playerRotationOverrideDecayRate * Time.deltaTime));
			}
			base.transform.rotation = this.playerRotationOverride;
			this.turnParent.transform.localScale = Vector3.one * this.scale;
			this.playerRigidBody.MovePosition(this.playerRigidBody.position + position - this.headCollider.transform.position);
			if (Math.Abs(this.lastScale - this.scale) > 0.001f)
			{
				if (this.mainCamera == null)
				{
					this.mainCamera = Camera.main;
				}
				this.mainCamera.nearClipPlane = ((this.scale > 0.5f) ? 0.01f : 0.002f);
			}
			this.lastScale = this.scale;
			this.debugLastRightHandPosition = this.lastRightHandPosition;
			this.debugPlatformDeltaPosition = this.MovingSurfaceMovement();
			this.rigidBodyMovement = Vector3.zero;
			this.leftHandPushDisplacement = Vector3.zero;
			this.rightHandPushDisplacement = Vector3.zero;
			if (this.debugMovement)
			{
				this.tempRealTime = Time.time;
				this.calcDeltaTime = Time.deltaTime;
				this.lastRealTime = this.tempRealTime;
			}
			else
			{
				this.tempRealTime = Time.realtimeSinceStartup;
				this.calcDeltaTime = this.tempRealTime - this.lastRealTime;
				this.lastRealTime = this.tempRealTime;
				if (this.calcDeltaTime > 0.1f)
				{
					this.calcDeltaTime = 0.05f;
				}
			}
			Vector3 a;
			if (this.lastFrameHasValidTouchPos && this.lastPlatformTouched != null && Player.ComputeWorldHitPoint(this.lastHitInfoHand, this.lastFrameTouchPosLocal, out a))
			{
				this.refMovement = a - this.lastFrameTouchPosWorld;
			}
			else
			{
				this.refMovement = Vector3.zero;
			}
			if (!this.didAJump && (this.wasLeftHandTouching || this.wasRightHandTouching))
			{
				base.transform.position = base.transform.position + 4.9f * Vector3.down * this.calcDeltaTime * this.calcDeltaTime * this.scale;
				if (Vector3.Dot(this.denormalizedVelocityAverage, this.slideAverageNormal) <= 0f && Vector3.Dot(Vector3.down, this.slideAverageNormal) <= 0f)
				{
					base.transform.position = base.transform.position - Vector3.Project(Mathf.Min(this.stickDepth * this.scale, Vector3.Project(this.denormalizedVelocityAverage, this.slideAverageNormal).magnitude * this.calcDeltaTime) * this.slideAverageNormal, Vector3.down);
				}
			}
			if (!this.didAJump && (this.wasLeftHandSlide || this.wasRightHandSlide))
			{
				base.transform.position = base.transform.position + this.slideAverage * this.calcDeltaTime;
				this.slideAverage += 9.8f * Vector3.down * this.calcDeltaTime * this.scale;
			}
			this.FirstHandIteration(this.leftControllerTransform, this.leftHandOffset, this.GetLastLeftHandPosition(), this.wasLeftHandSlide, this.wasLeftHandTouching, this.LeftSlipOverriddenToMax(), out this.leftHandPushDisplacement, ref this.leftHandSlipPercentage, ref this.leftHandSlide, ref this.leftHandSlideNormal, ref this.leftHandColliding, ref this.leftHandMaterialTouchIndex, ref this.leftHandSurfaceOverride, this.leftHandHolding);
			this.leftHandColliding = (this.leftHandColliding && this.controllerState.LeftValid);
			this.leftHandSlide = (this.leftHandSlide && this.controllerState.LeftValid);
			this.FirstHandIteration(this.rightControllerTransform, this.rightHandOffset, this.GetLastRightHandPosition(), this.wasRightHandSlide, this.wasRightHandTouching, this.RightSlipOverriddenToMax(), out this.rightHandPushDisplacement, ref this.rightHandSlipPercentage, ref this.rightHandSlide, ref this.rightHandSlideNormal, ref this.rightHandColliding, ref this.rightHandMaterialTouchIndex, ref this.rightHandSurfaceOverride, this.rightHandHolding);
			this.rightHandColliding = (this.rightHandColliding && this.controllerState.RightValid);
			this.rightHandSlide = (this.rightHandSlide && this.controllerState.RightValid);
			this.touchPoints = 0;
			this.rigidBodyMovement = Vector3.zero;
			if (this.leftHandColliding || this.wasLeftHandTouching)
			{
				this.rigidBodyMovement += this.leftHandPushDisplacement;
				this.touchPoints++;
			}
			if (this.rightHandColliding || this.wasRightHandTouching)
			{
				this.rigidBodyMovement += this.rightHandPushDisplacement;
				this.touchPoints++;
			}
			if (this.touchPoints != 0)
			{
				this.rigidBodyMovement /= (float)this.touchPoints;
			}
			if (!this.MaxSphereSizeForNoOverlap(this.headCollider.radius * 0.9f * this.scale, this.lastHeadPosition, true, out this.maxSphereSize1) && !this.CrazyCheck2(this.headCollider.radius * 0.9f * 0.75f * this.scale, this.lastHeadPosition))
			{
				this.lastHeadPosition = this.lastOpenHeadPosition;
			}
			if (this.IterativeCollisionSphereCast(this.lastHeadPosition, this.headCollider.radius * 0.9f * this.scale, this.headCollider.transform.position + this.rigidBodyMovement - this.lastHeadPosition, out this.finalPosition, false, out this.slipPercentage, out this.junkHit, true))
			{
				this.rigidBodyMovement = this.finalPosition - this.headCollider.transform.position;
			}
			if (!this.MaxSphereSizeForNoOverlap(this.headCollider.radius * 0.9f * this.scale, this.lastHeadPosition + this.rigidBodyMovement, true, out this.maxSphereSize1) || !this.CrazyCheck2(this.headCollider.radius * 0.9f * 0.75f * this.scale, this.lastHeadPosition + this.rigidBodyMovement))
			{
				this.lastHeadPosition = this.lastOpenHeadPosition;
				this.rigidBodyMovement = this.lastHeadPosition - this.headCollider.transform.position;
			}
			else if (this.headCollider.radius * 0.9f * 0.825f * this.scale < this.maxSphereSize1)
			{
				this.lastOpenHeadPosition = this.headCollider.transform.position + this.rigidBodyMovement;
			}
			if (this.rigidBodyMovement != Vector3.zero)
			{
				base.transform.position += this.rigidBodyMovement;
			}
			this.lastHeadPosition = this.headCollider.transform.position;
			this.areBothTouching = ((!this.leftHandColliding && !this.wasLeftHandTouching) || (!this.rightHandColliding && !this.wasRightHandTouching));
			Vector3 vector = this.FinalHandPosition(this.leftControllerTransform, this.leftHandOffset, this.GetLastLeftHandPosition(), this.areBothTouching, this.leftHandColliding, out this.leftHandColliding, this.leftHandSlide, out this.leftHandSlide, this.leftHandMaterialTouchIndex, out this.leftHandMaterialTouchIndex, this.leftHandSurfaceOverride, out this.leftHandSurfaceOverride, this.leftHandHolding);
			this.leftHandColliding = (this.leftHandColliding && this.controllerState.LeftValid);
			this.leftHandSlide = (this.leftHandSlide && this.controllerState.LeftValid);
			Vector3 vector2 = this.FinalHandPosition(this.rightControllerTransform, this.rightHandOffset, this.GetLastRightHandPosition(), this.areBothTouching, this.rightHandColliding, out this.rightHandColliding, this.rightHandSlide, out this.rightHandSlide, this.rightHandMaterialTouchIndex, out this.rightHandMaterialTouchIndex, this.rightHandSurfaceOverride, out this.rightHandSurfaceOverride, this.rightHandHolding);
			this.rightHandColliding = (this.rightHandColliding && this.controllerState.RightValid);
			this.rightHandSlide = (this.rightHandSlide && this.controllerState.RightValid);
			this.StoreVelocities();
			this.didAJump = false;
			if (this.LeftSlipOverriddenToMax() && this.RightSlipOverriddenToMax())
			{
				this.didAJump = true;
			}
			else if (this.rightHandSlide || this.leftHandSlide)
			{
				this.slideAverageNormal = Vector3.zero;
				this.touchPoints = 0;
				this.averageSlipPercentage = 0f;
				if (this.leftHandSlide)
				{
					this.slideAverageNormal += this.leftHandSlideNormal.normalized;
					this.averageSlipPercentage += this.leftHandSlipPercentage;
					this.touchPoints++;
				}
				if (this.rightHandSlide)
				{
					this.slideAverageNormal += this.rightHandSlideNormal.normalized;
					this.averageSlipPercentage += this.rightHandSlipPercentage;
					this.touchPoints++;
				}
				this.slideAverageNormal = this.slideAverageNormal.normalized;
				this.averageSlipPercentage /= (float)this.touchPoints;
				if (this.touchPoints == 1)
				{
					this.surfaceDirection = (this.rightHandSlide ? Vector3.ProjectOnPlane(this.rightControllerTransform.forward, this.rightHandSlideNormal) : Vector3.ProjectOnPlane(this.leftControllerTransform.forward, this.leftHandSlideNormal));
					if (Vector3.Dot(this.slideAverage, this.surfaceDirection) > 0f)
					{
						this.slideAverage = Vector3.Project(this.slideAverage, Vector3.Slerp(this.slideAverage, this.surfaceDirection.normalized * this.slideAverage.magnitude, this.slideControl));
					}
					else
					{
						this.slideAverage = Vector3.Project(this.slideAverage, Vector3.Slerp(this.slideAverage, -this.surfaceDirection.normalized * this.slideAverage.magnitude, this.slideControl));
					}
				}
				if (!this.wasLeftHandSlide && !this.wasRightHandSlide)
				{
					this.slideAverage = ((Vector3.Dot(this.playerRigidBody.velocity, this.slideAverageNormal) <= 0f) ? Vector3.ProjectOnPlane(this.playerRigidBody.velocity, this.slideAverageNormal) : this.playerRigidBody.velocity);
				}
				else
				{
					this.slideAverage = ((Vector3.Dot(this.slideAverage, this.slideAverageNormal) <= 0f) ? Vector3.ProjectOnPlane(this.slideAverage, this.slideAverageNormal) : this.slideAverage);
				}
				this.slideAverage = this.slideAverage.normalized * Mathf.Min(this.slideAverage.magnitude, Mathf.Max(0.5f, this.denormalizedVelocityAverage.magnitude * 2f));
				this.playerRigidBody.velocity = Vector3.zero;
			}
			else if (this.leftHandColliding || this.rightHandColliding)
			{
				if (!this.turnedThisFrame)
				{
					this.playerRigidBody.velocity = Vector3.zero;
				}
				else
				{
					this.playerRigidBody.velocity = this.playerRigidBody.velocity.normalized * Mathf.Min(2f, this.playerRigidBody.velocity.magnitude);
				}
			}
			else if (this.wasLeftHandSlide || this.wasRightHandSlide)
			{
				this.playerRigidBody.velocity = ((Vector3.Dot(this.slideAverage, this.slideAverageNormal) <= 0f) ? Vector3.ProjectOnPlane(this.slideAverage, this.slideAverageNormal) : this.slideAverage);
			}
			if ((this.rightHandColliding || this.leftHandColliding) && !this.disableMovement && !this.turnedThisFrame && !this.didAJump)
			{
				if (this.rightHandSlide || this.leftHandSlide)
				{
					if (Vector3.Project(this.denormalizedVelocityAverage, this.slideAverageNormal).magnitude > this.slideVelocityLimit && Vector3.Dot(this.denormalizedVelocityAverage, this.slideAverageNormal) > 0f && Vector3.Project(this.denormalizedVelocityAverage, this.slideAverageNormal).magnitude > Vector3.Project(this.slideAverage, this.slideAverageNormal).magnitude)
					{
						this.leftHandSlide = false;
						this.rightHandSlide = false;
						this.didAJump = true;
						this.playerRigidBody.velocity = Mathf.Min(this.maxJumpSpeed * this.ExtraVelMaxMultiplier(), this.jumpMultiplier * this.ExtraVelMultiplier() * Vector3.Project(this.denormalizedVelocityAverage, this.slideAverageNormal).magnitude) * this.slideAverageNormal.normalized + Vector3.ProjectOnPlane(this.slideAverage, this.slideAverageNormal);
					}
				}
				else if (this.denormalizedVelocityAverage.magnitude > this.velocityLimit * this.scale)
				{
					float num = (this.InWater && this.CurrentWaterVolume != null) ? this.liquidPropertiesList[(int)this.CurrentWaterVolume.LiquidType].surfaceJumpFactor : 1f;
					Vector3 vector3 = Mathf.Min(this.maxJumpSpeed * this.ExtraVelMaxMultiplier(), this.jumpMultiplier * this.ExtraVelMultiplier() * num * this.denormalizedVelocityAverage.magnitude) * this.denormalizedVelocityAverage.normalized;
					this.didAJump = true;
					this.playerRigidBody.velocity = vector3;
					if (this.InWater)
					{
						this.swimmingVelocity += vector3 * this.swimmingParams.underwaterJumpsAsSwimVelocityFactor;
					}
				}
			}
			this.stuckHandsCheckLateUpdate(ref vector, ref vector2);
			if (this.currentPlatform == null)
			{
				if (!this.playerRigidBody.isKinematic)
				{
					this.playerRigidBody.velocity += this.refMovement / this.calcDeltaTime;
				}
				this.refMovement = Vector3.zero;
			}
			Vector3 vector4 = Vector3.zero;
			float a2 = 0f;
			Vector3 b;
			if (this.GetSwimmingVelocityForHand(this.lastLeftHandPosition, vector, this.leftControllerTransform.right, this.calcDeltaTime, ref this.leftHandWaterVolume, ref this.leftHandWaterSurface, out b) && !this.turnedThisFrame)
			{
				a2 = Mathf.InverseLerp(0f, 0.2f, b.magnitude) * this.swimmingParams.swimmingHapticsStrength;
				vector4 += b;
			}
			float a3 = 0f;
			Vector3 b2;
			if (this.GetSwimmingVelocityForHand(this.lastRightHandPosition, vector2, -this.rightControllerTransform.right, this.calcDeltaTime, ref this.rightHandWaterVolume, ref this.rightHandWaterSurface, out b2) && !this.turnedThisFrame)
			{
				a3 = Mathf.InverseLerp(0f, 0.15f, b2.magnitude) * this.swimmingParams.swimmingHapticsStrength;
				vector4 += b2;
			}
			Vector3 vector5 = Vector3.zero;
			Vector3 b3;
			if (this.swimmingParams.allowWaterSurfaceJumps && time - this.lastWaterSurfaceJumpTimeLeft > this.waterSurfaceJumpCooldown && this.CheckWaterSurfaceJump(this.lastLeftHandPosition, vector, this.leftControllerTransform.right, this.leftHandCenterVelocityTracker.GetAverageVelocity(false, 0.1f, false) * this.scale, this.swimmingParams, this.leftHandWaterVolume, this.leftHandWaterSurface, out b3))
			{
				if (time - this.lastWaterSurfaceJumpTimeRight > this.waterSurfaceJumpCooldown)
				{
					vector5 += b3;
				}
				this.lastWaterSurfaceJumpTimeLeft = Time.time;
				GorillaTagger.Instance.StartVibration(true, GorillaTagger.Instance.tapHapticStrength, GorillaTagger.Instance.tapHapticDuration);
			}
			Vector3 b4;
			if (this.swimmingParams.allowWaterSurfaceJumps && time - this.lastWaterSurfaceJumpTimeRight > this.waterSurfaceJumpCooldown && this.CheckWaterSurfaceJump(this.lastRightHandPosition, vector2, -this.rightControllerTransform.right, this.rightHandCenterVelocityTracker.GetAverageVelocity(false, 0.1f, false) * this.scale, this.swimmingParams, this.rightHandWaterVolume, this.rightHandWaterSurface, out b4))
			{
				if (time - this.lastWaterSurfaceJumpTimeLeft > this.waterSurfaceJumpCooldown)
				{
					vector5 += b4;
				}
				this.lastWaterSurfaceJumpTimeRight = Time.time;
				GorillaTagger.Instance.StartVibration(false, GorillaTagger.Instance.tapHapticStrength, GorillaTagger.Instance.tapHapticDuration);
			}
			vector5 = Vector3.ClampMagnitude(vector5, this.swimmingParams.waterSurfaceJumpMaxSpeed * this.scale);
			float num2 = Mathf.Max(a2, this.leftHandNonDiveHapticsAmount);
			if (num2 > 0.001f && time - this.lastWaterSurfaceJumpTimeLeft > GorillaTagger.Instance.tapHapticDuration)
			{
				GorillaTagger.Instance.DoVibration(XRNode.LeftHand, num2, this.calcDeltaTime);
			}
			float num3 = Mathf.Max(a3, this.rightHandNonDiveHapticsAmount);
			if (num3 > 0.001f && time - this.lastWaterSurfaceJumpTimeRight > GorillaTagger.Instance.tapHapticDuration)
			{
				GorillaTagger.Instance.DoVibration(XRNode.RightHand, num3, this.calcDeltaTime);
			}
			if (!this.disableMovement)
			{
				this.swimmingVelocity += vector4;
				if (!this.playerRigidBody.isKinematic)
				{
					this.playerRigidBody.velocity += vector4 + vector5;
				}
			}
			else
			{
				this.swimmingVelocity = Vector3.zero;
			}
			this.leftHandFollower.position = vector;
			this.rightHandFollower.position = vector2;
			this.leftHandFollower.rotation = this.leftControllerTransform.rotation * this.leftHandRotOffset;
			this.rightHandFollower.rotation = this.rightControllerTransform.rotation * this.rightHandRotOffset;
			this.wasLeftHandTouching = this.leftHandColliding;
			this.wasRightHandTouching = this.rightHandColliding;
			this.wasLeftHandSlide = this.leftHandSlide;
			this.wasRightHandSlide = this.rightHandSlide;
			if ((this.leftHandColliding && !this.leftHandSlide) || (this.rightHandColliding && !this.rightHandSlide))
			{
				this.lastTouchedGroundTimestamp = Time.time;
			}
			this.degreesTurnedThisFrame = 0f;
			this.lastPlatformTouched = this.currentPlatform;
			this.currentPlatform = null;
			this.lastLeftHandPosition = vector;
			this.lastRightHandPosition = vector2;
			Vector3 vector6;
			if (Player.ComputeLocalHitPoint(this.lastHitInfoHand, out vector6))
			{
				this.lastFrameHasValidTouchPos = true;
				this.lastFrameTouchPosLocal = vector6;
				this.lastFrameTouchPosWorld = this.lastHitInfoHand.point;
			}
			else
			{
				this.lastFrameHasValidTouchPos = false;
				this.lastFrameTouchPosLocal = Vector3.zero;
				this.lastFrameTouchPosWorld = Vector3.zero;
			}
			this.lastRigidbodyPosition = this.playerRigidBody.transform.position;
			this.BodyCollider();
		}

		// Token: 0x060021E2 RID: 8674 RVA: 0x000A183C File Offset: 0x0009FA3C
		private void stuckHandsCheckFixedUpdate()
		{
			this.stuckLeft = (!this.controllerState.LeftValid || (this.leftHandColliding && (this.GetCurrentLeftHandPosition() - this.GetLastLeftHandPosition()).magnitude > this.unStickDistance * this.scale && !Physics.Raycast(this.headCollider.transform.position, (this.GetCurrentLeftHandPosition() - this.headCollider.transform.position).normalized, out this.hitInfo, (this.GetCurrentLeftHandPosition() - this.headCollider.transform.position).magnitude, this.locomotionEnabledLayers.value)));
			this.stuckRight = (!this.controllerState.RightValid || (this.rightHandColliding && (this.GetCurrentRightHandPosition() - this.GetLastRightHandPosition()).magnitude > this.unStickDistance * this.scale && !Physics.Raycast(this.headCollider.transform.position, (this.GetCurrentRightHandPosition() - this.headCollider.transform.position).normalized, out this.hitInfo, (this.GetCurrentRightHandPosition() - this.headCollider.transform.position).magnitude, this.locomotionEnabledLayers.value)));
		}

		// Token: 0x060021E3 RID: 8675 RVA: 0x000A19C8 File Offset: 0x0009FBC8
		private void stuckHandsCheckLateUpdate(ref Vector3 finalLeftHandPosition, ref Vector3 finalRightHandPosition)
		{
			if (this.stuckLeft)
			{
				finalLeftHandPosition = this.GetCurrentLeftHandPosition();
				this.stuckLeft = (this.leftHandColliding = false);
			}
			if (this.stuckRight)
			{
				finalRightHandPosition = this.GetCurrentRightHandPosition();
				this.stuckRight = (this.rightHandColliding = false);
			}
		}

		// Token: 0x060021E4 RID: 8676 RVA: 0x000A1A20 File Offset: 0x0009FC20
		private void handleClimbing(float deltaTime)
		{
			if (this.isClimbing && (this.inOverlay || this.climbHelper == null || this.currentClimbable == null || !this.currentClimbable.isActiveAndEnabled))
			{
				this.EndClimbing(this.currentClimber, false, false);
			}
			Vector3 b = Vector3.zero;
			if (this.isClimbing && (this.currentClimber.transform.position - this.climbHelper.position).magnitude > 1f)
			{
				this.EndClimbing(this.currentClimber, false, false);
			}
			if (this.isClimbing)
			{
				this.playerRigidBody.velocity = Vector3.zero;
				this.climbHelper.localPosition = Vector3.MoveTowards(this.climbHelper.localPosition, this.climbHelperTargetPos, deltaTime * 12f);
				b = this.currentClimber.transform.position - this.climbHelper.position;
				this.playerRigidBody.MovePosition(this.playerRigidBody.position - b);
				if (this.currentSwing)
				{
					this.currentSwing.lastGrabTime = Time.time;
				}
			}
		}

		// Token: 0x060021E5 RID: 8677 RVA: 0x000A1B5C File Offset: 0x0009FD5C
		private Vector3 FirstHandIteration(Transform handTransform, Vector3 handOffset, Vector3 lastHandPosition, bool wasHandSlide, bool wasHandTouching, bool fullSlideOverride, out Vector3 pushDisplacement, ref float handSlipPercentage, ref bool handSlide, ref Vector3 slideNormal, ref bool handColliding, ref int materialTouchIndex, ref GorillaSurfaceOverride touchedOverride, bool skipCollisionChecks)
		{
			Vector3 currentHandPosition = this.GetCurrentHandPosition(handTransform, handOffset);
			Vector3 vector = currentHandPosition;
			this.distanceTraveled = currentHandPosition - lastHandPosition;
			if (!this.didAJump && wasHandSlide && Vector3.Dot(slideNormal, Vector3.up) > 0f)
			{
				this.distanceTraveled += Vector3.Project(-this.slideAverageNormal * this.stickDepth * this.scale, Vector3.down);
			}
			if (this.IterativeCollisionSphereCast(lastHandPosition, this.minimumRaycastDistance * this.scale, this.distanceTraveled, out this.finalPosition, true, out this.slipPercentage, out this.tempHitInfo, fullSlideOverride) && !skipCollisionChecks && !this.InReportMenu)
			{
				if (wasHandTouching && this.slipPercentage <= this.defaultSlideFactor)
				{
					vector = lastHandPosition;
				}
				else
				{
					vector = this.finalPosition;
				}
				pushDisplacement = vector - currentHandPosition;
				handSlipPercentage = this.slipPercentage;
				handSlide = (this.slipPercentage > this.iceThreshold);
				slideNormal = this.tempHitInfo.normal;
				handColliding = true;
				materialTouchIndex = this.currentMaterialIndex;
				touchedOverride = this.currentOverride;
				this.lastHitInfoHand = this.tempHitInfo;
			}
			else
			{
				pushDisplacement = Vector3.zero;
				handSlipPercentage = 0f;
				handSlide = false;
				slideNormal = Vector3.up;
				handColliding = false;
				materialTouchIndex = 0;
				touchedOverride = null;
			}
			return vector;
		}

		// Token: 0x060021E6 RID: 8678 RVA: 0x000A1CD4 File Offset: 0x0009FED4
		private Vector3 FinalHandPosition(Transform handTransform, Vector3 handOffset, Vector3 lastHandPosition, bool bothTouching, bool isHandTouching, out bool handColliding, bool isHandSlide, out bool handSlide, int currentMaterialTouchIndex, out int materialTouchIndex, GorillaSurfaceOverride currentSurface, out GorillaSurfaceOverride touchedOverride, bool skipCollisionChecks)
		{
			handColliding = isHandTouching;
			handSlide = isHandSlide;
			materialTouchIndex = currentMaterialTouchIndex;
			touchedOverride = currentSurface;
			this.distanceTraveled = this.GetCurrentHandPosition(handTransform, handOffset) - lastHandPosition;
			if (this.IterativeCollisionSphereCast(lastHandPosition, this.minimumRaycastDistance * this.scale, this.distanceTraveled, out this.finalPosition, bothTouching, out this.slipPercentage, out this.junkHit, false) && !skipCollisionChecks)
			{
				handColliding = true;
				handSlide = (this.slipPercentage > this.iceThreshold);
				materialTouchIndex = this.currentMaterialIndex;
				touchedOverride = this.currentOverride;
				this.lastHitInfoHand = this.junkHit;
				return this.finalPosition;
			}
			return this.GetCurrentHandPosition(handTransform, handOffset);
		}

		// Token: 0x060021E7 RID: 8679 RVA: 0x000A1D80 File Offset: 0x0009FF80
		private bool IterativeCollisionSphereCast(Vector3 startPosition, float sphereRadius, Vector3 movementVector, out Vector3 endPosition, bool singleHand, out float slipPercentage, out RaycastHit iterativeHitInfo, bool fullSlide)
		{
			slipPercentage = this.defaultSlideFactor;
			if (!this.CollisionsSphereCast(startPosition, sphereRadius, movementVector, out endPosition, out this.tempIterativeHit))
			{
				iterativeHitInfo = this.tempIterativeHit;
				endPosition = Vector3.zero;
				return false;
			}
			this.firstPosition = endPosition;
			iterativeHitInfo = this.tempIterativeHit;
			this.slideFactor = this.GetSlidePercentage(iterativeHitInfo);
			slipPercentage = ((this.slideFactor != this.defaultSlideFactor) ? this.slideFactor : ((!singleHand) ? this.defaultSlideFactor : 0.001f));
			if (fullSlide)
			{
				slipPercentage = 1f;
			}
			this.movementToProjectedAboveCollisionPlane = Vector3.ProjectOnPlane(startPosition + movementVector - this.firstPosition, iterativeHitInfo.normal) * slipPercentage;
			if (this.CollisionsSphereCast(this.firstPosition, sphereRadius, this.movementToProjectedAboveCollisionPlane, out endPosition, out this.tempIterativeHit))
			{
				iterativeHitInfo = this.tempIterativeHit;
				return true;
			}
			if (this.CollisionsSphereCast(this.movementToProjectedAboveCollisionPlane + this.firstPosition, sphereRadius, startPosition + movementVector - (this.movementToProjectedAboveCollisionPlane + this.firstPosition), out endPosition, out this.tempIterativeHit))
			{
				iterativeHitInfo = this.tempIterativeHit;
				return true;
			}
			endPosition = Vector3.zero;
			return false;
		}

		// Token: 0x060021E8 RID: 8680 RVA: 0x000A1EE0 File Offset: 0x000A00E0
		private bool CollisionsSphereCast(Vector3 startPosition, float sphereRadius, Vector3 movementVector, out Vector3 finalPosition, out RaycastHit collisionsHitInfo)
		{
			this.MaxSphereSizeForNoOverlap(sphereRadius, startPosition, false, out this.maxSphereSize1);
			bool flag = false;
			this.ClearRaycasthitBuffer(ref this.rayCastNonAllocColliders);
			this.bufferCount = Physics.SphereCastNonAlloc(startPosition, this.maxSphereSize1, movementVector.normalized, this.rayCastNonAllocColliders, movementVector.magnitude, this.locomotionEnabledLayers.value);
			if (this.bufferCount > 0)
			{
				this.tempHitInfo = this.rayCastNonAllocColliders[0];
				for (int i = 0; i < this.bufferCount; i++)
				{
					if (this.tempHitInfo.distance > 0f && (!flag || this.rayCastNonAllocColliders[i].distance < this.tempHitInfo.distance))
					{
						flag = true;
						this.tempHitInfo = this.rayCastNonAllocColliders[i];
					}
				}
			}
			if (flag)
			{
				collisionsHitInfo = this.tempHitInfo;
				finalPosition = collisionsHitInfo.point + collisionsHitInfo.normal * sphereRadius;
				this.ClearRaycasthitBuffer(ref this.rayCastNonAllocColliders);
				this.bufferCount = Physics.RaycastNonAlloc(startPosition, (finalPosition - startPosition).normalized, this.rayCastNonAllocColliders, (finalPosition - startPosition).magnitude, this.locomotionEnabledLayers.value, QueryTriggerInteraction.Ignore);
				if (this.bufferCount > 0)
				{
					this.tempHitInfo = this.rayCastNonAllocColliders[0];
					for (int j = 0; j < this.bufferCount; j++)
					{
						if (this.rayCastNonAllocColliders[j].distance < this.tempHitInfo.distance)
						{
							this.tempHitInfo = this.rayCastNonAllocColliders[j];
						}
					}
					finalPosition = startPosition + movementVector.normalized * this.tempHitInfo.distance;
				}
				this.MaxSphereSizeForNoOverlap(sphereRadius, finalPosition, false, out this.maxSphereSize2);
				this.ClearRaycasthitBuffer(ref this.rayCastNonAllocColliders);
				this.bufferCount = Physics.SphereCastNonAlloc(startPosition, Mathf.Min(this.maxSphereSize1, this.maxSphereSize2), (finalPosition - startPosition).normalized, this.rayCastNonAllocColliders, (finalPosition - startPosition).magnitude, this.locomotionEnabledLayers.value);
				if (this.bufferCount > 0)
				{
					this.tempHitInfo = this.rayCastNonAllocColliders[0];
					for (int k = 0; k < this.bufferCount; k++)
					{
						if (this.rayCastNonAllocColliders[k].collider != null && this.rayCastNonAllocColliders[k].distance < this.tempHitInfo.distance)
						{
							this.tempHitInfo = this.rayCastNonAllocColliders[k];
						}
					}
					finalPosition = startPosition + this.tempHitInfo.distance * (finalPosition - startPosition).normalized;
					collisionsHitInfo = this.tempHitInfo;
				}
				this.ClearRaycasthitBuffer(ref this.rayCastNonAllocColliders);
				this.bufferCount = Physics.RaycastNonAlloc(startPosition, (finalPosition - startPosition).normalized, this.rayCastNonAllocColliders, (finalPosition - startPosition).magnitude, this.locomotionEnabledLayers.value);
				if (this.bufferCount > 0)
				{
					this.tempHitInfo = this.rayCastNonAllocColliders[0];
					for (int l = 0; l < this.bufferCount; l++)
					{
						if (this.rayCastNonAllocColliders[l].distance < this.tempHitInfo.distance)
						{
							this.tempHitInfo = this.rayCastNonAllocColliders[l];
						}
					}
					collisionsHitInfo = this.tempHitInfo;
					finalPosition = startPosition;
				}
				return true;
			}
			this.ClearRaycasthitBuffer(ref this.rayCastNonAllocColliders);
			this.bufferCount = Physics.RaycastNonAlloc(startPosition, movementVector.normalized, this.rayCastNonAllocColliders, movementVector.magnitude, this.locomotionEnabledLayers.value);
			if (this.bufferCount > 0)
			{
				this.tempHitInfo = this.rayCastNonAllocColliders[0];
				for (int m = 0; m < this.bufferCount; m++)
				{
					if (this.rayCastNonAllocColliders[m].collider != null && this.rayCastNonAllocColliders[m].distance < this.tempHitInfo.distance)
					{
						this.tempHitInfo = this.rayCastNonAllocColliders[m];
					}
				}
				collisionsHitInfo = this.tempHitInfo;
				finalPosition = startPosition;
				return true;
			}
			finalPosition = startPosition + movementVector;
			collisionsHitInfo = default(RaycastHit);
			return false;
		}

		// Token: 0x060021E9 RID: 8681 RVA: 0x000A239E File Offset: 0x000A059E
		public bool IsHandTouching(bool forLeftHand)
		{
			if (forLeftHand)
			{
				return this.wasLeftHandTouching;
			}
			return this.wasRightHandTouching;
		}

		// Token: 0x060021EA RID: 8682 RVA: 0x000A23B0 File Offset: 0x000A05B0
		public bool IsHandSliding(bool forLeftHand)
		{
			if (forLeftHand)
			{
				return this.wasLeftHandSlide || this.leftHandSlide;
			}
			return this.wasRightHandSlide || this.rightHandSlide;
		}

		// Token: 0x060021EB RID: 8683 RVA: 0x000A23D8 File Offset: 0x000A05D8
		public float GetSlidePercentage(RaycastHit raycastHit)
		{
			this.currentOverride = raycastHit.collider.gameObject.GetComponent<GorillaSurfaceOverride>();
			BasePlatform x = raycastHit.collider.gameObject.GetComponent<BasePlatform>();
			if (x == null)
			{
				BuilderPiece builderPiece = BuilderPiece.GetBuilderPieceFromCollider(raycastHit.collider);
				if (builderPiece != null)
				{
					BasePlatform basePlatform = null;
					while (basePlatform == null && builderPiece != null)
					{
						basePlatform = builderPiece.platform;
						builderPiece = builderPiece.parentPiece;
					}
					if (basePlatform != null)
					{
						x = basePlatform;
					}
				}
			}
			if (x != null)
			{
				this.currentPlatform = x;
			}
			if (this.currentOverride != null)
			{
				this.currentMaterialIndex = this.currentOverride.overrideIndex;
				if (!this.materialData[this.currentMaterialIndex].overrideSlidePercent)
				{
					return this.defaultSlideFactor;
				}
				return this.materialData[this.currentMaterialIndex].slidePercent;
			}
			else
			{
				this.meshCollider = (raycastHit.collider as MeshCollider);
				if (this.meshCollider == null || this.meshCollider.sharedMesh == null || this.meshCollider.convex)
				{
					return this.defaultSlideFactor;
				}
				this.collidedMesh = this.meshCollider.sharedMesh;
				if (!this.meshTrianglesDict.TryGetValue(this.collidedMesh, out this.sharedMeshTris))
				{
					this.sharedMeshTris = this.collidedMesh.triangles;
					this.meshTrianglesDict.Add(this.collidedMesh, (int[])this.sharedMeshTris.Clone());
				}
				this.vertex1 = this.sharedMeshTris[raycastHit.triangleIndex * 3];
				this.vertex2 = this.sharedMeshTris[raycastHit.triangleIndex * 3 + 1];
				this.vertex3 = this.sharedMeshTris[raycastHit.triangleIndex * 3 + 2];
				this.slideRenderer = raycastHit.collider.GetComponent<Renderer>();
				this.slideRenderer.GetSharedMaterials(this.tempMaterialArray);
				if (this.tempMaterialArray.Count > 1)
				{
					for (int i = 0; i < this.tempMaterialArray.Count; i++)
					{
						this.collidedMesh.GetTriangles(this.trianglesList, i);
						int j = 0;
						while (j < this.trianglesList.Count)
						{
							if (this.trianglesList[j] == this.vertex1 && this.trianglesList[j + 1] == this.vertex2 && this.trianglesList[j + 2] == this.vertex3)
							{
								this.findMatName = this.tempMaterialArray[i].name;
								if (this.findMatName.EndsWith("Uber"))
								{
									string text = this.findMatName;
									this.findMatName = text.Substring(0, text.Length - 4);
								}
								this.foundMatData = this.materialData.Find((Player.MaterialData matData) => matData.matName == this.findMatName);
								this.currentMaterialIndex = this.materialData.FindIndex((Player.MaterialData matData) => matData.matName == this.findMatName);
								if (this.currentMaterialIndex == -1)
								{
									this.currentMaterialIndex = 0;
								}
								if (!this.foundMatData.overrideSlidePercent)
								{
									return this.defaultSlideFactor;
								}
								return this.foundMatData.slidePercent;
							}
							else
							{
								j += 3;
							}
						}
					}
					this.currentMaterialIndex = 0;
					return this.defaultSlideFactor;
				}
				this.findMatName = this.tempMaterialArray[0].name;
				if (this.findMatName.EndsWith("Uber"))
				{
					string text = this.findMatName;
					this.findMatName = text.Substring(0, text.Length - 4);
				}
				this.foundMatData = this.materialData.Find((Player.MaterialData matData) => matData.matName == this.findMatName);
				this.currentMaterialIndex = this.materialData.FindIndex((Player.MaterialData matData) => matData.matName == this.findMatName);
				if (this.currentMaterialIndex == -1)
				{
					this.currentMaterialIndex = 0;
				}
				if (!this.foundMatData.overrideSlidePercent)
				{
					return this.defaultSlideFactor;
				}
				return this.foundMatData.slidePercent;
			}
		}

		// Token: 0x060021EC RID: 8684 RVA: 0x000A27F0 File Offset: 0x000A09F0
		public void Turn(float degrees)
		{
			Vector3 position = this.headCollider.transform.position;
			bool flag = this.rightHandColliding || this.rightHandHolding;
			bool flag2 = this.leftHandColliding || this.leftHandHolding;
			if (flag != flag2 && flag)
			{
				position = this.rightControllerTransform.position;
			}
			if (flag != flag2 && flag2)
			{
				position = this.leftControllerTransform.position;
			}
			this.turnParent.transform.RotateAround(position, base.transform.up, degrees);
			this.degreesTurnedThisFrame = degrees;
			this.denormalizedVelocityAverage = Vector3.zero;
			for (int i = 0; i < this.velocityHistory.Length; i++)
			{
				this.velocityHistory[i] = Quaternion.Euler(0f, degrees, 0f) * this.velocityHistory[i];
				this.denormalizedVelocityAverage += this.velocityHistory[i];
			}
		}

		// Token: 0x060021ED RID: 8685 RVA: 0x000A28EC File Offset: 0x000A0AEC
		public void BeginClimbing(GorillaClimbable climbable, GorillaHandClimber hand, GorillaClimbableRef climbableRef = null)
		{
			if (this.currentClimber != null)
			{
				this.EndClimbing(this.currentClimber, true, false);
			}
			try
			{
				Action<GorillaHandClimber, GorillaClimbableRef> onBeforeClimb = climbable.onBeforeClimb;
				if (onBeforeClimb != null)
				{
					onBeforeClimb(hand, climbableRef);
				}
			}
			catch (Exception message)
			{
				Debug.LogError(message);
			}
			Rigidbody rigidbody;
			climbable.TryGetComponent<Rigidbody>(out rigidbody);
			this.VerifyClimbHelper();
			this.climbHelper.SetParent(climbable.transform);
			this.climbHelper.position = hand.transform.position;
			Vector3 localPosition = this.climbHelper.localPosition;
			if (climbable.snapX)
			{
				Player.<BeginClimbing>g__SnapAxis|278_0(ref localPosition.x, climbable.maxDistanceSnap);
			}
			if (climbable.snapY)
			{
				Player.<BeginClimbing>g__SnapAxis|278_0(ref localPosition.y, climbable.maxDistanceSnap);
			}
			if (climbable.snapZ)
			{
				Player.<BeginClimbing>g__SnapAxis|278_0(ref localPosition.z, climbable.maxDistanceSnap);
			}
			this.climbHelperTargetPos = localPosition;
			climbable.isBeingClimbed = true;
			hand.isClimbing = true;
			this.currentClimbable = climbable;
			this.currentClimber = hand;
			this.isClimbing = true;
			GorillaRopeSegment gorillaRopeSegment;
			GorillaZipline gorillaZipline;
			PhotonView view;
			if (climbable.TryGetComponent<GorillaRopeSegment>(out gorillaRopeSegment) && gorillaRopeSegment.swing)
			{
				this.currentSwing = gorillaRopeSegment.swing;
				this.currentSwing.AttachLocalPlayer(hand.xrNode, climbable.transform, this.climbHelperTargetPos, this.currentVelocity);
			}
			else if (climbable.transform.parent && climbable.transform.parent.TryGetComponent<GorillaZipline>(out gorillaZipline))
			{
				this.currentZipline = gorillaZipline;
			}
			else if (climbable.TryGetComponent<PhotonView>(out view))
			{
				VRRig.AttachLocalPlayerToPhotonView(view, hand.xrNode, this.climbHelperTargetPos, this.currentVelocity);
			}
			this.enablePlayerGravity(false);
			GorillaTagger.Instance.StartVibration(this.currentClimber.xrNode == XRNode.LeftHand, 0.6f, 0.06f);
			if (climbable.clip)
			{
				GorillaTagger.Instance.offlineVRRig.PlayClimbSound(climbable.clip, hand.xrNode == XRNode.LeftHand);
			}
		}

		// Token: 0x060021EE RID: 8686 RVA: 0x000A2AEC File Offset: 0x000A0CEC
		private void VerifyClimbHelper()
		{
			if (this.climbHelper == null || this.climbHelper.gameObject == null)
			{
				this.climbHelper = new GameObject("Climb Helper").transform;
			}
		}

		// Token: 0x060021EF RID: 8687 RVA: 0x000A2B24 File Offset: 0x000A0D24
		public void EndClimbing(GorillaHandClimber hand, bool startingNewClimb, bool doDontReclimb = false)
		{
			if (hand != this.currentClimber)
			{
				return;
			}
			if (!startingNewClimb)
			{
				this.enablePlayerGravity(true);
			}
			Rigidbody rigidbody = null;
			if (this.currentClimbable)
			{
				this.currentClimbable.TryGetComponent<Rigidbody>(out rigidbody);
				this.currentClimbable.isBeingClimbed = false;
			}
			Vector3 vector = Vector3.zero;
			if (this.currentClimber)
			{
				this.currentClimber.isClimbing = false;
				if (doDontReclimb)
				{
					this.currentClimber.dontReclimbLast = this.currentClimbable;
				}
				else
				{
					this.currentClimber.dontReclimbLast = null;
				}
				this.currentClimber.queuedToBecomeValidToGrabAgain = true;
				this.currentClimber.lastAutoReleasePos = this.currentClimber.handRoot.localPosition;
				if (!startingNewClimb && this.currentClimbable)
				{
					GorillaVelocityTracker gorillaVelocityTracker;
					if (this.currentClimber.xrNode == XRNode.LeftHand)
					{
						gorillaVelocityTracker = this.leftInteractPointVelocityTracker;
					}
					else
					{
						gorillaVelocityTracker = this.rightInteractPointVelocityTracker;
					}
					if (rigidbody)
					{
						this.playerRigidBody.velocity = rigidbody.velocity;
					}
					else if (this.currentSwing)
					{
						this.playerRigidBody.velocity = this.currentSwing.velocityTracker.GetAverageVelocity(true, 0.25f, false);
					}
					else if (this.currentZipline)
					{
						this.playerRigidBody.velocity = this.currentZipline.GetCurrentDirection() * this.currentZipline.currentSpeed;
					}
					else
					{
						this.playerRigidBody.velocity = this.bodyVelocityTracker.GetAverageVelocity(true, 0.15f, false) * 0.7f;
					}
					vector = this.turnParent.transform.rotation * -gorillaVelocityTracker.GetAverageVelocity(false, 0.1f, true) * this.scale;
					vector = Vector3.ClampMagnitude(vector, 5.5f * this.scale);
					this.playerRigidBody.AddForce(vector, ForceMode.VelocityChange);
				}
			}
			if (this.currentSwing)
			{
				this.currentSwing.DetachLocalPlayer();
			}
			PhotonView photonView;
			if (this.currentClimbable.TryGetComponent<PhotonView>(out photonView))
			{
				VRRig.DetachLocalPlayerFromPhotonView();
			}
			if (!startingNewClimb && vector.magnitude > 2f && this.currentClimbable && this.currentClimbable.clipOnFullRelease)
			{
				GorillaTagger.Instance.offlineVRRig.PlayClimbSound(this.currentClimbable.clipOnFullRelease, hand.xrNode == XRNode.LeftHand);
			}
			this.currentClimbable = null;
			this.currentClimber = null;
			this.currentSwing = null;
			this.currentZipline = null;
			this.isClimbing = false;
		}

		// Token: 0x060021F0 RID: 8688 RVA: 0x000A2DB2 File Offset: 0x000A0FB2
		private void enablePlayerGravity(bool useGravity)
		{
			this.playerRigidBody.useGravity = useGravity;
		}

		// Token: 0x060021F1 RID: 8689 RVA: 0x000A2DC0 File Offset: 0x000A0FC0
		private void StoreVelocities()
		{
			this.velocityIndex = (this.velocityIndex + 1) % this.velocityHistorySize;
			this.currentVelocity = (base.transform.position - this.lastPosition - this.MovingSurfaceMovement()) / this.calcDeltaTime;
			this.velocityHistory[this.velocityIndex] = this.currentVelocity;
			this.denormalizedVelocityAverage = Vector3.zero;
			for (int i = 0; i < this.velocityHistory.Length; i++)
			{
				this.denormalizedVelocityAverage += this.velocityHistory[i];
			}
			this.denormalizedVelocityAverage /= (float)this.velocityHistorySize;
			this.lastPosition = base.transform.position;
		}

		// Token: 0x060021F2 RID: 8690 RVA: 0x000A2E90 File Offset: 0x000A1090
		private void AntiTeleportTechnology()
		{
			if ((this.headCollider.transform.position - this.lastHeadPosition).magnitude >= this.teleportThresholdNoVel + this.playerRigidBody.velocity.magnitude * this.calcDeltaTime)
			{
				base.transform.position = base.transform.position + this.lastHeadPosition - this.headCollider.transform.position;
			}
		}

		// Token: 0x060021F3 RID: 8691 RVA: 0x000A2F1C File Offset: 0x000A111C
		private bool MaxSphereSizeForNoOverlap(float testRadius, Vector3 checkPosition, bool ignoreOneWay, out float overlapRadiusTest)
		{
			overlapRadiusTest = testRadius;
			this.overlapAttempts = 0;
			int num = 100;
			while (this.overlapAttempts < num && overlapRadiusTest > testRadius * 0.75f)
			{
				this.ClearColliderBuffer(ref this.overlapColliders);
				this.bufferCount = Physics.OverlapSphereNonAlloc(checkPosition, overlapRadiusTest, this.overlapColliders, this.locomotionEnabledLayers.value, QueryTriggerInteraction.Ignore);
				if (ignoreOneWay)
				{
					int num2 = 0;
					for (int i = 0; i < this.bufferCount; i++)
					{
						if (this.overlapColliders[i].CompareTag("NoCrazyCheck"))
						{
							num2++;
						}
					}
					if (num2 == this.bufferCount)
					{
						return true;
					}
				}
				if (this.bufferCount <= 0)
				{
					overlapRadiusTest *= 0.995f;
					return true;
				}
				overlapRadiusTest = Mathf.Lerp(testRadius, 0f, (float)this.overlapAttempts / (float)num);
				this.overlapAttempts++;
			}
			return false;
		}

		// Token: 0x060021F4 RID: 8692 RVA: 0x000A2FFC File Offset: 0x000A11FC
		private bool CrazyCheck2(float sphereSize, Vector3 startPosition)
		{
			for (int i = 0; i < this.crazyCheckVectors.Length; i++)
			{
				if (this.NonAllocRaycast(startPosition, startPosition + this.crazyCheckVectors[i] * sphereSize) > 0)
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x060021F5 RID: 8693 RVA: 0x000A3044 File Offset: 0x000A1244
		private int NonAllocRaycast(Vector3 startPosition, Vector3 endPosition)
		{
			Vector3 direction = endPosition - startPosition;
			int num = Physics.RaycastNonAlloc(startPosition, direction, this.rayCastNonAllocColliders, direction.magnitude, this.locomotionEnabledLayers.value, QueryTriggerInteraction.Ignore);
			int num2 = 0;
			for (int i = 0; i < num; i++)
			{
				if (!this.rayCastNonAllocColliders[i].collider.gameObject.CompareTag("NoCrazyCheck"))
				{
					num2++;
				}
			}
			return num2;
		}

		// Token: 0x060021F6 RID: 8694 RVA: 0x000A30B0 File Offset: 0x000A12B0
		private void ClearColliderBuffer(ref Collider[] colliders)
		{
			for (int i = 0; i < colliders.Length; i++)
			{
				colliders[i] = null;
			}
		}

		// Token: 0x060021F7 RID: 8695 RVA: 0x000A30D4 File Offset: 0x000A12D4
		private void ClearRaycasthitBuffer(ref RaycastHit[] raycastHits)
		{
			for (int i = 0; i < raycastHits.Length; i++)
			{
				raycastHits[i] = this.emptyHit;
			}
		}

		// Token: 0x060021F8 RID: 8696 RVA: 0x000A30FE File Offset: 0x000A12FE
		private Vector3 MovingSurfaceMovement()
		{
			return this.refMovement;
		}

		// Token: 0x060021F9 RID: 8697 RVA: 0x000A3108 File Offset: 0x000A1308
		private static bool ComputeLocalHitPoint(RaycastHit hit, out Vector3 localHitPoint)
		{
			if (hit.collider == null || hit.point.sqrMagnitude < 0.001f)
			{
				localHitPoint = Vector3.zero;
				return false;
			}
			localHitPoint = hit.collider.transform.InverseTransformPoint(hit.point);
			return true;
		}

		// Token: 0x060021FA RID: 8698 RVA: 0x000A3166 File Offset: 0x000A1366
		private static bool ComputeWorldHitPoint(RaycastHit hit, Vector3 localPoint, out Vector3 worldHitPoint)
		{
			if (hit.collider == null)
			{
				worldHitPoint = Vector3.zero;
				return false;
			}
			worldHitPoint = hit.collider.transform.TransformPoint(localPoint);
			return true;
		}

		// Token: 0x060021FB RID: 8699 RVA: 0x000A31A0 File Offset: 0x000A13A0
		private float ExtraVelMultiplier()
		{
			float num = 1f;
			if (this.leftHandSurfaceOverride != null)
			{
				num = Mathf.Max(num, this.leftHandSurfaceOverride.extraVelMultiplier);
			}
			if (this.rightHandSurfaceOverride != null)
			{
				num = Mathf.Max(num, this.rightHandSurfaceOverride.extraVelMultiplier);
			}
			return num;
		}

		// Token: 0x060021FC RID: 8700 RVA: 0x000A31F4 File Offset: 0x000A13F4
		private float ExtraVelMaxMultiplier()
		{
			float num = 1f;
			if (this.leftHandSurfaceOverride != null)
			{
				num = Mathf.Max(num, this.leftHandSurfaceOverride.extraVelMaxMultiplier);
			}
			if (this.rightHandSurfaceOverride != null)
			{
				num = Mathf.Max(num, this.rightHandSurfaceOverride.extraVelMaxMultiplier);
			}
			return num * this.scale;
		}

		// Token: 0x060021FD RID: 8701 RVA: 0x000A3251 File Offset: 0x000A1451
		public void SetMaximumSlipThisFrame()
		{
			this.leftSlipSetToMaxFrameIdx = Time.frameCount;
			this.rightSlipSetToMaxFrameIdx = Time.frameCount;
		}

		// Token: 0x060021FE RID: 8702 RVA: 0x000A3269 File Offset: 0x000A1469
		public void SetLeftMaximumSlipThisFrame()
		{
			this.leftSlipSetToMaxFrameIdx = Time.frameCount;
		}

		// Token: 0x060021FF RID: 8703 RVA: 0x000A3276 File Offset: 0x000A1476
		public void SetRightMaximumSlipThisFrame()
		{
			this.rightSlipSetToMaxFrameIdx = Time.frameCount;
		}

		// Token: 0x06002200 RID: 8704 RVA: 0x000A3283 File Offset: 0x000A1483
		public bool LeftSlipOverriddenToMax()
		{
			return this.leftSlipSetToMaxFrameIdx == Time.frameCount;
		}

		// Token: 0x06002201 RID: 8705 RVA: 0x000A3292 File Offset: 0x000A1492
		public bool RightSlipOverriddenToMax()
		{
			return this.rightSlipSetToMaxFrameIdx == Time.frameCount;
		}

		// Token: 0x06002202 RID: 8706 RVA: 0x000A32A4 File Offset: 0x000A14A4
		public void OnEnterWaterVolume(Collider playerCollider, WaterVolume volume)
		{
			if (playerCollider == this.headCollider)
			{
				if (!this.headOverlappingWaterVolumes.Contains(volume))
				{
					this.headOverlappingWaterVolumes.Add(volume);
					return;
				}
			}
			else if (playerCollider == this.bodyCollider && !this.bodyOverlappingWaterVolumes.Contains(volume))
			{
				this.bodyOverlappingWaterVolumes.Add(volume);
			}
		}

		// Token: 0x06002203 RID: 8707 RVA: 0x000A3302 File Offset: 0x000A1502
		public void OnExitWaterVolume(Collider playerCollider, WaterVolume volume)
		{
			if (playerCollider == this.headCollider)
			{
				this.headOverlappingWaterVolumes.Remove(volume);
				return;
			}
			if (playerCollider == this.bodyCollider)
			{
				this.bodyOverlappingWaterVolumes.Remove(volume);
			}
		}

		// Token: 0x06002204 RID: 8708 RVA: 0x000A333C File Offset: 0x000A153C
		private bool GetSwimmingVelocityForHand(Vector3 startingHandPosition, Vector3 endingHandPosition, Vector3 palmForwardDirection, float dt, ref WaterVolume contactingWaterVolume, ref WaterVolume.SurfaceQuery waterSurface, out Vector3 swimmingVelocityChange)
		{
			contactingWaterVolume = null;
			this.bufferCount = Physics.OverlapSphereNonAlloc(endingHandPosition, this.minimumRaycastDistance, this.overlapColliders, this.waterLayer.value, QueryTriggerInteraction.Collide);
			if (this.bufferCount > 0)
			{
				float num = float.MinValue;
				for (int i = 0; i < this.bufferCount; i++)
				{
					WaterVolume component = this.overlapColliders[i].GetComponent<WaterVolume>();
					WaterVolume.SurfaceQuery surfaceQuery;
					if (component != null && component.GetSurfaceQueryForPoint(endingHandPosition, out surfaceQuery, false) && surfaceQuery.surfacePoint.y > num)
					{
						num = surfaceQuery.surfacePoint.y;
						contactingWaterVolume = component;
						waterSurface = surfaceQuery;
					}
				}
			}
			if (contactingWaterVolume != null)
			{
				Vector3 a = endingHandPosition - startingHandPosition;
				Vector3 b = Vector3.zero;
				Vector3 b2 = this.playerRigidBody.transform.position - this.lastRigidbodyPosition;
				if (this.turnedThisFrame)
				{
					Vector3 vector = startingHandPosition - this.headCollider.transform.position;
					b = Quaternion.AngleAxis(this.degreesTurnedThisFrame, Vector3.up) * vector - vector;
				}
				float num2 = Vector3.Dot(a - b - b2, palmForwardDirection);
				float num3 = 0f;
				if (num2 > 0f)
				{
					Plane surfacePlane = waterSurface.surfacePlane;
					float distanceToPoint = surfacePlane.GetDistanceToPoint(startingHandPosition);
					float distanceToPoint2 = surfacePlane.GetDistanceToPoint(endingHandPosition);
					if (distanceToPoint <= 0f && distanceToPoint2 <= 0f)
					{
						num3 = 1f;
					}
					else if (distanceToPoint > 0f && distanceToPoint2 <= 0f)
					{
						num3 = -distanceToPoint2 / (distanceToPoint - distanceToPoint2);
					}
					else if (distanceToPoint <= 0f && distanceToPoint2 > 0f)
					{
						num3 = -distanceToPoint / (distanceToPoint2 - distanceToPoint);
					}
					if (num3 > Mathf.Epsilon)
					{
						float resistance = this.liquidPropertiesList[(int)contactingWaterVolume.LiquidType].resistance;
						swimmingVelocityChange = -palmForwardDirection * num2 * 2f * resistance * num3;
						return true;
					}
				}
			}
			swimmingVelocityChange = Vector3.zero;
			return false;
		}

		// Token: 0x06002205 RID: 8709 RVA: 0x000A3550 File Offset: 0x000A1750
		private bool CheckWaterSurfaceJump(Vector3 startingHandPosition, Vector3 endingHandPosition, Vector3 palmForwardDirection, Vector3 handAvgVelocity, PlayerSwimmingParameters parameters, WaterVolume contactingWaterVolume, WaterVolume.SurfaceQuery waterSurface, out Vector3 jumpVelocity)
		{
			if (contactingWaterVolume != null)
			{
				Plane surfacePlane = waterSurface.surfacePlane;
				bool flag = handAvgVelocity.sqrMagnitude > parameters.waterSurfaceJumpHandSpeedThreshold * parameters.waterSurfaceJumpHandSpeedThreshold;
				if (surfacePlane.GetSide(startingHandPosition) && !surfacePlane.GetSide(endingHandPosition) && flag)
				{
					float value = Vector3.Dot(palmForwardDirection, -waterSurface.surfaceNormal);
					float value2 = Vector3.Dot(handAvgVelocity.normalized, -waterSurface.surfaceNormal);
					float d = parameters.waterSurfaceJumpPalmFacingCurve.Evaluate(Mathf.Clamp(value, 0.01f, 0.99f));
					float d2 = parameters.waterSurfaceJumpHandVelocityFacingCurve.Evaluate(Mathf.Clamp(value2, 0.01f, 0.99f));
					jumpVelocity = -handAvgVelocity * parameters.waterSurfaceJumpAmount * d * d2;
					return true;
				}
			}
			jumpVelocity = Vector3.zero;
			return false;
		}

		// Token: 0x06002206 RID: 8710 RVA: 0x000A3649 File Offset: 0x000A1849
		private bool TryNormalize(Vector3 input, out Vector3 normalized, out float magnitude, float eps = 0.0001f)
		{
			magnitude = input.magnitude;
			if (magnitude > eps)
			{
				normalized = input / magnitude;
				return true;
			}
			normalized = Vector3.zero;
			return false;
		}

		// Token: 0x06002207 RID: 8711 RVA: 0x000A3676 File Offset: 0x000A1876
		private bool TryNormalizeDown(Vector3 input, out Vector3 normalized, out float magnitude, float eps = 0.0001f)
		{
			magnitude = input.magnitude;
			if (magnitude > 1f)
			{
				normalized = input / magnitude;
				return true;
			}
			if (magnitude >= eps)
			{
				normalized = input;
				return true;
			}
			normalized = Vector3.zero;
			return false;
		}

		// Token: 0x06002208 RID: 8712 RVA: 0x000A36B8 File Offset: 0x000A18B8
		private void OnCollisionStay(Collision collision)
		{
			this.bodyCollisionContactsCount = collision.GetContacts(this.bodyCollisionContacts);
			float num = -1f;
			for (int i = 0; i < this.bodyCollisionContactsCount; i++)
			{
				float num2 = Vector3.Dot(this.bodyCollisionContacts[i].normal, Vector3.up);
				if (num2 > num)
				{
					this.bodyGroundContact = this.bodyCollisionContacts[i];
					num = num2;
				}
			}
			float num3 = 0.5f;
			if (num > num3)
			{
				this.bodyGroundContactTime = Time.time;
			}
		}

		// Token: 0x06002209 RID: 8713 RVA: 0x000A3740 File Offset: 0x000A1940
		internal void AddHandHold(Transform handHold, Transform grabber, bool rightHand, bool rotatePlayerWhenHeld, out Vector3 grabbedVelocity)
		{
			grabbedVelocity = Vector3.zero;
			if (this.handHolds.Count == 0)
			{
				grabbedVelocity = -this.bodyCollider.attachedRigidbody.velocity;
				this.playerRigidBody.AddForce(grabbedVelocity, ForceMode.VelocityChange);
			}
			this.handHoldGrabbers[handHold] = grabber;
			this.attachedPosition[grabber] = grabber.transform.position;
			this.attachedPrevPosition[grabber] = this.attachedPosition[grabber];
			if (!this.handHolds.Contains(handHold))
			{
				this.handHolds.Add(handHold);
				this.handHoldPositions[handHold] = handHold.transform.position;
				this.handHoldVelocities[handHold] = Vector3.zero;
				if (rotatePlayerWhenHeld)
				{
					this.handHoldRotations[handHold] = handHold.transform.rotation;
				}
			}
			if (rightHand)
			{
				this.rightHandHolding = true;
				return;
			}
			this.leftHandHolding = true;
		}

		// Token: 0x0600220A RID: 8714 RVA: 0x000A3840 File Offset: 0x000A1A40
		internal void RemoveHandHold(Transform handHold, bool rightHand)
		{
			this.handHoldVelocities.Remove(handHold);
			this.handHoldPositions.Remove(handHold);
			this.handHoldGrabbers.Remove(handHold);
			this.handHoldRotations.Remove(handHold);
			this.handHolds.Remove(handHold);
			if (rightHand)
			{
				this.rightHandHolding = false;
			}
			else
			{
				this.leftHandHolding = false;
			}
			if (this.handHolds.Count == 0)
			{
				this.attachedPosition.Clear();
				this.attachedPrevPosition.Clear();
			}
		}

		// Token: 0x0600220B RID: 8715 RVA: 0x000A38C4 File Offset: 0x000A1AC4
		private void FixedUpdate_HandHolds(float timeDelta)
		{
			if (this.handHolds.Count > 0)
			{
				Vector3 a = Vector3.zero;
				Transform transform = this.handHolds[this.handHolds.Count - 1];
				Vector3 vector = (transform.transform.position - this.handHoldPositions[transform]) / timeDelta;
				Vector3 a2 = vector - this.handHoldVelocities[transform] / timeDelta;
				this.handHoldPositions[transform] = transform.transform.position;
				this.handHoldVelocities[transform] = vector;
				a += vector - a2 * Mathf.Pow(timeDelta, 2.3f);
				if (this.handHoldRotations.ContainsKey(transform))
				{
					this.Turn(-(this.handHoldRotations[transform] * Quaternion.Inverse(transform.transform.rotation)).eulerAngles.y);
					this.handHoldRotations[transform] = transform.transform.rotation;
				}
				this.attachedPosition[this.handHoldGrabbers[transform]] = this.handHoldGrabbers[transform].transform.position;
				Vector3 b = (this.attachedPosition[this.handHoldGrabbers[transform]] - this.attachedPrevPosition[this.handHoldGrabbers[transform]]) / timeDelta;
				this.attachedPrevPosition[this.handHoldGrabbers[transform]] = this.attachedPosition[this.handHoldGrabbers[transform]];
				a -= b;
				this.playerRigidBody.AddForce(a - Physics.gravity * timeDelta, ForceMode.VelocityChange);
			}
		}

		// Token: 0x06002211 RID: 8721 RVA: 0x000A3CBD File Offset: 0x000A1EBD
		[CompilerGenerated]
		internal static void <BeginClimbing>g__SnapAxis|278_0(ref float val, float maxDist)
		{
			if (val > maxDist)
			{
				val = maxDist;
				return;
			}
			if (val < -maxDist)
			{
				val = -maxDist;
			}
		}

		// Token: 0x04002327 RID: 8999
		private static Player _instance;

		// Token: 0x04002328 RID: 9000
		public static bool hasInstance;

		// Token: 0x04002329 RID: 9001
		public SphereCollider headCollider;

		// Token: 0x0400232A RID: 9002
		public CapsuleCollider bodyCollider;

		// Token: 0x0400232B RID: 9003
		private float bodyInitialRadius;

		// Token: 0x0400232C RID: 9004
		private float bodyInitialHeight;

		// Token: 0x0400232D RID: 9005
		private RaycastHit bodyHitInfo;

		// Token: 0x0400232E RID: 9006
		private RaycastHit lastHitInfoHand;

		// Token: 0x0400232F RID: 9007
		public Transform leftHandFollower;

		// Token: 0x04002330 RID: 9008
		public Transform rightHandFollower;

		// Token: 0x04002331 RID: 9009
		public Transform rightControllerTransform;

		// Token: 0x04002332 RID: 9010
		public Transform leftControllerTransform;

		// Token: 0x04002333 RID: 9011
		public GorillaVelocityTracker rightHandCenterVelocityTracker;

		// Token: 0x04002334 RID: 9012
		public GorillaVelocityTracker leftHandCenterVelocityTracker;

		// Token: 0x04002335 RID: 9013
		public GorillaVelocityTracker rightInteractPointVelocityTracker;

		// Token: 0x04002336 RID: 9014
		public GorillaVelocityTracker leftInteractPointVelocityTracker;

		// Token: 0x04002337 RID: 9015
		public GorillaVelocityTracker bodyVelocityTracker;

		// Token: 0x04002338 RID: 9016
		public PlayerAudioManager audioManager;

		// Token: 0x04002339 RID: 9017
		private Vector3 lastLeftHandPosition;

		// Token: 0x0400233A RID: 9018
		private Vector3 lastRightHandPosition;

		// Token: 0x0400233B RID: 9019
		public Vector3 lastHeadPosition;

		// Token: 0x0400233C RID: 9020
		private Vector3 lastRigidbodyPosition;

		// Token: 0x0400233D RID: 9021
		private Rigidbody playerRigidBody;

		// Token: 0x0400233E RID: 9022
		private Camera mainCamera;

		// Token: 0x0400233F RID: 9023
		public int velocityHistorySize;

		// Token: 0x04002340 RID: 9024
		public float maxArmLength = 1f;

		// Token: 0x04002341 RID: 9025
		public float unStickDistance = 1f;

		// Token: 0x04002342 RID: 9026
		public float velocityLimit;

		// Token: 0x04002343 RID: 9027
		public float slideVelocityLimit;

		// Token: 0x04002344 RID: 9028
		public float maxJumpSpeed;

		// Token: 0x04002345 RID: 9029
		public float jumpMultiplier;

		// Token: 0x04002346 RID: 9030
		public float minimumRaycastDistance = 0.05f;

		// Token: 0x04002347 RID: 9031
		public float defaultSlideFactor = 0.03f;

		// Token: 0x04002348 RID: 9032
		public float slidingMinimum = 0.9f;

		// Token: 0x04002349 RID: 9033
		public float defaultPrecision = 0.995f;

		// Token: 0x0400234A RID: 9034
		public float teleportThresholdNoVel = 1f;

		// Token: 0x0400234B RID: 9035
		public float frictionConstant = 1f;

		// Token: 0x0400234C RID: 9036
		public float slideControl = 0.00425f;

		// Token: 0x0400234D RID: 9037
		public float stickDepth = 0.01f;

		// Token: 0x0400234E RID: 9038
		private Vector3[] velocityHistory;

		// Token: 0x0400234F RID: 9039
		private Vector3[] slideAverageHistory;

		// Token: 0x04002350 RID: 9040
		private int velocityIndex;

		// Token: 0x04002351 RID: 9041
		public Vector3 currentVelocity;

		// Token: 0x04002352 RID: 9042
		private Vector3 denormalizedVelocityAverage;

		// Token: 0x04002353 RID: 9043
		private Vector3 lastPosition;

		// Token: 0x04002354 RID: 9044
		public Vector3 rightHandOffset;

		// Token: 0x04002355 RID: 9045
		public Vector3 leftHandOffset;

		// Token: 0x04002356 RID: 9046
		public Quaternion rightHandRotOffset = Quaternion.identity;

		// Token: 0x04002357 RID: 9047
		public Quaternion leftHandRotOffset = Quaternion.identity;

		// Token: 0x04002358 RID: 9048
		public Vector3 bodyOffset;

		// Token: 0x04002359 RID: 9049
		public LayerMask locomotionEnabledLayers;

		// Token: 0x0400235A RID: 9050
		public LayerMask waterLayer;

		// Token: 0x0400235B RID: 9051
		public bool wasLeftHandTouching;

		// Token: 0x0400235C RID: 9052
		public bool wasRightHandTouching;

		// Token: 0x0400235D RID: 9053
		public bool wasHeadTouching;

		// Token: 0x0400235E RID: 9054
		public int currentMaterialIndex;

		// Token: 0x0400235F RID: 9055
		public bool leftHandSlide;

		// Token: 0x04002360 RID: 9056
		public Vector3 leftHandSlideNormal;

		// Token: 0x04002361 RID: 9057
		public bool rightHandSlide;

		// Token: 0x04002362 RID: 9058
		public Vector3 rightHandSlideNormal;

		// Token: 0x04002363 RID: 9059
		public Vector3 headSlideNormal;

		// Token: 0x04002364 RID: 9060
		public float rightHandSlipPercentage;

		// Token: 0x04002365 RID: 9061
		public float leftHandSlipPercentage;

		// Token: 0x04002366 RID: 9062
		public float headSlipPercentage;

		// Token: 0x04002367 RID: 9063
		public bool wasLeftHandSlide;

		// Token: 0x04002368 RID: 9064
		public bool wasRightHandSlide;

		// Token: 0x04002369 RID: 9065
		public Vector3 rightHandHitPoint;

		// Token: 0x0400236A RID: 9066
		public Vector3 leftHandHitPoint;

		// Token: 0x0400236B RID: 9067
		public float scale = 1f;

		// Token: 0x0400236C RID: 9068
		public bool debugMovement;

		// Token: 0x0400236D RID: 9069
		public bool disableMovement;

		// Token: 0x0400236E RID: 9070
		[NonSerialized]
		public bool inOverlay;

		// Token: 0x0400236F RID: 9071
		[NonSerialized]
		public bool isUserPresent;

		// Token: 0x04002370 RID: 9072
		public GameObject turnParent;

		// Token: 0x04002371 RID: 9073
		public int leftHandMaterialTouchIndex;

		// Token: 0x04002372 RID: 9074
		public GorillaSurfaceOverride leftHandSurfaceOverride;

		// Token: 0x04002373 RID: 9075
		public int rightHandMaterialTouchIndex;

		// Token: 0x04002374 RID: 9076
		public GorillaSurfaceOverride rightHandSurfaceOverride;

		// Token: 0x04002375 RID: 9077
		public GorillaSurfaceOverride currentOverride;

		// Token: 0x04002376 RID: 9078
		public MaterialDatasSO materialDatasSO;

		// Token: 0x04002377 RID: 9079
		private bool leftHandColliding;

		// Token: 0x04002378 RID: 9080
		private bool rightHandColliding;

		// Token: 0x04002379 RID: 9081
		private bool headColliding;

		// Token: 0x0400237A RID: 9082
		private float degreesTurnedThisFrame;

		// Token: 0x0400237B RID: 9083
		private Vector3 finalPosition;

		// Token: 0x0400237C RID: 9084
		private Vector3 rigidBodyMovement;

		// Token: 0x0400237D RID: 9085
		private Vector3 leftHandPushDisplacement;

		// Token: 0x0400237E RID: 9086
		private Vector3 rightHandPushDisplacement;

		// Token: 0x0400237F RID: 9087
		private RaycastHit hitInfo;

		// Token: 0x04002380 RID: 9088
		private RaycastHit iterativeHitInfo;

		// Token: 0x04002381 RID: 9089
		private RaycastHit collisionsInnerHit;

		// Token: 0x04002382 RID: 9090
		private float slipPercentage;

		// Token: 0x04002383 RID: 9091
		private Vector3 bodyOffsetVector;

		// Token: 0x04002384 RID: 9092
		private Vector3 distanceTraveled;

		// Token: 0x04002385 RID: 9093
		private Vector3 movementToProjectedAboveCollisionPlane;

		// Token: 0x04002386 RID: 9094
		private MeshCollider meshCollider;

		// Token: 0x04002387 RID: 9095
		private Mesh collidedMesh;

		// Token: 0x04002388 RID: 9096
		private Player.MaterialData foundMatData;

		// Token: 0x04002389 RID: 9097
		private string findMatName;

		// Token: 0x0400238A RID: 9098
		private int vertex1;

		// Token: 0x0400238B RID: 9099
		private int vertex2;

		// Token: 0x0400238C RID: 9100
		private int vertex3;

		// Token: 0x0400238D RID: 9101
		private List<int> trianglesList = new List<int>(1000000);

		// Token: 0x0400238E RID: 9102
		private Dictionary<Mesh, int[]> meshTrianglesDict = new Dictionary<Mesh, int[]>(128);

		// Token: 0x0400238F RID: 9103
		private int[] sharedMeshTris;

		// Token: 0x04002390 RID: 9104
		private float lastRealTime;

		// Token: 0x04002391 RID: 9105
		private float calcDeltaTime;

		// Token: 0x04002392 RID: 9106
		private float tempRealTime;

		// Token: 0x04002393 RID: 9107
		private Vector3 junkNormal;

		// Token: 0x04002394 RID: 9108
		private Vector3 slideAverage;

		// Token: 0x04002395 RID: 9109
		private Vector3 slideAverageNormal;

		// Token: 0x04002396 RID: 9110
		private Vector3 tempVector3;

		// Token: 0x04002397 RID: 9111
		private RaycastHit tempHitInfo;

		// Token: 0x04002398 RID: 9112
		private RaycastHit junkHit;

		// Token: 0x04002399 RID: 9113
		private Vector3 firstPosition;

		// Token: 0x0400239A RID: 9114
		private RaycastHit tempIterativeHit;

		// Token: 0x0400239B RID: 9115
		private bool collisionsReturnBool;

		// Token: 0x0400239C RID: 9116
		private float overlapRadiusFunction;

		// Token: 0x0400239D RID: 9117
		private float maxSphereSize1;

		// Token: 0x0400239E RID: 9118
		private float maxSphereSize2;

		// Token: 0x0400239F RID: 9119
		private Collider[] overlapColliders = new Collider[10];

		// Token: 0x040023A0 RID: 9120
		private int overlapAttempts;

		// Token: 0x040023A1 RID: 9121
		private int touchPoints;

		// Token: 0x040023A2 RID: 9122
		private float averageSlipPercentage;

		// Token: 0x040023A3 RID: 9123
		private Vector3 surfaceDirection;

		// Token: 0x040023A4 RID: 9124
		public float iceThreshold = 0.9f;

		// Token: 0x040023A5 RID: 9125
		private float bodyMaxRadius;

		// Token: 0x040023A6 RID: 9126
		public float bodyLerp = 0.17f;

		// Token: 0x040023A7 RID: 9127
		private bool areBothTouching;

		// Token: 0x040023A8 RID: 9128
		private float slideFactor;

		// Token: 0x040023A9 RID: 9129
		[DebugOption]
		public bool didAJump;

		// Token: 0x040023AA RID: 9130
		private Renderer slideRenderer;

		// Token: 0x040023AB RID: 9131
		private RaycastHit[] rayCastNonAllocColliders;

		// Token: 0x040023AC RID: 9132
		private Vector3[] crazyCheckVectors;

		// Token: 0x040023AD RID: 9133
		private RaycastHit emptyHit;

		// Token: 0x040023AE RID: 9134
		private int bufferCount;

		// Token: 0x040023AF RID: 9135
		private Vector3 lastOpenHeadPosition;

		// Token: 0x040023B0 RID: 9136
		private List<Material> tempMaterialArray = new List<Material>(16);

		// Token: 0x040023B1 RID: 9137
		private int leftSlipSetToMaxFrameIdx = -1;

		// Token: 0x040023B2 RID: 9138
		private int rightSlipSetToMaxFrameIdx = -1;

		// Token: 0x040023B3 RID: 9139
		private const float CameraFarClipDefault = 500f;

		// Token: 0x040023B4 RID: 9140
		private const float CameraNearClipDefault = 0.01f;

		// Token: 0x040023B5 RID: 9141
		private const float CameraNearClipTiny = 0.002f;

		// Token: 0x040023B6 RID: 9142
		[Header("Swimming")]
		public PlayerSwimmingParameters swimmingParams;

		// Token: 0x040023B7 RID: 9143
		public WaterParameters waterParams;

		// Token: 0x040023B8 RID: 9144
		public List<Player.LiquidProperties> liquidPropertiesList = new List<Player.LiquidProperties>(16);

		// Token: 0x040023B9 RID: 9145
		public bool debugDrawSwimming;

		// Token: 0x040023BA RID: 9146
		[Header("Slam/Hit effects")]
		public GameObject wizardStaffSlamEffects;

		// Token: 0x040023BB RID: 9147
		public GameObject geodeHitEffects;

		// Token: 0x040023BC RID: 9148
		private WaterVolume leftHandWaterVolume;

		// Token: 0x040023BD RID: 9149
		private WaterVolume rightHandWaterVolume;

		// Token: 0x040023BE RID: 9150
		private WaterVolume.SurfaceQuery leftHandWaterSurface;

		// Token: 0x040023BF RID: 9151
		private WaterVolume.SurfaceQuery rightHandWaterSurface;

		// Token: 0x040023C0 RID: 9152
		private Vector3 swimmingVelocity = Vector3.zero;

		// Token: 0x040023C1 RID: 9153
		private WaterVolume.SurfaceQuery waterSurfaceForHead;

		// Token: 0x040023C2 RID: 9154
		private bool bodyInWater;

		// Token: 0x040023C3 RID: 9155
		private bool headInWater;

		// Token: 0x040023C4 RID: 9156
		private float buoyancyExtension;

		// Token: 0x040023C5 RID: 9157
		private float lastWaterSurfaceJumpTimeLeft = -1f;

		// Token: 0x040023C6 RID: 9158
		private float lastWaterSurfaceJumpTimeRight = -1f;

		// Token: 0x040023C7 RID: 9159
		private float waterSurfaceJumpCooldown = 0.1f;

		// Token: 0x040023C8 RID: 9160
		private float leftHandNonDiveHapticsAmount;

		// Token: 0x040023C9 RID: 9161
		private float rightHandNonDiveHapticsAmount;

		// Token: 0x040023CA RID: 9162
		private List<WaterVolume> headOverlappingWaterVolumes = new List<WaterVolume>(16);

		// Token: 0x040023CB RID: 9163
		private List<WaterVolume> bodyOverlappingWaterVolumes = new List<WaterVolume>(16);

		// Token: 0x040023CC RID: 9164
		private List<WaterCurrent> activeWaterCurrents = new List<WaterCurrent>(16);

		// Token: 0x040023CD RID: 9165
		private Quaternion playerRotationOverride;

		// Token: 0x040023CE RID: 9166
		private int playerRotationOverrideFrame = -1;

		// Token: 0x040023CF RID: 9167
		private float playerRotationOverrideDecayRate = Mathf.Exp(1.5f);

		// Token: 0x040023D0 RID: 9168
		private ContactPoint[] bodyCollisionContacts = new ContactPoint[8];

		// Token: 0x040023D1 RID: 9169
		private int bodyCollisionContactsCount;

		// Token: 0x040023D2 RID: 9170
		private ContactPoint bodyGroundContact;

		// Token: 0x040023D3 RID: 9171
		private float bodyGroundContactTime;

		// Token: 0x040023D4 RID: 9172
		private BasePlatform currentPlatform;

		// Token: 0x040023D5 RID: 9173
		private BasePlatform lastPlatformTouched;

		// Token: 0x040023D6 RID: 9174
		private Vector3 lastFrameTouchPosLocal;

		// Token: 0x040023D7 RID: 9175
		private Vector3 lastFrameTouchPosWorld;

		// Token: 0x040023D8 RID: 9176
		private bool lastFrameHasValidTouchPos;

		// Token: 0x040023D9 RID: 9177
		private Vector3 refMovement = Vector3.zero;

		// Token: 0x040023DA RID: 9178
		private Vector3 platformTouchOffset;

		// Token: 0x040023DB RID: 9179
		private Vector3 debugLastRightHandPosition;

		// Token: 0x040023DC RID: 9180
		private Vector3 debugPlatformDeltaPosition;

		// Token: 0x040023DD RID: 9181
		private const float climbingMaxThrowSpeed = 5.5f;

		// Token: 0x040023DE RID: 9182
		private const float climbHelperSmoothSnapSpeed = 12f;

		// Token: 0x040023DF RID: 9183
		[SerializeField]
		private float velocityThrowClimbingMultiplier = 1f;

		// Token: 0x040023E0 RID: 9184
		[SerializeField]
		private float climbingMaxThrowMagnitude = 10f;

		// Token: 0x040023E1 RID: 9185
		[NonSerialized]
		public bool isClimbing;

		// Token: 0x040023E2 RID: 9186
		private GorillaClimbable currentClimbable;

		// Token: 0x040023E3 RID: 9187
		private GorillaHandClimber currentClimber;

		// Token: 0x040023E4 RID: 9188
		private Vector3 climbHelperTargetPos = Vector3.zero;

		// Token: 0x040023E5 RID: 9189
		private Transform climbHelper;

		// Token: 0x040023E6 RID: 9190
		private GorillaRopeSwing currentSwing;

		// Token: 0x040023E7 RID: 9191
		private GorillaZipline currentZipline;

		// Token: 0x040023E8 RID: 9192
		[SerializeField]
		private ConnectedControllerHandler controllerState;

		// Token: 0x040023E9 RID: 9193
		public int sizeLayerMask;

		// Token: 0x040023EA RID: 9194
		public bool InReportMenu;

		// Token: 0x040023EB RID: 9195
		private float halloweenLevitationStrength;

		// Token: 0x040023EC RID: 9196
		private float halloweenLevitationFullStrengthDuration;

		// Token: 0x040023ED RID: 9197
		private float halloweenLevitationTotalDuration = 1f;

		// Token: 0x040023EE RID: 9198
		private float halloweenLevitationBonusStrength;

		// Token: 0x040023EF RID: 9199
		private float halloweenLevitateBonusOffAtYSpeed;

		// Token: 0x040023F0 RID: 9200
		private float halloweenLevitateBonusFullAtYSpeed = 1f;

		// Token: 0x040023F1 RID: 9201
		private float lastTouchedGroundTimestamp;

		// Token: 0x040023F2 RID: 9202
		private bool teleportToTrain;

		// Token: 0x040023F3 RID: 9203
		public bool isAttachedToTrain;

		// Token: 0x040023F4 RID: 9204
		private bool stuckLeft;

		// Token: 0x040023F5 RID: 9205
		private bool stuckRight;

		// Token: 0x040023F6 RID: 9206
		private float lastScale;

		// Token: 0x040023F7 RID: 9207
		private const float ACCELERATION_HELPER_CURVE = 2.3f;

		// Token: 0x040023F8 RID: 9208
		private List<Transform> handHolds = new List<Transform>();

		// Token: 0x040023F9 RID: 9209
		private Dictionary<Transform, Transform> handHoldGrabbers = new Dictionary<Transform, Transform>();

		// Token: 0x040023FA RID: 9210
		private Dictionary<Transform, Vector3> handHoldPositions = new Dictionary<Transform, Vector3>();

		// Token: 0x040023FB RID: 9211
		private Dictionary<Transform, Quaternion> handHoldRotations = new Dictionary<Transform, Quaternion>();

		// Token: 0x040023FC RID: 9212
		private Dictionary<Transform, Vector3> handHoldVelocities = new Dictionary<Transform, Vector3>();

		// Token: 0x040023FD RID: 9213
		private Dictionary<Transform, Vector3> attachedPosition = new Dictionary<Transform, Vector3>();

		// Token: 0x040023FE RID: 9214
		private Dictionary<Transform, Vector3> attachedPrevPosition = new Dictionary<Transform, Vector3>();

		// Token: 0x040023FF RID: 9215
		private bool rightHandHolding;

		// Token: 0x04002400 RID: 9216
		private bool leftHandHolding;

		// Token: 0x020005AD RID: 1453
		[Serializable]
		public struct MaterialData
		{
			// Token: 0x04002401 RID: 9217
			public string matName;

			// Token: 0x04002402 RID: 9218
			public bool overrideAudio;

			// Token: 0x04002403 RID: 9219
			public AudioClip audio;

			// Token: 0x04002404 RID: 9220
			public bool overrideSlidePercent;

			// Token: 0x04002405 RID: 9221
			public float slidePercent;
		}

		// Token: 0x020005AE RID: 1454
		[Serializable]
		public struct LiquidProperties
		{
			// Token: 0x04002406 RID: 9222
			[Range(0f, 2f)]
			[Tooltip("0: no resistance just like air, 1: full resistance like solid geometry")]
			public float resistance;

			// Token: 0x04002407 RID: 9223
			[Range(0f, 3f)]
			[Tooltip("0: no buoyancy. 1: Fully compensates gravity. 2: net force is upwards equal to gravity")]
			public float buoyancy;

			// Token: 0x04002408 RID: 9224
			[Range(0f, 3f)]
			[Tooltip("Damping Half-life Multiplier")]
			public float dampingFactor;

			// Token: 0x04002409 RID: 9225
			[Range(0f, 1f)]
			public float surfaceJumpFactor;
		}

		// Token: 0x020005AF RID: 1455
		public enum LiquidType
		{
			// Token: 0x0400240B RID: 9227
			Water,
			// Token: 0x0400240C RID: 9228
			Lava
		}
	}
}
