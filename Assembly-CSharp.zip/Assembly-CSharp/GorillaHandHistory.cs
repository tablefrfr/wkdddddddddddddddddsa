﻿using System;
using UnityEngine;

// Token: 0x02000300 RID: 768
public class GorillaHandHistory : MonoBehaviour
{
	// Token: 0x0600118C RID: 4492 RVA: 0x0005C530 File Offset: 0x0005A730
	private void Start()
	{
		this.direction = default(Vector3);
		this.lastPosition = default(Vector3);
	}

	// Token: 0x0600118D RID: 4493 RVA: 0x0005C54A File Offset: 0x0005A74A
	private void FixedUpdate()
	{
		this.direction = this.lastPosition - base.transform.position;
		this.lastLastPosition = this.lastPosition;
		this.lastPosition = base.transform.position;
	}

	// Token: 0x040013E9 RID: 5097
	public Vector3 direction;

	// Token: 0x040013EA RID: 5098
	private Vector3 lastPosition;

	// Token: 0x040013EB RID: 5099
	private Vector3 lastLastPosition;
}
