﻿using System;
using UnityEngine;

// Token: 0x0200036A RID: 874
public class GorillaColorizableParticle : GorillaColorizableBase
{
	// Token: 0x060013E7 RID: 5095 RVA: 0x00068C40 File Offset: 0x00066E40
	public override void SetColor(Color color)
	{
		ParticleSystem.MainModule main = this.particleSystem.main;
		Color color2 = new Color(Mathf.Pow(color.r, this.gradientColorPower), Mathf.Pow(color.g, this.gradientColorPower), Mathf.Pow(color.b, this.gradientColorPower), color.a);
		main.startColor = new ParticleSystem.MinMaxGradient(this.useLinearColor ? color.linear : color, this.useLinearColor ? color2.linear : color2);
	}

	// Token: 0x040016B3 RID: 5811
	public ParticleSystem particleSystem;

	// Token: 0x040016B4 RID: 5812
	public float gradientColorPower = 2f;

	// Token: 0x040016B5 RID: 5813
	public bool useLinearColor = true;
}
