﻿using System;
using UnityEngine;

// Token: 0x02000268 RID: 616
public class BitmapFontText : MonoBehaviour
{
	// Token: 0x06000D43 RID: 3395 RVA: 0x00045042 File Offset: 0x00043242
	private void Awake()
	{
		this.Init();
		this.Render();
	}

	// Token: 0x06000D44 RID: 3396 RVA: 0x00045050 File Offset: 0x00043250
	public void Render()
	{
		this.font.RenderToTexture(this.texture, this.uppercaseOnly ? this.text.ToUpperInvariant() : this.text);
	}

	// Token: 0x06000D45 RID: 3397 RVA: 0x00045080 File Offset: 0x00043280
	public void Init()
	{
		this.texture = new Texture2D(this.textArea.x, this.textArea.y, this.font.fontImage.format, false);
		this.texture.filterMode = FilterMode.Point;
		this.material = new Material(this.renderer.sharedMaterial);
		this.material.mainTexture = this.texture;
		this.renderer.sharedMaterial = this.material;
	}

	// Token: 0x04000EA1 RID: 3745
	public string text;

	// Token: 0x04000EA2 RID: 3746
	public bool uppercaseOnly;

	// Token: 0x04000EA3 RID: 3747
	public Vector2Int textArea;

	// Token: 0x04000EA4 RID: 3748
	[Space]
	public Renderer renderer;

	// Token: 0x04000EA5 RID: 3749
	public Texture2D texture;

	// Token: 0x04000EA6 RID: 3750
	public Material material;

	// Token: 0x04000EA7 RID: 3751
	public BitmapFont font;
}
