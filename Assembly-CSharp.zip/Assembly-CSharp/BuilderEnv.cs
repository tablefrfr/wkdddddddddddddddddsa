﻿using System;
using UnityEngine;

// Token: 0x02000318 RID: 792
public class BuilderEnv : MonoBehaviour
{
	// Token: 0x060011D2 RID: 4562 RVA: 0x00003051 File Offset: 0x00001251
	private void Start()
	{
	}

	// Token: 0x060011D3 RID: 4563 RVA: 0x00003051 File Offset: 0x00001251
	private void Update()
	{
	}
}
