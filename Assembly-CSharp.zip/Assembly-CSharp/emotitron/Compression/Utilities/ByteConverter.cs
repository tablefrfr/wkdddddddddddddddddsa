﻿using System;
using System.Runtime.InteropServices;

namespace emotitron.Compression.Utilities
{
	// Token: 0x020007C0 RID: 1984
	[StructLayout(LayoutKind.Explicit)]
	public struct ByteConverter
	{
		// Token: 0x1700053C RID: 1340
		public byte this[int index]
		{
			get
			{
				switch (index)
				{
				case 0:
					return this.byte0;
				case 1:
					return this.byte1;
				case 2:
					return this.byte2;
				case 3:
					return this.byte3;
				case 4:
					return this.byte4;
				case 5:
					return this.byte5;
				case 6:
					return this.byte6;
				case 7:
					return this.byte7;
				default:
					return 0;
				}
			}
		}

		// Token: 0x06002FF0 RID: 12272 RVA: 0x000EBA3C File Offset: 0x000E9C3C
		public static implicit operator ByteConverter(byte[] bytes)
		{
			ByteConverter result = default(ByteConverter);
			int num = bytes.Length;
			result.byte0 = bytes[0];
			if (num > 0)
			{
				result.byte1 = bytes[1];
			}
			if (num > 1)
			{
				result.byte2 = bytes[2];
			}
			if (num > 2)
			{
				result.byte3 = bytes[3];
			}
			if (num > 3)
			{
				result.byte4 = bytes[4];
			}
			if (num > 4)
			{
				result.byte5 = bytes[5];
			}
			if (num > 5)
			{
				result.byte6 = bytes[3];
			}
			if (num > 6)
			{
				result.byte7 = bytes[7];
			}
			return result;
		}

		// Token: 0x06002FF1 RID: 12273 RVA: 0x000EBAC0 File Offset: 0x000E9CC0
		public static implicit operator ByteConverter(byte val)
		{
			return new ByteConverter
			{
				byte0 = val
			};
		}

		// Token: 0x06002FF2 RID: 12274 RVA: 0x000EBAE0 File Offset: 0x000E9CE0
		public static implicit operator ByteConverter(sbyte val)
		{
			return new ByteConverter
			{
				int8 = val
			};
		}

		// Token: 0x06002FF3 RID: 12275 RVA: 0x000EBB00 File Offset: 0x000E9D00
		public static implicit operator ByteConverter(char val)
		{
			return new ByteConverter
			{
				character = val
			};
		}

		// Token: 0x06002FF4 RID: 12276 RVA: 0x000EBB20 File Offset: 0x000E9D20
		public static implicit operator ByteConverter(uint val)
		{
			return new ByteConverter
			{
				uint32 = val
			};
		}

		// Token: 0x06002FF5 RID: 12277 RVA: 0x000EBB40 File Offset: 0x000E9D40
		public static implicit operator ByteConverter(int val)
		{
			return new ByteConverter
			{
				int32 = val
			};
		}

		// Token: 0x06002FF6 RID: 12278 RVA: 0x000EBB60 File Offset: 0x000E9D60
		public static implicit operator ByteConverter(ulong val)
		{
			return new ByteConverter
			{
				uint64 = val
			};
		}

		// Token: 0x06002FF7 RID: 12279 RVA: 0x000EBB80 File Offset: 0x000E9D80
		public static implicit operator ByteConverter(long val)
		{
			return new ByteConverter
			{
				int64 = val
			};
		}

		// Token: 0x06002FF8 RID: 12280 RVA: 0x000EBBA0 File Offset: 0x000E9DA0
		public static implicit operator ByteConverter(float val)
		{
			return new ByteConverter
			{
				float32 = val
			};
		}

		// Token: 0x06002FF9 RID: 12281 RVA: 0x000EBBC0 File Offset: 0x000E9DC0
		public static implicit operator ByteConverter(double val)
		{
			return new ByteConverter
			{
				float64 = val
			};
		}

		// Token: 0x06002FFA RID: 12282 RVA: 0x000EBBE0 File Offset: 0x000E9DE0
		public static implicit operator ByteConverter(bool val)
		{
			return new ByteConverter
			{
				int32 = (val ? 1 : 0)
			};
		}

		// Token: 0x06002FFB RID: 12283 RVA: 0x000EBC04 File Offset: 0x000E9E04
		public void ExtractByteArray(byte[] targetArray)
		{
			int num = targetArray.Length;
			targetArray[0] = this.byte0;
			if (num > 0)
			{
				targetArray[1] = this.byte1;
			}
			if (num > 1)
			{
				targetArray[2] = this.byte2;
			}
			if (num > 2)
			{
				targetArray[3] = this.byte3;
			}
			if (num > 3)
			{
				targetArray[4] = this.byte4;
			}
			if (num > 4)
			{
				targetArray[5] = this.byte5;
			}
			if (num > 5)
			{
				targetArray[6] = this.byte6;
			}
			if (num > 6)
			{
				targetArray[7] = this.byte7;
			}
		}

		// Token: 0x06002FFC RID: 12284 RVA: 0x000EBC77 File Offset: 0x000E9E77
		public static implicit operator byte(ByteConverter bc)
		{
			return bc.byte0;
		}

		// Token: 0x06002FFD RID: 12285 RVA: 0x000EBC7F File Offset: 0x000E9E7F
		public static implicit operator sbyte(ByteConverter bc)
		{
			return bc.int8;
		}

		// Token: 0x06002FFE RID: 12286 RVA: 0x000EBC87 File Offset: 0x000E9E87
		public static implicit operator char(ByteConverter bc)
		{
			return bc.character;
		}

		// Token: 0x06002FFF RID: 12287 RVA: 0x000EBC8F File Offset: 0x000E9E8F
		public static implicit operator ushort(ByteConverter bc)
		{
			return bc.uint16;
		}

		// Token: 0x06003000 RID: 12288 RVA: 0x000EBC97 File Offset: 0x000E9E97
		public static implicit operator short(ByteConverter bc)
		{
			return bc.int16;
		}

		// Token: 0x06003001 RID: 12289 RVA: 0x000EBC9F File Offset: 0x000E9E9F
		public static implicit operator uint(ByteConverter bc)
		{
			return bc.uint32;
		}

		// Token: 0x06003002 RID: 12290 RVA: 0x000EBCA7 File Offset: 0x000E9EA7
		public static implicit operator int(ByteConverter bc)
		{
			return bc.int32;
		}

		// Token: 0x06003003 RID: 12291 RVA: 0x000EBCAF File Offset: 0x000E9EAF
		public static implicit operator ulong(ByteConverter bc)
		{
			return bc.uint64;
		}

		// Token: 0x06003004 RID: 12292 RVA: 0x000EBCB7 File Offset: 0x000E9EB7
		public static implicit operator long(ByteConverter bc)
		{
			return bc.int64;
		}

		// Token: 0x06003005 RID: 12293 RVA: 0x000EBCBF File Offset: 0x000E9EBF
		public static implicit operator float(ByteConverter bc)
		{
			return bc.float32;
		}

		// Token: 0x06003006 RID: 12294 RVA: 0x000EBCC7 File Offset: 0x000E9EC7
		public static implicit operator double(ByteConverter bc)
		{
			return bc.float64;
		}

		// Token: 0x06003007 RID: 12295 RVA: 0x000EBCCF File Offset: 0x000E9ECF
		public static implicit operator bool(ByteConverter bc)
		{
			return bc.int32 != 0;
		}

		// Token: 0x04003289 RID: 12937
		[FieldOffset(0)]
		public float float32;

		// Token: 0x0400328A RID: 12938
		[FieldOffset(0)]
		public double float64;

		// Token: 0x0400328B RID: 12939
		[FieldOffset(0)]
		public sbyte int8;

		// Token: 0x0400328C RID: 12940
		[FieldOffset(0)]
		public short int16;

		// Token: 0x0400328D RID: 12941
		[FieldOffset(0)]
		public ushort uint16;

		// Token: 0x0400328E RID: 12942
		[FieldOffset(0)]
		public char character;

		// Token: 0x0400328F RID: 12943
		[FieldOffset(0)]
		public int int32;

		// Token: 0x04003290 RID: 12944
		[FieldOffset(0)]
		public uint uint32;

		// Token: 0x04003291 RID: 12945
		[FieldOffset(0)]
		public long int64;

		// Token: 0x04003292 RID: 12946
		[FieldOffset(0)]
		public ulong uint64;

		// Token: 0x04003293 RID: 12947
		[FieldOffset(0)]
		public byte byte0;

		// Token: 0x04003294 RID: 12948
		[FieldOffset(1)]
		public byte byte1;

		// Token: 0x04003295 RID: 12949
		[FieldOffset(2)]
		public byte byte2;

		// Token: 0x04003296 RID: 12950
		[FieldOffset(3)]
		public byte byte3;

		// Token: 0x04003297 RID: 12951
		[FieldOffset(4)]
		public byte byte4;

		// Token: 0x04003298 RID: 12952
		[FieldOffset(5)]
		public byte byte5;

		// Token: 0x04003299 RID: 12953
		[FieldOffset(6)]
		public byte byte6;

		// Token: 0x0400329A RID: 12954
		[FieldOffset(7)]
		public byte byte7;

		// Token: 0x0400329B RID: 12955
		[FieldOffset(4)]
		public uint uint16_B;
	}
}
