﻿using System;
using UnityEngine;
using UnityEngine.Events;

namespace GameObjectScheduling
{
	// Token: 0x020007CF RID: 1999
	public class GameObjectSchedulerEventDispatcher : MonoBehaviour
	{
		// Token: 0x17000546 RID: 1350
		// (get) Token: 0x0600306E RID: 12398 RVA: 0x000ED429 File Offset: 0x000EB629
		public UnityEvent OnScheduledActivation
		{
			get
			{
				return this.onScheduledActivation;
			}
		}

		// Token: 0x17000547 RID: 1351
		// (get) Token: 0x0600306F RID: 12399 RVA: 0x000ED431 File Offset: 0x000EB631
		public UnityEvent OnScheduledDeactivation
		{
			get
			{
				return this.onScheduledDeactivation;
			}
		}

		// Token: 0x040032D9 RID: 13017
		[SerializeField]
		private UnityEvent onScheduledActivation;

		// Token: 0x040032DA RID: 13018
		[SerializeField]
		private UnityEvent onScheduledDeactivation;
	}
}
