﻿using System;

namespace BuildSafe
{
	// Token: 0x0200062E RID: 1582
	public static class SceneView
	{
		// Token: 0x1400003D RID: 61
		// (add) Token: 0x0600253C RID: 9532 RVA: 0x00003051 File Offset: 0x00001251
		// (remove) Token: 0x0600253D RID: 9533 RVA: 0x00003051 File Offset: 0x00001251
		public static event Action duringSceneGui
		{
			add
			{
			}
			remove
			{
			}
		}

		// Token: 0x1400003E RID: 62
		// (add) Token: 0x0600253E RID: 9534 RVA: 0x00003051 File Offset: 0x00001251
		// (remove) Token: 0x0600253F RID: 9535 RVA: 0x00003051 File Offset: 0x00001251
		public static event Action duringSceneGuiTick
		{
			add
			{
			}
			remove
			{
			}
		}
	}
}
