﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text;
using Backtrace.Unity;
using GorillaTagScripts;
using Photon.Pun;
using Photon.Realtime;
using PlayFab;
using PlayFab.ClientModels;
using PlayFab.CloudScriptModels;
using PlayFab.Json;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;
using UnityEngine.XR.Interaction.Toolkit;

namespace GorillaNetworking
{
	// Token: 0x020006B5 RID: 1717
	public class GorillaComputer : MonoBehaviour, IMatchmakingCallbacks
	{
		// Token: 0x06002880 RID: 10368 RVA: 0x000C6F71 File Offset: 0x000C5171
		public DateTime GetServerTime()
		{
			return this.startupTime + TimeSpan.FromSeconds((double)Time.realtimeSinceStartup);
		}

		// Token: 0x170004C2 RID: 1218
		// (get) Token: 0x06002881 RID: 10369 RVA: 0x000C6F8C File Offset: 0x000C518C
		public GorillaComputer.ComputerState currentState
		{
			get
			{
				GorillaComputer.ComputerState result;
				this.stateStack.TryPeek(out result);
				return result;
			}
		}

		// Token: 0x06002882 RID: 10370 RVA: 0x000C6FA8 File Offset: 0x000C51A8
		private void Awake()
		{
			if (GorillaComputer.instance == null)
			{
				GorillaComputer.instance = this;
				GorillaComputer.hasInstance = true;
				return;
			}
			if (GorillaComputer.instance != this)
			{
				Object.Destroy(base.gameObject);
			}
		}

		// Token: 0x06002883 RID: 10371 RVA: 0x000C6FE2 File Offset: 0x000C51E2
		private void Start()
		{
			Debug.Log("Computer Init");
			this.Initialise();
			base.StartCoroutine(this.<Start>g__Start_Local|98_0());
		}

		// Token: 0x06002884 RID: 10372 RVA: 0x000C7001 File Offset: 0x000C5201
		private void OnEnable()
		{
			PlayFabAuthenticator playFabAuthenticator = PlayFabAuthenticator.instance;
			playFabAuthenticator.OnSafetyUpdate = (Action<bool>)Delegate.Combine(playFabAuthenticator.OnSafetyUpdate, new Action<bool>(this.SetComputerSettingsBySafety));
		}

		// Token: 0x06002885 RID: 10373 RVA: 0x000C702C File Offset: 0x000C522C
		protected void OnDestroy()
		{
			if (GorillaComputer.instance == this)
			{
				GorillaComputer.hasInstance = false;
				GorillaComputer.instance = null;
			}
			PlayFabAuthenticator playFabAuthenticator = PlayFabAuthenticator.instance;
			playFabAuthenticator.OnSafetyUpdate = (Action<bool>)Delegate.Remove(playFabAuthenticator.OnSafetyUpdate, new Action<bool>(this.SetComputerSettingsBySafety));
		}

		// Token: 0x06002886 RID: 10374 RVA: 0x000C7080 File Offset: 0x000C5280
		private void Update()
		{
			this.stateUpdated = false;
			if (!this.CheckInternetConnection())
			{
				this.UpdateFailureText("NO WIFI OR LAN CONNECTION DETECTED.");
				this.internetFailure = true;
				return;
			}
			if (this.internetFailure)
			{
				if (this.CheckInternetConnection())
				{
					this.internetFailure = false;
				}
				this.RestoreFromFailureState();
				this.UpdateScreen();
				return;
			}
			if (this.isConnectedToMaster && Time.time > this.lastUpdateTime + this.updateCooldown)
			{
				this.lastUpdateTime = Time.time;
				this.UpdateScreen();
			}
		}

		// Token: 0x06002887 RID: 10375 RVA: 0x000C7100 File Offset: 0x000C5300
		private void Initialise()
		{
			GameEvents.OnGorrillaKeyboardButtonPressedEvent.AddListener(new UnityAction<GorillaKeyboardBindings>(this.PressButton));
			NetworkSystem.Instance.OnMultiplayerStarted += this.UpdateScreen;
			NetworkSystem.Instance.OnReturnedToSinglePlayer += this.UpdateScreen;
			NetworkSystem.Instance.OnPlayerJoined += this.PlayerCountChangedCallback;
			NetworkSystem.Instance.OnPlayerLeft += this.PlayerCountChangedCallback;
			PhotonNetwork.AddCallbackTarget(this);
			this.InitialiseRoomScreens();
			this.InitialiseStrings();
			this.InitialiseAllRoomStates();
			this.UpdateScreen();
			this.initialized = true;
		}

		// Token: 0x06002888 RID: 10376 RVA: 0x000C71A0 File Offset: 0x000C53A0
		private void InitialiseRoomScreens()
		{
			this.screenText.Initialize(this.computerScreenRenderer.materials, this.wrongVersionMaterial, GameEvents.ScreenTextChangedEvent, GameEvents.ScreenTextMaterialsEvent);
			this.functionSelectText.Initialize(this.computerScreenRenderer.materials, this.wrongVersionMaterial, GameEvents.FunctionSelectTextChangedEvent, null);
		}

		// Token: 0x06002889 RID: 10377 RVA: 0x000C71F8 File Offset: 0x000C53F8
		private void InitialiseStrings()
		{
			this.roomToJoin = "";
			this.redText = "";
			this.blueText = "";
			this.greenText = "";
			this.currentName = "";
			this.savedName = "";
		}

		// Token: 0x0600288A RID: 10378 RVA: 0x000C7248 File Offset: 0x000C5448
		private void InitialiseAllRoomStates()
		{
			this.SwitchState(GorillaComputer.ComputerState.Startup, true);
			this.InitializeNameState();
			this.InitializeRoomState();
			this.InitializeTurnState();
			this.InitializeStartupState();
			this.InitializeQueueState();
			this.InitializeMicState();
			this.InitializeGroupState();
			this.InitializeVoiceState();
			this.InitializeAutoMuteState();
			this.InitializeGameMode();
			this.InitializeVisualsState();
			this.InitializeCreditsState();
			this.InitializeTimeState();
			this.InitializeSupportState();
		}

		// Token: 0x0600288B RID: 10379 RVA: 0x00003051 File Offset: 0x00001251
		private void InitializeStartupState()
		{
		}

		// Token: 0x0600288C RID: 10380 RVA: 0x00003051 File Offset: 0x00001251
		private void InitializeRoomState()
		{
		}

		// Token: 0x0600288D RID: 10381 RVA: 0x000C72B4 File Offset: 0x000C54B4
		private void InitializeColorState()
		{
			this.redValue = PlayerPrefs.GetFloat("redValue", 0f);
			this.greenValue = PlayerPrefs.GetFloat("greenValue", 0f);
			this.blueValue = PlayerPrefs.GetFloat("blueValue", 0f);
			this.blueText = Mathf.Floor(this.blueValue * 9f).ToString();
			this.redText = Mathf.Floor(this.redValue * 9f).ToString();
			this.greenText = Mathf.Floor(this.greenValue * 9f).ToString();
			this.colorCursorLine = 0;
			GorillaTagger.Instance.UpdateColor(this.redValue, this.greenValue, this.blueValue);
		}

		// Token: 0x0600288E RID: 10382 RVA: 0x000C7380 File Offset: 0x000C5580
		private void InitializeNameState()
		{
			this.savedName = PlayerPrefs.GetString("playerName", "gorilla");
			NetworkSystem.Instance.SetMyNickName(this.savedName);
			this.currentName = this.savedName;
			this.exactOneWeek = this.exactOneWeekFile.text.Split('\n', StringSplitOptions.None);
			this.anywhereOneWeek = this.anywhereOneWeekFile.text.Split('\n', StringSplitOptions.None);
			this.anywhereTwoWeek = this.anywhereTwoWeekFile.text.Split('\n', StringSplitOptions.None);
			for (int i = 0; i < this.exactOneWeek.Length; i++)
			{
				this.exactOneWeek[i] = this.exactOneWeek[i].ToLower().TrimEnd(new char[]
				{
					'\r',
					'\n'
				});
			}
			for (int j = 0; j < this.anywhereOneWeek.Length; j++)
			{
				this.anywhereOneWeek[j] = this.anywhereOneWeek[j].ToLower().TrimEnd(new char[]
				{
					'\r',
					'\n'
				});
			}
			for (int k = 0; k < this.anywhereTwoWeek.Length; k++)
			{
				this.anywhereTwoWeek[k] = this.anywhereTwoWeek[k].ToLower().TrimEnd(new char[]
				{
					'\r',
					'\n'
				});
			}
		}

		// Token: 0x0600288F RID: 10383 RVA: 0x000C74C0 File Offset: 0x000C56C0
		private void InitializeTurnState()
		{
			this.gorillaTurn = GorillaTagger.Instance.GetComponent<GorillaSnapTurn>();
			string defaultValue = (Application.platform == RuntimePlatform.Android) ? "NONE" : "SNAP";
			this.turnType = PlayerPrefs.GetString("stickTurning", defaultValue);
			this.turnValue = PlayerPrefs.GetInt("turnFactor", 4);
			this.gorillaTurn.ChangeTurnMode(this.turnType, this.turnValue);
		}

		// Token: 0x06002890 RID: 10384 RVA: 0x000C752C File Offset: 0x000C572C
		private void InitializeMicState()
		{
			this.pttType = PlayerPrefs.GetString("pttType", "ALL CHAT");
		}

		// Token: 0x06002891 RID: 10385 RVA: 0x000C7544 File Offset: 0x000C5744
		private void InitializeAutoMuteState()
		{
			int @int = PlayerPrefs.GetInt("autoMute", 1);
			if (@int == 0)
			{
				this.autoMuteType = "OFF";
				return;
			}
			if (@int == 1)
			{
				this.autoMuteType = "MODERATE";
				return;
			}
			if (@int == 2)
			{
				this.autoMuteType = "AGGRESSIVE";
			}
		}

		// Token: 0x06002892 RID: 10386 RVA: 0x000C758C File Offset: 0x000C578C
		private void InitializeQueueState()
		{
			this.currentQueue = PlayerPrefs.GetString("currentQueue", "DEFAULT");
			this.allowedInCompetitive = (PlayerPrefs.GetInt("allowedInCompetitive", 0) == 1);
			if (!this.allowedInCompetitive && this.currentQueue == "COMPETITIVE")
			{
				PlayerPrefs.SetString("currentQueue", "DEFAULT");
				PlayerPrefs.Save();
				this.currentQueue = "DEFAULT";
			}
		}

		// Token: 0x06002893 RID: 10387 RVA: 0x000C75FB File Offset: 0x000C57FB
		private void InitializeGroupState()
		{
			this.groupMapJoin = PlayerPrefs.GetString("groupMapJoin", "FOREST");
			this.groupMapJoinIndex = PlayerPrefs.GetInt("groupMapJoinIndex", 0);
			this.allowedMapsToJoin = this.friendJoinCollider.myAllowedMapsToJoin;
		}

		// Token: 0x06002894 RID: 10388 RVA: 0x000C7634 File Offset: 0x000C5834
		private void InitializeVoiceState()
		{
			this.voiceChatOn = PlayerPrefs.GetString("voiceChatOn", "TRUE");
		}

		// Token: 0x06002895 RID: 10389 RVA: 0x000C764C File Offset: 0x000C584C
		private void InitializeGameMode()
		{
			string text = PlayerPrefs.GetString("currentGameMode", "INFECTION");
			if (text != "CASUAL" && text != "INFECTION" && text != "HUNT" && text != "BATTLE")
			{
				PlayerPrefs.SetString("currentGameMode", "INFECTION");
				PlayerPrefs.Save();
				text = "INFECTION";
			}
			this.leftHanded = (PlayerPrefs.GetInt("leftHanded", 0) == 1);
			this.OnModeSelectButtonPress(text, this.leftHanded);
			GameModePages.SetSelectedGameModeShared(text);
		}

		// Token: 0x06002896 RID: 10390 RVA: 0x00003051 File Offset: 0x00001251
		private void InitializeCreditsState()
		{
		}

		// Token: 0x06002897 RID: 10391 RVA: 0x000C76DE File Offset: 0x000C58DE
		private void InitializeTimeState()
		{
			BetterDayNightManager.instance.currentSetting = TimeSettings.Normal;
		}

		// Token: 0x06002898 RID: 10392 RVA: 0x000C76ED File Offset: 0x000C58ED
		private void InitializeSupportState()
		{
			this.displaySupport = false;
		}

		// Token: 0x06002899 RID: 10393 RVA: 0x000C76F8 File Offset: 0x000C58F8
		private void InitializeVisualsState()
		{
			this.disableParticles = (PlayerPrefs.GetString("disableParticles", "FALSE") == "TRUE");
			GorillaTagger.Instance.ShowCosmeticParticles(!this.disableParticles);
			this.instrumentVolume = PlayerPrefs.GetFloat("instrumentVolume", 0.1f);
		}

		// Token: 0x0600289A RID: 10394 RVA: 0x000C774C File Offset: 0x000C594C
		private bool CheckInternetConnection()
		{
			return Application.internetReachability > NetworkReachability.NotReachable;
		}

		// Token: 0x0600289B RID: 10395 RVA: 0x000C7758 File Offset: 0x000C5958
		public void OnConnectedToMasterStuff()
		{
			if (!this.isConnectedToMaster)
			{
				this.isConnectedToMaster = true;
				GorillaServer.Instance.ReturnCurrentVersion(new ReturnCurrentVersionRequest
				{
					CurrentVersion = NetworkSystemConfig.AppVersion,
					UpdatedSynchTest = new int?(this.includeUpdatedServerSynchTest)
				}, new Action<ExecuteFunctionResult>(this.OnReturnCurrentVersion), new Action<PlayFabError>(GorillaComputer.OnErrorShared));
				if (this.startupMillis == 0L && !this.tryGetTimeAgain)
				{
					this.GetCurrentTime();
				}
				RuntimePlatform platform = Application.platform;
				this.SaveModAccountData();
				if (PlayFabAuthenticator.instance.GetSafety())
				{
					this.SetComputerSettingsBySafety(PlayFabAuthenticator.instance.GetSafety());
				}
			}
		}

		// Token: 0x0600289C RID: 10396 RVA: 0x000C7804 File Offset: 0x000C5A04
		private void OnReturnCurrentVersion(ExecuteFunctionResult result)
		{
			JsonObject jsonObject = (JsonObject)result.FunctionResult;
			if (jsonObject == null)
			{
				this.GeneralFailureMessage(this.versionMismatch);
				return;
			}
			object obj;
			if (jsonObject.TryGetValue("SynchTime", out obj))
			{
				Debug.Log("message value is: " + (string)obj);
			}
			if (jsonObject.TryGetValue("Fail", out obj) && (bool)obj)
			{
				this.GeneralFailureMessage(this.versionMismatch);
				return;
			}
			if (jsonObject.TryGetValue("ResultCode", out obj) && (ulong)obj != 0UL)
			{
				this.GeneralFailureMessage(this.versionMismatch);
				return;
			}
			if (jsonObject.TryGetValue("BannedUsers", out obj))
			{
				this.usersBanned = int.Parse((string)obj);
			}
			this.UpdateScreen();
		}

		// Token: 0x0600289D RID: 10397 RVA: 0x000C78C4 File Offset: 0x000C5AC4
		public void SaveModAccountData()
		{
			string path = Application.persistentDataPath + "/DoNotShareWithAnyoneEVERNoMatterWhatTheySay.txt";
			if (File.Exists(path))
			{
				return;
			}
			GorillaServer.Instance.ReturnMyOculusHash(delegate(ExecuteFunctionResult result)
			{
				object obj;
				if (((JsonObject)result.FunctionResult).TryGetValue("oculusHash", out obj))
				{
					StreamWriter streamWriter = new StreamWriter(path);
					streamWriter.Write(PlayFabAuthenticator.instance._playFabPlayerIdCache + "." + (string)obj);
					streamWriter.Close();
				}
			}, delegate(PlayFabError error)
			{
				if (error.Error == PlayFabErrorCode.NotAuthenticated)
				{
					PlayFabAuthenticator.instance.AuthenticateWithPlayFab();
					return;
				}
				if (error.Error == PlayFabErrorCode.AccountBanned)
				{
					GorillaGameManager.ForceStopGame_DisconnectAndDestroy();
				}
			});
		}

		// Token: 0x0600289E RID: 10398 RVA: 0x000C7934 File Offset: 0x000C5B34
		public void PressButton(GorillaKeyboardBindings buttonPressed)
		{
			if (this.currentState == GorillaComputer.ComputerState.Startup)
			{
				this.ProcessStartupState(buttonPressed);
				this.UpdateScreen();
				return;
			}
			bool flag = true;
			if (buttonPressed == GorillaKeyboardBindings.up)
			{
				flag = false;
				this.DecreaseState();
			}
			else if (buttonPressed == GorillaKeyboardBindings.down)
			{
				flag = false;
				this.IncreaseState();
			}
			if (flag)
			{
				switch (this.currentState)
				{
				case GorillaComputer.ComputerState.Color:
					this.ProcessColorState(buttonPressed);
					break;
				case GorillaComputer.ComputerState.Name:
					this.ProcessNameState(buttonPressed);
					break;
				case GorillaComputer.ComputerState.Turn:
					this.ProcessTurnState(buttonPressed);
					break;
				case GorillaComputer.ComputerState.Mic:
					this.ProcessMicState(buttonPressed);
					break;
				case GorillaComputer.ComputerState.Room:
					this.ProcessRoomState(buttonPressed);
					break;
				case GorillaComputer.ComputerState.Queue:
					this.ProcessQueueState(buttonPressed);
					break;
				case GorillaComputer.ComputerState.Group:
					this.ProcessGroupState(buttonPressed);
					break;
				case GorillaComputer.ComputerState.Voice:
					this.ProcessVoiceState(buttonPressed);
					break;
				case GorillaComputer.ComputerState.AutoMute:
					this.ProcessAutoMuteState(buttonPressed);
					break;
				case GorillaComputer.ComputerState.Credits:
					this.ProcessCreditsState(buttonPressed);
					break;
				case GorillaComputer.ComputerState.Visuals:
					this.ProcessVisualsState(buttonPressed);
					break;
				case GorillaComputer.ComputerState.NameWarning:
					this.ProcessNameWarningState(buttonPressed);
					break;
				case GorillaComputer.ComputerState.Support:
					this.ProcessSupportState(buttonPressed);
					break;
				}
			}
			this.UpdateScreen();
		}

		// Token: 0x0600289F RID: 10399 RVA: 0x000C7A41 File Offset: 0x000C5C41
		public void OnModeSelectButtonPress(string gameMode, bool leftHand)
		{
			this.currentGameMode.Value = gameMode;
			PlayerPrefs.SetString("currentGameMode", gameMode);
			if (leftHand != this.leftHanded)
			{
				PlayerPrefs.SetInt("leftHanded", leftHand ? 1 : 0);
				this.leftHanded = leftHand;
			}
			PlayerPrefs.Save();
		}

		// Token: 0x060028A0 RID: 10400 RVA: 0x000C7A80 File Offset: 0x000C5C80
		private GorillaNetworkJoinTrigger GetSelectedMapJoinTrigger()
		{
			GorillaNetworkJoinTrigger result = null;
			string text = this.allowedMapsToJoin[Mathf.Min(this.allowedMapsToJoin.Length - 1, this.groupMapJoinIndex)];
			uint num = <PrivateImplementationDetails>.ComputeStringHash(text);
			if (num <= 1238098082U)
			{
				if (num <= 867966839U)
				{
					if (num != 230981954U)
					{
						if (num == 867966839U)
						{
							if (text == "clouds")
							{
								result = this.skyjungleMapTrigger;
							}
						}
					}
					else if (text == "city")
					{
						result = this.cityMapTrigger;
					}
				}
				else if (num != 1176688605U)
				{
					if (num != 1219117101U)
					{
						if (num == 1238098082U)
						{
							if (text == "mountain")
							{
								result = this.mountainMapTrigger;
							}
						}
					}
					else if (text == "rotating")
					{
						result = this.rotatingMapTrigger;
					}
				}
				else if (text == "canyon")
				{
					result = this.canyonMapTrigger;
				}
			}
			else if (num <= 2536635992U)
			{
				if (num != 1328097888U)
				{
					if (num == 2536635992U)
					{
						if (text == "cave")
						{
							result = this.caveMapTrigger;
						}
					}
				}
				else if (text == "forest")
				{
					result = this.forestMapTrigger;
				}
			}
			else if (num != 2638718637U)
			{
				if (num != 4068581324U)
				{
					if (num == 4105357384U)
					{
						if (text == "beach")
						{
							result = this.beachMapTrigger;
						}
					}
				}
				else if (text == "basement")
				{
					result = this.basementMapTrigger;
				}
			}
			else if (text == "metropolis")
			{
				result = this.metroMapTrigger;
			}
			return result;
		}

		// Token: 0x060028A1 RID: 10401 RVA: 0x000C7C58 File Offset: 0x000C5E58
		public void OnGroupJoinButtonPress(int mapJoinIndex, GorillaFriendCollider chosenFriendJoinCollider)
		{
			Debug.Log("On Group button press. Map:" + mapJoinIndex.ToString() + " - collider: " + chosenFriendJoinCollider.name);
			if (mapJoinIndex >= this.allowedMapsToJoin.Length)
			{
				this.roomNotAllowed = true;
				this.currentStateIndex = 0;
				this.SwitchState(this.GetState(this.currentStateIndex), true);
				return;
			}
			GorillaNetworkJoinTrigger selectedMapJoinTrigger = this.GetSelectedMapJoinTrigger();
			if (!FriendshipGroupDetection.Instance.IsInParty)
			{
				if (NetworkSystem.Instance.InRoom && NetworkSystem.Instance.SessionIsPrivate)
				{
					PhotonNetworkController.Instance.friendIDList = new List<string>(chosenFriendJoinCollider.playerIDsCurrentlyTouching);
					foreach (string str in this.networkController.friendIDList)
					{
						Debug.Log("Friend ID:" + str);
					}
					PhotonNetworkController.Instance.shuffler = Random.Range(0, 99).ToString().PadLeft(2, '0') + Random.Range(0, 99999999).ToString().PadLeft(8, '0');
					PhotonNetworkController.Instance.keyStr = Random.Range(0, 99999999).ToString().PadLeft(8, '0');
					RoomSystem.SendNearbyFollowCommand(chosenFriendJoinCollider, PhotonNetworkController.Instance.shuffler, PhotonNetworkController.Instance.keyStr);
					PhotonNetwork.SendAllOutgoingCommands();
					PhotonNetworkController.Instance.AttemptToJoinPublicRoom(selectedMapJoinTrigger, JoinType.JoinWithNearby);
					this.currentStateIndex = 0;
					this.SwitchState(this.GetState(this.currentStateIndex), true);
				}
				return;
			}
			if (selectedMapJoinTrigger != null && selectedMapJoinTrigger.CanPartyJoin())
			{
				PhotonNetworkController.Instance.AttemptToJoinPublicRoom(selectedMapJoinTrigger, JoinType.ForceJoinWithParty);
				this.currentStateIndex = 0;
				this.SwitchState(this.GetState(this.currentStateIndex), true);
				return;
			}
			this.UpdateScreen();
		}

		// Token: 0x060028A2 RID: 10402 RVA: 0x000C7E48 File Offset: 0x000C6048
		public void CompQueueUnlockButtonPress()
		{
			this.allowedInCompetitive = true;
			PlayerPrefs.SetInt("allowedInCompetitive", 1);
			PlayerPrefs.Save();
		}

		// Token: 0x060028A3 RID: 10403 RVA: 0x000C7E64 File Offset: 0x000C6064
		private void SwitchState(GorillaComputer.ComputerState newState, bool clearStack = true)
		{
			if (this.previousComputerState != this.currentComputerState)
			{
				this.previousComputerState = this.currentComputerState;
			}
			this.currentComputerState = newState;
			if (this.LoadingRoutine != null)
			{
				base.StopCoroutine(this.LoadingRoutine);
			}
			if (clearStack)
			{
				this.stateStack.Clear();
			}
			this.stateStack.Push(newState);
		}

		// Token: 0x060028A4 RID: 10404 RVA: 0x000C7EC0 File Offset: 0x000C60C0
		private void PopState()
		{
			this.currentComputerState = this.previousComputerState;
			if (this.stateStack.Count <= 1)
			{
				Debug.LogError("Can't pop into an empty stack");
				return;
			}
			this.stateStack.Pop();
			this.UpdateScreen();
		}

		// Token: 0x060028A5 RID: 10405 RVA: 0x000C7EF9 File Offset: 0x000C60F9
		private void SwitchToWarningState()
		{
			this.warningConfirmationInputString = string.Empty;
			this.SwitchState(GorillaComputer.ComputerState.NameWarning, false);
		}

		// Token: 0x060028A6 RID: 10406 RVA: 0x000C7F0F File Offset: 0x000C610F
		private void SwitchToLoadingState()
		{
			this.SwitchState(GorillaComputer.ComputerState.Loading, false);
		}

		// Token: 0x060028A7 RID: 10407 RVA: 0x000C7F1A File Offset: 0x000C611A
		private void ProcessStartupState(GorillaKeyboardBindings buttonPressed)
		{
			this.SwitchState(this.GetState(this.currentStateIndex), true);
		}

		// Token: 0x060028A8 RID: 10408 RVA: 0x000C7F30 File Offset: 0x000C6130
		private void ProcessColorState(GorillaKeyboardBindings buttonPressed)
		{
			switch (buttonPressed)
			{
			case GorillaKeyboardBindings.enter:
				return;
			case GorillaKeyboardBindings.option1:
				this.colorCursorLine = 0;
				return;
			case GorillaKeyboardBindings.option2:
				this.colorCursorLine = 1;
				return;
			case GorillaKeyboardBindings.option3:
				this.colorCursorLine = 2;
				return;
			default:
			{
				int num = (int)buttonPressed;
				if (num < 10)
				{
					switch (this.colorCursorLine)
					{
					case 0:
						this.redText = num.ToString();
						this.redValue = (float)num / 9f;
						PlayerPrefs.SetFloat("redValue", this.redValue);
						break;
					case 1:
						this.greenText = num.ToString();
						this.greenValue = (float)num / 9f;
						PlayerPrefs.SetFloat("greenValue", this.greenValue);
						break;
					case 2:
						this.blueText = num.ToString();
						this.blueValue = (float)num / 9f;
						PlayerPrefs.SetFloat("blueValue", this.blueValue);
						break;
					}
					GorillaTagger.Instance.UpdateColor(this.redValue, this.greenValue, this.blueValue);
					PlayerPrefs.Save();
					if (NetworkSystem.Instance.InRoom)
					{
						GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
						{
							this.redValue,
							this.greenValue,
							this.blueValue
						});
					}
				}
				return;
			}
			}
		}

		// Token: 0x060028A9 RID: 10409 RVA: 0x000C8090 File Offset: 0x000C6290
		public void ProcessNameState(GorillaKeyboardBindings buttonPressed)
		{
			if (buttonPressed != GorillaKeyboardBindings.delete)
			{
				if (buttonPressed == GorillaKeyboardBindings.enter)
				{
					if (this.currentName != this.savedName && this.currentName != "")
					{
						this.CheckAutoBanListForPlayerName(this.currentName);
						return;
					}
				}
				else if (this.currentName.Length < 12 && (buttonPressed < GorillaKeyboardBindings.up || buttonPressed > GorillaKeyboardBindings.option3))
				{
					string str = this.currentName;
					string str2;
					if (buttonPressed >= GorillaKeyboardBindings.up)
					{
						str2 = buttonPressed.ToString();
					}
					else
					{
						int num = (int)buttonPressed;
						str2 = num.ToString();
					}
					this.currentName = str + str2;
				}
			}
			else if (this.currentName.Length > 0)
			{
				this.currentName = this.currentName.Substring(0, this.currentName.Length - 1);
				return;
			}
		}

		// Token: 0x060028AA RID: 10410 RVA: 0x000C8154 File Offset: 0x000C6354
		private void ProcessRoomState(GorillaKeyboardBindings buttonPressed)
		{
			bool safety = PlayFabAuthenticator.instance.GetSafety();
			switch (buttonPressed)
			{
			case GorillaKeyboardBindings.delete:
				if (!safety && this.roomToJoin.Length > 0)
				{
					this.roomToJoin = this.roomToJoin.Substring(0, this.roomToJoin.Length - 1);
					return;
				}
				break;
			case GorillaKeyboardBindings.enter:
				if (!safety && this.roomToJoin != "")
				{
					this.CheckAutoBanListForRoomName(this.roomToJoin);
					return;
				}
				break;
			case GorillaKeyboardBindings.option1:
				if (FriendshipGroupDetection.Instance.IsInParty)
				{
					FriendshipGroupDetection.Instance.LeaveParty();
					this.DisconnectAfterDelay(1f);
					return;
				}
				NetworkSystem.Instance.ReturnToSinglePlayer();
				return;
			case GorillaKeyboardBindings.option2:
			case GorillaKeyboardBindings.option3:
				break;
			default:
				if (!safety && this.roomToJoin.Length < 10)
				{
					string str = this.roomToJoin;
					string str2;
					if (buttonPressed >= GorillaKeyboardBindings.up)
					{
						str2 = buttonPressed.ToString();
					}
					else
					{
						int num = (int)buttonPressed;
						str2 = num.ToString();
					}
					this.roomToJoin = str + str2;
				}
				break;
			}
		}

		// Token: 0x060028AB RID: 10411 RVA: 0x000C8254 File Offset: 0x000C6454
		private void DisconnectAfterDelay(float seconds)
		{
			GorillaComputer.<DisconnectAfterDelay>d__138 <DisconnectAfterDelay>d__;
			<DisconnectAfterDelay>d__.<>t__builder = AsyncVoidMethodBuilder.Create();
			<DisconnectAfterDelay>d__.seconds = seconds;
			<DisconnectAfterDelay>d__.<>1__state = -1;
			<DisconnectAfterDelay>d__.<>t__builder.Start<GorillaComputer.<DisconnectAfterDelay>d__138>(ref <DisconnectAfterDelay>d__);
		}

		// Token: 0x060028AC RID: 10412 RVA: 0x000C828C File Offset: 0x000C648C
		private void ProcessTurnState(GorillaKeyboardBindings buttonPressed)
		{
			if (buttonPressed < GorillaKeyboardBindings.up)
			{
				this.turnValue = (int)buttonPressed;
				PlayerPrefs.SetInt("turnFactor", this.turnValue);
				PlayerPrefs.Save();
				this.gorillaTurn.ChangeTurnMode(this.turnType, this.turnValue);
				return;
			}
			switch (buttonPressed)
			{
			case GorillaKeyboardBindings.option1:
				this.turnType = "SNAP";
				PlayerPrefs.SetString("stickTurning", this.turnType);
				PlayerPrefs.Save();
				this.gorillaTurn.ChangeTurnMode(this.turnType, this.turnValue);
				return;
			case GorillaKeyboardBindings.option2:
				this.turnType = "SMOOTH";
				PlayerPrefs.SetString("stickTurning", this.turnType);
				PlayerPrefs.Save();
				this.gorillaTurn.ChangeTurnMode(this.turnType, this.turnValue);
				return;
			case GorillaKeyboardBindings.option3:
				this.turnType = "NONE";
				PlayerPrefs.SetString("stickTurning", this.turnType);
				PlayerPrefs.Save();
				this.gorillaTurn.ChangeTurnMode(this.turnType, this.turnValue);
				return;
			default:
				return;
			}
		}

		// Token: 0x060028AD RID: 10413 RVA: 0x000C8394 File Offset: 0x000C6594
		private void ProcessMicState(GorillaKeyboardBindings buttonPressed)
		{
			switch (buttonPressed)
			{
			case GorillaKeyboardBindings.option1:
				this.pttType = "ALL CHAT";
				PlayerPrefs.SetString("pttType", this.pttType);
				PlayerPrefs.Save();
				return;
			case GorillaKeyboardBindings.option2:
				this.pttType = "PUSH TO TALK";
				PlayerPrefs.SetString("pttType", this.pttType);
				PlayerPrefs.Save();
				return;
			case GorillaKeyboardBindings.option3:
				this.pttType = "PUSH TO MUTE";
				PlayerPrefs.SetString("pttType", this.pttType);
				PlayerPrefs.Save();
				return;
			default:
				return;
			}
		}

		// Token: 0x060028AE RID: 10414 RVA: 0x000C841C File Offset: 0x000C661C
		private void ProcessQueueState(GorillaKeyboardBindings buttonPressed)
		{
			switch (buttonPressed)
			{
			case GorillaKeyboardBindings.option1:
				this.currentQueue = "DEFAULT";
				PlayerPrefs.SetString("currentQueue", this.currentQueue);
				PlayerPrefs.Save();
				return;
			case GorillaKeyboardBindings.option2:
				this.currentQueue = "MINIGAMES";
				PlayerPrefs.SetString("currentQueue", this.currentQueue);
				PlayerPrefs.Save();
				return;
			case GorillaKeyboardBindings.option3:
				if (this.allowedInCompetitive)
				{
					this.currentQueue = "COMPETITIVE";
					PlayerPrefs.SetString("currentQueue", this.currentQueue);
					PlayerPrefs.Save();
				}
				return;
			default:
				return;
			}
		}

		// Token: 0x060028AF RID: 10415 RVA: 0x000C84AC File Offset: 0x000C66AC
		private void ProcessGroupState(GorillaKeyboardBindings buttonPressed)
		{
			switch (buttonPressed)
			{
			case GorillaKeyboardBindings.one:
				this.groupMapJoin = "FOREST";
				this.groupMapJoinIndex = 0;
				PlayerPrefs.SetString("groupMapJoin", this.groupMapJoin);
				PlayerPrefs.SetInt("groupMapJoinIndex", this.groupMapJoinIndex);
				PlayerPrefs.Save();
				break;
			case GorillaKeyboardBindings.two:
				this.groupMapJoin = "CAVE";
				this.groupMapJoinIndex = 1;
				PlayerPrefs.SetString("groupMapJoin", this.groupMapJoin);
				PlayerPrefs.SetInt("groupMapJoinIndex", this.groupMapJoinIndex);
				PlayerPrefs.Save();
				break;
			case GorillaKeyboardBindings.three:
				this.groupMapJoin = "CANYON";
				this.groupMapJoinIndex = 2;
				PlayerPrefs.SetString("groupMapJoin", this.groupMapJoin);
				PlayerPrefs.SetInt("groupMapJoinIndex", this.groupMapJoinIndex);
				PlayerPrefs.Save();
				break;
			case GorillaKeyboardBindings.four:
				this.groupMapJoin = "CITY";
				this.groupMapJoinIndex = 3;
				PlayerPrefs.SetString("groupMapJoin", this.groupMapJoin);
				PlayerPrefs.SetInt("groupMapJoinIndex", this.groupMapJoinIndex);
				PlayerPrefs.Save();
				break;
			case GorillaKeyboardBindings.five:
				this.groupMapJoin = "CLOUDS";
				this.groupMapJoinIndex = 4;
				PlayerPrefs.SetString("groupMapJoin", this.groupMapJoin);
				PlayerPrefs.SetInt("groupMapJoinIndex", this.groupMapJoinIndex);
				PlayerPrefs.Save();
				break;
			default:
				if (buttonPressed == GorillaKeyboardBindings.enter)
				{
					this.OnGroupJoinButtonPress(Mathf.Min(this.allowedMapsToJoin.Length - 1, this.groupMapJoinIndex), this.friendJoinCollider);
				}
				break;
			}
			this.roomFull = false;
		}

		// Token: 0x060028B0 RID: 10416 RVA: 0x000C8630 File Offset: 0x000C6830
		private void ProcessVoiceState(GorillaKeyboardBindings buttonPressed)
		{
			if (buttonPressed == GorillaKeyboardBindings.option1)
			{
				this.voiceChatOn = "TRUE";
				PlayerPrefs.SetString("voiceChatOn", this.voiceChatOn);
				PlayerPrefs.Save();
				RigContainer.RefreshAllRigVoices();
				return;
			}
			if (buttonPressed != GorillaKeyboardBindings.option2)
			{
				return;
			}
			this.voiceChatOn = "FALSE";
			PlayerPrefs.SetString("voiceChatOn", this.voiceChatOn);
			PlayerPrefs.Save();
			RigContainer.RefreshAllRigVoices();
		}

		// Token: 0x060028B1 RID: 10417 RVA: 0x000C8694 File Offset: 0x000C6894
		private void ProcessAutoMuteState(GorillaKeyboardBindings buttonPressed)
		{
			switch (buttonPressed)
			{
			case GorillaKeyboardBindings.option1:
				this.autoMuteType = "AGGRESSIVE";
				PlayerPrefs.SetInt("autoMute", 2);
				PlayerPrefs.Save();
				RigContainer.RefreshAllRigVoices();
				break;
			case GorillaKeyboardBindings.option2:
				this.autoMuteType = "MODERATE";
				PlayerPrefs.SetInt("autoMute", 1);
				PlayerPrefs.Save();
				RigContainer.RefreshAllRigVoices();
				break;
			case GorillaKeyboardBindings.option3:
				this.autoMuteType = "OFF";
				PlayerPrefs.SetInt("autoMute", 0);
				PlayerPrefs.Save();
				RigContainer.RefreshAllRigVoices();
				break;
			}
			this.UpdateScreen();
		}

		// Token: 0x060028B2 RID: 10418 RVA: 0x000C8724 File Offset: 0x000C6924
		private void ProcessVisualsState(GorillaKeyboardBindings buttonPressed)
		{
			if (buttonPressed < GorillaKeyboardBindings.up)
			{
				this.instrumentVolume = (float)buttonPressed / 50f;
				PlayerPrefs.SetFloat("instrumentVolume", this.instrumentVolume);
				PlayerPrefs.Save();
				return;
			}
			if (buttonPressed == GorillaKeyboardBindings.option1)
			{
				this.disableParticles = false;
				PlayerPrefs.SetString("disableParticles", "FALSE");
				PlayerPrefs.Save();
				GorillaTagger.Instance.ShowCosmeticParticles(!this.disableParticles);
				return;
			}
			if (buttonPressed != GorillaKeyboardBindings.option2)
			{
				return;
			}
			this.disableParticles = true;
			PlayerPrefs.SetString("disableParticles", "TRUE");
			PlayerPrefs.Save();
			GorillaTagger.Instance.ShowCosmeticParticles(!this.disableParticles);
		}

		// Token: 0x060028B3 RID: 10419 RVA: 0x000C87C4 File Offset: 0x000C69C4
		private void ProcessCreditsState(GorillaKeyboardBindings buttonPressed)
		{
			if (buttonPressed == GorillaKeyboardBindings.enter)
			{
				this.creditsView.ProcessButtonPress(buttonPressed);
			}
		}

		// Token: 0x060028B4 RID: 10420 RVA: 0x000C87D7 File Offset: 0x000C69D7
		private void ProcessSupportState(GorillaKeyboardBindings buttonPressed)
		{
			if (buttonPressed == GorillaKeyboardBindings.enter)
			{
				this.displaySupport = true;
			}
		}

		// Token: 0x060028B5 RID: 10421 RVA: 0x000C87E8 File Offset: 0x000C69E8
		private void ProcessNameWarningState(GorillaKeyboardBindings buttonPressed)
		{
			if (this.warningConfirmationInputString.ToLower() == "yes")
			{
				this.PopState();
				return;
			}
			if (buttonPressed == GorillaKeyboardBindings.delete)
			{
				if (this.warningConfirmationInputString.Length > 0)
				{
					this.warningConfirmationInputString = this.warningConfirmationInputString.Substring(0, this.warningConfirmationInputString.Length - 1);
					return;
				}
			}
			else if (this.warningConfirmationInputString.Length < 3)
			{
				this.warningConfirmationInputString += buttonPressed.ToString();
			}
		}

		// Token: 0x060028B6 RID: 10422 RVA: 0x000C8874 File Offset: 0x000C6A74
		public void UpdateScreen()
		{
			if (NetworkSystem.Instance != null && !NetworkSystem.Instance.WrongVersion)
			{
				this.UpdateFunctionScreen();
				switch (this.currentState)
				{
				case GorillaComputer.ComputerState.Startup:
					this.StartupScreen();
					break;
				case GorillaComputer.ComputerState.Color:
					this.ColourScreen();
					break;
				case GorillaComputer.ComputerState.Name:
					this.NameScreen();
					break;
				case GorillaComputer.ComputerState.Turn:
					this.TurnScreen();
					break;
				case GorillaComputer.ComputerState.Mic:
					this.MicScreen();
					break;
				case GorillaComputer.ComputerState.Room:
					this.RoomScreen();
					break;
				case GorillaComputer.ComputerState.Queue:
					this.QueueScreen();
					break;
				case GorillaComputer.ComputerState.Group:
					this.GroupScreen();
					break;
				case GorillaComputer.ComputerState.Voice:
					this.VoiceScreen();
					break;
				case GorillaComputer.ComputerState.AutoMute:
					this.AutomuteScreen();
					break;
				case GorillaComputer.ComputerState.Credits:
					this.CreditsScreen();
					break;
				case GorillaComputer.ComputerState.Visuals:
					this.VisualsScreen();
					break;
				case GorillaComputer.ComputerState.Time:
					this.TimeScreen();
					break;
				case GorillaComputer.ComputerState.NameWarning:
					this.NameWarningScreen();
					break;
				case GorillaComputer.ComputerState.Loading:
					this.LoadingScreen();
					break;
				case GorillaComputer.ComputerState.Support:
					this.SupportScreen();
					break;
				}
			}
			this.UpdateGameModeText();
		}

		// Token: 0x060028B7 RID: 10423 RVA: 0x000C8979 File Offset: 0x000C6B79
		private void LoadingScreen()
		{
			this.screenText.Text = "LOADING";
			this.LoadingRoutine = base.StartCoroutine(this.<LoadingScreen>g__LoadingScreenLocal|150_0());
		}

		// Token: 0x060028B8 RID: 10424 RVA: 0x000C89A0 File Offset: 0x000C6BA0
		private void NameWarningScreen()
		{
			this.screenText.Text = "<color=red>WARNING: PLEASE CHOOSE A BETTER NAME\n\nENTERING ANOTHER BAD NAME WILL RESULT IN A BAN</color>";
			if (this.warningConfirmationInputString.ToLower() == "yes")
			{
				GorillaText gorillaText = this.screenText;
				gorillaText.Text += "\n\nPRESS ANY KEY TO CONTINUE";
				return;
			}
			GorillaText gorillaText2 = this.screenText;
			gorillaText2.Text = gorillaText2.Text + "\n\nTYPE 'YES' TO CONFIRM: " + this.warningConfirmationInputString;
		}

		// Token: 0x060028B9 RID: 10425 RVA: 0x000C8A14 File Offset: 0x000C6C14
		private void SupportScreen()
		{
			if (this.displaySupport)
			{
				string text = "STEAM";
				this.screenText.Text = string.Concat(new string[]
				{
					"SUPPORT\n\nPLAYERID   ",
					PlayFabAuthenticator.instance._playFabPlayerIdCache,
					"\nVERSION    ",
					this.version.ToUpper(),
					"\nPLATFORM   ",
					text,
					"\nBUILD DATE ",
					this.buildDate,
					"\n"
				});
				return;
			}
			this.screenText.Text = "SUPPORT\n\n";
			GorillaText gorillaText = this.screenText;
			gorillaText.Text += "PRESS ENTER TO DISPLAY SUPPORT AND ACCOUNT INFORMATION\n\n\n\n";
			GorillaText gorillaText2 = this.screenText;
			gorillaText2.Text += "<color=red>DO NOT SHARE ACCOUNT INFORMATION WITH ANYONE OTHER ";
			GorillaText gorillaText3 = this.screenText;
			gorillaText3.Text += "THAN ANOTHER AXIOM SUPPORT</color>";
		}

		// Token: 0x060028BA RID: 10426 RVA: 0x000C8B00 File Offset: 0x000C6D00
		private void TimeScreen()
		{
			this.screenText.Text = string.Concat(new string[]
			{
				"UPDATE TIME SETTINGS. (LOCALLY ONLY). \nPRESS OPTION 1 FOR NORMAL MODE. \nPRESS OPTION 2 FOR STATIC MODE. \nPRESS 1-10 TO CHANGE TIME OF DAY. \nCURRENT MODE: ",
				BetterDayNightManager.instance.currentSetting.ToString().ToUpper(),
				". \nTIME OF DAY: ",
				BetterDayNightManager.instance.currentTimeOfDay.ToUpper(),
				". \n"
			});
		}

		// Token: 0x060028BB RID: 10427 RVA: 0x000C8B6E File Offset: 0x000C6D6E
		private void CreditsScreen()
		{
			this.screenText.Text = this.creditsView.GetScreenText();
		}

		// Token: 0x060028BC RID: 10428 RVA: 0x000C8B88 File Offset: 0x000C6D88
		private void VisualsScreen()
		{
			this.screenText.Text = "UPDATE ITEMS SETTINGS. PRESS OPTION 1 TO ENABLE ITEM PARTICLES. PRESS OPTION 2 TO DISABLE ITEM PARTICLES. PRESS 1-10 TO CHANGE INSTRUMENT VOLUME FOR OTHER PLAYERS.\n\nITEM PARTICLES ON: " + (this.disableParticles ? "FALSE" : "TRUE") + "\nINSTRUMENT VOLUME: " + Mathf.CeilToInt(this.instrumentVolume * 50f).ToString();
		}

		// Token: 0x060028BD RID: 10429 RVA: 0x000C8BDC File Offset: 0x000C6DDC
		private void VoiceScreen()
		{
			this.screenText.Text = "CHOOSE WHICH TYPE OF VOICE YOU WANT TO HEAR AND SPEAK. \nPRESS OPTION 1 = HUMAN VOICES. \nPRESS OPTION 2 = MONKE VOICES. \n\nVOICE TYPE: " + ((this.voiceChatOn == "TRUE") ? "HUMAN" : ((this.voiceChatOn == "FALSE") ? "MONKE" : "OFF"));
		}

		// Token: 0x060028BE RID: 10430 RVA: 0x000C8C35 File Offset: 0x000C6E35
		private void AutomuteScreen()
		{
			this.screenText.Text = "AUTOMOD AUTOMATICALLY MUTES PLAYERS WHEN THEY JOIN YOUR ROOM IF A LOT OF OTHER PLAYERS HAVE MUTED THEM\nPRESS OPTION 1 FOR AGGRESSIVE MUTING\nPRESS OPTION 2 FOR MODERATE MUTING\nPRESS OPTION 3 TO TURN AUTOMOD OFF\n\nCURRENT AUTOMOD LEVEL: " + this.autoMuteType;
		}

		// Token: 0x060028BF RID: 10431 RVA: 0x000C8C54 File Offset: 0x000C6E54
		private void GroupScreen()
		{
			string str = (this.allowedMapsToJoin.Length > 1) ? this.groupMapJoin : this.allowedMapsToJoin[0].ToUpper();
			string str2 = (this.allowedMapsToJoin.Length > 1) ? "\n\nUSE NUMBER KEYS TO SELECT DESTINATION\n1: FOREST, 2: CAVE, 3: CANYON, 4: CITY, 5: CLOUDS." : "";
			if (FriendshipGroupDetection.Instance.IsInParty)
			{
				string str3 = this.GetSelectedMapJoinTrigger().CanPartyJoin() ? "" : "\n\n<color=red>CANNOT JOIN BECAUSE YOUR GROUP IS NOT HERE</color>";
				this.screenText.Text = "PRESS ENTER TO JOIN A PUBLIC GAME WITH YOUR FRIENDSHIP GROUP.\n\nACTIVE ZONE WILL BE: " + str + str2 + str3;
				return;
			}
			this.screenText.Text = "PRESS ENTER TO JOIN A PUBLIC GAME AND BRING EVERYONE IN THIS ROOM WITH YOU.\n\nACTIVE ZONE WILL BE: " + str + str2;
		}

		// Token: 0x060028C0 RID: 10432 RVA: 0x000C8CF0 File Offset: 0x000C6EF0
		private void MicScreen()
		{
			this.screenText.Text = "PRESS OPTION 1 = ALL CHAT.\nPRESS OPTION 2 = PUSH TO TALK.\nPRESS OPTION 3 = PUSH TO MUTE.\n\nCURRENT MIC SETTING: " + this.pttType + "\n\nPUSH TO TALK AND PUSH TO MUTE WORK WITH ANY FACE BUTTON";
		}

		// Token: 0x060028C1 RID: 10433 RVA: 0x000C8D14 File Offset: 0x000C6F14
		private void QueueScreen()
		{
			if (this.allowedInCompetitive)
			{
				this.screenText.Text = "THIS OPTION AFFECTS WHO YOU PLAY WITH. DEFAULT IS FOR ANYONE TO PLAY NORMALLY. MINIGAMES IS FOR PEOPLE LOOKING TO PLAY WITH THEIR OWN MADE UP RULES.COMPETITIVE IS FOR PLAYERS WHO WANT TO PLAY THE GAME AND TRY AS HARD AS THEY CAN. PRESS OPTION 1 FOR DEFAULT, OPTION 2 FOR MINIGAMES, OR OPTION 3 FOR COMPETITIVE.\n\nCURRENT QUEUE: " + this.currentQueue;
				return;
			}
			this.screenText.Text = "THIS OPTION AFFECTS WHO YOU PLAY WITH. DEFAULT IS FOR ANYONE TO PLAY NORMALLY. MINIGAMES IS FOR PEOPLE LOOKING TO PLAY WITH THEIR OWN MADE UP RULES.BEAT THE OBSTACLE COURSE IN CITY TO ALLOW COMPETITIVE PLAY. PRESS OPTION 1 FOR DEFAULT, OR OPTION 2 FOR MINIGAMES\n\nCURRENT QUEUE: " + this.currentQueue;
		}

		// Token: 0x060028C2 RID: 10434 RVA: 0x000C8D60 File Offset: 0x000C6F60
		private void TurnScreen()
		{
			this.screenText.Text = "PRESS OPTION 1 TO USE SNAP TURN. PRESS OPTION 2 TO USE SMOOTH TURN. PRESS OPTION 3 TO USE NO ARTIFICIAL TURNING. PRESS THE NUMBER KEYS TO CHOOSE A TURNING SPEED.\n CURRENT TURN TYPE: " + this.turnType + "\nCURRENT TURN SPEED: " + this.turnValue.ToString();
		}

		// Token: 0x060028C3 RID: 10435 RVA: 0x000C8D8D File Offset: 0x000C6F8D
		private void NameScreen()
		{
			this.screenText.Text = "PRESS ENTER TO CHANGE YOUR NAME TO THE ENTERED NEW NAME.\n\nCURRENT NAME: " + this.savedName;
			GorillaText gorillaText = this.screenText;
			gorillaText.Text = gorillaText.Text + "\n\n    NEW NAME: " + this.currentName;
		}

		// Token: 0x060028C4 RID: 10436 RVA: 0x000C8DCC File Offset: 0x000C6FCC
		private void StartupScreen()
		{
			string text = string.Empty;
			if (PlayFabAuthenticator.instance.GetSafety())
			{
				text = "YOU ARE PLAYING ON A MANAGED ACCOUNT\nSOME SETTINGS ARE DISABLED\n\n";
			}
			this.screenText.Text = string.Concat(new string[]
			{
				"GORILLA OS\n\n",
				text,
				NetworkSystem.Instance.GlobalPlayerCount().ToString(),
				" PLAYERS ONLINE\n\n",
				this.usersBanned.ToString(),
				" USERS BANNED YESTERDAY\n\nPRESS ANY KEY TO BEGIN"
			});
		}

		// Token: 0x060028C5 RID: 10437 RVA: 0x000C8E48 File Offset: 0x000C7048
		private void ColourScreen()
		{
			this.screenText.Text = "USE THE OPTIONS BUTTONS TO SELECT THE COLOR TO UPDATE, THEN PRESS 0-9 TO SET A NEW VALUE.";
			GorillaText gorillaText = this.screenText;
			gorillaText.Text = gorillaText.Text + "\n\n  RED: " + Mathf.FloorToInt(this.redValue * 9f).ToString() + ((this.colorCursorLine == 0) ? "<--" : "");
			GorillaText gorillaText2 = this.screenText;
			gorillaText2.Text = gorillaText2.Text + "\n\nGREEN: " + Mathf.FloorToInt(this.greenValue * 9f).ToString() + ((this.colorCursorLine == 1) ? "<--" : "");
			GorillaText gorillaText3 = this.screenText;
			gorillaText3.Text = gorillaText3.Text + "\n\n BLUE: " + Mathf.FloorToInt(this.blueValue * 9f).ToString() + ((this.colorCursorLine == 2) ? "<--" : "");
		}

		// Token: 0x060028C6 RID: 10438 RVA: 0x000C8F40 File Offset: 0x000C7140
		private void RoomScreen()
		{
			bool safety = PlayFabAuthenticator.instance.GetSafety();
			this.screenText.Text = "";
			if (!safety)
			{
				GorillaText gorillaText = this.screenText;
				gorillaText.Text += "PRESS ENTER TO JOIN OR CREATE A CUSTOM ROOM WITH THE ENTERED CODE. ";
			}
			GorillaText gorillaText2 = this.screenText;
			gorillaText2.Text += "PRESS OPTION 1 TO DISCONNECT FROM THE CURRENT ROOM. ";
			if (FriendshipGroupDetection.Instance.IsInParty)
			{
				if (FriendshipGroupDetection.Instance.IsPartyWithinCollider(this.friendJoinCollider))
				{
					GorillaText gorillaText3 = this.screenText;
					gorillaText3.Text += "YOUR GROUP WILL TRAVEL WITH YOU. ";
				}
				else
				{
					GorillaText gorillaText4 = this.screenText;
					gorillaText4.Text += "<color=red>YOU WILL LEAVE YOUR PARTY UNLESS YOU GATHER THEM HERE FIRST!</color> ";
				}
			}
			GorillaText gorillaText5 = this.screenText;
			gorillaText5.Text += "\n\nCURRENT ROOM: ";
			if (NetworkSystem.Instance.InRoom)
			{
				GorillaText gorillaText6 = this.screenText;
				gorillaText6.Text += NetworkSystem.Instance.RoomName;
				GorillaText gorillaText7 = this.screenText;
				gorillaText7.Text = gorillaText7.Text + "\n\nPLAYERS IN ROOM: " + NetworkSystem.Instance.RoomPlayerCount.ToString();
			}
			else
			{
				GorillaText gorillaText8 = this.screenText;
				gorillaText8.Text += "-NOT IN ROOM-";
				GorillaText gorillaText9 = this.screenText;
				gorillaText9.Text = gorillaText9.Text + "\n\nPLAYERS ONLINE: " + NetworkSystem.Instance.GlobalPlayerCount().ToString();
			}
			if (!safety)
			{
				GorillaText gorillaText10 = this.screenText;
				gorillaText10.Text = gorillaText10.Text + "\n\nROOM TO JOIN: " + this.roomToJoin;
				if (this.roomFull)
				{
					GorillaText gorillaText11 = this.screenText;
					gorillaText11.Text += "\n\nROOM FULL. JOIN ROOM FAILED.";
					return;
				}
				if (this.roomNotAllowed)
				{
					GorillaText gorillaText12 = this.screenText;
					gorillaText12.Text += "\n\nCANNOT JOIN ROOM TYPE FROM HERE.";
				}
			}
		}

		// Token: 0x060028C7 RID: 10439 RVA: 0x000C9120 File Offset: 0x000C7320
		private void UpdateGameModeText()
		{
			if (NetworkSystem.Instance.InRoom)
			{
				if (GorillaGameManager.instance != null)
				{
					this.currentGameModeText.Value = "CURRENT MODE\n" + GorillaGameManager.instance.GameModeName();
					return;
				}
				this.currentGameModeText.Value = "CURRENT MODE\n-NOT IN ROOM-";
			}
		}

		// Token: 0x060028C8 RID: 10440 RVA: 0x000C9176 File Offset: 0x000C7376
		private void UpdateFunctionScreen()
		{
			this.functionSelectText.Text = this.GetOrderListForScreen(this.currentState);
		}

		// Token: 0x060028C9 RID: 10441 RVA: 0x000C918F File Offset: 0x000C738F
		private void CheckAutoBanListForRoomName(string nameToCheck)
		{
			this.SwitchToLoadingState();
			this.AutoBanPlayfabFunction(nameToCheck, true, new Action<ExecuteFunctionResult>(this.OnRoomNameChecked));
		}

		// Token: 0x060028CA RID: 10442 RVA: 0x000C91AB File Offset: 0x000C73AB
		private void CheckAutoBanListForPlayerName(string nameToCheck)
		{
			this.SwitchToLoadingState();
			this.AutoBanPlayfabFunction(nameToCheck, false, new Action<ExecuteFunctionResult>(this.OnPlayerNameChecked));
		}

		// Token: 0x060028CB RID: 10443 RVA: 0x000C91C7 File Offset: 0x000C73C7
		private void AutoBanPlayfabFunction(string nameToCheck, bool forRoom, Action<ExecuteFunctionResult> resultCallback)
		{
			GorillaServer.Instance.CheckForBadName(new CheckForBadNameRequest
			{
				name = nameToCheck,
				forRoom = forRoom
			}, resultCallback, new Action<PlayFabError>(this.OnErrorNameCheck));
		}

		// Token: 0x060028CC RID: 10444 RVA: 0x000C91F8 File Offset: 0x000C73F8
		private void OnRoomNameChecked(ExecuteFunctionResult result)
		{
			object obj;
			if (((JsonObject)result.FunctionResult).TryGetValue("result", out obj))
			{
				switch (int.Parse(obj.ToString()))
				{
				case 0:
					if (FriendshipGroupDetection.Instance.IsInParty && !FriendshipGroupDetection.Instance.IsPartyWithinCollider(this.friendJoinCollider))
					{
						FriendshipGroupDetection.Instance.LeaveParty();
					}
					this.networkController.AttemptToJoinSpecificRoom(this.roomToJoin, FriendshipGroupDetection.Instance.IsInParty ? JoinType.JoinWithParty : JoinType.Solo);
					break;
				case 1:
					this.roomToJoin = "";
					this.SwitchToWarningState();
					break;
				case 2:
					this.roomToJoin = "";
					GorillaGameManager.ForceStopGame_DisconnectAndDestroy();
					break;
				}
			}
			if (this.currentState == GorillaComputer.ComputerState.Loading)
			{
				this.PopState();
			}
		}

		// Token: 0x060028CD RID: 10445 RVA: 0x000C92C0 File Offset: 0x000C74C0
		private void OnPlayerNameChecked(ExecuteFunctionResult result)
		{
			object obj;
			if (((JsonObject)result.FunctionResult).TryGetValue("result", out obj))
			{
				switch (int.Parse(obj.ToString()))
				{
				case 0:
					NetworkSystem.Instance.SetMyNickName(this.currentName);
					break;
				case 1:
					NetworkSystem.Instance.SetMyNickName("gorilla");
					this.currentName = "gorilla";
					this.SwitchToWarningState();
					break;
				case 2:
					NetworkSystem.Instance.SetMyNickName("gorilla");
					this.currentName = "gorilla";
					GorillaGameManager.ForceStopGame_DisconnectAndDestroy();
					break;
				}
			}
			this.offlineVRRigNametagText.text = this.currentName;
			this.savedName = this.currentName;
			PlayerPrefs.SetString("playerName", this.currentName);
			PlayerPrefs.Save();
			if (NetworkSystem.Instance.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
				{
					this.redValue,
					this.greenValue,
					this.blueValue
				});
			}
			if (this.currentState == GorillaComputer.ComputerState.Loading)
			{
				this.PopState();
			}
		}

		// Token: 0x060028CE RID: 10446 RVA: 0x000C93EC File Offset: 0x000C75EC
		private void OnErrorNameCheck(PlayFabError error)
		{
			if (this.currentState == GorillaComputer.ComputerState.Loading)
			{
				this.PopState();
			}
			GorillaComputer.OnErrorShared(error);
		}

		// Token: 0x060028CF RID: 10447 RVA: 0x000C9404 File Offset: 0x000C7604
		public bool CheckAutoBanListForName(string nameToCheck)
		{
			nameToCheck = nameToCheck.ToLower();
			nameToCheck = new string(Array.FindAll<char>(nameToCheck.ToCharArray(), (char c) => char.IsLetterOrDigit(c)));
			foreach (string value in this.anywhereTwoWeek)
			{
				if (nameToCheck.IndexOf(value) >= 0)
				{
					return false;
				}
			}
			foreach (string value2 in this.anywhereOneWeek)
			{
				if (nameToCheck.IndexOf(value2) >= 0 && !nameToCheck.Contains("fagol"))
				{
					return false;
				}
			}
			string[] array = this.exactOneWeek;
			for (int i = 0; i < array.Length; i++)
			{
				if (array[i] == nameToCheck)
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x060028D0 RID: 10448 RVA: 0x000C94C4 File Offset: 0x000C76C4
		public void UpdateFailureText(string failMessage)
		{
			GorillaScoreboardTotalUpdater.instance.SetOfflineFailureText(failMessage);
			PhotonNetworkController.Instance.UpdateTriggerScreens();
			this.screenText.EnableFailedState(failMessage);
			this.functionSelectText.EnableFailedState(failMessage);
		}

		// Token: 0x060028D1 RID: 10449 RVA: 0x000C94F5 File Offset: 0x000C76F5
		private void RestoreFromFailureState()
		{
			GorillaScoreboardTotalUpdater.instance.ClearOfflineFailureText();
			PhotonNetworkController.Instance.UpdateTriggerScreens();
			this.screenText.DisableFailedState();
			this.functionSelectText.DisableFailedState();
		}

		// Token: 0x060028D2 RID: 10450 RVA: 0x000C9523 File Offset: 0x000C7723
		public void GeneralFailureMessage(string failMessage)
		{
			this.isConnectedToMaster = false;
			NetworkSystem.Instance.SetWrongVersion();
			this.UpdateFailureText(failMessage);
			this.UpdateScreen();
		}

		// Token: 0x060028D3 RID: 10451 RVA: 0x000C9544 File Offset: 0x000C7744
		private static void OnErrorShared(PlayFabError error)
		{
			if (error.Error == PlayFabErrorCode.NotAuthenticated)
			{
				PlayFabAuthenticator.instance.AuthenticateWithPlayFab();
			}
			else if (error.Error == PlayFabErrorCode.AccountBanned)
			{
				GorillaGameManager.ForceStopGame_DisconnectAndDestroy();
			}
			if (error.ErrorMessage == "The account making this request is currently banned")
			{
				using (Dictionary<string, List<string>>.Enumerator enumerator = error.ErrorDetails.GetEnumerator())
				{
					if (!enumerator.MoveNext())
					{
						return;
					}
					KeyValuePair<string, List<string>> keyValuePair = enumerator.Current;
					if (keyValuePair.Value[0] != "Indefinite")
					{
						GorillaComputer.instance.GeneralFailureMessage(string.Concat(new string[]
						{
							"YOUR ACCOUNT ",
							PlayFabAuthenticator.instance._playFabPlayerIdCache,
							" HAS BEEN BANNED. YOU WILL NOT BE ABLE TO PLAY UNTIL THE BAN EXPIRES.\nREASON: ",
							keyValuePair.Key,
							"\nHOURS LEFT: ",
							((int)((DateTime.Parse(keyValuePair.Value[0]) - DateTime.UtcNow).TotalHours + 1.0)).ToString()
						}));
						return;
					}
					GorillaComputer.instance.GeneralFailureMessage("YOUR ACCOUNT " + PlayFabAuthenticator.instance._playFabPlayerIdCache + " HAS BEEN BANNED INDEFINITELY.\nREASON: " + keyValuePair.Key);
					return;
				}
			}
			if (error.ErrorMessage == "The IP making this request is currently banned")
			{
				using (Dictionary<string, List<string>>.Enumerator enumerator = error.ErrorDetails.GetEnumerator())
				{
					if (enumerator.MoveNext())
					{
						KeyValuePair<string, List<string>> keyValuePair2 = enumerator.Current;
						if (keyValuePair2.Value[0] != "Indefinite")
						{
							GorillaComputer.instance.GeneralFailureMessage("THIS IP HAS BEEN BANNED. YOU WILL NOT BE ABLE TO PLAY UNTIL THE BAN EXPIRES.\nREASON: " + keyValuePair2.Key + "\nHOURS LEFT: " + ((int)((DateTime.Parse(keyValuePair2.Value[0]) - DateTime.UtcNow).TotalHours + 1.0)).ToString());
						}
						else
						{
							GorillaComputer.instance.GeneralFailureMessage("THIS IP HAS BEEN BANNED INDEFINITELY.\nREASON: " + keyValuePair2.Key);
						}
					}
				}
			}
		}

		// Token: 0x060028D4 RID: 10452 RVA: 0x000C979C File Offset: 0x000C799C
		private void DecreaseState()
		{
			this.currentStateIndex--;
			if (this.GetState(this.currentStateIndex) == GorillaComputer.ComputerState.Time)
			{
				this.currentStateIndex--;
			}
			if (this.currentStateIndex < 0)
			{
				this.currentStateIndex = this.FunctionsCount - 1;
			}
			this.SwitchState(this.GetState(this.currentStateIndex), true);
		}

		// Token: 0x060028D5 RID: 10453 RVA: 0x000C9800 File Offset: 0x000C7A00
		private void IncreaseState()
		{
			this.currentStateIndex++;
			if (this.GetState(this.currentStateIndex) == GorillaComputer.ComputerState.Time)
			{
				this.currentStateIndex++;
			}
			if (this.currentStateIndex >= this.FunctionsCount)
			{
				this.currentStateIndex = 0;
			}
			this.SwitchState(this.GetState(this.currentStateIndex), true);
		}

		// Token: 0x060028D6 RID: 10454 RVA: 0x000C9864 File Offset: 0x000C7A64
		public GorillaComputer.ComputerState GetState(int index)
		{
			GorillaComputer.ComputerState state;
			try
			{
				state = this.OrderList[index].State;
			}
			catch
			{
				state = this.OrderList[0].State;
			}
			return state;
		}

		// Token: 0x060028D7 RID: 10455 RVA: 0x000C98AC File Offset: 0x000C7AAC
		public int GetStateIndex(GorillaComputer.ComputerState state)
		{
			return this.OrderList.FindIndex((GorillaComputer.StateOrderItem s) => s.State == state);
		}

		// Token: 0x060028D8 RID: 10456 RVA: 0x000C98E0 File Offset: 0x000C7AE0
		public string GetOrderListForScreen(GorillaComputer.ComputerState currentState)
		{
			StringBuilder stringBuilder = new StringBuilder();
			int stateIndex = this.GetStateIndex(currentState);
			for (int i = 0; i < this.FunctionsCount; i++)
			{
				stringBuilder.Append(this.FunctionNames[i]);
				if (i == stateIndex)
				{
					stringBuilder.Append(this.Pointer);
				}
				if (i < this.FunctionsCount - 1)
				{
					stringBuilder.Append("\n");
				}
			}
			return stringBuilder.ToString();
		}

		// Token: 0x060028D9 RID: 10457 RVA: 0x000C994D File Offset: 0x000C7B4D
		private void GetCurrentTime()
		{
			this.tryGetTimeAgain = true;
			PlayFabClientAPI.GetTime(new GetTimeRequest(), new Action<GetTimeResult>(this.OnGetTimeSuccess), new Action<PlayFabError>(this.OnGetTimeFailure), null, null);
		}

		// Token: 0x060028DA RID: 10458 RVA: 0x000C997C File Offset: 0x000C7B7C
		private void OnGetTimeSuccess(GetTimeResult result)
		{
			this.startupMillis = (long)(TimeSpan.FromTicks(result.Time.Ticks).TotalMilliseconds - (double)(Time.realtimeSinceStartup * 1000f));
			this.startupTime = result.Time - TimeSpan.FromSeconds((double)Time.realtimeSinceStartup);
			Action onServerTimeUpdated = this.OnServerTimeUpdated;
			if (onServerTimeUpdated == null)
			{
				return;
			}
			onServerTimeUpdated();
		}

		// Token: 0x060028DB RID: 10459 RVA: 0x000C99E4 File Offset: 0x000C7BE4
		private void OnGetTimeFailure(PlayFabError error)
		{
			this.startupMillis = (long)(TimeSpan.FromTicks(DateTime.UtcNow.Ticks).TotalMilliseconds - (double)(Time.realtimeSinceStartup * 1000f));
			this.startupTime = DateTime.UtcNow - TimeSpan.FromSeconds((double)Time.realtimeSinceStartup);
			Action onServerTimeUpdated = this.OnServerTimeUpdated;
			if (onServerTimeUpdated != null)
			{
				onServerTimeUpdated();
			}
			if (error.Error == PlayFabErrorCode.NotAuthenticated)
			{
				PlayFabAuthenticator.instance.AuthenticateWithPlayFab();
				return;
			}
			if (error.Error == PlayFabErrorCode.AccountBanned)
			{
				GorillaGameManager.ForceStopGame_DisconnectAndDestroy();
			}
		}

		// Token: 0x060028DC RID: 10460 RVA: 0x000C9A77 File Offset: 0x000C7C77
		private void PlayerCountChangedCallback(int playerID)
		{
			this.UpdateScreen();
		}

		// Token: 0x060028DD RID: 10461 RVA: 0x000C9A80 File Offset: 0x000C7C80
		public void SetNameBySafety(bool isSafety)
		{
			if (!isSafety)
			{
				return;
			}
			PlayerPrefs.SetString("playerNameBackup", this.currentName);
			this.currentName = "gorilla" + Random.Range(0, 9999).ToString().PadLeft(4, '0');
			this.savedName = this.currentName;
			NetworkSystem.Instance.SetMyNickName(this.currentName);
			this.offlineVRRigNametagText.text = this.currentName;
			PlayerPrefs.SetString("playerName", this.currentName);
			PlayerPrefs.Save();
			if (PhotonNetwork.InRoom)
			{
				GorillaTagger.Instance.myVRRig.RPC("InitializeNoobMaterial", RpcTarget.All, new object[]
				{
					this.redValue,
					this.greenValue,
					this.blueValue,
					this.leftHanded
				});
			}
		}

		// Token: 0x060028DE RID: 10462 RVA: 0x000C9B68 File Offset: 0x000C7D68
		public void SetComputerSettingsBySafety(bool isSafety)
		{
			if (!isSafety)
			{
				return;
			}
			int i = 0;
			int num = this.OrderList.Count;
			while (i < num)
			{
				if (this.OrderList[i].State == GorillaComputer.ComputerState.Name || this.OrderList[i].State == GorillaComputer.ComputerState.Group || this.OrderList[i].State == GorillaComputer.ComputerState.Voice || this.OrderList[i].State == GorillaComputer.ComputerState.AutoMute)
				{
					this.OrderList.RemoveAt(i);
					i--;
					num--;
					this.FunctionsCount--;
				}
				i++;
			}
			this.FunctionNames.Clear();
			this.OrderList.ForEach(delegate(GorillaComputer.StateOrderItem s)
			{
				string name = s.GetName();
				if (name.Length > this.highestCharacterCount)
				{
					this.highestCharacterCount = name.Length;
				}
				this.FunctionNames.Add(name);
			});
			for (int j = 0; j < this.FunctionsCount; j++)
			{
				int num2 = this.highestCharacterCount - this.FunctionNames[j].Length;
				for (int k = 0; k < num2; k++)
				{
					List<string> functionNames = this.FunctionNames;
					int index = j;
					functionNames[index] += " ";
				}
			}
			this.UpdateScreen();
			this.voiceChatOn = "FALSE";
			PlayerPrefs.SetString("voiceChatOn", this.voiceChatOn);
			PlayerPrefs.Save();
			RigContainer.RefreshAllRigVoices();
		}

		// Token: 0x060028DF RID: 10463 RVA: 0x00003051 File Offset: 0x00001251
		void IMatchmakingCallbacks.OnFriendListUpdate(List<Photon.Realtime.FriendInfo> friendList)
		{
		}

		// Token: 0x060028E0 RID: 10464 RVA: 0x00003051 File Offset: 0x00001251
		void IMatchmakingCallbacks.OnCreatedRoom()
		{
		}

		// Token: 0x060028E1 RID: 10465 RVA: 0x00003051 File Offset: 0x00001251
		void IMatchmakingCallbacks.OnCreateRoomFailed(short returnCode, string message)
		{
		}

		// Token: 0x060028E2 RID: 10466 RVA: 0x00003051 File Offset: 0x00001251
		void IMatchmakingCallbacks.OnJoinedRoom()
		{
		}

		// Token: 0x060028E3 RID: 10467 RVA: 0x00003051 File Offset: 0x00001251
		void IMatchmakingCallbacks.OnJoinRandomFailed(short returnCode, string message)
		{
		}

		// Token: 0x060028E4 RID: 10468 RVA: 0x00003051 File Offset: 0x00001251
		void IMatchmakingCallbacks.OnLeftRoom()
		{
		}

		// Token: 0x060028E5 RID: 10469 RVA: 0x00003051 File Offset: 0x00001251
		void IMatchmakingCallbacks.OnPreLeavingRoom()
		{
		}

		// Token: 0x060028E6 RID: 10470 RVA: 0x000C9CB2 File Offset: 0x000C7EB2
		void IMatchmakingCallbacks.OnJoinRoomFailed(short returnCode, string message)
		{
			if (returnCode == 32765)
			{
				this.roomFull = true;
			}
		}

		// Token: 0x060028E8 RID: 10472 RVA: 0x000C9DDD File Offset: 0x000C7FDD
		[CompilerGenerated]
		private IEnumerator <Start>g__Start_Local|98_0()
		{
			yield return null;
			if (BacktraceClient.Instance)
			{
				int num = this.includeUpdatedServerSynchTest;
			}
			if (BacktraceClient.Instance && BacktraceClient.Instance.gameObject)
			{
				Object.Destroy(BacktraceClient.Instance.gameObject);
			}
			yield break;
		}

		// Token: 0x060028E9 RID: 10473 RVA: 0x000C9DEC File Offset: 0x000C7FEC
		[CompilerGenerated]
		private IEnumerator <LoadingScreen>g__LoadingScreenLocal|150_0()
		{
			int dotsCount = 0;
			while (this.currentState == GorillaComputer.ComputerState.Loading)
			{
				int num = dotsCount;
				dotsCount = num + 1;
				if (dotsCount == 3)
				{
					dotsCount = 0;
				}
				this.screenText.Text = "LOADING";
				for (int i = 0; i < dotsCount; i++)
				{
					GorillaText gorillaText = this.screenText;
					gorillaText.Text += ". ";
				}
				yield return this.waitOneSecond;
			}
			yield break;
		}

		// Token: 0x04002B59 RID: 11097
		[OnEnterPlay_SetNull]
		public static volatile GorillaComputer instance;

		// Token: 0x04002B5A RID: 11098
		[OnEnterPlay_Set(false)]
		public static bool hasInstance;

		// Token: 0x04002B5B RID: 11099
		public bool tryGetTimeAgain;

		// Token: 0x04002B5C RID: 11100
		public Material unpressedMaterial;

		// Token: 0x04002B5D RID: 11101
		public Material pressedMaterial;

		// Token: 0x04002B5E RID: 11102
		public string currentTextField;

		// Token: 0x04002B5F RID: 11103
		public float buttonFadeTime;

		// Token: 0x04002B60 RID: 11104
		public string offlineTextInitialString;

		// Token: 0x04002B61 RID: 11105
		public GorillaText screenText;

		// Token: 0x04002B62 RID: 11106
		public GorillaText functionSelectText;

		// Token: 0x04002B63 RID: 11107
		public GorillaText wallScreenText;

		// Token: 0x04002B64 RID: 11108
		public Text offlineVRRigNametagText;

		// Token: 0x04002B65 RID: 11109
		public string versionMismatch = "PLEASE UPDATE TO THE LATEST VERSION OF GORILLA TAG. YOU'RE ON AN OLD VERSION. FEEL FREE TO RUN AROUND, BUT YOU WON'T BE ABLE TO PLAY WITH ANYONE ELSE.";

		// Token: 0x04002B66 RID: 11110
		public string unableToConnect = "UNABLE TO CONNECT TO THE INTERNET. PLEASE CHECK YOUR CONNECTION AND RESTART THE GAME.";

		// Token: 0x04002B67 RID: 11111
		public Material wrongVersionMaterial;

		// Token: 0x04002B68 RID: 11112
		public MeshRenderer wallScreenRenderer;

		// Token: 0x04002B69 RID: 11113
		public MeshRenderer computerScreenRenderer;

		// Token: 0x04002B6A RID: 11114
		public long startupMillis;

		// Token: 0x04002B6B RID: 11115
		public DateTime startupTime;

		// Token: 0x04002B6C RID: 11116
		public WatchableStringSO currentGameMode;

		// Token: 0x04002B6D RID: 11117
		public WatchableStringSO currentGameModeText;

		// Token: 0x04002B6E RID: 11118
		public int includeUpdatedServerSynchTest;

		// Token: 0x04002B6F RID: 11119
		public PhotonNetworkController networkController;

		// Token: 0x04002B70 RID: 11120
		public float updateCooldown = 1f;

		// Token: 0x04002B71 RID: 11121
		public float lastUpdateTime;

		// Token: 0x04002B72 RID: 11122
		public bool isConnectedToMaster;

		// Token: 0x04002B73 RID: 11123
		public bool internetFailure;

		// Token: 0x04002B74 RID: 11124
		public string[] allowedMapsToJoin;

		// Token: 0x04002B75 RID: 11125
		[Header("State vars")]
		public bool stateUpdated;

		// Token: 0x04002B76 RID: 11126
		public bool screenChanged;

		// Token: 0x04002B77 RID: 11127
		public bool initialized;

		// Token: 0x04002B78 RID: 11128
		public List<GorillaComputer.StateOrderItem> OrderList = new List<GorillaComputer.StateOrderItem>
		{
			new GorillaComputer.StateOrderItem(GorillaComputer.ComputerState.Room),
			new GorillaComputer.StateOrderItem(GorillaComputer.ComputerState.Name),
			new GorillaComputer.StateOrderItem(GorillaComputer.ComputerState.Color),
			new GorillaComputer.StateOrderItem(GorillaComputer.ComputerState.Turn),
			new GorillaComputer.StateOrderItem(GorillaComputer.ComputerState.Mic),
			new GorillaComputer.StateOrderItem(GorillaComputer.ComputerState.Queue),
			new GorillaComputer.StateOrderItem(GorillaComputer.ComputerState.Group),
			new GorillaComputer.StateOrderItem(GorillaComputer.ComputerState.Voice),
			new GorillaComputer.StateOrderItem(GorillaComputer.ComputerState.AutoMute, "Automod"),
			new GorillaComputer.StateOrderItem(GorillaComputer.ComputerState.Visuals, "Items"),
			new GorillaComputer.StateOrderItem(GorillaComputer.ComputerState.Credits),
			new GorillaComputer.StateOrderItem(GorillaComputer.ComputerState.Support)
		};

		// Token: 0x04002B79 RID: 11129
		public string Pointer = "<-";

		// Token: 0x04002B7A RID: 11130
		public int highestCharacterCount;

		// Token: 0x04002B7B RID: 11131
		public List<string> FunctionNames = new List<string>();

		// Token: 0x04002B7C RID: 11132
		public int FunctionsCount;

		// Token: 0x04002B7D RID: 11133
		[Header("Room vars")]
		public string roomToJoin;

		// Token: 0x04002B7E RID: 11134
		public bool roomFull;

		// Token: 0x04002B7F RID: 11135
		public bool roomNotAllowed;

		// Token: 0x04002B80 RID: 11136
		[Header("Mic vars")]
		public string pttType;

		// Token: 0x04002B81 RID: 11137
		[Header("Automute vars")]
		public string autoMuteType;

		// Token: 0x04002B82 RID: 11138
		[Header("Queue vars")]
		public string currentQueue;

		// Token: 0x04002B83 RID: 11139
		public bool allowedInCompetitive;

		// Token: 0x04002B84 RID: 11140
		[Header("Group Vars")]
		public string groupMapJoin;

		// Token: 0x04002B85 RID: 11141
		public int groupMapJoinIndex;

		// Token: 0x04002B86 RID: 11142
		public GorillaFriendCollider friendJoinCollider;

		// Token: 0x04002B87 RID: 11143
		[Header("Join Triggers")]
		public GorillaNetworkJoinTrigger caveMapTrigger;

		// Token: 0x04002B88 RID: 11144
		public GorillaNetworkJoinTrigger forestMapTrigger;

		// Token: 0x04002B89 RID: 11145
		public GorillaNetworkJoinTrigger canyonMapTrigger;

		// Token: 0x04002B8A RID: 11146
		public GorillaNetworkJoinTrigger cityMapTrigger;

		// Token: 0x04002B8B RID: 11147
		public GorillaNetworkJoinTrigger mountainMapTrigger;

		// Token: 0x04002B8C RID: 11148
		public GorillaNetworkJoinTrigger skyjungleMapTrigger;

		// Token: 0x04002B8D RID: 11149
		public GorillaNetworkJoinTrigger basementMapTrigger;

		// Token: 0x04002B8E RID: 11150
		public GorillaNetworkJoinTrigger beachMapTrigger;

		// Token: 0x04002B8F RID: 11151
		public GorillaNetworkJoinTrigger rotatingMapTrigger;

		// Token: 0x04002B90 RID: 11152
		public GorillaNetworkJoinTrigger metroMapTrigger;

		// Token: 0x04002B91 RID: 11153
		public string voiceChatOn;

		// Token: 0x04002B92 RID: 11154
		[Header("Mode select vars")]
		public ModeSelectButton[] modeSelectButtons;

		// Token: 0x04002B93 RID: 11155
		public string version;

		// Token: 0x04002B94 RID: 11156
		public string buildDate;

		// Token: 0x04002B95 RID: 11157
		public string buildCode;

		// Token: 0x04002B96 RID: 11158
		[Header("Cosmetics")]
		public bool disableParticles;

		// Token: 0x04002B97 RID: 11159
		public float instrumentVolume;

		// Token: 0x04002B98 RID: 11160
		[Header("Credits")]
		public CreditsView creditsView;

		// Token: 0x04002B99 RID: 11161
		[Header("Handedness")]
		public bool leftHanded;

		// Token: 0x04002B9A RID: 11162
		[Header("Name state vars")]
		public string savedName;

		// Token: 0x04002B9B RID: 11163
		public string currentName;

		// Token: 0x04002B9C RID: 11164
		public TextAsset exactOneWeekFile;

		// Token: 0x04002B9D RID: 11165
		public TextAsset anywhereOneWeekFile;

		// Token: 0x04002B9E RID: 11166
		public TextAsset anywhereTwoWeekFile;

		// Token: 0x04002B9F RID: 11167
		private Stack<GorillaComputer.ComputerState> stateStack = new Stack<GorillaComputer.ComputerState>();

		// Token: 0x04002BA0 RID: 11168
		private GorillaComputer.ComputerState currentComputerState;

		// Token: 0x04002BA1 RID: 11169
		private GorillaComputer.ComputerState previousComputerState;

		// Token: 0x04002BA2 RID: 11170
		private int currentStateIndex;

		// Token: 0x04002BA3 RID: 11171
		private int usersBanned;

		// Token: 0x04002BA4 RID: 11172
		private float redValue;

		// Token: 0x04002BA5 RID: 11173
		private string redText;

		// Token: 0x04002BA6 RID: 11174
		private float blueValue;

		// Token: 0x04002BA7 RID: 11175
		private string blueText;

		// Token: 0x04002BA8 RID: 11176
		private float greenValue;

		// Token: 0x04002BA9 RID: 11177
		private string greenText;

		// Token: 0x04002BAA RID: 11178
		private int colorCursorLine;

		// Token: 0x04002BAB RID: 11179
		private int turnValue;

		// Token: 0x04002BAC RID: 11180
		private string turnType;

		// Token: 0x04002BAD RID: 11181
		private GorillaSnapTurn gorillaTurn;

		// Token: 0x04002BAE RID: 11182
		private string warningConfirmationInputString = string.Empty;

		// Token: 0x04002BAF RID: 11183
		private bool displaySupport;

		// Token: 0x04002BB0 RID: 11184
		private string[] exactOneWeek;

		// Token: 0x04002BB1 RID: 11185
		private string[] anywhereOneWeek;

		// Token: 0x04002BB2 RID: 11186
		private string[] anywhereTwoWeek;

		// Token: 0x04002BB3 RID: 11187
		private WaitForSeconds waitOneSecond = new WaitForSeconds(1f);

		// Token: 0x04002BB4 RID: 11188
		private Coroutine LoadingRoutine;

		// Token: 0x04002BB5 RID: 11189
		public Action OnServerTimeUpdated;

		// Token: 0x020006B6 RID: 1718
		public enum ComputerState
		{
			// Token: 0x04002BB7 RID: 11191
			Startup,
			// Token: 0x04002BB8 RID: 11192
			Color,
			// Token: 0x04002BB9 RID: 11193
			Name,
			// Token: 0x04002BBA RID: 11194
			Turn,
			// Token: 0x04002BBB RID: 11195
			Mic,
			// Token: 0x04002BBC RID: 11196
			Room,
			// Token: 0x04002BBD RID: 11197
			Queue,
			// Token: 0x04002BBE RID: 11198
			Group,
			// Token: 0x04002BBF RID: 11199
			Voice,
			// Token: 0x04002BC0 RID: 11200
			AutoMute,
			// Token: 0x04002BC1 RID: 11201
			Credits,
			// Token: 0x04002BC2 RID: 11202
			Visuals,
			// Token: 0x04002BC3 RID: 11203
			Time,
			// Token: 0x04002BC4 RID: 11204
			NameWarning,
			// Token: 0x04002BC5 RID: 11205
			Loading,
			// Token: 0x04002BC6 RID: 11206
			Support
		}

		// Token: 0x020006B7 RID: 1719
		private enum NameCheckResult
		{
			// Token: 0x04002BC8 RID: 11208
			Success,
			// Token: 0x04002BC9 RID: 11209
			Warning,
			// Token: 0x04002BCA RID: 11210
			Ban
		}

		// Token: 0x020006B8 RID: 1720
		[Serializable]
		public class StateOrderItem
		{
			// Token: 0x060028EB RID: 10475 RVA: 0x000C9E36 File Offset: 0x000C8036
			public StateOrderItem()
			{
			}

			// Token: 0x060028EC RID: 10476 RVA: 0x000C9E49 File Offset: 0x000C8049
			public StateOrderItem(GorillaComputer.ComputerState state)
			{
				this.State = state;
			}

			// Token: 0x060028ED RID: 10477 RVA: 0x000C9E63 File Offset: 0x000C8063
			public StateOrderItem(GorillaComputer.ComputerState state, string overrideName)
			{
				this.State = state;
				this.OverrideName = overrideName;
			}

			// Token: 0x060028EE RID: 10478 RVA: 0x000C9E84 File Offset: 0x000C8084
			public string GetName()
			{
				if (!string.IsNullOrEmpty(this.OverrideName))
				{
					return this.OverrideName.ToUpper();
				}
				return this.State.ToString().ToUpper();
			}

			// Token: 0x04002BCB RID: 11211
			public GorillaComputer.ComputerState State;

			// Token: 0x04002BCC RID: 11212
			[Tooltip("Case not important - ToUpper applied at runtime")]
			public string OverrideName = "";
		}
	}
}
