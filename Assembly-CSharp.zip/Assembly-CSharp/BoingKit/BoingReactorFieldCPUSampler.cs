﻿using System;
using UnityEngine;

namespace BoingKit
{
	// Token: 0x02000816 RID: 2070
	public class BoingReactorFieldCPUSampler : MonoBehaviour
	{
		// Token: 0x06003233 RID: 12851 RVA: 0x000FB292 File Offset: 0x000F9492
		public void OnEnable()
		{
			BoingManager.Register(this);
		}

		// Token: 0x06003234 RID: 12852 RVA: 0x000FB29A File Offset: 0x000F949A
		public void OnDisable()
		{
			BoingManager.Unregister(this);
		}

		// Token: 0x06003235 RID: 12853 RVA: 0x000FB2A4 File Offset: 0x000F94A4
		public void SampleFromField()
		{
			this.m_objPosition = base.transform.position;
			this.m_objRotation = base.transform.rotation;
			if (this.ReactorField == null)
			{
				return;
			}
			BoingReactorField component = this.ReactorField.GetComponent<BoingReactorField>();
			if (component == null)
			{
				return;
			}
			if (component.HardwareMode != BoingReactorField.HardwareModeEnum.CPU)
			{
				return;
			}
			Vector3 a;
			Vector4 v;
			if (!component.SampleCpuGrid(base.transform.position, out a, out v))
			{
				return;
			}
			base.transform.position = this.m_objPosition + a * this.PositionSampleMultiplier;
			base.transform.rotation = QuaternionUtil.Pow(QuaternionUtil.FromVector4(v, true), this.RotationSampleMultiplier) * this.m_objRotation;
		}

		// Token: 0x06003236 RID: 12854 RVA: 0x000FB363 File Offset: 0x000F9563
		public void Restore()
		{
			base.transform.position = this.m_objPosition;
			base.transform.rotation = this.m_objRotation;
		}

		// Token: 0x040034B4 RID: 13492
		public BoingReactorField ReactorField;

		// Token: 0x040034B5 RID: 13493
		[Tooltip("Match this mode with how you update your object's transform.\n\nUpdate - Use this mode if you update your object's transform in Update(). This uses variable Time.detalTime. Use FixedUpdate if physics simulation becomes unstable.\n\nFixed Update - Use this mode if you update your object's transform in FixedUpdate(). This uses fixed Time.fixedDeltaTime. Also, use this mode if the game object is affected by Unity physics (i.e. has a rigid body component), which uses fixed updates.")]
		public BoingManager.UpdateMode UpdateMode = BoingManager.UpdateMode.LateUpdate;

		// Token: 0x040034B6 RID: 13494
		[Range(0f, 10f)]
		[Tooltip("Multiplier on positional samples from reactor field.\n1.0 means 100%.")]
		public float PositionSampleMultiplier = 1f;

		// Token: 0x040034B7 RID: 13495
		[Range(0f, 10f)]
		[Tooltip("Multiplier on rotational samples from reactor field.\n1.0 means 100%.")]
		public float RotationSampleMultiplier = 1f;

		// Token: 0x040034B8 RID: 13496
		private Vector3 m_objPosition;

		// Token: 0x040034B9 RID: 13497
		private Quaternion m_objRotation;
	}
}
