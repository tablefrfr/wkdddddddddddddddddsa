﻿using System;
using UnityEngine;

// Token: 0x020004A6 RID: 1190
public class AmbientSoundRandomizer : MonoBehaviour
{
	// Token: 0x06001B43 RID: 6979 RVA: 0x0008AFA0 File Offset: 0x000891A0
	private void Button_Cache()
	{
		this.audioSources = base.GetComponentsInChildren<AudioSource>();
	}

	// Token: 0x06001B44 RID: 6980 RVA: 0x0008AFAE File Offset: 0x000891AE
	private void Awake()
	{
		this.SetTarget();
	}

	// Token: 0x06001B45 RID: 6981 RVA: 0x0008AFB8 File Offset: 0x000891B8
	private void Update()
	{
		if (this.timer >= this.timerTarget)
		{
			int num = Random.Range(0, this.audioSources.Length);
			int num2 = Random.Range(0, this.audioClips.Length);
			this.audioSources[num].clip = this.audioClips[num2];
			this.audioSources[num].Play();
			this.SetTarget();
			return;
		}
		this.timer += Time.deltaTime;
	}

	// Token: 0x06001B46 RID: 6982 RVA: 0x0008B02C File Offset: 0x0008922C
	private void SetTarget()
	{
		this.timerTarget = this.baseTime + Random.Range(0f, this.randomModifier);
		this.timer = 0f;
	}

	// Token: 0x04001F33 RID: 7987
	[SerializeField]
	private AudioSource[] audioSources;

	// Token: 0x04001F34 RID: 7988
	[SerializeField]
	private AudioClip[] audioClips;

	// Token: 0x04001F35 RID: 7989
	[SerializeField]
	private float baseTime = 15f;

	// Token: 0x04001F36 RID: 7990
	[SerializeField]
	private float randomModifier = 5f;

	// Token: 0x04001F37 RID: 7991
	private float timer;

	// Token: 0x04001F38 RID: 7992
	private float timerTarget;
}
