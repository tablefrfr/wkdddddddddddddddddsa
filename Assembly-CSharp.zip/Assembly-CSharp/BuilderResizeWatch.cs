﻿using System;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x0200032C RID: 812
public class BuilderResizeWatch : MonoBehaviour
{
	// Token: 0x0600123C RID: 4668 RVA: 0x000614EE File Offset: 0x0005F6EE
	private void Start()
	{
		if (this.enlargeButton != null)
		{
			this.enlargeButton.onPressButton.AddListener(new UnityAction(this.OnEnlargeButtonPressed));
		}
		this.ownerRig = base.GetComponentInParent<VRRig>();
	}

	// Token: 0x0600123D RID: 4669 RVA: 0x00061526 File Offset: 0x0005F726
	private void OnDestroy()
	{
		if (this.enlargeButton != null)
		{
			this.enlargeButton.onPressButton.RemoveListener(new UnityAction(this.OnEnlargeButtonPressed));
		}
	}

	// Token: 0x0600123E RID: 4670 RVA: 0x00061554 File Offset: 0x0005F754
	private void OnEnlargeButtonPressed()
	{
		if (this.sizeManger == null)
		{
			if (this.ownerRig == null)
			{
				Debug.LogWarning("Builder resize watch has no owner rig");
			}
			this.sizeManger = this.ownerRig.sizeManager;
		}
		if (this.sizeManger != null)
		{
			this.sizeManger.touchingChangers.Clear();
		}
	}

	// Token: 0x0400150C RID: 5388
	[SerializeField]
	private HeldButton enlargeButton;

	// Token: 0x0400150D RID: 5389
	private VRRig ownerRig;

	// Token: 0x0400150E RID: 5390
	private SizeManager sizeManger;
}
