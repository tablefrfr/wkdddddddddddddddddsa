﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x020004B6 RID: 1206
internal class CallbackContainer<T> where T : ICallBack
{
	// Token: 0x06001B73 RID: 7027 RVA: 0x0008B844 File Offset: 0x00089A44
	public virtual void Add(T inCallback)
	{
		this.callbackCount++;
		this.callbackList.Add(inCallback);
	}

	// Token: 0x06001B74 RID: 7028 RVA: 0x0008B860 File Offset: 0x00089A60
	public virtual void Remove(T inCallback)
	{
		int num = this.callbackList.IndexOf(inCallback);
		if (num > -1)
		{
			if (num <= this.currentIndex)
			{
				this.currentIndex--;
			}
			this.callbackCount--;
			this.callbackList.RemoveAt(num);
		}
	}

	// Token: 0x06001B75 RID: 7029 RVA: 0x0008B8B0 File Offset: 0x00089AB0
	public virtual void TryRunCallbacks()
	{
		this.callbackCount = this.callbackList.Count;
		this.currentIndex = 0;
		while (this.currentIndex < this.callbackCount)
		{
			try
			{
				T t = this.callbackList[this.currentIndex];
				t.CallBack();
			}
			catch (Exception ex)
			{
				Debug.LogError(ex.ToString());
			}
			this.currentIndex++;
		}
	}

	// Token: 0x06001B76 RID: 7030 RVA: 0x0008B934 File Offset: 0x00089B34
	public virtual void Clear()
	{
		this.callbackList.Clear();
	}

	// Token: 0x04001F54 RID: 8020
	protected List<T> callbackList = new List<T>(100);

	// Token: 0x04001F55 RID: 8021
	protected int currentIndex = -1;

	// Token: 0x04001F56 RID: 8022
	protected int callbackCount = -1;
}
