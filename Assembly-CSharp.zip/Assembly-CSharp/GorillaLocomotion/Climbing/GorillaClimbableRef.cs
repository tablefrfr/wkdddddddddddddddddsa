﻿using System;

namespace GorillaLocomotion.Climbing
{
	// Token: 0x020005D4 RID: 1492
	public class GorillaClimbableRef : GorillaClimbable
	{
		// Token: 0x04002572 RID: 9586
		public GorillaClimbable climb;
	}
}
