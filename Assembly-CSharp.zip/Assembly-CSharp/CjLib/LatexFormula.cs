﻿using System;
using UnityEngine;

namespace CjLib
{
	// Token: 0x020007DD RID: 2013
	[ExecuteInEditMode]
	public class LatexFormula : MonoBehaviour
	{
		// Token: 0x04003325 RID: 13093
		public static readonly string BaseUrl = "http://tex.s2cms.ru/svg/f(x) ";

		// Token: 0x04003326 RID: 13094
		private int m_hash = LatexFormula.BaseUrl.GetHashCode();

		// Token: 0x04003327 RID: 13095
		[SerializeField]
		private string m_formula = "";

		// Token: 0x04003328 RID: 13096
		private Texture m_texture;
	}
}
