﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

// Token: 0x02000265 RID: 613
public class BitmapFont : ScriptableObject
{
	// Token: 0x06000D3C RID: 3388 RVA: 0x00044E94 File Offset: 0x00043094
	private void OnEnable()
	{
		this._charToSymbol = this.symbols.ToDictionary((BitmapFont.SymbolData s) => s.character, (BitmapFont.SymbolData s) => s);
	}

	// Token: 0x06000D3D RID: 3389 RVA: 0x00044EF0 File Offset: 0x000430F0
	public void RenderToTexture(Texture2D target, string text)
	{
		if (text == null)
		{
			text = string.Empty;
		}
		int num = target.width * target.height;
		if (this._empty.Length != num)
		{
			this._empty = new Color[num];
			for (int i = 0; i < this._empty.Length; i++)
			{
				this._empty[i] = Color.black;
			}
		}
		target.SetPixels(this._empty);
		int length = text.Length;
		int num2 = 1;
		int width = this.fontImage.width;
		int height = this.fontImage.height;
		for (int j = 0; j < length; j++)
		{
			char key = text[j];
			BitmapFont.SymbolData symbolData = this._charToSymbol[key];
			int width2 = symbolData.width;
			int height2 = symbolData.height;
			int x = symbolData.x;
			int y = symbolData.y;
			Graphics.CopyTexture(this.fontImage, 0, 0, x, height - (y + height2), width2, height2, target, 0, 0, num2, 2 + symbolData.yoffset);
			num2 += width2 + 1;
		}
		target.Apply(false);
	}

	// Token: 0x04000E8F RID: 3727
	public Texture2D fontImage;

	// Token: 0x04000E90 RID: 3728
	public TextAsset fontJson;

	// Token: 0x04000E91 RID: 3729
	public int symbolPixelsPerUnit = 1;

	// Token: 0x04000E92 RID: 3730
	public string characterMap;

	// Token: 0x04000E93 RID: 3731
	[Space]
	public BitmapFont.SymbolData[] symbols = new BitmapFont.SymbolData[0];

	// Token: 0x04000E94 RID: 3732
	private Dictionary<char, BitmapFont.SymbolData> _charToSymbol;

	// Token: 0x04000E95 RID: 3733
	private Color[] _empty = new Color[0];

	// Token: 0x02000266 RID: 614
	[Serializable]
	public struct SymbolData
	{
		// Token: 0x04000E96 RID: 3734
		public char character;

		// Token: 0x04000E97 RID: 3735
		[Space]
		public int id;

		// Token: 0x04000E98 RID: 3736
		public int width;

		// Token: 0x04000E99 RID: 3737
		public int height;

		// Token: 0x04000E9A RID: 3738
		public int x;

		// Token: 0x04000E9B RID: 3739
		public int y;

		// Token: 0x04000E9C RID: 3740
		public int xadvance;

		// Token: 0x04000E9D RID: 3741
		public int yoffset;
	}
}
