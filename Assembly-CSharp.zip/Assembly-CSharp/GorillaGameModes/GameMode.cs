﻿using System;
using System.Collections.Generic;
using GorillaExtensions;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

namespace GorillaGameModes
{
	// Token: 0x020005AB RID: 1451
	public class GameMode : MonoBehaviour
	{
		// Token: 0x0600219C RID: 8604 RVA: 0x0009E608 File Offset: 0x0009C808
		private void Awake()
		{
			if (GameMode.instance.IsNull())
			{
				GameMode.instance = this;
				foreach (GorillaGameManager gorillaGameManager in base.gameObject.GetComponentsInChildren<GorillaGameManager>(true))
				{
					int num = (int)gorillaGameManager.GameType();
					string text = gorillaGameManager.GameModeName();
					if (GameMode.gameModeTable.ContainsKey(num))
					{
						Debug.LogWarning("Duplicate gamemode type, skipping this instance", gorillaGameManager);
					}
					else
					{
						GameMode.gameModeTable.Add((int)gorillaGameManager.GameType(), gorillaGameManager);
						GameMode.gameModeKeyByName.Add(text, num);
						GameMode.gameModes.Add(gorillaGameManager);
						GameMode.gameModeNames.Add(text);
					}
				}
				return;
			}
			Object.Destroy(this);
		}

		// Token: 0x0600219D RID: 8605 RVA: 0x0009E6AD File Offset: 0x0009C8AD
		private void OnDestroy()
		{
			if (GameMode.instance == this)
			{
				GameMode.instance = null;
			}
		}

		// Token: 0x170003E9 RID: 1001
		// (get) Token: 0x0600219E RID: 8606 RVA: 0x0009E6C2 File Offset: 0x0009C8C2
		public static GorillaGameManager ActiveGameMode
		{
			get
			{
				return GameMode.activeGameMode;
			}
		}

		// Token: 0x170003EA RID: 1002
		// (get) Token: 0x0600219F RID: 8607 RVA: 0x0009E6C9 File Offset: 0x0009C8C9
		internal static GameModeSerializer ActiveNetworkHandler
		{
			get
			{
				return GameMode.activeNetworkHandler;
			}
		}

		// Token: 0x060021A0 RID: 8608 RVA: 0x0009E6D0 File Offset: 0x0009C8D0
		static GameMode()
		{
			GameMode.StaticLoad();
		}

		// Token: 0x060021A1 RID: 8609 RVA: 0x0009E740 File Offset: 0x0009C940
		[OnEnterPlay_Run]
		private static void StaticLoad()
		{
			RoomSystem.LeftRoomEvent = (Action)Delegate.Combine(RoomSystem.LeftRoomEvent, new Action(GameMode.ResetGameModes));
			RoomSystem.JoinedRoomEvent = (Action)Delegate.Combine(RoomSystem.JoinedRoomEvent, new Action(GameMode.RefreshPlayers));
			RoomSystem.PlayersChangedEvent = (Action)Delegate.Combine(RoomSystem.PlayersChangedEvent, new Action(GameMode.RefreshPlayers));
		}

		// Token: 0x060021A2 RID: 8610 RVA: 0x0009E7AD File Offset: 0x0009C9AD
		internal static bool LoadGameModeFromProperty()
		{
			return GameMode.LoadGameMode(GameMode.FindGameModeFromRoomProperty());
		}

		// Token: 0x060021A3 RID: 8611 RVA: 0x0009E7B9 File Offset: 0x0009C9B9
		internal static bool ChangeGameFromProperty()
		{
			return GameMode.ChangeGameMode(GameMode.FindGameModeFromRoomProperty());
		}

		// Token: 0x060021A4 RID: 8612 RVA: 0x0009E7C5 File Offset: 0x0009C9C5
		internal static bool LoadGameModeFromProperty(string prop)
		{
			return GameMode.LoadGameMode(GameMode.FindGameModeInString(prop));
		}

		// Token: 0x060021A5 RID: 8613 RVA: 0x0009E7D2 File Offset: 0x0009C9D2
		internal static bool ChangeGameFromProperty(string prop)
		{
			return GameMode.ChangeGameMode(GameMode.FindGameModeInString(prop));
		}

		// Token: 0x060021A6 RID: 8614 RVA: 0x0009E7E0 File Offset: 0x0009C9E0
		private static string FindGameModeFromRoomProperty()
		{
			object obj;
			if (PhotonNetwork.InRoom && PhotonNetwork.CurrentRoom != null && PhotonNetwork.CurrentRoom.CustomProperties.TryGetValue("gameMode", out obj))
			{
				string text = obj as string;
				if (text != null)
				{
					return GameMode.FindGameModeInString(text);
				}
			}
			return null;
		}

		// Token: 0x060021A7 RID: 8615 RVA: 0x0009E828 File Offset: 0x0009CA28
		private static string FindGameModeInString(string gmString)
		{
			for (int i = 0; i < GameMode.gameModeNames.Count; i++)
			{
				string text = GameMode.gameModeNames[i];
				if (gmString.Contains(text))
				{
					return text;
				}
			}
			return null;
		}

		// Token: 0x060021A8 RID: 8616 RVA: 0x0009E864 File Offset: 0x0009CA64
		public static bool LoadGameMode(string gameMode)
		{
			if (gameMode == null)
			{
				Debug.LogError("GAME MODE NULL");
				return false;
			}
			int key;
			if (!GameMode.gameModeKeyByName.TryGetValue(gameMode, out key))
			{
				Debug.LogWarning("Unable to find game mode key for " + gameMode);
				return false;
			}
			return GameMode.LoadGameMode(key);
		}

		// Token: 0x060021A9 RID: 8617 RVA: 0x0009E8A8 File Offset: 0x0009CAA8
		public static bool LoadGameMode(int key)
		{
			foreach (KeyValuePair<int, GorillaGameManager> keyValuePair in GameMode.gameModeTable)
			{
			}
			if (!GameMode.gameModeTable.ContainsKey(key))
			{
				Debug.LogWarning("Missing game mode for key " + key.ToString());
				return false;
			}
			if (PhotonNetwork.InstantiateRoomObject("GameMode", Vector3.zero, Quaternion.identity, 0, new object[]
			{
				key
			}).IsNull())
			{
				Debug.LogWarning("Unable to create GameManager with key " + key.ToString());
				return false;
			}
			return true;
		}

		// Token: 0x060021AA RID: 8618 RVA: 0x0009E95C File Offset: 0x0009CB5C
		internal static bool ChangeGameMode(string gameMode)
		{
			if (gameMode == null)
			{
				return false;
			}
			int key;
			if (!GameMode.gameModeKeyByName.TryGetValue(gameMode, out key))
			{
				Debug.LogWarning("Unable to find game mode key for " + gameMode);
				return false;
			}
			return GameMode.ChangeGameMode(key);
		}

		// Token: 0x060021AB RID: 8619 RVA: 0x0009E998 File Offset: 0x0009CB98
		internal static bool ChangeGameMode(int key)
		{
			GorillaGameManager x;
			if (!PhotonNetwork.IsMasterClient || !GameMode.gameModeTable.TryGetValue(key, out x) || x == GameMode.activeGameMode)
			{
				return false;
			}
			if (GameMode.activeNetworkHandler.IsNotNull())
			{
				PhotonNetwork.Destroy(GameMode.activeNetworkHandler.gameObject);
			}
			GameMode.activeGameMode.StopPlaying();
			GameMode.activeGameMode = null;
			GameMode.activeNetworkHandler = null;
			return GameMode.LoadGameMode(key);
		}

		// Token: 0x060021AC RID: 8620 RVA: 0x0009EA04 File Offset: 0x0009CC04
		internal static void SetupGameModeRemote(GameModeSerializer networkSerializer)
		{
			GorillaGameManager gameModeInstance = networkSerializer.GameModeInstance;
			if (GameMode.activeGameMode.IsNotNull() && gameModeInstance.IsNotNull() && gameModeInstance != GameMode.activeGameMode)
			{
				GameMode.activeGameMode.StopPlaying();
			}
			GameMode.activeNetworkHandler = networkSerializer;
			GameMode.activeGameMode = gameModeInstance;
			GameMode.activeGameMode.NetworkLinkSetup(networkSerializer);
			GameMode.activeGameMode.StartPlaying();
		}

		// Token: 0x060021AD RID: 8621 RVA: 0x0009EA64 File Offset: 0x0009CC64
		internal static void RemoveNetworkLink(GameModeSerializer networkSerializer)
		{
			if (networkSerializer == GameMode.activeNetworkHandler)
			{
				GameMode.activeGameMode.NetworkLinkDestroyed(networkSerializer);
				GameMode.activeNetworkHandler = null;
				return;
			}
		}

		// Token: 0x060021AE RID: 8622 RVA: 0x0009EA85 File Offset: 0x0009CC85
		public static GorillaGameManager GetGameModeInstance(GameModeType type)
		{
			return GameMode.GetGameModeInstance((int)type);
		}

		// Token: 0x060021AF RID: 8623 RVA: 0x0009EA90 File Offset: 0x0009CC90
		public static GorillaGameManager GetGameModeInstance(int type)
		{
			GorillaGameManager gorillaGameManager;
			if (GameMode.gameModeTable.TryGetValue(type, out gorillaGameManager))
			{
				if (gorillaGameManager == null)
				{
					Debug.LogError("COuldnt get mode from table");
					foreach (KeyValuePair<int, GorillaGameManager> keyValuePair in GameMode.gameModeTable)
					{
					}
				}
				return gorillaGameManager;
			}
			return null;
		}

		// Token: 0x060021B0 RID: 8624 RVA: 0x0009EB00 File Offset: 0x0009CD00
		public static T GetGameModeInstance<T>(GameModeType type) where T : GorillaGameManager
		{
			return GameMode.GetGameModeInstance<T>((int)type);
		}

		// Token: 0x060021B1 RID: 8625 RVA: 0x0009EB08 File Offset: 0x0009CD08
		public static T GetGameModeInstance<T>(int type) where T : GorillaGameManager
		{
			T t = GameMode.GetGameModeInstance(type) as T;
			if (t != null)
			{
				return t;
			}
			return default(T);
		}

		// Token: 0x060021B2 RID: 8626 RVA: 0x0009EB3C File Offset: 0x0009CD3C
		public static void ResetGameModes()
		{
			GameMode.activeGameMode = null;
			GameMode.activeNetworkHandler = null;
			GameMode.optOutPlayers.Clear();
			GameMode.ParticipatingPlayers.Clear();
			for (int i = 0; i < GameMode.gameModes.Count; i++)
			{
				GorillaGameManager gorillaGameManager = GameMode.gameModes[i];
				gorillaGameManager.StopPlaying();
				gorillaGameManager.Reset();
			}
		}

		// Token: 0x060021B3 RID: 8627 RVA: 0x0009EB94 File Offset: 0x0009CD94
		public static void ReportTag(Player player)
		{
			if (PhotonNetwork.InRoom && GameMode.activeNetworkHandler.IsNotNull())
			{
				GameMode.activeNetworkHandler.SendRPC("ReportTagRPC", false, new object[]
				{
					player
				});
			}
		}

		// Token: 0x060021B4 RID: 8628 RVA: 0x0009EBC3 File Offset: 0x0009CDC3
		public static void ReportHit()
		{
			if (PhotonNetwork.InRoom && GameMode.activeNetworkHandler.IsNotNull())
			{
				GameMode.activeNetworkHandler.SendRPC("ReportHitRPC", false, Array.Empty<object>());
			}
		}

		// Token: 0x060021B5 RID: 8629 RVA: 0x0009EBF0 File Offset: 0x0009CDF0
		public static void RefreshPlayers()
		{
			List<Player> playersInRoom = RoomSystem.PlayersInRoom;
			int num = Mathf.Min(playersInRoom.Count, 10);
			GameMode.ParticipatingPlayers.Clear();
			for (int i = 0; i < num; i++)
			{
				if (GameMode.CanParticipate(playersInRoom[i]))
				{
					GameMode.ParticipatingPlayers.Add(playersInRoom[i]);
				}
			}
		}

		// Token: 0x060021B6 RID: 8630 RVA: 0x0009EC46 File Offset: 0x0009CE46
		public static void OptOut(VRRig rig)
		{
			GameMode.OptOut(rig.creator.ActorNumber);
		}

		// Token: 0x060021B7 RID: 8631 RVA: 0x0009EC58 File Offset: 0x0009CE58
		public static void OptOut(Player player)
		{
			GameMode.OptOut(player.ActorNumber);
		}

		// Token: 0x060021B8 RID: 8632 RVA: 0x0009EC65 File Offset: 0x0009CE65
		public static void OptOut(int playerActorNumber)
		{
			if (GameMode.optOutPlayers.Add(playerActorNumber))
			{
				GameMode.RefreshPlayers();
			}
		}

		// Token: 0x060021B9 RID: 8633 RVA: 0x0009EC79 File Offset: 0x0009CE79
		public static void OptIn(VRRig rig)
		{
			GameMode.OptIn(rig.creator.ActorNumber);
		}

		// Token: 0x060021BA RID: 8634 RVA: 0x0009EC8B File Offset: 0x0009CE8B
		public static void OptIn(Player player)
		{
			GameMode.OptIn(player.ActorNumber);
		}

		// Token: 0x060021BB RID: 8635 RVA: 0x0009EC98 File Offset: 0x0009CE98
		public static void OptIn(int playerActorNumber)
		{
			if (GameMode.optOutPlayers.Remove(playerActorNumber))
			{
				GameMode.RefreshPlayers();
			}
		}

		// Token: 0x060021BC RID: 8636 RVA: 0x0009ECAC File Offset: 0x0009CEAC
		private static bool CanParticipate(Player player)
		{
			object obj;
			return player.InRoom() && !GameMode.optOutPlayers.Contains(player.ActorNumber) && (!player.CustomProperties.TryGetValue("didTutorial", out obj) || (bool)obj);
		}

		// Token: 0x0400231D RID: 8989
		[OnEnterPlay_SetNull]
		private static GameMode instance;

		// Token: 0x0400231E RID: 8990
		[OnEnterPlay_Clear]
		private static Dictionary<int, GorillaGameManager> gameModeTable = new Dictionary<int, GorillaGameManager>();

		// Token: 0x0400231F RID: 8991
		[OnEnterPlay_Clear]
		private static Dictionary<string, int> gameModeKeyByName = new Dictionary<string, int>();

		// Token: 0x04002320 RID: 8992
		[OnEnterPlay_Clear]
		private static List<GorillaGameManager> gameModes = new List<GorillaGameManager>(10);

		// Token: 0x04002321 RID: 8993
		[OnEnterPlay_Clear]
		public static readonly List<string> gameModeNames = new List<string>(10);

		// Token: 0x04002322 RID: 8994
		[OnEnterPlay_SetNull]
		private static GorillaGameManager activeGameMode = null;

		// Token: 0x04002323 RID: 8995
		[OnEnterPlay_SetNull]
		private static GameModeSerializer activeNetworkHandler = null;

		// Token: 0x04002324 RID: 8996
		private static List<Player> participatingPlayers = new List<Player>(10);

		// Token: 0x04002325 RID: 8997
		[OnEnterPlay_Clear]
		private static readonly HashSet<int> optOutPlayers = new HashSet<int>(10);

		// Token: 0x04002326 RID: 8998
		[OnEnterPlay_Clear]
		public static readonly List<Player> ParticipatingPlayers = new List<Player>(10);
	}
}
