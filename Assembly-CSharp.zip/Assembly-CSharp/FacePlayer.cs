﻿using System;
using UnityEngine;

// Token: 0x020002F6 RID: 758
public class FacePlayer : MonoBehaviour
{
	// Token: 0x06001167 RID: 4455 RVA: 0x0005BF4C File Offset: 0x0005A14C
	private void LateUpdate()
	{
		base.transform.rotation = Quaternion.LookRotation(base.transform.position - GorillaTagger.Instance.headCollider.transform.position) * Quaternion.AngleAxis(-90f, Vector3.up);
	}
}
