﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

// Token: 0x02000192 RID: 402
public class ButtonDownListener : MonoBehaviour, IPointerDownHandler, IEventSystemHandler
{
	// Token: 0x14000015 RID: 21
	// (add) Token: 0x06000855 RID: 2133 RVA: 0x000295CC File Offset: 0x000277CC
	// (remove) Token: 0x06000856 RID: 2134 RVA: 0x00029604 File Offset: 0x00027804
	public event Action onButtonDown;

	// Token: 0x06000857 RID: 2135 RVA: 0x00029639 File Offset: 0x00027839
	public void OnPointerDown(PointerEventData eventData)
	{
		if (this.onButtonDown != null)
		{
			this.onButtonDown();
		}
	}
}
