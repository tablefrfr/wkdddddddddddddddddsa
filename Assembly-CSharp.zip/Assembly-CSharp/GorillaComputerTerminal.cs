﻿using System;
using System.Collections;
using System.Runtime.CompilerServices;
using GorillaNetworking;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

// Token: 0x020003F7 RID: 1015
public class GorillaComputerTerminal : MonoBehaviour
{
	// Token: 0x0600179D RID: 6045 RVA: 0x00079437 File Offset: 0x00077637
	private void OnEnable()
	{
		if (GorillaComputer.instance == null)
		{
			base.StartCoroutine(this.<OnEnable>g__OnEnable_Local|3_0());
			return;
		}
		this.Init();
	}

	// Token: 0x0600179E RID: 6046 RVA: 0x0007945C File Offset: 0x0007765C
	private void Init()
	{
		GameEvents.ScreenTextChangedEvent.AddListener(new UnityAction<string>(this.OnScreenTextChanged));
		GameEvents.FunctionSelectTextChangedEvent.AddListener(new UnityAction<string>(this.OnFunctionTextChanged));
		GameEvents.ScreenTextMaterialsEvent.AddListener(new UnityAction<Material[]>(this.OnMaterialsChanged));
		this.myScreenText.text = GorillaComputer.instance.screenText.Text;
		this.myFunctionText.text = GorillaComputer.instance.functionSelectText.Text;
		if (GorillaComputer.instance.screenText.currentMaterials != null)
		{
			this.monitorMesh.materials = GorillaComputer.instance.screenText.currentMaterials;
		}
	}

	// Token: 0x0600179F RID: 6047 RVA: 0x00079514 File Offset: 0x00077714
	private void OnDisable()
	{
		GameEvents.ScreenTextChangedEvent.RemoveListener(new UnityAction<string>(this.OnScreenTextChanged));
		GameEvents.FunctionSelectTextChangedEvent.RemoveListener(new UnityAction<string>(this.OnFunctionTextChanged));
		GameEvents.ScreenTextMaterialsEvent.RemoveListener(new UnityAction<Material[]>(this.OnMaterialsChanged));
	}

	// Token: 0x060017A0 RID: 6048 RVA: 0x00079563 File Offset: 0x00077763
	public void OnScreenTextChanged(string text)
	{
		this.myScreenText.text = text;
	}

	// Token: 0x060017A1 RID: 6049 RVA: 0x00079571 File Offset: 0x00077771
	public void OnFunctionTextChanged(string text)
	{
		this.myFunctionText.text = text;
	}

	// Token: 0x060017A2 RID: 6050 RVA: 0x0007957F File Offset: 0x0007777F
	private void OnMaterialsChanged(Material[] materials)
	{
		this.monitorMesh.materials = materials;
	}

	// Token: 0x060017A4 RID: 6052 RVA: 0x0007958D File Offset: 0x0007778D
	[CompilerGenerated]
	private IEnumerator <OnEnable>g__OnEnable_Local|3_0()
	{
		yield return new WaitUntil(() => GorillaComputer.instance != null && GorillaComputer.instance.initialized);
		yield return null;
		this.Init();
		yield break;
	}

	// Token: 0x04001B0F RID: 6927
	public Text myScreenText;

	// Token: 0x04001B10 RID: 6928
	public Text myFunctionText;

	// Token: 0x04001B11 RID: 6929
	public MeshRenderer monitorMesh;
}
