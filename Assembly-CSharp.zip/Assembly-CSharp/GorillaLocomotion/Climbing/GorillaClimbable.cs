﻿using System;
using UnityEngine;

namespace GorillaLocomotion.Climbing
{
	// Token: 0x020005D3 RID: 1491
	public class GorillaClimbable : MonoBehaviour
	{
		// Token: 0x060022EC RID: 8940 RVA: 0x000AB0D9 File Offset: 0x000A92D9
		private void Awake()
		{
			this.colliderCache = base.GetComponent<Collider>();
		}

		// Token: 0x04002568 RID: 9576
		public bool snapX;

		// Token: 0x04002569 RID: 9577
		public bool snapY;

		// Token: 0x0400256A RID: 9578
		public bool snapZ;

		// Token: 0x0400256B RID: 9579
		public float maxDistanceSnap = 0.05f;

		// Token: 0x0400256C RID: 9580
		public AudioClip clip;

		// Token: 0x0400256D RID: 9581
		public AudioClip clipOnFullRelease;

		// Token: 0x0400256E RID: 9582
		public Action<GorillaHandClimber, GorillaClimbableRef> onBeforeClimb;

		// Token: 0x0400256F RID: 9583
		public bool climbOnlyWhileSmall;

		// Token: 0x04002570 RID: 9584
		[NonSerialized]
		public bool isBeingClimbed;

		// Token: 0x04002571 RID: 9585
		[NonSerialized]
		public Collider colliderCache;
	}
}
