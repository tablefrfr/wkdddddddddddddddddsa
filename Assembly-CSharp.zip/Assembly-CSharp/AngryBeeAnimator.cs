﻿using System;
using UnityEngine;

// Token: 0x02000066 RID: 102
public class AngryBeeAnimator : MonoBehaviour
{
	// Token: 0x06000209 RID: 521 RVA: 0x0000EA28 File Offset: 0x0000CC28
	private void Awake()
	{
		this.bees = new GameObject[this.numBees];
		this.beeOrbits = new GameObject[this.numBees];
		this.beeOrbitalRadii = new float[this.numBees];
		this.beeOrbitalAxes = new Vector3[this.numBees];
		for (int i = 0; i < this.numBees; i++)
		{
			GameObject gameObject = new GameObject();
			gameObject.transform.parent = base.transform;
			Vector2 vector = Random.insideUnitCircle * this.orbitMaxCenterDisplacement;
			gameObject.transform.localPosition = new Vector3(vector.x, Random.Range(-this.orbitMaxHeightDisplacement, this.orbitMaxHeightDisplacement), vector.y);
			gameObject.transform.localRotation = Quaternion.Euler(Random.Range(-this.orbitMaxTilt, this.orbitMaxTilt), (float)Random.Range(0, 360), 0f);
			this.beeOrbitalAxes[i] = gameObject.transform.up;
			GameObject gameObject2 = Object.Instantiate<GameObject>(this.beePrefab, gameObject.transform);
			float num = Random.Range(this.orbitMinRadius, this.orbitMaxRadius);
			this.beeOrbitalRadii[i] = num;
			gameObject2.transform.localPosition = Vector3.forward * num;
			gameObject2.transform.localRotation = Quaternion.Euler(-90f, 90f, 0f);
			gameObject2.transform.localScale = Vector3.one * this.beeScale;
			this.bees[i] = gameObject2;
			this.beeOrbits[i] = gameObject;
		}
	}

	// Token: 0x0600020A RID: 522 RVA: 0x0000EBC4 File Offset: 0x0000CDC4
	private void Update()
	{
		float angle = this.orbitSpeed * Time.deltaTime;
		for (int i = 0; i < this.numBees; i++)
		{
			this.beeOrbits[i].transform.Rotate(this.beeOrbitalAxes[i], angle);
		}
	}

	// Token: 0x0600020B RID: 523 RVA: 0x0000EC10 File Offset: 0x0000CE10
	public void SetEmergeFraction(float fraction)
	{
		for (int i = 0; i < this.numBees; i++)
		{
			this.bees[i].transform.localPosition = Vector3.forward * fraction * this.beeOrbitalRadii[i];
		}
	}

	// Token: 0x040002D4 RID: 724
	[SerializeField]
	private GameObject beePrefab;

	// Token: 0x040002D5 RID: 725
	[SerializeField]
	private int numBees;

	// Token: 0x040002D6 RID: 726
	[SerializeField]
	private float orbitMinRadius;

	// Token: 0x040002D7 RID: 727
	[SerializeField]
	private float orbitMaxRadius;

	// Token: 0x040002D8 RID: 728
	[SerializeField]
	private float orbitMaxHeightDisplacement;

	// Token: 0x040002D9 RID: 729
	[SerializeField]
	private float orbitMaxCenterDisplacement;

	// Token: 0x040002DA RID: 730
	[SerializeField]
	private float orbitMaxTilt;

	// Token: 0x040002DB RID: 731
	[SerializeField]
	private float orbitSpeed;

	// Token: 0x040002DC RID: 732
	[SerializeField]
	private float beeScale;

	// Token: 0x040002DD RID: 733
	private GameObject[] beeOrbits;

	// Token: 0x040002DE RID: 734
	private GameObject[] bees;

	// Token: 0x040002DF RID: 735
	private Vector3[] beeOrbitalAxes;

	// Token: 0x040002E0 RID: 736
	private float[] beeOrbitalRadii;
}
