﻿using System;

// Token: 0x020000A5 RID: 165
[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field)]
public class DevInspectorYellow : DevInspectorColor
{
	// Token: 0x0600031D RID: 797 RVA: 0x0001651B File Offset: 0x0001471B
	public DevInspectorYellow() : base("#ff5")
	{
	}
}
