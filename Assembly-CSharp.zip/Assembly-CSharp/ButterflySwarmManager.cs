﻿using System;
using System.Collections.Generic;
using Photon.Pun;
using UnityEngine;

// Token: 0x02000071 RID: 113
public class ButterflySwarmManager : MonoBehaviourPun
{
	// Token: 0x17000021 RID: 33
	// (get) Token: 0x06000258 RID: 600 RVA: 0x00010D1B File Offset: 0x0000EF1B
	// (set) Token: 0x06000259 RID: 601 RVA: 0x00010D23 File Offset: 0x0000EF23
	public float PerchedFlapSpeed { get; private set; }

	// Token: 0x17000022 RID: 34
	// (get) Token: 0x0600025A RID: 602 RVA: 0x00010D2C File Offset: 0x0000EF2C
	// (set) Token: 0x0600025B RID: 603 RVA: 0x00010D34 File Offset: 0x0000EF34
	public float PerchedFlapPhase { get; private set; }

	// Token: 0x17000023 RID: 35
	// (get) Token: 0x0600025C RID: 604 RVA: 0x00010D3D File Offset: 0x0000EF3D
	// (set) Token: 0x0600025D RID: 605 RVA: 0x00010D45 File Offset: 0x0000EF45
	public float BeeSpeed { get; private set; }

	// Token: 0x17000024 RID: 36
	// (get) Token: 0x0600025E RID: 606 RVA: 0x00010D4E File Offset: 0x0000EF4E
	// (set) Token: 0x0600025F RID: 607 RVA: 0x00010D56 File Offset: 0x0000EF56
	public float BeeMaxTravelTime { get; private set; }

	// Token: 0x17000025 RID: 37
	// (get) Token: 0x06000260 RID: 608 RVA: 0x00010D5F File Offset: 0x0000EF5F
	// (set) Token: 0x06000261 RID: 609 RVA: 0x00010D67 File Offset: 0x0000EF67
	public float BeeAcceleration { get; private set; }

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x06000262 RID: 610 RVA: 0x00010D70 File Offset: 0x0000EF70
	// (set) Token: 0x06000263 RID: 611 RVA: 0x00010D78 File Offset: 0x0000EF78
	public float BeeJitterStrength { get; private set; }

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x06000264 RID: 612 RVA: 0x00010D81 File Offset: 0x0000EF81
	// (set) Token: 0x06000265 RID: 613 RVA: 0x00010D89 File Offset: 0x0000EF89
	public float BeeJitterDamping { get; private set; }

	// Token: 0x17000028 RID: 40
	// (get) Token: 0x06000266 RID: 614 RVA: 0x00010D92 File Offset: 0x0000EF92
	// (set) Token: 0x06000267 RID: 615 RVA: 0x00010D9A File Offset: 0x0000EF9A
	public float BeeMaxJitterRadius { get; private set; }

	// Token: 0x17000029 RID: 41
	// (get) Token: 0x06000268 RID: 616 RVA: 0x00010DA3 File Offset: 0x0000EFA3
	// (set) Token: 0x06000269 RID: 617 RVA: 0x00010DAB File Offset: 0x0000EFAB
	public float BeeNearDestinationRadius { get; private set; }

	// Token: 0x1700002A RID: 42
	// (get) Token: 0x0600026A RID: 618 RVA: 0x00010DB4 File Offset: 0x0000EFB4
	// (set) Token: 0x0600026B RID: 619 RVA: 0x00010DBC File Offset: 0x0000EFBC
	public float DestRotationAlignmentSpeed { get; private set; }

	// Token: 0x1700002B RID: 43
	// (get) Token: 0x0600026C RID: 620 RVA: 0x00010DC5 File Offset: 0x0000EFC5
	// (set) Token: 0x0600026D RID: 621 RVA: 0x00010DCD File Offset: 0x0000EFCD
	public Vector3 TravellingLocalRotationEuler { get; private set; }

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x0600026E RID: 622 RVA: 0x00010DD6 File Offset: 0x0000EFD6
	// (set) Token: 0x0600026F RID: 623 RVA: 0x00010DDE File Offset: 0x0000EFDE
	public Quaternion TravellingLocalRotation { get; private set; }

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x06000270 RID: 624 RVA: 0x00010DE7 File Offset: 0x0000EFE7
	// (set) Token: 0x06000271 RID: 625 RVA: 0x00010DEF File Offset: 0x0000EFEF
	public float AvoidPointRadius { get; private set; }

	// Token: 0x1700002E RID: 46
	// (get) Token: 0x06000272 RID: 626 RVA: 0x00010DF8 File Offset: 0x0000EFF8
	// (set) Token: 0x06000273 RID: 627 RVA: 0x00010E00 File Offset: 0x0000F000
	public float BeeMinFlowerDuration { get; private set; }

	// Token: 0x1700002F RID: 47
	// (get) Token: 0x06000274 RID: 628 RVA: 0x00010E09 File Offset: 0x0000F009
	// (set) Token: 0x06000275 RID: 629 RVA: 0x00010E11 File Offset: 0x0000F011
	public float BeeMaxFlowerDuration { get; private set; }

	// Token: 0x17000030 RID: 48
	// (get) Token: 0x06000276 RID: 630 RVA: 0x00010E1A File Offset: 0x0000F01A
	// (set) Token: 0x06000277 RID: 631 RVA: 0x00010E22 File Offset: 0x0000F022
	public Color[] BeeColors { get; private set; }

	// Token: 0x06000278 RID: 632 RVA: 0x00010E2C File Offset: 0x0000F02C
	private void Awake()
	{
		this.TravellingLocalRotation = Quaternion.Euler(this.TravellingLocalRotationEuler);
		this.butterflies = new List<AnimatedButterfly>(this.numBees);
		for (int i = 0; i < this.numBees; i++)
		{
			AnimatedButterfly item = default(AnimatedButterfly);
			item.InitVisual(this.beePrefab, this);
			if (this.BeeColors.Length != 0)
			{
				item.SetColor(this.BeeColors[i % this.BeeColors.Length]);
			}
			this.butterflies.Add(item);
		}
	}

	// Token: 0x06000279 RID: 633 RVA: 0x00010EB4 File Offset: 0x0000F0B4
	private void Start()
	{
		foreach (XSceneRef xsceneRef in this.perchSections)
		{
			GameObject gameObject;
			if (xsceneRef.TryResolve(out gameObject))
			{
				List<GameObject> list = new List<GameObject>();
				this.allPerchZones.Add(list);
				foreach (object obj in gameObject.transform)
				{
					Transform transform = (Transform)obj;
					list.Add(transform.gameObject);
				}
			}
		}
		this.OnSeedChange();
		RandomTimedSeedManager.instance.AddCallbackOnSeedChanged(new Action(this.OnSeedChange));
	}

	// Token: 0x0600027A RID: 634 RVA: 0x00010F74 File Offset: 0x0000F174
	private void OnDestroy()
	{
		RandomTimedSeedManager.instance.RemoveCallbackOnSeedChanged(new Action(this.OnSeedChange));
	}

	// Token: 0x0600027B RID: 635 RVA: 0x00010F8C File Offset: 0x0000F18C
	private void Update()
	{
		for (int i = 0; i < this.butterflies.Count; i++)
		{
			AnimatedButterfly value = this.butterflies[i];
			value.UpdateVisual(RandomTimedSeedManager.instance.currentSyncTime, this);
			this.butterflies[i] = value;
		}
	}

	// Token: 0x0600027C RID: 636 RVA: 0x00010FDC File Offset: 0x0000F1DC
	private void OnSeedChange()
	{
		SRand srand = new SRand(RandomTimedSeedManager.instance.seed);
		List<List<GameObject>> list = new List<List<GameObject>>(this.allPerchZones.Count);
		for (int i = 0; i < this.allPerchZones.Count; i++)
		{
			List<GameObject> list2 = new List<GameObject>();
			list2.AddRange(this.allPerchZones[i]);
			list.Add(list2);
		}
		List<GameObject> list3 = new List<GameObject>(this.loopSizePerBee);
		List<float> list4 = new List<float>(this.loopSizePerBee);
		for (int j = 0; j < this.butterflies.Count; j++)
		{
			AnimatedButterfly value = this.butterflies[j];
			value.SetFlapSpeed(srand.NextFloat(this.minFlapSpeed, this.maxFlapSpeed));
			list3.Clear();
			list4.Clear();
			this.PickPoints(this.loopSizePerBee, list, ref srand, list3);
			for (int k = 0; k < list3.Count; k++)
			{
				list4.Add(srand.NextFloat(this.BeeMinFlowerDuration, this.BeeMaxFlowerDuration));
			}
			if (list3.Count == 0)
			{
				this.butterflies.Clear();
				return;
			}
			value.InitRoute(list3, list4, this);
			this.butterflies[j] = value;
		}
	}

	// Token: 0x0600027D RID: 637 RVA: 0x00011120 File Offset: 0x0000F320
	private void PickPoints(int n, List<List<GameObject>> pickBuffer, ref SRand rand, List<GameObject> resultBuffer)
	{
		int exclude = rand.NextInt(0, pickBuffer.Count);
		int num = -1;
		int num2 = n - 2;
		while (resultBuffer.Count < n)
		{
			int num3;
			if (resultBuffer.Count < num2)
			{
				num3 = rand.NextIntWithExclusion(0, pickBuffer.Count, num);
			}
			else
			{
				num3 = rand.NextIntWithExclusion2(0, pickBuffer.Count, num, exclude);
			}
			int num4 = 10;
			while (num3 == num || pickBuffer[num3].Count == 0)
			{
				num3 = (num3 + 1) % pickBuffer.Count;
				num4--;
				if (num4 <= 0)
				{
					return;
				}
			}
			num = num3;
			List<GameObject> list = pickBuffer[num];
			while (list.Count == 0)
			{
				num = (num + 1) % pickBuffer.Count;
				list = pickBuffer[num];
			}
			resultBuffer.Add(list[list.Count - 1]);
			list.RemoveAt(list.Count - 1);
		}
	}

	// Token: 0x04000355 RID: 853
	[SerializeField]
	private XSceneRef[] perchSections;

	// Token: 0x04000356 RID: 854
	[SerializeField]
	private int loopSizePerBee;

	// Token: 0x04000357 RID: 855
	[SerializeField]
	private int numBees;

	// Token: 0x04000358 RID: 856
	[SerializeField]
	private MeshRenderer beePrefab;

	// Token: 0x04000359 RID: 857
	[SerializeField]
	private float maxFlapSpeed;

	// Token: 0x0400035A RID: 858
	[SerializeField]
	private float minFlapSpeed;

	// Token: 0x0400036B RID: 875
	private List<AnimatedButterfly> butterflies;

	// Token: 0x0400036C RID: 876
	private List<List<GameObject>> allPerchZones = new List<List<GameObject>>();
}
