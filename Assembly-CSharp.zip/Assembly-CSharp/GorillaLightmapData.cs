﻿using System;
using UnityEngine;

// Token: 0x02000384 RID: 900
public class GorillaLightmapData : MonoBehaviour
{
	// Token: 0x06001490 RID: 5264 RVA: 0x0006C6C4 File Offset: 0x0006A8C4
	public void Awake()
	{
		this.lights = new Color[this.lightTextures.Length][];
		this.dirs = new Color[this.dirTextures.Length][];
		for (int i = 0; i < this.dirTextures.Length; i++)
		{
			float value = Random.value;
			Debug.Log(value.ToString() + " before load " + Time.realtimeSinceStartup.ToString());
			this.dirs[i] = this.dirTextures[i].GetPixels();
			this.lights[i] = this.lightTextures[i].GetPixels();
			Debug.Log(value.ToString() + " after load " + Time.realtimeSinceStartup.ToString());
		}
	}

	// Token: 0x0400177A RID: 6010
	[SerializeField]
	public Texture2D[] dirTextures;

	// Token: 0x0400177B RID: 6011
	[SerializeField]
	public Texture2D[] lightTextures;

	// Token: 0x0400177C RID: 6012
	public Color[][] lights;

	// Token: 0x0400177D RID: 6013
	public Color[][] dirs;

	// Token: 0x0400177E RID: 6014
	public bool done;
}
