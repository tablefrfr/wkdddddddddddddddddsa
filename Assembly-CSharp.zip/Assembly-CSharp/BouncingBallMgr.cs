﻿using System;
using UnityEngine;

// Token: 0x020001C9 RID: 457
public class BouncingBallMgr : MonoBehaviour
{
	// Token: 0x06000973 RID: 2419 RVA: 0x000315D8 File Offset: 0x0002F7D8
	private void Update()
	{
		if (!this.ballGrabbed && OVRInput.GetDown(this.actionBtn, OVRInput.Controller.Active))
		{
			this.currentBall = Object.Instantiate<GameObject>(this.ball, this.rightControllerPivot.transform.position, Quaternion.identity);
			this.currentBall.transform.parent = this.rightControllerPivot.transform;
			this.ballGrabbed = true;
		}
		if (this.ballGrabbed && OVRInput.GetUp(this.actionBtn, OVRInput.Controller.Active))
		{
			this.currentBall.transform.parent = null;
			Vector3 position = this.currentBall.transform.position;
			Vector3 vel = this.trackingspace.rotation * OVRInput.GetLocalControllerVelocity(OVRInput.Controller.RTouch);
			Vector3 localControllerAngularVelocity = OVRInput.GetLocalControllerAngularVelocity(OVRInput.Controller.RTouch);
			this.currentBall.GetComponent<BouncingBallLogic>().Release(position, vel, localControllerAngularVelocity);
			this.ballGrabbed = false;
		}
	}

	// Token: 0x04000A72 RID: 2674
	[SerializeField]
	private Transform trackingspace;

	// Token: 0x04000A73 RID: 2675
	[SerializeField]
	private GameObject rightControllerPivot;

	// Token: 0x04000A74 RID: 2676
	[SerializeField]
	private OVRInput.RawButton actionBtn;

	// Token: 0x04000A75 RID: 2677
	[SerializeField]
	private GameObject ball;

	// Token: 0x04000A76 RID: 2678
	private GameObject currentBall;

	// Token: 0x04000A77 RID: 2679
	private bool ballGrabbed;
}
