﻿using System;

// Token: 0x0200036B RID: 875
public static class GorillaConstants
{
	// Token: 0x040016B6 RID: 5814
	public const float PlayerColorMin = 0f;

	// Token: 0x040016B7 RID: 5815
	public const string PlayerLocalRigName = "Local Gorilla Player";
}
