﻿using System;
using UnityEngine;

// Token: 0x02000292 RID: 658
public class Drum : MonoBehaviour
{
	// Token: 0x04001081 RID: 4225
	public bool disabler;

	// Token: 0x04001082 RID: 4226
	public AudioSource mySource;

	// Token: 0x04001083 RID: 4227
	public int myIndex;
}
