﻿using System;
using UnityEngine;

// Token: 0x02000091 RID: 145
public static class GlobalDeactivatedSpawnRoot
{
	// Token: 0x060002F7 RID: 759 RVA: 0x00015E60 File Offset: 0x00014060
	public static Transform GetOrCreate()
	{
		if (!GlobalDeactivatedSpawnRoot._xform)
		{
			GlobalDeactivatedSpawnRoot._xform = new GameObject("GlobalDeactivatedSpawnRoot").transform;
			GlobalDeactivatedSpawnRoot._xform.gameObject.SetActive(false);
			Object.DontDestroyOnLoad(GlobalDeactivatedSpawnRoot._xform.gameObject);
		}
		GlobalDeactivatedSpawnRoot._xform.gameObject.SetActive(false);
		return GlobalDeactivatedSpawnRoot._xform;
	}

	// Token: 0x0400042B RID: 1067
	private static Transform _xform;
}
