﻿using System;
using System.Collections;
using System.Globalization;
using GorillaNetworking;
using TMPro;
using UnityEngine;

namespace GameObjectScheduling
{
	// Token: 0x020007C6 RID: 1990
	public class CountdownText : MonoBehaviour
	{
		// Token: 0x06003045 RID: 12357 RVA: 0x000ECC9C File Offset: 0x000EAE9C
		private void Awake()
		{
			this.displayText = base.GetComponent<TMP_Text>();
			this.displayTextFormat = this.displayText.text;
			if (this.CountdownTo.FormatString.Length > 0)
			{
				this.displayTextFormat = this.CountdownTo.FormatString;
			}
			this.displayText.text = string.Empty;
		}

		// Token: 0x06003046 RID: 12358 RVA: 0x000ECCFA File Offset: 0x000EAEFA
		private void OnEnable()
		{
			if (this.monitor == null)
			{
				this.monitor = base.StartCoroutine(this.MonitorTime());
			}
		}

		// Token: 0x06003047 RID: 12359 RVA: 0x000ECD16 File Offset: 0x000EAF16
		private void OnDisable()
		{
			if (this.monitor != null)
			{
				base.StopCoroutine(this.monitor);
			}
			this.monitor = null;
		}

		// Token: 0x06003048 RID: 12360 RVA: 0x000ECD33 File Offset: 0x000EAF33
		private IEnumerator MonitorTime()
		{
			while (GorillaComputer.instance == null || GorillaComputer.instance.startupMillis == 0L)
			{
				yield return null;
			}
			TimeSpan timeSpan = this.TryParseDateTime().Subtract(GorillaComputer.instance.GetServerTime());
			this.displayText.text = string.Empty;
			if (timeSpan.TotalDays < (double)this.CountdownTo.DaysThreshold)
			{
				if (timeSpan.Days > 0)
				{
					this.displayText.text = string.Format(this.displayTextFormat, timeSpan.Days, this.getTimeChunkString(CountdownText.TimeChunk.DAY, timeSpan.Days));
				}
				else if (timeSpan.Hours > 0)
				{
					this.displayText.text = string.Format(this.displayTextFormat, timeSpan.Hours, this.getTimeChunkString(CountdownText.TimeChunk.HOUR, timeSpan.Hours));
				}
				else if (timeSpan.Minutes > 0)
				{
					this.displayText.text = string.Format(this.displayTextFormat, timeSpan.Minutes, this.getTimeChunkString(CountdownText.TimeChunk.MINUTE, timeSpan.Minutes));
				}
			}
			this.monitor = null;
			yield break;
		}

		// Token: 0x06003049 RID: 12361 RVA: 0x000ECD44 File Offset: 0x000EAF44
		private string getTimeChunkString(CountdownText.TimeChunk chunk, int n)
		{
			switch (chunk)
			{
			case CountdownText.TimeChunk.DAY:
				if (n == 1)
				{
					return "day";
				}
				return "days";
			case CountdownText.TimeChunk.HOUR:
				if (n == 1)
				{
					return "hour";
				}
				return "hours";
			case CountdownText.TimeChunk.MINUTE:
				if (n == 1)
				{
					return "minute";
				}
				return "minutes";
			default:
				return string.Empty;
			}
		}

		// Token: 0x0600304A RID: 12362 RVA: 0x000ECD9C File Offset: 0x000EAF9C
		private DateTime TryParseDateTime()
		{
			DateTime result;
			try
			{
				result = DateTime.Parse(this.CountdownTo.CountdownTo, CultureInfo.InvariantCulture);
			}
			catch
			{
				result = DateTime.MinValue;
			}
			return result;
		}

		// Token: 0x040032B9 RID: 12985
		[SerializeField]
		private CountdownTextDate CountdownTo;

		// Token: 0x040032BA RID: 12986
		private TMP_Text displayText;

		// Token: 0x040032BB RID: 12987
		private string displayTextFormat;

		// Token: 0x040032BC RID: 12988
		private Coroutine monitor;

		// Token: 0x020007C7 RID: 1991
		private enum TimeChunk
		{
			// Token: 0x040032BE RID: 12990
			DAY,
			// Token: 0x040032BF RID: 12991
			HOUR,
			// Token: 0x040032C0 RID: 12992
			MINUTE
		}
	}
}
