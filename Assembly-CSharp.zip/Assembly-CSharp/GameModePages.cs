﻿using System;
using System.Collections.Generic;
using System.Text;
using GorillaGameModes;
using GorillaNetworking;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x020002FA RID: 762
public class GameModePages : BasePageHandler
{
	// Token: 0x170001DE RID: 478
	// (get) Token: 0x06001172 RID: 4466 RVA: 0x0005C01F File Offset: 0x0005A21F
	protected override int pageSize
	{
		get
		{
			return this.buttons.Length;
		}
	}

	// Token: 0x170001DF RID: 479
	// (get) Token: 0x06001173 RID: 4467 RVA: 0x0005C029 File Offset: 0x0005A229
	protected override int entriesCount
	{
		get
		{
			return GameMode.gameModeNames.Count;
		}
	}

	// Token: 0x06001174 RID: 4468 RVA: 0x0005C038 File Offset: 0x0005A238
	private void Awake()
	{
		GameModePages.gameModeSelectorInstances.Add(this);
		this.buttons = base.GetComponentsInChildren<GameModeSelectButton>();
		for (int i = 0; i < this.buttons.Length; i++)
		{
			this.buttons[i].buttonIndex = i;
			this.buttons[i].selector = this;
		}
	}

	// Token: 0x06001175 RID: 4469 RVA: 0x0005C08B File Offset: 0x0005A28B
	protected override void Start()
	{
		base.Start();
		base.SelectEntryFromIndex(GameModePages.sharedSelectedIndex);
		this.initialized = true;
	}

	// Token: 0x06001176 RID: 4470 RVA: 0x0005C0A5 File Offset: 0x0005A2A5
	private void OnEnable()
	{
		if (this.initialized)
		{
			base.SelectEntryFromIndex(GameModePages.sharedSelectedIndex);
		}
	}

	// Token: 0x06001177 RID: 4471 RVA: 0x0005C0BA File Offset: 0x0005A2BA
	private void OnDestroy()
	{
		GameModePages.gameModeSelectorInstances.Remove(this);
	}

	// Token: 0x06001178 RID: 4472 RVA: 0x0005C0C8 File Offset: 0x0005A2C8
	protected override void ShowPage(int selectedPage, int startIndex, int endIndex)
	{
		GameModePages.textBuilder.Clear();
		for (int i = startIndex; i < endIndex; i++)
		{
			GameModePages.textBuilder.AppendLine(GameMode.gameModeNames[i]);
		}
		this.gameModeText.text = GameModePages.textBuilder.ToString();
		if (base.selectedIndex >= startIndex && base.selectedIndex <= endIndex)
		{
			this.UpdateAllButtons(this.currentButtonIndex);
		}
		else
		{
			this.UpdateAllButtons(-1);
		}
		int buttonsMissing = (selectedPage == base.pages - 1 && base.maxEntires > endIndex) ? (base.maxEntires - endIndex) : 0;
		this.EnableEntryButtons(buttonsMissing);
	}

	// Token: 0x06001179 RID: 4473 RVA: 0x0005C165 File Offset: 0x0005A365
	protected override void PageEntrySelected(int pageEntry, int selectionIndex)
	{
		if (selectionIndex >= this.entriesCount)
		{
			return;
		}
		GameModePages.sharedSelectedIndex = selectionIndex;
		this.UpdateAllButtons(pageEntry);
		this.currentButtonIndex = pageEntry;
		GorillaComputer.instance.OnModeSelectButtonPress(GameMode.gameModeNames[selectionIndex], false);
	}

	// Token: 0x0600117A RID: 4474 RVA: 0x0005C1A0 File Offset: 0x0005A3A0
	private void UpdateAllButtons(int onButton)
	{
		for (int i = 0; i < this.buttons.Length; i++)
		{
			if (i == onButton)
			{
				this.buttons[onButton].isOn = true;
				this.buttons[onButton].UpdateColor();
			}
			else if (this.buttons[i].isOn)
			{
				this.buttons[i].isOn = false;
				this.buttons[i].UpdateColor();
			}
		}
	}

	// Token: 0x0600117B RID: 4475 RVA: 0x0005C20C File Offset: 0x0005A40C
	private void EnableEntryButtons(int buttonsMissing)
	{
		int num = this.buttons.Length - buttonsMissing;
		int i;
		for (i = 0; i < num; i++)
		{
			this.buttons[i].gameObject.SetActive(true);
		}
		while (i < this.buttons.Length)
		{
			this.buttons[i].gameObject.SetActive(false);
			i++;
		}
	}

	// Token: 0x0600117C RID: 4476 RVA: 0x0005C268 File Offset: 0x0005A468
	public static void SetSelectedGameModeShared(string gameMode)
	{
		GameModePages.sharedSelectedIndex = GameMode.gameModeNames.IndexOf(gameMode);
		if (GameModePages.sharedSelectedIndex < 0)
		{
			return;
		}
		for (int i = 0; i < GameModePages.gameModeSelectorInstances.Count; i++)
		{
			GameModePages.gameModeSelectorInstances[i].SelectEntryFromIndex(GameModePages.sharedSelectedIndex);
		}
	}

	// Token: 0x040013CD RID: 5069
	private int currentButtonIndex;

	// Token: 0x040013CE RID: 5070
	private int maxEntries;

	// Token: 0x040013CF RID: 5071
	[SerializeField]
	private Text gameModeText;

	// Token: 0x040013D0 RID: 5072
	[SerializeField]
	private GameModeSelectButton[] buttons;

	// Token: 0x040013D1 RID: 5073
	private bool initialized;

	// Token: 0x040013D2 RID: 5074
	private static int sharedSelectedIndex = 0;

	// Token: 0x040013D3 RID: 5075
	private static StringBuilder textBuilder = new StringBuilder(50);

	// Token: 0x040013D4 RID: 5076
	[OnEnterPlay_Clear]
	private static List<GameModePages> gameModeSelectorInstances = new List<GameModePages>(7);
}
