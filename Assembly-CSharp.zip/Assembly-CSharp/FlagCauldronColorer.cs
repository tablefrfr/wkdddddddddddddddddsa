﻿using System;
using UnityEngine;

// Token: 0x020000AB RID: 171
public class FlagCauldronColorer : MonoBehaviour
{
	// Token: 0x040004A7 RID: 1191
	public FlagCauldronColorer.ColorMode mode;

	// Token: 0x040004A8 RID: 1192
	public Transform colorPoint;

	// Token: 0x020000AC RID: 172
	public enum ColorMode
	{
		// Token: 0x040004AA RID: 1194
		None,
		// Token: 0x040004AB RID: 1195
		Red,
		// Token: 0x040004AC RID: 1196
		Green,
		// Token: 0x040004AD RID: 1197
		Blue,
		// Token: 0x040004AE RID: 1198
		Black,
		// Token: 0x040004AF RID: 1199
		Clear
	}
}
