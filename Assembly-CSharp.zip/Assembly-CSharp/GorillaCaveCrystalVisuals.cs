﻿using System;
using GorillaTagScripts;
using UnityEngine;

// Token: 0x02000367 RID: 871
public class GorillaCaveCrystalVisuals : MonoBehaviour
{
	// Token: 0x1700020B RID: 523
	// (get) Token: 0x060013DA RID: 5082 RVA: 0x000689EF File Offset: 0x00066BEF
	// (set) Token: 0x060013DB RID: 5083 RVA: 0x000689F7 File Offset: 0x00066BF7
	public float lerp
	{
		get
		{
			return this._lerp;
		}
		set
		{
			this._lerp = value;
		}
	}

	// Token: 0x060013DC RID: 5084 RVA: 0x00068A00 File Offset: 0x00066C00
	public void Setup()
	{
		base.TryGetComponent<MeshRenderer>(out this._renderer);
		if (this._renderer == null)
		{
			return;
		}
		this._setup = GorillaCaveCrystalSetup.Instance;
		this._sharedMaterial = this._renderer.sharedMaterial;
		this._initialized = (this.crysalPreset != null && this._renderer != null && this._sharedMaterial != null);
		this.Update();
	}

	// Token: 0x060013DD RID: 5085 RVA: 0x00068A7C File Offset: 0x00066C7C
	private void Start()
	{
		this.UpdateAlbedo();
		this.ForceUpdate();
	}

	// Token: 0x060013DE RID: 5086 RVA: 0x00068A8C File Offset: 0x00066C8C
	public void UpdateAlbedo()
	{
		if (!this._initialized)
		{
			return;
		}
		if (this.instanceAlbedo == null)
		{
			return;
		}
		if (this._block == null)
		{
			this._block = new MaterialPropertyBlock();
		}
		this._renderer.GetPropertyBlock(this._block);
		this._block.SetTexture(ShaderIds._MainTex, this.instanceAlbedo);
		this._renderer.SetPropertyBlock(this._block);
	}

	// Token: 0x060013DF RID: 5087 RVA: 0x00068AFC File Offset: 0x00066CFC
	private void Awake()
	{
		this.UpdateAlbedo();
		this.Update();
	}

	// Token: 0x060013E0 RID: 5088 RVA: 0x00068B0C File Offset: 0x00066D0C
	private void Update()
	{
		if (!this._initialized)
		{
			return;
		}
		if (Application.isPlaying)
		{
			int hashCode = new ValueTuple<CrystalVisualsPreset, float>(this.crysalPreset, this._lerp).GetHashCode();
			if (this._lastState == hashCode)
			{
				return;
			}
			this._lastState = hashCode;
		}
		if (this._block == null)
		{
			this._block = new MaterialPropertyBlock();
		}
		CrystalVisualsPreset.VisualState stateA = this.crysalPreset.stateA;
		CrystalVisualsPreset.VisualState stateB = this.crysalPreset.stateB;
		Color value = Color.Lerp(stateA.albedo, stateB.albedo, this._lerp);
		Color value2 = Color.Lerp(stateA.emission, stateB.emission, this._lerp);
		this._renderer.GetPropertyBlock(this._block);
		this._block.SetColor(ShaderIds._Color, value);
		this._block.SetColor(ShaderIds._EmissionColor, value2);
		this._renderer.SetPropertyBlock(this._block);
	}

	// Token: 0x060013E1 RID: 5089 RVA: 0x00068BF8 File Offset: 0x00066DF8
	public void ForceUpdate()
	{
		this._lastState = 0;
		this.Update();
	}

	// Token: 0x060013E2 RID: 5090 RVA: 0x00068C08 File Offset: 0x00066E08
	private static void InitializeCrystals()
	{
		foreach (GorillaCaveCrystalVisuals gorillaCaveCrystalVisuals in Object.FindObjectsByType<GorillaCaveCrystalVisuals>(FindObjectsInactive.Include, FindObjectsSortMode.InstanceID))
		{
			gorillaCaveCrystalVisuals.UpdateAlbedo();
			gorillaCaveCrystalVisuals.ForceUpdate();
			gorillaCaveCrystalVisuals._lastState = -1;
		}
	}

	// Token: 0x040016A8 RID: 5800
	public CrystalVisualsPreset crysalPreset;

	// Token: 0x040016A9 RID: 5801
	[SerializeField]
	[Range(0f, 1f)]
	private float _lerp;

	// Token: 0x040016AA RID: 5802
	[Space]
	public MeshRenderer _renderer;

	// Token: 0x040016AB RID: 5803
	public Material _sharedMaterial;

	// Token: 0x040016AC RID: 5804
	[SerializeField]
	public Texture2D instanceAlbedo;

	// Token: 0x040016AD RID: 5805
	[SerializeField]
	private bool _initialized;

	// Token: 0x040016AE RID: 5806
	[SerializeField]
	private int _lastState;

	// Token: 0x040016AF RID: 5807
	[SerializeField]
	public GorillaCaveCrystalSetup _setup;

	// Token: 0x040016B0 RID: 5808
	private MaterialPropertyBlock _block;

	// Token: 0x040016B1 RID: 5809
	[NonSerialized]
	private bool _ranSetupOnce;
}
