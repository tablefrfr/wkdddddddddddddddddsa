﻿using System;
using UnityEngine;

// Token: 0x02000369 RID: 873
public abstract class GorillaColorizableBase : MonoBehaviour
{
	// Token: 0x060013E5 RID: 5093
	public abstract void SetColor(Color color);
}
