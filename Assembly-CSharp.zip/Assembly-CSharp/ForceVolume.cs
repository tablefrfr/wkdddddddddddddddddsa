﻿using System;
using GorillaLocomotion;
using UnityEngine;

// Token: 0x02000450 RID: 1104
public class ForceVolume : MonoBehaviour
{
	// Token: 0x060019B5 RID: 6581 RVA: 0x00082E96 File Offset: 0x00081096
	private void Awake()
	{
		this.volume = base.GetComponent<Collider>();
		this.audioState = ForceVolume.AudioState.None;
	}

	// Token: 0x060019B6 RID: 6582 RVA: 0x00082EAC File Offset: 0x000810AC
	private void LateUpdate()
	{
		if (this.audioSource && this.audioSource != null && !this.audioSource.isPlaying && this.audioSource.enabled)
		{
			this.audioSource.enabled = false;
		}
	}

	// Token: 0x060019B7 RID: 6583 RVA: 0x00082EFC File Offset: 0x000810FC
	private bool TriggerFilter(Collider other, out Rigidbody rb, out Transform xf)
	{
		rb = null;
		xf = null;
		if (other.gameObject == GorillaTagger.Instance.headCollider.gameObject)
		{
			rb = GorillaTagger.Instance.GetComponent<Rigidbody>();
			xf = GorillaTagger.Instance.headCollider.GetComponent<Transform>();
		}
		return rb != null && xf != null;
	}

	// Token: 0x060019B8 RID: 6584 RVA: 0x00082F5C File Offset: 0x0008115C
	public void OnTriggerEnter(Collider other)
	{
		Rigidbody rigidbody = null;
		Transform transform = null;
		if (!this.TriggerFilter(other, out rigidbody, out transform))
		{
			return;
		}
		if (this.enterClip == null)
		{
			return;
		}
		if (this.audioSource)
		{
			this.audioSource.enabled = true;
			this.audioSource.PlayOneShot(this.enterClip);
			this.audioState = ForceVolume.AudioState.Enter;
		}
		this.enterPos = transform.position;
	}

	// Token: 0x060019B9 RID: 6585 RVA: 0x00082FC8 File Offset: 0x000811C8
	public void OnTriggerExit(Collider other)
	{
		Rigidbody rigidbody = null;
		Transform transform = null;
		if (!this.TriggerFilter(other, out rigidbody, out transform))
		{
			return;
		}
		if (this.audioSource)
		{
			this.audioSource.enabled = true;
			this.audioSource.PlayOneShot(this.exitClip);
			this.audioState = ForceVolume.AudioState.None;
		}
	}

	// Token: 0x060019BA RID: 6586 RVA: 0x00083018 File Offset: 0x00081218
	public void OnTriggerStay(Collider other)
	{
		Rigidbody rigidbody = null;
		Transform transform = null;
		if (!this.TriggerFilter(other, out rigidbody, out transform))
		{
			return;
		}
		if (this.audioSource && !this.audioSource.isPlaying)
		{
			ForceVolume.AudioState audioState = this.audioState;
			if (audioState != ForceVolume.AudioState.Enter)
			{
				if (audioState == ForceVolume.AudioState.Loop)
				{
					if (this.loopClip != null)
					{
						this.audioSource.enabled = true;
						this.audioSource.PlayOneShot(this.loopClip);
					}
					this.audioState = ForceVolume.AudioState.Loop;
				}
			}
			else
			{
				if (this.loopCresendoClip != null)
				{
					this.audioSource.enabled = true;
					this.audioSource.PlayOneShot(this.loopCresendoClip);
				}
				this.audioState = ForceVolume.AudioState.Crescendo;
			}
		}
		if (this.disableGrip)
		{
			Player.Instance.SetMaximumSlipThisFrame();
		}
		SizeManager sizeManager = null;
		if (this.scaleWithSize)
		{
			sizeManager = rigidbody.GetComponent<SizeManager>();
		}
		Vector3 vector = rigidbody.velocity;
		if (this.scaleWithSize && sizeManager)
		{
			vector /= sizeManager.currentScale;
		}
		Vector3 b = Vector3.Dot(transform.position - base.transform.position, base.transform.up) * base.transform.up;
		Vector3 a = base.transform.position + b - transform.position;
		float num = a.magnitude + 0.0001f;
		Vector3 vector2 = a / num;
		float num2 = Vector3.Dot(vector, vector2);
		float d = this.accel;
		if (this.maxDepth > -1f)
		{
			float num3 = Vector3.Dot(transform.position - this.enterPos, vector2);
			float num4 = this.maxDepth - num3;
			float b2 = 0f;
			if (num4 > 0.0001f)
			{
				b2 = num2 * num2 / num4;
			}
			d = Mathf.Max(this.accel, b2);
		}
		float deltaTime = Time.deltaTime;
		Vector3 b3 = base.transform.up * d * deltaTime;
		vector += b3;
		Vector3 a2 = Mathf.Min(Vector3.Dot(vector, base.transform.up), this.maxSpeed) * base.transform.up;
		Vector3 a3 = Vector3.Dot(vector, base.transform.right) * base.transform.right;
		Vector3 a4 = Vector3.Dot(vector, base.transform.forward) * base.transform.forward;
		float d2 = 1f;
		float d3 = 1f;
		if (this.dampenLateralVelocity)
		{
			d2 = 1f - this.dampenXVelPerc * 0.01f * deltaTime;
			d3 = 1f - this.dampenZVelPerc * 0.01f * deltaTime;
		}
		vector = a2 + d2 * a3 + d3 * a4;
		if (this.applyPullToCenterAcceleration && this.pullToCenterAccel > 0f && this.pullToCenterMaxSpeed > 0f)
		{
			vector -= num2 * vector2;
			if (num > this.pullTOCenterMinDistance)
			{
				num2 += this.pullToCenterAccel * deltaTime;
				float b4 = Mathf.Min(this.pullToCenterMaxSpeed, num / deltaTime);
				num2 = Mathf.Min(num2, b4);
			}
			else
			{
				num2 = 0f;
			}
			vector += num2 * vector2;
			if (vector.magnitude > 0.0001f)
			{
				Vector3 vector3 = Vector3.Cross(base.transform.up, vector2);
				float magnitude = vector3.magnitude;
				if (magnitude > 0.0001f)
				{
					vector3 /= magnitude;
					num2 = Vector3.Dot(vector, vector3);
					vector -= num2 * vector3;
					num2 -= this.pullToCenterAccel * deltaTime;
					num2 = Mathf.Max(0f, num2);
					vector += num2 * vector3;
				}
			}
		}
		if (this.scaleWithSize && sizeManager)
		{
			vector *= sizeManager.currentScale;
		}
		rigidbody.velocity = vector;
	}

	// Token: 0x060019BB RID: 6587 RVA: 0x00083424 File Offset: 0x00081624
	public void OnDrawGizmosSelected()
	{
		base.GetComponents<Collider>();
		Gizmos.color = Color.magenta;
		Gizmos.matrix = base.transform.localToWorldMatrix;
		Gizmos.DrawWireCube(Vector3.zero, new Vector3(this.pullTOCenterMinDistance / base.transform.lossyScale.x, 1f, this.pullTOCenterMinDistance / base.transform.lossyScale.z));
	}

	// Token: 0x04001D5B RID: 7515
	[SerializeField]
	public bool scaleWithSize = true;

	// Token: 0x04001D5C RID: 7516
	[SerializeField]
	private float accel;

	// Token: 0x04001D5D RID: 7517
	[SerializeField]
	private float maxDepth = -1f;

	// Token: 0x04001D5E RID: 7518
	[SerializeField]
	private float maxSpeed;

	// Token: 0x04001D5F RID: 7519
	[SerializeField]
	private bool disableGrip;

	// Token: 0x04001D60 RID: 7520
	[SerializeField]
	private bool dampenLateralVelocity = true;

	// Token: 0x04001D61 RID: 7521
	[SerializeField]
	private float dampenXVelPerc;

	// Token: 0x04001D62 RID: 7522
	[SerializeField]
	private float dampenZVelPerc;

	// Token: 0x04001D63 RID: 7523
	[SerializeField]
	private bool applyPullToCenterAcceleration = true;

	// Token: 0x04001D64 RID: 7524
	[SerializeField]
	private float pullToCenterAccel;

	// Token: 0x04001D65 RID: 7525
	[SerializeField]
	private float pullToCenterMaxSpeed;

	// Token: 0x04001D66 RID: 7526
	[SerializeField]
	private float pullTOCenterMinDistance = 0.1f;

	// Token: 0x04001D67 RID: 7527
	private Collider volume;

	// Token: 0x04001D68 RID: 7528
	public AudioClip enterClip;

	// Token: 0x04001D69 RID: 7529
	public AudioClip exitClip;

	// Token: 0x04001D6A RID: 7530
	public AudioClip loopClip;

	// Token: 0x04001D6B RID: 7531
	public AudioClip loopCresendoClip;

	// Token: 0x04001D6C RID: 7532
	public AudioSource audioSource;

	// Token: 0x04001D6D RID: 7533
	private Vector3 enterPos;

	// Token: 0x04001D6E RID: 7534
	private ForceVolume.AudioState audioState;

	// Token: 0x02000451 RID: 1105
	private enum AudioState
	{
		// Token: 0x04001D70 RID: 7536
		None,
		// Token: 0x04001D71 RID: 7537
		Enter,
		// Token: 0x04001D72 RID: 7538
		Crescendo,
		// Token: 0x04001D73 RID: 7539
		Loop,
		// Token: 0x04001D74 RID: 7540
		Exit
	}
}
