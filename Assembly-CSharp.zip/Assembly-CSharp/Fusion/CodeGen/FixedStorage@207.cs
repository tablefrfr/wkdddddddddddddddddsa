﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace Fusion.CodeGen
{
	// Token: 0x02000846 RID: 2118
	[NetworkStructWeaved(207)]
	[Serializable]
	[StructLayout(LayoutKind.Explicit)]
	internal struct FixedStorage@207 : INetworkStruct
	{
		// Token: 0x04003582 RID: 13698
		[FixedBuffer(typeof(int), 207)]
		[FieldOffset(0)]
		public FixedStorage@207.<Data>e__FixedBuffer Data;

		// Token: 0x04003583 RID: 13699
		[NonSerialized]
		[FieldOffset(4)]
		private int _1;

		// Token: 0x04003584 RID: 13700
		[NonSerialized]
		[FieldOffset(8)]
		private int _2;

		// Token: 0x04003585 RID: 13701
		[NonSerialized]
		[FieldOffset(12)]
		private int _3;

		// Token: 0x04003586 RID: 13702
		[NonSerialized]
		[FieldOffset(16)]
		private int _4;

		// Token: 0x04003587 RID: 13703
		[NonSerialized]
		[FieldOffset(20)]
		private int _5;

		// Token: 0x04003588 RID: 13704
		[NonSerialized]
		[FieldOffset(24)]
		private int _6;

		// Token: 0x04003589 RID: 13705
		[NonSerialized]
		[FieldOffset(28)]
		private int _7;

		// Token: 0x0400358A RID: 13706
		[NonSerialized]
		[FieldOffset(32)]
		private int _8;

		// Token: 0x0400358B RID: 13707
		[NonSerialized]
		[FieldOffset(36)]
		private int _9;

		// Token: 0x0400358C RID: 13708
		[NonSerialized]
		[FieldOffset(40)]
		private int _10;

		// Token: 0x0400358D RID: 13709
		[NonSerialized]
		[FieldOffset(44)]
		private int _11;

		// Token: 0x0400358E RID: 13710
		[NonSerialized]
		[FieldOffset(48)]
		private int _12;

		// Token: 0x0400358F RID: 13711
		[NonSerialized]
		[FieldOffset(52)]
		private int _13;

		// Token: 0x04003590 RID: 13712
		[NonSerialized]
		[FieldOffset(56)]
		private int _14;

		// Token: 0x04003591 RID: 13713
		[NonSerialized]
		[FieldOffset(60)]
		private int _15;

		// Token: 0x04003592 RID: 13714
		[NonSerialized]
		[FieldOffset(64)]
		private int _16;

		// Token: 0x04003593 RID: 13715
		[NonSerialized]
		[FieldOffset(68)]
		private int _17;

		// Token: 0x04003594 RID: 13716
		[NonSerialized]
		[FieldOffset(72)]
		private int _18;

		// Token: 0x04003595 RID: 13717
		[NonSerialized]
		[FieldOffset(76)]
		private int _19;

		// Token: 0x04003596 RID: 13718
		[NonSerialized]
		[FieldOffset(80)]
		private int _20;

		// Token: 0x04003597 RID: 13719
		[NonSerialized]
		[FieldOffset(84)]
		private int _21;

		// Token: 0x04003598 RID: 13720
		[NonSerialized]
		[FieldOffset(88)]
		private int _22;

		// Token: 0x04003599 RID: 13721
		[NonSerialized]
		[FieldOffset(92)]
		private int _23;

		// Token: 0x0400359A RID: 13722
		[NonSerialized]
		[FieldOffset(96)]
		private int _24;

		// Token: 0x0400359B RID: 13723
		[NonSerialized]
		[FieldOffset(100)]
		private int _25;

		// Token: 0x0400359C RID: 13724
		[NonSerialized]
		[FieldOffset(104)]
		private int _26;

		// Token: 0x0400359D RID: 13725
		[NonSerialized]
		[FieldOffset(108)]
		private int _27;

		// Token: 0x0400359E RID: 13726
		[NonSerialized]
		[FieldOffset(112)]
		private int _28;

		// Token: 0x0400359F RID: 13727
		[NonSerialized]
		[FieldOffset(116)]
		private int _29;

		// Token: 0x040035A0 RID: 13728
		[NonSerialized]
		[FieldOffset(120)]
		private int _30;

		// Token: 0x040035A1 RID: 13729
		[NonSerialized]
		[FieldOffset(124)]
		private int _31;

		// Token: 0x040035A2 RID: 13730
		[NonSerialized]
		[FieldOffset(128)]
		private int _32;

		// Token: 0x040035A3 RID: 13731
		[NonSerialized]
		[FieldOffset(132)]
		private int _33;

		// Token: 0x040035A4 RID: 13732
		[NonSerialized]
		[FieldOffset(136)]
		private int _34;

		// Token: 0x040035A5 RID: 13733
		[NonSerialized]
		[FieldOffset(140)]
		private int _35;

		// Token: 0x040035A6 RID: 13734
		[NonSerialized]
		[FieldOffset(144)]
		private int _36;

		// Token: 0x040035A7 RID: 13735
		[NonSerialized]
		[FieldOffset(148)]
		private int _37;

		// Token: 0x040035A8 RID: 13736
		[NonSerialized]
		[FieldOffset(152)]
		private int _38;

		// Token: 0x040035A9 RID: 13737
		[NonSerialized]
		[FieldOffset(156)]
		private int _39;

		// Token: 0x040035AA RID: 13738
		[NonSerialized]
		[FieldOffset(160)]
		private int _40;

		// Token: 0x040035AB RID: 13739
		[NonSerialized]
		[FieldOffset(164)]
		private int _41;

		// Token: 0x040035AC RID: 13740
		[NonSerialized]
		[FieldOffset(168)]
		private int _42;

		// Token: 0x040035AD RID: 13741
		[NonSerialized]
		[FieldOffset(172)]
		private int _43;

		// Token: 0x040035AE RID: 13742
		[NonSerialized]
		[FieldOffset(176)]
		private int _44;

		// Token: 0x040035AF RID: 13743
		[NonSerialized]
		[FieldOffset(180)]
		private int _45;

		// Token: 0x040035B0 RID: 13744
		[NonSerialized]
		[FieldOffset(184)]
		private int _46;

		// Token: 0x040035B1 RID: 13745
		[NonSerialized]
		[FieldOffset(188)]
		private int _47;

		// Token: 0x040035B2 RID: 13746
		[NonSerialized]
		[FieldOffset(192)]
		private int _48;

		// Token: 0x040035B3 RID: 13747
		[NonSerialized]
		[FieldOffset(196)]
		private int _49;

		// Token: 0x040035B4 RID: 13748
		[NonSerialized]
		[FieldOffset(200)]
		private int _50;

		// Token: 0x040035B5 RID: 13749
		[NonSerialized]
		[FieldOffset(204)]
		private int _51;

		// Token: 0x040035B6 RID: 13750
		[NonSerialized]
		[FieldOffset(208)]
		private int _52;

		// Token: 0x040035B7 RID: 13751
		[NonSerialized]
		[FieldOffset(212)]
		private int _53;

		// Token: 0x040035B8 RID: 13752
		[NonSerialized]
		[FieldOffset(216)]
		private int _54;

		// Token: 0x040035B9 RID: 13753
		[NonSerialized]
		[FieldOffset(220)]
		private int _55;

		// Token: 0x040035BA RID: 13754
		[NonSerialized]
		[FieldOffset(224)]
		private int _56;

		// Token: 0x040035BB RID: 13755
		[NonSerialized]
		[FieldOffset(228)]
		private int _57;

		// Token: 0x040035BC RID: 13756
		[NonSerialized]
		[FieldOffset(232)]
		private int _58;

		// Token: 0x040035BD RID: 13757
		[NonSerialized]
		[FieldOffset(236)]
		private int _59;

		// Token: 0x040035BE RID: 13758
		[NonSerialized]
		[FieldOffset(240)]
		private int _60;

		// Token: 0x040035BF RID: 13759
		[NonSerialized]
		[FieldOffset(244)]
		private int _61;

		// Token: 0x040035C0 RID: 13760
		[NonSerialized]
		[FieldOffset(248)]
		private int _62;

		// Token: 0x040035C1 RID: 13761
		[NonSerialized]
		[FieldOffset(252)]
		private int _63;

		// Token: 0x040035C2 RID: 13762
		[NonSerialized]
		[FieldOffset(256)]
		private int _64;

		// Token: 0x040035C3 RID: 13763
		[NonSerialized]
		[FieldOffset(260)]
		private int _65;

		// Token: 0x040035C4 RID: 13764
		[NonSerialized]
		[FieldOffset(264)]
		private int _66;

		// Token: 0x040035C5 RID: 13765
		[NonSerialized]
		[FieldOffset(268)]
		private int _67;

		// Token: 0x040035C6 RID: 13766
		[NonSerialized]
		[FieldOffset(272)]
		private int _68;

		// Token: 0x040035C7 RID: 13767
		[NonSerialized]
		[FieldOffset(276)]
		private int _69;

		// Token: 0x040035C8 RID: 13768
		[NonSerialized]
		[FieldOffset(280)]
		private int _70;

		// Token: 0x040035C9 RID: 13769
		[NonSerialized]
		[FieldOffset(284)]
		private int _71;

		// Token: 0x040035CA RID: 13770
		[NonSerialized]
		[FieldOffset(288)]
		private int _72;

		// Token: 0x040035CB RID: 13771
		[NonSerialized]
		[FieldOffset(292)]
		private int _73;

		// Token: 0x040035CC RID: 13772
		[NonSerialized]
		[FieldOffset(296)]
		private int _74;

		// Token: 0x040035CD RID: 13773
		[NonSerialized]
		[FieldOffset(300)]
		private int _75;

		// Token: 0x040035CE RID: 13774
		[NonSerialized]
		[FieldOffset(304)]
		private int _76;

		// Token: 0x040035CF RID: 13775
		[NonSerialized]
		[FieldOffset(308)]
		private int _77;

		// Token: 0x040035D0 RID: 13776
		[NonSerialized]
		[FieldOffset(312)]
		private int _78;

		// Token: 0x040035D1 RID: 13777
		[NonSerialized]
		[FieldOffset(316)]
		private int _79;

		// Token: 0x040035D2 RID: 13778
		[NonSerialized]
		[FieldOffset(320)]
		private int _80;

		// Token: 0x040035D3 RID: 13779
		[NonSerialized]
		[FieldOffset(324)]
		private int _81;

		// Token: 0x040035D4 RID: 13780
		[NonSerialized]
		[FieldOffset(328)]
		private int _82;

		// Token: 0x040035D5 RID: 13781
		[NonSerialized]
		[FieldOffset(332)]
		private int _83;

		// Token: 0x040035D6 RID: 13782
		[NonSerialized]
		[FieldOffset(336)]
		private int _84;

		// Token: 0x040035D7 RID: 13783
		[NonSerialized]
		[FieldOffset(340)]
		private int _85;

		// Token: 0x040035D8 RID: 13784
		[NonSerialized]
		[FieldOffset(344)]
		private int _86;

		// Token: 0x040035D9 RID: 13785
		[NonSerialized]
		[FieldOffset(348)]
		private int _87;

		// Token: 0x040035DA RID: 13786
		[NonSerialized]
		[FieldOffset(352)]
		private int _88;

		// Token: 0x040035DB RID: 13787
		[NonSerialized]
		[FieldOffset(356)]
		private int _89;

		// Token: 0x040035DC RID: 13788
		[NonSerialized]
		[FieldOffset(360)]
		private int _90;

		// Token: 0x040035DD RID: 13789
		[NonSerialized]
		[FieldOffset(364)]
		private int _91;

		// Token: 0x040035DE RID: 13790
		[NonSerialized]
		[FieldOffset(368)]
		private int _92;

		// Token: 0x040035DF RID: 13791
		[NonSerialized]
		[FieldOffset(372)]
		private int _93;

		// Token: 0x040035E0 RID: 13792
		[NonSerialized]
		[FieldOffset(376)]
		private int _94;

		// Token: 0x040035E1 RID: 13793
		[NonSerialized]
		[FieldOffset(380)]
		private int _95;

		// Token: 0x040035E2 RID: 13794
		[NonSerialized]
		[FieldOffset(384)]
		private int _96;

		// Token: 0x040035E3 RID: 13795
		[NonSerialized]
		[FieldOffset(388)]
		private int _97;

		// Token: 0x040035E4 RID: 13796
		[NonSerialized]
		[FieldOffset(392)]
		private int _98;

		// Token: 0x040035E5 RID: 13797
		[NonSerialized]
		[FieldOffset(396)]
		private int _99;

		// Token: 0x040035E6 RID: 13798
		[NonSerialized]
		[FieldOffset(400)]
		private int _100;

		// Token: 0x040035E7 RID: 13799
		[NonSerialized]
		[FieldOffset(404)]
		private int _101;

		// Token: 0x040035E8 RID: 13800
		[NonSerialized]
		[FieldOffset(408)]
		private int _102;

		// Token: 0x040035E9 RID: 13801
		[NonSerialized]
		[FieldOffset(412)]
		private int _103;

		// Token: 0x040035EA RID: 13802
		[NonSerialized]
		[FieldOffset(416)]
		private int _104;

		// Token: 0x040035EB RID: 13803
		[NonSerialized]
		[FieldOffset(420)]
		private int _105;

		// Token: 0x040035EC RID: 13804
		[NonSerialized]
		[FieldOffset(424)]
		private int _106;

		// Token: 0x040035ED RID: 13805
		[NonSerialized]
		[FieldOffset(428)]
		private int _107;

		// Token: 0x040035EE RID: 13806
		[NonSerialized]
		[FieldOffset(432)]
		private int _108;

		// Token: 0x040035EF RID: 13807
		[NonSerialized]
		[FieldOffset(436)]
		private int _109;

		// Token: 0x040035F0 RID: 13808
		[NonSerialized]
		[FieldOffset(440)]
		private int _110;

		// Token: 0x040035F1 RID: 13809
		[NonSerialized]
		[FieldOffset(444)]
		private int _111;

		// Token: 0x040035F2 RID: 13810
		[NonSerialized]
		[FieldOffset(448)]
		private int _112;

		// Token: 0x040035F3 RID: 13811
		[NonSerialized]
		[FieldOffset(452)]
		private int _113;

		// Token: 0x040035F4 RID: 13812
		[NonSerialized]
		[FieldOffset(456)]
		private int _114;

		// Token: 0x040035F5 RID: 13813
		[NonSerialized]
		[FieldOffset(460)]
		private int _115;

		// Token: 0x040035F6 RID: 13814
		[NonSerialized]
		[FieldOffset(464)]
		private int _116;

		// Token: 0x040035F7 RID: 13815
		[NonSerialized]
		[FieldOffset(468)]
		private int _117;

		// Token: 0x040035F8 RID: 13816
		[NonSerialized]
		[FieldOffset(472)]
		private int _118;

		// Token: 0x040035F9 RID: 13817
		[NonSerialized]
		[FieldOffset(476)]
		private int _119;

		// Token: 0x040035FA RID: 13818
		[NonSerialized]
		[FieldOffset(480)]
		private int _120;

		// Token: 0x040035FB RID: 13819
		[NonSerialized]
		[FieldOffset(484)]
		private int _121;

		// Token: 0x040035FC RID: 13820
		[NonSerialized]
		[FieldOffset(488)]
		private int _122;

		// Token: 0x040035FD RID: 13821
		[NonSerialized]
		[FieldOffset(492)]
		private int _123;

		// Token: 0x040035FE RID: 13822
		[NonSerialized]
		[FieldOffset(496)]
		private int _124;

		// Token: 0x040035FF RID: 13823
		[NonSerialized]
		[FieldOffset(500)]
		private int _125;

		// Token: 0x04003600 RID: 13824
		[NonSerialized]
		[FieldOffset(504)]
		private int _126;

		// Token: 0x04003601 RID: 13825
		[NonSerialized]
		[FieldOffset(508)]
		private int _127;

		// Token: 0x04003602 RID: 13826
		[NonSerialized]
		[FieldOffset(512)]
		private int _128;

		// Token: 0x04003603 RID: 13827
		[NonSerialized]
		[FieldOffset(516)]
		private int _129;

		// Token: 0x04003604 RID: 13828
		[NonSerialized]
		[FieldOffset(520)]
		private int _130;

		// Token: 0x04003605 RID: 13829
		[NonSerialized]
		[FieldOffset(524)]
		private int _131;

		// Token: 0x04003606 RID: 13830
		[NonSerialized]
		[FieldOffset(528)]
		private int _132;

		// Token: 0x04003607 RID: 13831
		[NonSerialized]
		[FieldOffset(532)]
		private int _133;

		// Token: 0x04003608 RID: 13832
		[NonSerialized]
		[FieldOffset(536)]
		private int _134;

		// Token: 0x04003609 RID: 13833
		[NonSerialized]
		[FieldOffset(540)]
		private int _135;

		// Token: 0x0400360A RID: 13834
		[NonSerialized]
		[FieldOffset(544)]
		private int _136;

		// Token: 0x0400360B RID: 13835
		[NonSerialized]
		[FieldOffset(548)]
		private int _137;

		// Token: 0x0400360C RID: 13836
		[NonSerialized]
		[FieldOffset(552)]
		private int _138;

		// Token: 0x0400360D RID: 13837
		[NonSerialized]
		[FieldOffset(556)]
		private int _139;

		// Token: 0x0400360E RID: 13838
		[NonSerialized]
		[FieldOffset(560)]
		private int _140;

		// Token: 0x0400360F RID: 13839
		[NonSerialized]
		[FieldOffset(564)]
		private int _141;

		// Token: 0x04003610 RID: 13840
		[NonSerialized]
		[FieldOffset(568)]
		private int _142;

		// Token: 0x04003611 RID: 13841
		[NonSerialized]
		[FieldOffset(572)]
		private int _143;

		// Token: 0x04003612 RID: 13842
		[NonSerialized]
		[FieldOffset(576)]
		private int _144;

		// Token: 0x04003613 RID: 13843
		[NonSerialized]
		[FieldOffset(580)]
		private int _145;

		// Token: 0x04003614 RID: 13844
		[NonSerialized]
		[FieldOffset(584)]
		private int _146;

		// Token: 0x04003615 RID: 13845
		[NonSerialized]
		[FieldOffset(588)]
		private int _147;

		// Token: 0x04003616 RID: 13846
		[NonSerialized]
		[FieldOffset(592)]
		private int _148;

		// Token: 0x04003617 RID: 13847
		[NonSerialized]
		[FieldOffset(596)]
		private int _149;

		// Token: 0x04003618 RID: 13848
		[NonSerialized]
		[FieldOffset(600)]
		private int _150;

		// Token: 0x04003619 RID: 13849
		[NonSerialized]
		[FieldOffset(604)]
		private int _151;

		// Token: 0x0400361A RID: 13850
		[NonSerialized]
		[FieldOffset(608)]
		private int _152;

		// Token: 0x0400361B RID: 13851
		[NonSerialized]
		[FieldOffset(612)]
		private int _153;

		// Token: 0x0400361C RID: 13852
		[NonSerialized]
		[FieldOffset(616)]
		private int _154;

		// Token: 0x0400361D RID: 13853
		[NonSerialized]
		[FieldOffset(620)]
		private int _155;

		// Token: 0x0400361E RID: 13854
		[NonSerialized]
		[FieldOffset(624)]
		private int _156;

		// Token: 0x0400361F RID: 13855
		[NonSerialized]
		[FieldOffset(628)]
		private int _157;

		// Token: 0x04003620 RID: 13856
		[NonSerialized]
		[FieldOffset(632)]
		private int _158;

		// Token: 0x04003621 RID: 13857
		[NonSerialized]
		[FieldOffset(636)]
		private int _159;

		// Token: 0x04003622 RID: 13858
		[NonSerialized]
		[FieldOffset(640)]
		private int _160;

		// Token: 0x04003623 RID: 13859
		[NonSerialized]
		[FieldOffset(644)]
		private int _161;

		// Token: 0x04003624 RID: 13860
		[NonSerialized]
		[FieldOffset(648)]
		private int _162;

		// Token: 0x04003625 RID: 13861
		[NonSerialized]
		[FieldOffset(652)]
		private int _163;

		// Token: 0x04003626 RID: 13862
		[NonSerialized]
		[FieldOffset(656)]
		private int _164;

		// Token: 0x04003627 RID: 13863
		[NonSerialized]
		[FieldOffset(660)]
		private int _165;

		// Token: 0x04003628 RID: 13864
		[NonSerialized]
		[FieldOffset(664)]
		private int _166;

		// Token: 0x04003629 RID: 13865
		[NonSerialized]
		[FieldOffset(668)]
		private int _167;

		// Token: 0x0400362A RID: 13866
		[NonSerialized]
		[FieldOffset(672)]
		private int _168;

		// Token: 0x0400362B RID: 13867
		[NonSerialized]
		[FieldOffset(676)]
		private int _169;

		// Token: 0x0400362C RID: 13868
		[NonSerialized]
		[FieldOffset(680)]
		private int _170;

		// Token: 0x0400362D RID: 13869
		[NonSerialized]
		[FieldOffset(684)]
		private int _171;

		// Token: 0x0400362E RID: 13870
		[NonSerialized]
		[FieldOffset(688)]
		private int _172;

		// Token: 0x0400362F RID: 13871
		[NonSerialized]
		[FieldOffset(692)]
		private int _173;

		// Token: 0x04003630 RID: 13872
		[NonSerialized]
		[FieldOffset(696)]
		private int _174;

		// Token: 0x04003631 RID: 13873
		[NonSerialized]
		[FieldOffset(700)]
		private int _175;

		// Token: 0x04003632 RID: 13874
		[NonSerialized]
		[FieldOffset(704)]
		private int _176;

		// Token: 0x04003633 RID: 13875
		[NonSerialized]
		[FieldOffset(708)]
		private int _177;

		// Token: 0x04003634 RID: 13876
		[NonSerialized]
		[FieldOffset(712)]
		private int _178;

		// Token: 0x04003635 RID: 13877
		[NonSerialized]
		[FieldOffset(716)]
		private int _179;

		// Token: 0x04003636 RID: 13878
		[NonSerialized]
		[FieldOffset(720)]
		private int _180;

		// Token: 0x04003637 RID: 13879
		[NonSerialized]
		[FieldOffset(724)]
		private int _181;

		// Token: 0x04003638 RID: 13880
		[NonSerialized]
		[FieldOffset(728)]
		private int _182;

		// Token: 0x04003639 RID: 13881
		[NonSerialized]
		[FieldOffset(732)]
		private int _183;

		// Token: 0x0400363A RID: 13882
		[NonSerialized]
		[FieldOffset(736)]
		private int _184;

		// Token: 0x0400363B RID: 13883
		[NonSerialized]
		[FieldOffset(740)]
		private int _185;

		// Token: 0x0400363C RID: 13884
		[NonSerialized]
		[FieldOffset(744)]
		private int _186;

		// Token: 0x0400363D RID: 13885
		[NonSerialized]
		[FieldOffset(748)]
		private int _187;

		// Token: 0x0400363E RID: 13886
		[NonSerialized]
		[FieldOffset(752)]
		private int _188;

		// Token: 0x0400363F RID: 13887
		[NonSerialized]
		[FieldOffset(756)]
		private int _189;

		// Token: 0x04003640 RID: 13888
		[NonSerialized]
		[FieldOffset(760)]
		private int _190;

		// Token: 0x04003641 RID: 13889
		[NonSerialized]
		[FieldOffset(764)]
		private int _191;

		// Token: 0x04003642 RID: 13890
		[NonSerialized]
		[FieldOffset(768)]
		private int _192;

		// Token: 0x04003643 RID: 13891
		[NonSerialized]
		[FieldOffset(772)]
		private int _193;

		// Token: 0x04003644 RID: 13892
		[NonSerialized]
		[FieldOffset(776)]
		private int _194;

		// Token: 0x04003645 RID: 13893
		[NonSerialized]
		[FieldOffset(780)]
		private int _195;

		// Token: 0x04003646 RID: 13894
		[NonSerialized]
		[FieldOffset(784)]
		private int _196;

		// Token: 0x04003647 RID: 13895
		[NonSerialized]
		[FieldOffset(788)]
		private int _197;

		// Token: 0x04003648 RID: 13896
		[NonSerialized]
		[FieldOffset(792)]
		private int _198;

		// Token: 0x04003649 RID: 13897
		[NonSerialized]
		[FieldOffset(796)]
		private int _199;

		// Token: 0x0400364A RID: 13898
		[NonSerialized]
		[FieldOffset(800)]
		private int _200;

		// Token: 0x0400364B RID: 13899
		[NonSerialized]
		[FieldOffset(804)]
		private int _201;

		// Token: 0x0400364C RID: 13900
		[NonSerialized]
		[FieldOffset(808)]
		private int _202;

		// Token: 0x0400364D RID: 13901
		[NonSerialized]
		[FieldOffset(812)]
		private int _203;

		// Token: 0x0400364E RID: 13902
		[NonSerialized]
		[FieldOffset(816)]
		private int _204;

		// Token: 0x0400364F RID: 13903
		[NonSerialized]
		[FieldOffset(820)]
		private int _205;

		// Token: 0x04003650 RID: 13904
		[NonSerialized]
		[FieldOffset(824)]
		private int _206;

		// Token: 0x02000847 RID: 2119
		[CompilerGenerated]
		[UnsafeValueType]
		[StructLayout(LayoutKind.Sequential, Size = 828)]
		public struct <Data>e__FixedBuffer
		{
			// Token: 0x04003651 RID: 13905
			private int FixedElementField;
		}
	}
}
