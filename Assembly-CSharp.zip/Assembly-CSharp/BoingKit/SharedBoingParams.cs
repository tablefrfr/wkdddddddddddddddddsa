﻿using System;
using UnityEngine;

namespace BoingKit
{
	// Token: 0x02000824 RID: 2084
	[CreateAssetMenu(fileName = "BoingParams", menuName = "Boing Kit/Shared Boing Params", order = 550)]
	public class SharedBoingParams : ScriptableObject
	{
		// Token: 0x06003289 RID: 12937 RVA: 0x000FE054 File Offset: 0x000FC254
		public SharedBoingParams()
		{
			this.Params.Init();
		}

		// Token: 0x0400351D RID: 13597
		public BoingWork.Params Params;
	}
}
