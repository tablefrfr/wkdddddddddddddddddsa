﻿using System;

namespace BoingKit
{
	// Token: 0x0200080D RID: 2061
	public class BoingReactor : BoingBehavior
	{
		// Token: 0x06003202 RID: 12802 RVA: 0x000F86E5 File Offset: 0x000F68E5
		protected override void Register()
		{
			BoingManager.Register(this);
		}

		// Token: 0x06003203 RID: 12803 RVA: 0x000F86ED File Offset: 0x000F68ED
		protected override void Unregister()
		{
			BoingManager.Unregister(this);
		}

		// Token: 0x06003204 RID: 12804 RVA: 0x000F86F5 File Offset: 0x000F68F5
		public override void PrepareExecute()
		{
			base.PrepareExecute(true);
		}
	}
}
