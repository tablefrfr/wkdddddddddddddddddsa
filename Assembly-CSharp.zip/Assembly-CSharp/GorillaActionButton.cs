﻿using System;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x020000AF RID: 175
public class GorillaActionButton : GorillaPressableButton
{
	// Token: 0x06000330 RID: 816 RVA: 0x000166C6 File Offset: 0x000148C6
	public override void ButtonActivation()
	{
		base.ButtonActivation();
		this.onPress.Invoke();
	}

	// Token: 0x040004BA RID: 1210
	[SerializeField]
	public UnityEvent onPress;
}
