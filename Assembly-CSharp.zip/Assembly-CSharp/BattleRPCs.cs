﻿using System;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x0200047A RID: 1146
internal class BattleRPCs : RPCNetworkBase
{
	// Token: 0x06001A8E RID: 6798 RVA: 0x0008821E File Offset: 0x0008641E
	public override void SetClassTarget(IGorillaSerializeable target, GorillaSerializer netHandler)
	{
		this.battleTarget = (GorillaBattleManager)target;
		this.serializer = (GameModeSerializer)netHandler;
	}

	// Token: 0x06001A8F RID: 6799 RVA: 0x00088238 File Offset: 0x00086438
	[PunRPC]
	public void ReportSlingshotHit(Player taggedPlayer, Vector3 hitLocation, int projectileCount, PhotonMessageInfo info)
	{
		GorillaNot.IncrementRPCCall(info, "ReportSlingshotHit");
		if (!PhotonNetwork.LocalPlayer.IsMasterClient)
		{
			return;
		}
		this.battleTarget.ReportSlingshotHit(taggedPlayer, hitLocation, projectileCount, info);
	}

	// Token: 0x04001E88 RID: 7816
	private GameModeSerializer serializer;

	// Token: 0x04001E89 RID: 7817
	private GorillaBattleManager battleTarget;
}
