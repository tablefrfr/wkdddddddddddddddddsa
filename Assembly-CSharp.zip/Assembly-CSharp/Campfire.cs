﻿using System;
using UnityEngine;

// Token: 0x02000331 RID: 817
public class Campfire : MonoBehaviour
{
	// Token: 0x0600124C RID: 4684 RVA: 0x00061A50 File Offset: 0x0005FC50
	private void Start()
	{
		this.lastAngleBottom = 0f;
		this.lastAngleMiddle = 0f;
		this.lastAngleTop = 0f;
		this.perlinBottom = (float)Random.Range(0, 100);
		this.perlinMiddle = (float)Random.Range(200, 300);
		this.perlinTop = (float)Random.Range(400, 500);
		this.startingRotationBottom = this.baseFire.localEulerAngles.x;
		this.startingRotationMiddle = this.middleFire.localEulerAngles.x;
		this.startingRotationTop = this.topFire.localEulerAngles.x;
		this.tempVec = new Vector3(0f, 0f, 0f);
		this.mergedBottom = false;
		this.mergedMiddle = false;
		this.mergedTop = false;
		this.wasActive = false;
	}

	// Token: 0x0600124D RID: 4685 RVA: 0x00061B34 File Offset: 0x0005FD34
	private void LateUpdate()
	{
		if (BetterDayNightManager.instance == null)
		{
			return;
		}
		if ((this.isActive[BetterDayNightManager.instance.currentTimeIndex] && BetterDayNightManager.instance.CurrentWeather() != BetterDayNightManager.WeatherType.Raining) || this.overrideDayNight == 1)
		{
			if (!this.wasActive)
			{
				this.wasActive = true;
				this.mergedBottom = false;
				this.mergedMiddle = false;
				this.mergedTop = false;
				Color.RGBToHSV(this.mat.color, out this.h, out this.s, out this.v);
				this.mat.color = Color.HSVToRGB(this.h, this.s, 1f);
			}
			this.Flap(ref this.perlinBottom, this.perlinStepBottom, ref this.lastAngleBottom, ref this.baseFire, this.bottomRange, this.baseMultiplier, ref this.mergedBottom);
			this.Flap(ref this.perlinMiddle, this.perlinStepMiddle, ref this.lastAngleMiddle, ref this.middleFire, this.middleRange, this.middleMultiplier, ref this.mergedMiddle);
			this.Flap(ref this.perlinTop, this.perlinStepTop, ref this.lastAngleTop, ref this.topFire, this.topRange, this.topMultiplier, ref this.mergedTop);
			return;
		}
		if (this.wasActive)
		{
			this.wasActive = false;
			this.mergedBottom = false;
			this.mergedMiddle = false;
			this.mergedTop = false;
			Color.RGBToHSV(this.mat.color, out this.h, out this.s, out this.v);
			this.mat.color = Color.HSVToRGB(this.h, this.s, 0.25f);
		}
		this.ReturnToOff(ref this.baseFire, this.startingRotationBottom, ref this.mergedBottom);
		this.ReturnToOff(ref this.middleFire, this.startingRotationMiddle, ref this.mergedMiddle);
		this.ReturnToOff(ref this.topFire, this.startingRotationTop, ref this.mergedTop);
	}

	// Token: 0x0600124E RID: 4686 RVA: 0x00061D28 File Offset: 0x0005FF28
	private void Flap(ref float perlinValue, float perlinStep, ref float lastAngle, ref Transform flameTransform, float range, float multiplier, ref bool isMerged)
	{
		perlinValue += perlinStep;
		lastAngle += Time.deltaTime * Mathf.PerlinNoise(perlinValue, 0f);
		this.tempVec.x = range * Mathf.Sin(lastAngle * multiplier);
		if (Mathf.Abs(this.tempVec.x - flameTransform.localEulerAngles.x) > 180f)
		{
			if (this.tempVec.x > flameTransform.localEulerAngles.x)
			{
				this.tempVec.x = this.tempVec.x - 360f;
			}
			else
			{
				this.tempVec.x = this.tempVec.x + 360f;
			}
		}
		if (isMerged)
		{
			flameTransform.localEulerAngles = this.tempVec;
			return;
		}
		if (Mathf.Abs(flameTransform.localEulerAngles.x - this.tempVec.x) < 1f)
		{
			isMerged = true;
			flameTransform.localEulerAngles = this.tempVec;
			return;
		}
		this.tempVec.x = (this.tempVec.x - flameTransform.localEulerAngles.x) * this.slerp + flameTransform.localEulerAngles.x;
		flameTransform.localEulerAngles = this.tempVec;
	}

	// Token: 0x0600124F RID: 4687 RVA: 0x00061E68 File Offset: 0x00060068
	private void ReturnToOff(ref Transform startTransform, float targetAngle, ref bool isMerged)
	{
		this.tempVec.x = targetAngle;
		if (Mathf.Abs(this.tempVec.x - startTransform.localEulerAngles.x) > 180f)
		{
			if (this.tempVec.x > startTransform.localEulerAngles.x)
			{
				this.tempVec.x = this.tempVec.x - 360f;
			}
			else
			{
				this.tempVec.x = this.tempVec.x + 360f;
			}
		}
		if (!isMerged)
		{
			if (Mathf.Abs(startTransform.localEulerAngles.x - targetAngle) < 1f)
			{
				isMerged = true;
				return;
			}
			this.tempVec.x = (this.tempVec.x - startTransform.localEulerAngles.x) * this.slerp + startTransform.localEulerAngles.x;
			startTransform.localEulerAngles = this.tempVec;
		}
	}

	// Token: 0x04001522 RID: 5410
	public Transform baseFire;

	// Token: 0x04001523 RID: 5411
	public Transform middleFire;

	// Token: 0x04001524 RID: 5412
	public Transform topFire;

	// Token: 0x04001525 RID: 5413
	public float baseMultiplier;

	// Token: 0x04001526 RID: 5414
	public float middleMultiplier;

	// Token: 0x04001527 RID: 5415
	public float topMultiplier;

	// Token: 0x04001528 RID: 5416
	public float bottomRange;

	// Token: 0x04001529 RID: 5417
	public float middleRange;

	// Token: 0x0400152A RID: 5418
	public float topRange;

	// Token: 0x0400152B RID: 5419
	private float lastAngleBottom;

	// Token: 0x0400152C RID: 5420
	private float lastAngleMiddle;

	// Token: 0x0400152D RID: 5421
	private float lastAngleTop;

	// Token: 0x0400152E RID: 5422
	public float perlinStepBottom;

	// Token: 0x0400152F RID: 5423
	public float perlinStepMiddle;

	// Token: 0x04001530 RID: 5424
	public float perlinStepTop;

	// Token: 0x04001531 RID: 5425
	private float perlinBottom;

	// Token: 0x04001532 RID: 5426
	private float perlinMiddle;

	// Token: 0x04001533 RID: 5427
	private float perlinTop;

	// Token: 0x04001534 RID: 5428
	public float startingRotationBottom;

	// Token: 0x04001535 RID: 5429
	public float startingRotationMiddle;

	// Token: 0x04001536 RID: 5430
	public float startingRotationTop;

	// Token: 0x04001537 RID: 5431
	public float slerp = 0.01f;

	// Token: 0x04001538 RID: 5432
	private bool mergedBottom;

	// Token: 0x04001539 RID: 5433
	private bool mergedMiddle;

	// Token: 0x0400153A RID: 5434
	private bool mergedTop;

	// Token: 0x0400153B RID: 5435
	public string lastTimeOfDay;

	// Token: 0x0400153C RID: 5436
	public Material mat;

	// Token: 0x0400153D RID: 5437
	private float h;

	// Token: 0x0400153E RID: 5438
	private float s;

	// Token: 0x0400153F RID: 5439
	private float v;

	// Token: 0x04001540 RID: 5440
	public int overrideDayNight;

	// Token: 0x04001541 RID: 5441
	private Vector3 tempVec;

	// Token: 0x04001542 RID: 5442
	public bool[] isActive;

	// Token: 0x04001543 RID: 5443
	public bool wasActive;
}
