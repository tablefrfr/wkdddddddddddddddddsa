﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x020002F5 RID: 757
public class GorillaDebugUI : MonoBehaviour
{
	// Token: 0x040013B3 RID: 5043
	private readonly float Delay = 0.5f;

	// Token: 0x040013B4 RID: 5044
	public GameObject parentCanvas;

	// Token: 0x040013B5 RID: 5045
	public GameObject rayInteractorLeft;

	// Token: 0x040013B6 RID: 5046
	public GameObject rayInteractorRight;

	// Token: 0x040013B7 RID: 5047
	[SerializeField]
	private TMP_Dropdown playfabIdDropdown;

	// Token: 0x040013B8 RID: 5048
	[SerializeField]
	private TMP_Dropdown roomIdDropdown;

	// Token: 0x040013B9 RID: 5049
	[SerializeField]
	private TMP_Dropdown locationDropdown;

	// Token: 0x040013BA RID: 5050
	[SerializeField]
	private TMP_Dropdown playerNameDropdown;

	// Token: 0x040013BB RID: 5051
	[SerializeField]
	private TMP_Dropdown gameModeDropdown;

	// Token: 0x040013BC RID: 5052
	[SerializeField]
	private TMP_Dropdown timeOfDayDropdown;

	// Token: 0x040013BD RID: 5053
	[SerializeField]
	private TMP_Text networkStateTextBox;

	// Token: 0x040013BE RID: 5054
	[SerializeField]
	private TMP_Text gameModeTextBox;

	// Token: 0x040013BF RID: 5055
	[SerializeField]
	private TMP_Text currentRoomTextBox;

	// Token: 0x040013C0 RID: 5056
	[SerializeField]
	private TMP_Text playerCountTextBox;

	// Token: 0x040013C1 RID: 5057
	[SerializeField]
	private TMP_Text roomVisibilityTextBox;

	// Token: 0x040013C2 RID: 5058
	[SerializeField]
	private TMP_Text timeMultiplierTextBox;

	// Token: 0x040013C3 RID: 5059
	[SerializeField]
	private TMP_Text versionTextBox;
}
