﻿using System;

namespace BuildSafe
{
	// Token: 0x0200062C RID: 1580
	public enum SceneBakeMode
	{
		// Token: 0x040027FE RID: 10238
		Always,
		// Token: 0x040027FF RID: 10239
		OnBuildPlayer,
		// Token: 0x04002800 RID: 10240
		OnEditorPlayMode,
		// Token: 0x04002801 RID: 10241
		Disabled
	}
}
