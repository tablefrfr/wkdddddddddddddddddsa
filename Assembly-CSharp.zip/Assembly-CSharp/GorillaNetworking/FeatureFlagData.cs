﻿using System;

namespace GorillaNetworking
{
	// Token: 0x020006D4 RID: 1748
	[Serializable]
	internal class FeatureFlagData
	{
		// Token: 0x04002C5E RID: 11358
		public string name;

		// Token: 0x04002C5F RID: 11359
		public int value;

		// Token: 0x04002C60 RID: 11360
		public string valueType;
	}
}
