﻿using System;
using Fusion;
using Fusion.StatsInternal;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000213 RID: 531
public class FusionStatsMeterBar : FusionGraphBase
{
	// Token: 0x17000165 RID: 357
	// (get) Token: 0x06000B0E RID: 2830 RVA: 0x0003B51C File Offset: 0x0003971C
	protected override Color BackColor
	{
		get
		{
			return base.BackColor * new Color(0.5f, 0.5f, 0.5f, 1f);
		}
	}

	// Token: 0x06000B0F RID: 2831 RVA: 0x0003B544 File Offset: 0x00039744
	public override void Initialize()
	{
		base.Initialize();
		this._max = (double)this.MeterMax;
		if (this.BackImage.sprite == null)
		{
			this.BackImage.sprite = FusionStatsUtilities.MeterSprite;
			this.Bar.sprite = this.BackImage.sprite;
		}
		this.BackImage.type = Image.Type.Simple;
		if (this.Bar.rectTransform.parent != this.BackImage.rectTransform.parent)
		{
			Transform parent = this.Bar.transform.parent;
			this.Bar.rectTransform.SetParent(this.BackImage.rectTransform.parent);
			this.Bar.transform.SetSiblingIndex(this.BackImage.transform.GetSiblingIndex() + 1);
		}
		this.Bar.type = Image.Type.Filled;
		this.Bar.fillMethod = Image.FillMethod.Horizontal;
		this.Bar.fillAmount = 0f;
	}

	// Token: 0x06000B10 RID: 2832 RVA: 0x0003B64C File Offset: 0x0003984C
	public override void Refresh()
	{
		if (this._layoutDirty)
		{
			this.CalculateLayout();
		}
		IStatsBuffer statsBuffer = base.StatsBuffer;
		if (statsBuffer == null || statsBuffer.Count < 1)
		{
			return;
		}
		if (statsBuffer.DefaultVisualization == FusionGraphVisualization.CountHistogram)
		{
			if (statsBuffer.Count > 0)
			{
				int num = 0;
				float num2 = (float)statsBuffer.GetSampleAtIndex(statsBuffer.Count - 1).TickValue;
				float num3 = num2;
				if ((double)num2 > this._lastImportedSampleTickTime)
				{
					int num4 = 0;
					for (int i = statsBuffer.Count - 1; i >= 0; i--)
					{
						int tickValue = statsBuffer.GetSampleAtIndex(i).TickValue;
						if ((double)tickValue <= this._lastImportedSampleTickTime)
						{
							break;
						}
						if ((float)tickValue != num3)
						{
							num3 = (float)tickValue;
							if (num4 > num)
							{
								num = num4;
							}
							num4 = 0;
						}
						num4++;
						this._total += 1.0;
					}
					this._lastImportedSampleTickTime = (double)num2;
				}
				this.SetValue((double)num);
			}
			return;
		}
		if (statsBuffer.Count > 0)
		{
			ISampleData sampleAtIndex = statsBuffer.GetSampleAtIndex(statsBuffer.Count - 1);
			if (sampleAtIndex.TickValue == this._fusionStats.Runner.Simulation.LatestServerState.Tick)
			{
				this.SetValue((double)sampleAtIndex.FloatValue);
				return;
			}
			this.SetValue(0.0);
		}
	}

	// Token: 0x06000B11 RID: 2833 RVA: 0x0003B794 File Offset: 0x00039994
	public void LateUpdate()
	{
		if (this.DecayTime <= 0f)
		{
			return;
		}
		if (this._currentBarValue <= 0.0)
		{
			return;
		}
		if (Time.time < this._lastPeakSetTime + this.HoldPeakTime)
		{
			return;
		}
		double bar = Math.Max(this._currentBarValue - (double)(Time.deltaTime / this.DecayTime) * this._max, 0.0);
		this.SetBar(bar);
	}

	// Token: 0x06000B12 RID: 2834 RVA: 0x0003B808 File Offset: 0x00039A08
	public void SetValue(double rawvalue)
	{
		Simulation.Statistics.StatSourceInfo statSourceInfo = this.StatSourceInfo;
		double num = rawvalue * statSourceInfo.Multiplier;
		if (this.MeterMax == 0 && num > this._max)
		{
			this._max = num;
		}
		double num2 = Math.Max(Math.Min(num, this._max), 0.0);
		double num3 = Math.Round(num2, statSourceInfo.Decimals);
		double num4 = (this._total > 0.0) ? this._total : num3;
		if (num2 >= this._currentBarValue)
		{
			this._lastPeakSetTime = Time.time;
		}
		if (num4 != this._currentDisplayValue)
		{
			this.ValueLabel.text = ((this._total > 0.0) ? this._total.ToString() : num2.ToString());
			this._currentDisplayValue = num4;
		}
		if (this.DecayTime >= 0f && num2 <= this._currentBarValue)
		{
			return;
		}
		if (num2 != this._currentBarValue)
		{
			this.SetBar(num2);
		}
	}

	// Token: 0x06000B13 RID: 2835 RVA: 0x0003B900 File Offset: 0x00039B00
	private void SetBar(double value)
	{
		FusionStats fusionStats = this._fusionStats;
		this.Bar.fillAmount = (float)(value / this._max);
		this._currentBarValue = value;
		if (value < (double)this.WarnThreshold)
		{
			Color graphColorGood = fusionStats.GraphColorGood;
			if (this.CurrentColor != graphColorGood)
			{
				this.CurrentColor = graphColorGood;
				this.Bar.color = graphColorGood;
				return;
			}
		}
		else if (value < (double)this.ErrorThreshold)
		{
			Color graphColorWarn = fusionStats.GraphColorWarn;
			if (this.CurrentColor != graphColorWarn)
			{
				this.Bar.color = graphColorWarn;
				this.CurrentColor = graphColorWarn;
				return;
			}
		}
		else
		{
			Color graphColorBad = fusionStats.GraphColorBad;
			if (this.CurrentColor != graphColorBad)
			{
				this.Bar.color = graphColorBad;
				this.CurrentColor = graphColorBad;
			}
		}
	}

	// Token: 0x06000B14 RID: 2836 RVA: 0x0003B9C0 File Offset: 0x00039BC0
	public override void CalculateLayout()
	{
		this._layoutDirty = false;
		float num = this.LabelTitle.transform.parent.GetComponent<RectTransform>().rect.height * 0.2f;
		this.LabelTitle.rectTransform.offsetMax = new Vector2(0f, -num);
		this.LabelTitle.rectTransform.offsetMin = new Vector2(10f, num * 1.2f);
		this.ValueLabel.rectTransform.offsetMax = new Vector2(-10f, -num);
		this.ValueLabel.rectTransform.offsetMin = new Vector2(0f, num * 1.2f);
		base.ApplyTitleText();
	}

	// Token: 0x06000B15 RID: 2837 RVA: 0x0003BA80 File Offset: 0x00039C80
	public static FusionStatsMeterBar Create(RectTransform parent, FusionStats fusionStats, Simulation.Statistics.StatSourceTypes statSourceType, int statId, float warnThreshold, float alertThreshold)
	{
		Simulation.Statistics.StatSourceInfo description = Simulation.Statistics.GetDescription(statSourceType, statId);
		FusionStatsMeterBar fusionStatsMeterBar = parent.CreateRectTransform(description.LongName, true).gameObject.AddComponent<FusionStatsMeterBar>();
		fusionStatsMeterBar.StatSourceInfo = description;
		fusionStatsMeterBar._fusionStats = fusionStats;
		fusionStatsMeterBar._statSourceType = statSourceType;
		fusionStatsMeterBar._statId = statId;
		fusionStatsMeterBar.GenerateMeter();
		return fusionStatsMeterBar;
	}

	// Token: 0x06000B16 RID: 2838 RVA: 0x0003BAD0 File Offset: 0x00039CD0
	public void GenerateMeter()
	{
		Simulation.Statistics.StatSourceInfo description = Simulation.Statistics.GetDescription(this._statSourceType, this._statId);
		RectTransform rectTransform = base.transform.CreateRectTransform("Back", true);
		this.BackImage = rectTransform.gameObject.AddComponent<Image>();
		this.BackImage.raycastTarget = false;
		this.BackImage.sprite = FusionStatsUtilities.MeterSprite;
		this.BackImage.color = this.BackColor;
		this.BackImage.type = Image.Type.Simple;
		RectTransform rectTransform2 = base.transform.CreateRectTransform("Bar", true);
		this.Bar = rectTransform2.gameObject.AddComponent<Image>();
		this.Bar.raycastTarget = false;
		this.Bar.sprite = this.BackImage.sprite;
		this.Bar.color = this._fusionStats.GraphColorGood;
		this.Bar.type = Image.Type.Filled;
		this.Bar.fillMethod = Image.FillMethod.Horizontal;
		this.Bar.fillAmount = 0f;
		RectTransform rt = base.transform.CreateRectTransform("Label", true).ExpandAnchor(null).SetAnchors(0f, 0.5f, 0f, 1f).SetOffsets(6f, -6f, 6f, -6f);
		this.LabelTitle = rt.AddText(description.LongName, TextAnchor.MiddleLeft, this._fusionStats.FontColor);
		this.LabelTitle.alignByGeometry = false;
		RectTransform rt2 = base.transform.CreateRectTransform("Value", true).ExpandAnchor(null).SetAnchors(0.5f, 1f, 0f, 1f).SetOffsets(6f, -6f, 6f, -6f);
		this.ValueLabel = rt2.AddText("0.0", TextAnchor.MiddleRight, this._fusionStats.FontColor);
		this.ValueLabel.alignByGeometry = false;
	}

	// Token: 0x04000C6F RID: 3183
	public float HoldPeakTime = 0.1f;

	// Token: 0x04000C70 RID: 3184
	public float DecayTime = 0.25f;

	// Token: 0x04000C71 RID: 3185
	[InlineHelp]
	public int MeterMax;

	// Token: 0x04000C72 RID: 3186
	[InlineHelp]
	[SerializeField]
	private bool _showUITargets;

	// Token: 0x04000C73 RID: 3187
	[DrawIf("_showUITargets", Hide = true)]
	public Text ValueLabel;

	// Token: 0x04000C74 RID: 3188
	[DrawIf("_showUITargets", Hide = true)]
	public Image Bar;

	// Token: 0x04000C75 RID: 3189
	private double _currentDisplayValue;

	// Token: 0x04000C76 RID: 3190
	private double _currentBarValue;

	// Token: 0x04000C77 RID: 3191
	private Color CurrentColor;

	// Token: 0x04000C78 RID: 3192
	private double _lastImportedSampleTickTime;

	// Token: 0x04000C79 RID: 3193
	private double _max;

	// Token: 0x04000C7A RID: 3194
	private double _total;

	// Token: 0x04000C7B RID: 3195
	private float _lastPeakSetTime;
}
