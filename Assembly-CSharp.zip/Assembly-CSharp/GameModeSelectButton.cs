﻿using System;
using UnityEngine;

// Token: 0x020002FB RID: 763
public class GameModeSelectButton : GorillaPressableButton
{
	// Token: 0x0600117F RID: 4479 RVA: 0x0005C2DF File Offset: 0x0005A4DF
	public override void ButtonActivation()
	{
		base.ButtonActivation();
		this.selector.SelectEntryOnPage(this.buttonIndex);
	}

	// Token: 0x040013D5 RID: 5077
	[SerializeField]
	internal GameModePages selector;

	// Token: 0x040013D6 RID: 5078
	[SerializeField]
	internal int buttonIndex;
}
