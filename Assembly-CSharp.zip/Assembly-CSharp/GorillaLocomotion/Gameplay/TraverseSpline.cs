﻿using System;
using Photon.Pun;
using UnityEngine;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005CF RID: 1487
	public class TraverseSpline : MonoBehaviourPun, IPunObservable
	{
		// Token: 0x060022D2 RID: 8914 RVA: 0x000A96F1 File Offset: 0x000A78F1
		protected virtual void Awake()
		{
			this._view = base.GetComponent<PhotonView>();
			this.progress = this.SplineProgressOffet % 1f;
		}

		// Token: 0x060022D3 RID: 8915 RVA: 0x000A9714 File Offset: 0x000A7914
		protected virtual void FixedUpdate()
		{
			if (!base.photonView.IsMine && this.progressLerpStartTime + 1f > Time.time)
			{
				this.progress = Mathf.Lerp(this.progressLerpStart, this.progressLerpEnd, (Time.time - this.progressLerpStartTime) / 1f);
			}
			else
			{
				if (this.isHeldByLocalPlayer)
				{
					this.currentSpeedMultiplier = Mathf.MoveTowards(this.currentSpeedMultiplier, this.speedMultiplierWhileHeld, this.acceleration * Time.deltaTime);
				}
				else
				{
					this.currentSpeedMultiplier = Mathf.MoveTowards(this.currentSpeedMultiplier, 1f, this.deceleration * Time.deltaTime);
				}
				if (this.goingForward)
				{
					this.progress += Time.deltaTime * this.currentSpeedMultiplier / this.duration;
					if (this.progress > 1f)
					{
						if (this.mode == SplineWalkerMode.Once)
						{
							this.progress = 1f;
						}
						else if (this.mode == SplineWalkerMode.Loop)
						{
							this.progress %= 1f;
						}
						else
						{
							this.progress = 2f - this.progress;
							this.goingForward = false;
						}
					}
				}
				else
				{
					this.progress -= Time.deltaTime * this.currentSpeedMultiplier / this.duration;
					if (this.progress < 0f)
					{
						this.progress = -this.progress;
						this.goingForward = true;
					}
				}
			}
			Vector3 point = this.spline.GetPoint(this.progress, this.constantVelocity);
			base.transform.position = point;
			if (this.lookForward)
			{
				base.transform.LookAt(base.transform.position + this.spline.GetDirection(this.progress, this.constantVelocity));
			}
		}

		// Token: 0x060022D4 RID: 8916 RVA: 0x000A98E4 File Offset: 0x000A7AE4
		public void OnPhotonSerializeView(PhotonStream stream, PhotonMessageInfo info)
		{
			if (stream.IsWriting)
			{
				stream.SendNext(this.progress + this.currentSpeedMultiplier * 1f / this.duration);
				return;
			}
			this.progressLerpEnd = (float)stream.ReceiveNext();
			if (float.IsNaN(this.progressLerpEnd) || float.IsInfinity(this.progressLerpEnd))
			{
				this.progressLerpEnd = 1f;
			}
			else
			{
				this.progressLerpEnd = Mathf.Abs(this.progressLerpEnd);
				if (this.progressLerpEnd > 1f)
				{
					this.progressLerpEnd = (float)((double)this.progressLerpEnd % 1.0);
				}
			}
			this.progressLerpStart = ((Mathf.Abs(this.progressLerpEnd - this.progress) > Mathf.Abs(this.progressLerpEnd - (this.progress - 1f))) ? (this.progress - 1f) : this.progress);
			this.progressLerpStartTime = Time.time;
		}

		// Token: 0x060022D5 RID: 8917 RVA: 0x000A99DE File Offset: 0x000A7BDE
		protected float GetProgress()
		{
			return this.progress;
		}

		// Token: 0x060022D6 RID: 8918 RVA: 0x000A99E6 File Offset: 0x000A7BE6
		public float GetCurrentSpeed()
		{
			return this.currentSpeedMultiplier;
		}

		// Token: 0x04002536 RID: 9526
		public BezierSpline spline;

		// Token: 0x04002537 RID: 9527
		public float duration = 30f;

		// Token: 0x04002538 RID: 9528
		public float speedMultiplierWhileHeld = 2f;

		// Token: 0x04002539 RID: 9529
		private float currentSpeedMultiplier;

		// Token: 0x0400253A RID: 9530
		public float acceleration = 1f;

		// Token: 0x0400253B RID: 9531
		public float deceleration = 1f;

		// Token: 0x0400253C RID: 9532
		private bool isHeldByLocalPlayer;

		// Token: 0x0400253D RID: 9533
		public bool lookForward = true;

		// Token: 0x0400253E RID: 9534
		public SplineWalkerMode mode;

		// Token: 0x0400253F RID: 9535
		[SerializeField]
		private float SplineProgressOffet;

		// Token: 0x04002540 RID: 9536
		private float progress;

		// Token: 0x04002541 RID: 9537
		private float progressLerpStart;

		// Token: 0x04002542 RID: 9538
		private float progressLerpEnd;

		// Token: 0x04002543 RID: 9539
		private const float progressLerpDuration = 1f;

		// Token: 0x04002544 RID: 9540
		private float progressLerpStartTime;

		// Token: 0x04002545 RID: 9541
		private bool goingForward = true;

		// Token: 0x04002546 RID: 9542
		private PhotonView _view;

		// Token: 0x04002547 RID: 9543
		[SerializeField]
		private bool constantVelocity;
	}
}
