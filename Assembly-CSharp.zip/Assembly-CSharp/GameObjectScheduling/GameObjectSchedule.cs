﻿using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

namespace GameObjectScheduling
{
	// Token: 0x020007CA RID: 1994
	[CreateAssetMenu(fileName = "New Game Object Schedule", menuName = "Game Object Scheduling/Game Object Schedule", order = 0)]
	public class GameObjectSchedule : ScriptableObject
	{
		// Token: 0x17000540 RID: 1344
		// (get) Token: 0x06003053 RID: 12371 RVA: 0x000ECF7B File Offset: 0x000EB17B
		public GameObjectSchedule.GameObjectScheduleNode[] Nodes
		{
			get
			{
				return this.nodes;
			}
		}

		// Token: 0x17000541 RID: 1345
		// (get) Token: 0x06003054 RID: 12372 RVA: 0x000ECF83 File Offset: 0x000EB183
		public bool InitialState
		{
			get
			{
				return this.initialState;
			}
		}

		// Token: 0x06003055 RID: 12373 RVA: 0x000ECF8C File Offset: 0x000EB18C
		public int GetCurrentNodeIndex(DateTime currentDate, int startFrom = 0)
		{
			if (startFrom >= this.nodes.Length)
			{
				return int.MaxValue;
			}
			for (int i = -1; i < this.nodes.Length - 1; i++)
			{
				if (currentDate < this.nodes[i + 1].DateTime)
				{
					return i;
				}
			}
			return int.MaxValue;
		}

		// Token: 0x06003056 RID: 12374 RVA: 0x000ECFDD File Offset: 0x000EB1DD
		public void Validate()
		{
			if (this.validated)
			{
				return;
			}
			this._validate();
			this.validated = true;
		}

		// Token: 0x06003057 RID: 12375 RVA: 0x000ECFF8 File Offset: 0x000EB1F8
		private void _validate()
		{
			for (int i = 0; i < this.nodes.Length; i++)
			{
				this.nodes[i].Validate();
			}
			List<GameObjectSchedule.GameObjectScheduleNode> list = new List<GameObjectSchedule.GameObjectScheduleNode>(this.nodes);
			list.Sort((GameObjectSchedule.GameObjectScheduleNode e1, GameObjectSchedule.GameObjectScheduleNode e2) => e1.DateTime.CompareTo(e2.DateTime));
			this.nodes = list.ToArray();
		}

		// Token: 0x040032C7 RID: 12999
		[SerializeField]
		private bool initialState;

		// Token: 0x040032C8 RID: 13000
		[SerializeField]
		private GameObjectSchedule.GameObjectScheduleNode[] nodes;

		// Token: 0x040032C9 RID: 13001
		[SerializeField]
		private SchedulingOptions options;

		// Token: 0x040032CA RID: 13002
		private bool validated;

		// Token: 0x020007CB RID: 1995
		[Serializable]
		public class GameObjectScheduleNode
		{
			// Token: 0x17000542 RID: 1346
			// (get) Token: 0x06003059 RID: 12377 RVA: 0x000ED062 File Offset: 0x000EB262
			public bool ActiveState
			{
				get
				{
					return this.activeState;
				}
			}

			// Token: 0x17000543 RID: 1347
			// (get) Token: 0x0600305A RID: 12378 RVA: 0x000ED06A File Offset: 0x000EB26A
			public DateTime DateTime
			{
				get
				{
					return this.dateTime;
				}
			}

			// Token: 0x0600305B RID: 12379 RVA: 0x000ED074 File Offset: 0x000EB274
			public void Validate()
			{
				try
				{
					this.dateTime = DateTime.Parse(this.activeDateTime, CultureInfo.InvariantCulture);
				}
				catch
				{
					this.dateTime = DateTime.MinValue;
				}
			}

			// Token: 0x040032CB RID: 13003
			[SerializeField]
			private string activeDateTime = "1/1/0001 00:00:00";

			// Token: 0x040032CC RID: 13004
			[SerializeField]
			[Tooltip("Check to turn on. Uncheck to turn off.")]
			private bool activeState = true;

			// Token: 0x040032CD RID: 13005
			private DateTime dateTime;
		}
	}
}
