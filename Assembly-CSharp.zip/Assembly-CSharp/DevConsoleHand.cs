﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x0200009F RID: 159
public class DevConsoleHand : DevConsoleInstance
{
	// Token: 0x04000466 RID: 1126
	public List<GameObject> otherButtonsList;

	// Token: 0x04000467 RID: 1127
	private bool isActuallyEnabled = true;

	// Token: 0x04000468 RID: 1128
	public bool isStillEnabled = true;

	// Token: 0x04000469 RID: 1129
	public bool isLeftHand;

	// Token: 0x0400046A RID: 1130
	public ConsoleMode mode;

	// Token: 0x0400046B RID: 1131
	public double debugScale;

	// Token: 0x0400046C RID: 1132
	public double inspectorScale;

	// Token: 0x0400046D RID: 1133
	public double componentInspectorScale;

	// Token: 0x0400046E RID: 1134
	public List<GameObject> consoleButtons;

	// Token: 0x0400046F RID: 1135
	public List<GameObject> inspectorButtons;

	// Token: 0x04000470 RID: 1136
	public List<GameObject> componentInspectorButtons;

	// Token: 0x04000471 RID: 1137
	public GorillaDevButton consoleButton;

	// Token: 0x04000472 RID: 1138
	public GorillaDevButton inspectorButton;

	// Token: 0x04000473 RID: 1139
	public GorillaDevButton componentInspectorButton;

	// Token: 0x04000474 RID: 1140
	public GorillaDevButton showNonStarItems;

	// Token: 0x04000475 RID: 1141
	public GorillaDevButton showPrivateItems;

	// Token: 0x04000476 RID: 1142
	public Text componentInspectionText;

	// Token: 0x04000477 RID: 1143
	public DevInspector selectedInspector;
}
