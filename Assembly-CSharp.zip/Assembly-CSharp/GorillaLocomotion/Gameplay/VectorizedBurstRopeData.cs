﻿using System;
using Unity.Collections;
using Unity.Mathematics;

namespace GorillaLocomotion.Gameplay
{
	// Token: 0x020005D1 RID: 1489
	public struct VectorizedBurstRopeData
	{
		// Token: 0x04002557 RID: 9559
		public NativeArray<float4> posX;

		// Token: 0x04002558 RID: 9560
		public NativeArray<float4> posY;

		// Token: 0x04002559 RID: 9561
		public NativeArray<float4> posZ;

		// Token: 0x0400255A RID: 9562
		public NativeArray<int4> validNodes;

		// Token: 0x0400255B RID: 9563
		public NativeArray<float4> lastPosX;

		// Token: 0x0400255C RID: 9564
		public NativeArray<float4> lastPosY;

		// Token: 0x0400255D RID: 9565
		public NativeArray<float4> lastPosZ;

		// Token: 0x0400255E RID: 9566
		public NativeArray<float3> ropeRoots;

		// Token: 0x0400255F RID: 9567
		public NativeArray<float4> nodeMass;
	}
}
