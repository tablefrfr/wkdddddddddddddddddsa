﻿using System;
using System.Collections.Generic;
using Unity.Burst;
using Unity.Collections;
using Unity.Jobs;
using UnityEngine;

// Token: 0x0200037E RID: 894
public class GorillaIKMgr : MonoBehaviour
{
	// Token: 0x17000216 RID: 534
	// (get) Token: 0x06001480 RID: 5248 RVA: 0x0006BC04 File Offset: 0x00069E04
	public static GorillaIKMgr Instance
	{
		get
		{
			return GorillaIKMgr._instance;
		}
	}

	// Token: 0x06001481 RID: 5249 RVA: 0x0006BC0B File Offset: 0x00069E0B
	private void Awake()
	{
		GorillaIKMgr._instance = this;
		this.cachedInput = new NativeArray<GorillaIKMgr.IKInput>(40, Allocator.Persistent, NativeArrayOptions.ClearMemory);
		this.cachedOutput = new NativeArray<GorillaIKMgr.IKOutput>(40, Allocator.Persistent, NativeArrayOptions.ClearMemory);
		this.firstFrame = true;
	}

	// Token: 0x06001482 RID: 5250 RVA: 0x0006BC38 File Offset: 0x00069E38
	private void OnDestroy()
	{
		this.jobHandle.Complete();
		this.cachedInput.Dispose();
		this.cachedOutput.Dispose();
	}

	// Token: 0x06001483 RID: 5251 RVA: 0x0006BC5B File Offset: 0x00069E5B
	public void RegisterIK(GorillaIK ik)
	{
		this.ikList.Add(ik);
		this.actualListSz += 2;
	}

	// Token: 0x06001484 RID: 5252 RVA: 0x0006BC77 File Offset: 0x00069E77
	public void DeregisterIK(GorillaIK ik)
	{
		this.ikList.Remove(ik);
		this.actualListSz -= 2;
	}

	// Token: 0x06001485 RID: 5253 RVA: 0x0006BC94 File Offset: 0x00069E94
	private void CopyInput()
	{
		for (int i = 0; i < this.actualListSz; i += 2)
		{
			this.ikList[i / 2].leftUpperArm.localRotation = this.ikList[i / 2].initialUpperLeft;
			this.ikList[i / 2].leftLowerArm.localRotation = this.ikList[i / 2].initialLowerLeft;
			this.ikList[i / 2].rightUpperArm.localRotation = this.ikList[i / 2].initialUpperRight;
			this.ikList[i / 2].rightLowerArm.localRotation = this.ikList[i / 2].initialLowerRight;
			this.cachedInput[i] = new GorillaIKMgr.IKInput
			{
				handPos = this.ikList[i / 2].leftHand.position,
				upperArmPos = this.ikList[i / 2].leftUpperArm.position,
				upperArmRot = this.ikList[i / 2].leftUpperArm.rotation,
				upperArmLocalRot = this.ikList[i / 2].leftUpperArm.localRotation,
				lowerArmPos = this.ikList[i / 2].leftLowerArm.position,
				lowerArmRot = this.ikList[i / 2].leftLowerArm.rotation,
				lowerArmLocalRot = this.ikList[i / 2].leftLowerArm.localRotation,
				initRotLower = this.ikList[i / 2].initialLowerLeft,
				initRotUpper = this.ikList[i / 2].initialUpperLeft,
				targetPos = this.ikList[i / 2].targetLeft.position,
				eps = this.ikList[i / 2].eps
			};
			this.cachedInput[i + 1] = new GorillaIKMgr.IKInput
			{
				handPos = this.ikList[i / 2].rightHand.position,
				upperArmPos = this.ikList[i / 2].rightUpperArm.position,
				upperArmRot = this.ikList[i / 2].rightUpperArm.rotation,
				upperArmLocalRot = this.ikList[i / 2].rightUpperArm.localRotation,
				lowerArmPos = this.ikList[i / 2].rightLowerArm.position,
				lowerArmRot = this.ikList[i / 2].rightLowerArm.rotation,
				lowerArmLocalRot = this.ikList[i / 2].rightLowerArm.localRotation,
				initRotLower = this.ikList[i / 2].initialLowerRight,
				initRotUpper = this.ikList[i / 2].initialUpperRight,
				targetPos = this.ikList[i / 2].targetRight.position,
				eps = this.ikList[i / 2].eps
			};
		}
	}

	// Token: 0x06001486 RID: 5254 RVA: 0x0006C01C File Offset: 0x0006A21C
	private void CopyOutput()
	{
		for (int i = 0; i < this.ikList.Count; i++)
		{
			this.ikList[i].leftUpperArm.localRotation = this.cachedOutput[i * 2].upperArmLocalRot;
			this.ikList[i].leftLowerArm.localRotation = this.cachedOutput[i * 2].lowerArmLocalRot;
			this.ikList[i].rightUpperArm.localRotation = this.cachedOutput[i * 2 + 1].upperArmLocalRot;
			this.ikList[i].rightLowerArm.localRotation = this.cachedOutput[i * 2 + 1].lowerArmLocalRot;
		}
	}

	// Token: 0x06001487 RID: 5255 RVA: 0x0006C0F0 File Offset: 0x0006A2F0
	public void LateUpdate()
	{
		this.CopyInput();
		GorillaIKMgr.IKJob jobData = new GorillaIKMgr.IKJob
		{
			input = this.cachedInput,
			output = this.cachedOutput
		};
		this.jobHandle = jobData.Schedule(this.actualListSz, 1, default(JobHandle));
		this.jobHandle.Complete();
		this.CopyOutput();
		foreach (GorillaIK gorillaIK in this.ikList)
		{
			gorillaIK.headBone.rotation = gorillaIK.targetHead.rotation;
			gorillaIK.leftHand.rotation = gorillaIK.targetLeft.rotation;
			gorillaIK.rightHand.rotation = gorillaIK.targetRight.rotation;
		}
		this.firstFrame = false;
	}

	// Token: 0x0400175E RID: 5982
	[OnEnterPlay_SetNull]
	private static GorillaIKMgr _instance;

	// Token: 0x0400175F RID: 5983
	private const int MaxSize = 20;

	// Token: 0x04001760 RID: 5984
	private List<GorillaIK> ikList = new List<GorillaIK>(20);

	// Token: 0x04001761 RID: 5985
	private NativeArray<GorillaIKMgr.IKInput> cachedInput;

	// Token: 0x04001762 RID: 5986
	private NativeArray<GorillaIKMgr.IKOutput> cachedOutput;

	// Token: 0x04001763 RID: 5987
	private int actualListSz;

	// Token: 0x04001764 RID: 5988
	private JobHandle jobHandle;

	// Token: 0x04001765 RID: 5989
	private bool firstFrame = true;

	// Token: 0x0200037F RID: 895
	private struct IKInput
	{
		// Token: 0x04001766 RID: 5990
		public Vector3 handPos;

		// Token: 0x04001767 RID: 5991
		public Vector3 upperArmPos;

		// Token: 0x04001768 RID: 5992
		public Quaternion upperArmRot;

		// Token: 0x04001769 RID: 5993
		public Quaternion upperArmLocalRot;

		// Token: 0x0400176A RID: 5994
		public Vector3 lowerArmPos;

		// Token: 0x0400176B RID: 5995
		public Quaternion lowerArmRot;

		// Token: 0x0400176C RID: 5996
		public Quaternion lowerArmLocalRot;

		// Token: 0x0400176D RID: 5997
		public Quaternion initRotLower;

		// Token: 0x0400176E RID: 5998
		public Quaternion initRotUpper;

		// Token: 0x0400176F RID: 5999
		public Vector3 targetPos;

		// Token: 0x04001770 RID: 6000
		public float eps;
	}

	// Token: 0x02000380 RID: 896
	private struct IKOutput
	{
		// Token: 0x06001489 RID: 5257 RVA: 0x0006C200 File Offset: 0x0006A400
		public IKOutput(Quaternion upperArmLocalRot_, Quaternion lowerArmLocalRot_)
		{
			this.upperArmLocalRot = upperArmLocalRot_;
			this.lowerArmLocalRot = lowerArmLocalRot_;
		}

		// Token: 0x04001771 RID: 6001
		public Quaternion upperArmLocalRot;

		// Token: 0x04001772 RID: 6002
		public Quaternion lowerArmLocalRot;
	}

	// Token: 0x02000381 RID: 897
	[BurstCompile]
	private struct IKJob : IJobParallelFor
	{
		// Token: 0x0600148A RID: 5258 RVA: 0x0006C210 File Offset: 0x0006A410
		public void Execute(int i)
		{
			float eps = this.input[i].eps;
			float magnitude = (this.input[i].upperArmPos - this.input[i].lowerArmPos).magnitude;
			float magnitude2 = (this.input[i].lowerArmPos - this.input[i].handPos).magnitude;
			float max = magnitude + magnitude2 - eps;
			float num = Mathf.Clamp((this.input[i].targetPos - this.input[i].upperArmPos).magnitude, eps, max);
			float num2 = Mathf.Acos(Mathf.Clamp(Vector3.Dot((this.input[i].handPos - this.input[i].upperArmPos).normalized, (this.input[i].lowerArmPos - this.input[i].upperArmPos).normalized), -1f, 1f));
			float num3 = Mathf.Acos(Mathf.Clamp(Vector3.Dot((this.input[i].upperArmPos - this.input[i].lowerArmPos).normalized, (this.input[i].handPos - this.input[i].lowerArmPos).normalized), -1f, 1f));
			float num4 = Mathf.Acos(Mathf.Clamp(Vector3.Dot((this.input[i].handPos - this.input[i].upperArmPos).normalized, (this.input[i].targetPos - this.input[i].upperArmPos).normalized), -1f, 1f));
			float num5 = Mathf.Acos(Mathf.Clamp((magnitude2 * magnitude2 - magnitude * magnitude - num * num) / (-2f * magnitude * num), -1f, 1f));
			float num6 = Mathf.Acos(Mathf.Clamp((num * num - magnitude * magnitude - magnitude2 * magnitude2) / (-2f * magnitude * magnitude2), -1f, 1f));
			Vector3 normalized = Vector3.Cross(this.input[i].handPos - this.input[i].upperArmPos, this.input[i].lowerArmPos - this.input[i].upperArmPos).normalized;
			Vector3 normalized2 = Vector3.Cross(this.input[i].handPos - this.input[i].upperArmPos, this.input[i].targetPos - this.input[i].upperArmPos).normalized;
			Quaternion rhs = Quaternion.AngleAxis((num5 - num2) * 57.29578f, Quaternion.Inverse(this.input[i].upperArmRot) * normalized);
			Quaternion rhs2 = Quaternion.AngleAxis((num6 - num3) * 57.29578f, Quaternion.Inverse(this.input[i].lowerArmRot) * normalized);
			Quaternion rhs3 = Quaternion.AngleAxis(num4 * 57.29578f, Quaternion.Inverse(this.input[i].upperArmRot) * normalized2);
			Quaternion upperArmLocalRot_ = this.input[i].initRotUpper * rhs3 * rhs;
			Quaternion lowerArmLocalRot_ = this.input[i].initRotLower * rhs2;
			this.output[i] = new GorillaIKMgr.IKOutput(upperArmLocalRot_, lowerArmLocalRot_);
		}

		// Token: 0x04001773 RID: 6003
		[ReadOnly]
		public NativeArray<GorillaIKMgr.IKInput> input;

		// Token: 0x04001774 RID: 6004
		public NativeArray<GorillaIKMgr.IKOutput> output;
	}
}
