﻿using System;
using System.Linq;
using System.Reflection;

namespace BuildSafe
{
	// Token: 0x02000627 RID: 1575
	public static class Reflection<T>
	{
		// Token: 0x1700042D RID: 1069
		// (get) Token: 0x06002517 RID: 9495 RVA: 0x000B6DD4 File Offset: 0x000B4FD4
		public static Type Type { get; } = typeof(T);

		// Token: 0x1700042E RID: 1070
		// (get) Token: 0x06002518 RID: 9496 RVA: 0x000B6DDB File Offset: 0x000B4FDB
		public static EventInfo[] Events
		{
			get
			{
				return Reflection<T>.PreFetchEvents();
			}
		}

		// Token: 0x1700042F RID: 1071
		// (get) Token: 0x06002519 RID: 9497 RVA: 0x000B6DE2 File Offset: 0x000B4FE2
		public static MethodInfo[] Methods
		{
			get
			{
				return Reflection<T>.PreFetchMethods();
			}
		}

		// Token: 0x17000430 RID: 1072
		// (get) Token: 0x0600251A RID: 9498 RVA: 0x000B6DE9 File Offset: 0x000B4FE9
		public static FieldInfo[] Fields
		{
			get
			{
				return Reflection<T>.PreFetchFields();
			}
		}

		// Token: 0x17000431 RID: 1073
		// (get) Token: 0x0600251B RID: 9499 RVA: 0x000B6DF0 File Offset: 0x000B4FF0
		public static PropertyInfo[] Properties
		{
			get
			{
				return Reflection<T>.PreFetchProperties();
			}
		}

		// Token: 0x0600251C RID: 9500 RVA: 0x000B6DF7 File Offset: 0x000B4FF7
		private static EventInfo[] PreFetchEvents()
		{
			if (Reflection<T>.gEventsCache != null)
			{
				return Reflection<T>.gEventsCache;
			}
			return Reflection<T>.gEventsCache = Reflection<T>.Type.GetRuntimeEvents().ToArray<EventInfo>();
		}

		// Token: 0x0600251D RID: 9501 RVA: 0x000B6E1B File Offset: 0x000B501B
		private static PropertyInfo[] PreFetchProperties()
		{
			if (Reflection<T>.gPropertiesCache != null)
			{
				return Reflection<T>.gPropertiesCache;
			}
			return Reflection<T>.gPropertiesCache = Reflection<T>.Type.GetRuntimeProperties().ToArray<PropertyInfo>();
		}

		// Token: 0x0600251E RID: 9502 RVA: 0x000B6E3F File Offset: 0x000B503F
		private static MethodInfo[] PreFetchMethods()
		{
			if (Reflection<T>.gMethodsCache != null)
			{
				return Reflection<T>.gMethodsCache;
			}
			return Reflection<T>.gMethodsCache = Reflection<T>.Type.GetRuntimeMethods().ToArray<MethodInfo>();
		}

		// Token: 0x0600251F RID: 9503 RVA: 0x000B6E63 File Offset: 0x000B5063
		private static FieldInfo[] PreFetchFields()
		{
			if (Reflection<T>.gFieldsCache != null)
			{
				return Reflection<T>.gFieldsCache;
			}
			return Reflection<T>.gFieldsCache = Reflection<T>.Type.GetRuntimeFields().ToArray<FieldInfo>();
		}

		// Token: 0x040027EE RID: 10222
		private static Type gCachedType;

		// Token: 0x040027EF RID: 10223
		private static MethodInfo[] gMethodsCache;

		// Token: 0x040027F0 RID: 10224
		private static FieldInfo[] gFieldsCache;

		// Token: 0x040027F1 RID: 10225
		private static PropertyInfo[] gPropertiesCache;

		// Token: 0x040027F2 RID: 10226
		private static EventInfo[] gEventsCache;
	}
}
