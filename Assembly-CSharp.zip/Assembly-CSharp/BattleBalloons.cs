﻿using System;
using Photon.Realtime;
using UnityEngine;

// Token: 0x0200023A RID: 570
public class BattleBalloons : MonoBehaviour
{
	// Token: 0x06000C15 RID: 3093 RVA: 0x0004071C File Offset: 0x0003E91C
	protected void Awake()
	{
		this.matPropBlock = new MaterialPropertyBlock();
		this.renderers = new Renderer[this.balloons.Length];
		this.balloonsCachedActiveState = new bool[this.balloons.Length];
		for (int i = 0; i < this.balloons.Length; i++)
		{
			this.renderers[i] = this.balloons[i].GetComponentInChildren<Renderer>();
			this.balloonsCachedActiveState[i] = this.balloons[i].activeSelf;
		}
		this.colorShaderPropID = Shader.PropertyToID("_Color");
	}

	// Token: 0x06000C16 RID: 3094 RVA: 0x000407A7 File Offset: 0x0003E9A7
	protected void OnEnable()
	{
		this.UpdateBalloonColors();
	}

	// Token: 0x06000C17 RID: 3095 RVA: 0x000407B0 File Offset: 0x0003E9B0
	protected void LateUpdate()
	{
		if (GorillaGameManager.instance != null && (this.bMgr != null || GorillaGameManager.instance.gameObject.GetComponent<GorillaBattleManager>() != null))
		{
			if (this.bMgr == null)
			{
				this.bMgr = GorillaGameManager.instance.gameObject.GetComponent<GorillaBattleManager>();
			}
			int playerLives = this.bMgr.GetPlayerLives(this.myRig.creator);
			for (int i = 0; i < this.balloons.Length; i++)
			{
				bool flag = playerLives >= i + 1;
				if (flag != this.balloonsCachedActiveState[i])
				{
					this.balloonsCachedActiveState[i] = flag;
					this.balloons[i].SetActive(flag);
					if (!flag)
					{
						this.PopBalloon(i);
					}
				}
			}
		}
		else if (GorillaGameManager.instance != null)
		{
			base.gameObject.SetActive(false);
		}
		this.UpdateBalloonColors();
	}

	// Token: 0x06000C18 RID: 3096 RVA: 0x0004089C File Offset: 0x0003EA9C
	private void PopBalloon(int i)
	{
		GameObject gameObject = ObjectPools.instance.Instantiate(this.balloonPopFXPrefab);
		gameObject.transform.position = this.balloons[i].transform.position;
		GorillaColorizableBase componentInChildren = gameObject.GetComponentInChildren<GorillaColorizableBase>();
		if (componentInChildren != null)
		{
			componentInChildren.SetColor(this.teamColor);
		}
	}

	// Token: 0x06000C19 RID: 3097 RVA: 0x000408F4 File Offset: 0x0003EAF4
	public void UpdateBalloonColors()
	{
		if (this.bMgr != null && this.myRig.creator != null)
		{
			if (this.bMgr.OnRedTeam(this.myRig.creator))
			{
				this.teamColor = this.orangeColor;
			}
			else
			{
				this.teamColor = this.blueColor;
			}
		}
		if (this.teamColor != this.lastColor)
		{
			this.lastColor = this.teamColor;
			foreach (Renderer renderer in this.renderers)
			{
				if (renderer)
				{
					foreach (Material material in renderer.materials)
					{
						if (!(material == null))
						{
							if (material.HasProperty("_BaseColor"))
							{
								material.SetColor("_BaseColor", this.teamColor);
							}
							if (material.HasProperty("_Color"))
							{
								material.SetColor("_Color", this.teamColor);
							}
						}
					}
				}
			}
		}
	}

	// Token: 0x04000D72 RID: 3442
	public VRRig myRig;

	// Token: 0x04000D73 RID: 3443
	public GameObject[] balloons;

	// Token: 0x04000D74 RID: 3444
	public Color orangeColor;

	// Token: 0x04000D75 RID: 3445
	public Color blueColor;

	// Token: 0x04000D76 RID: 3446
	public Color defaultColor;

	// Token: 0x04000D77 RID: 3447
	public Color lastColor;

	// Token: 0x04000D78 RID: 3448
	public GameObject balloonPopFXPrefab;

	// Token: 0x04000D79 RID: 3449
	public GorillaBattleManager bMgr;

	// Token: 0x04000D7A RID: 3450
	public Player myPlayer;

	// Token: 0x04000D7B RID: 3451
	private int colorShaderPropID;

	// Token: 0x04000D7C RID: 3452
	private MaterialPropertyBlock matPropBlock;

	// Token: 0x04000D7D RID: 3453
	private bool[] balloonsCachedActiveState;

	// Token: 0x04000D7E RID: 3454
	private Renderer[] renderers;

	// Token: 0x04000D7F RID: 3455
	private Color teamColor;
}
