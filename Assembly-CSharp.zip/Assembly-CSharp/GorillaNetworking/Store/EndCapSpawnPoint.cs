﻿using System;
using UnityEngine;

namespace GorillaNetworking.Store
{
	// Token: 0x020006F6 RID: 1782
	public class EndCapSpawnPoint : MonoBehaviour
	{
	}
}
