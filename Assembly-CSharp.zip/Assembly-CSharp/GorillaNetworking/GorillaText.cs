﻿using System;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace GorillaNetworking
{
	// Token: 0x020006C2 RID: 1730
	[Serializable]
	public class GorillaText
	{
		// Token: 0x06002910 RID: 10512 RVA: 0x000CA482 File Offset: 0x000C8682
		public void Initialize(Material[] originalMaterials, Material failureMaterial, UnityEvent<string> callback = null, UnityEvent<Material[]> materialCallback = null)
		{
			this.failureMaterial = failureMaterial;
			this.originalMaterials = originalMaterials;
			this.currentMaterials = originalMaterials;
			Debug.Log("Original text = " + this.originalText);
			this.updateTextCallback = callback;
			this.updateMaterialCallback = materialCallback;
		}

		// Token: 0x170004C9 RID: 1225
		// (get) Token: 0x06002911 RID: 10513 RVA: 0x000CA4BD File Offset: 0x000C86BD
		// (set) Token: 0x06002912 RID: 10514 RVA: 0x000CA4C5 File Offset: 0x000C86C5
		public string Text
		{
			get
			{
				return this.originalText;
			}
			set
			{
				if (this.originalText == value)
				{
					return;
				}
				this.originalText = value;
				if (!this.failedState)
				{
					UnityEvent<string> unityEvent = this.updateTextCallback;
					if (unityEvent == null)
					{
						return;
					}
					unityEvent.Invoke(value);
				}
			}
		}

		// Token: 0x06002913 RID: 10515 RVA: 0x000CA4F8 File Offset: 0x000C86F8
		public void EnableFailedState(string failText)
		{
			this.failedState = true;
			this.failureText = failText;
			UnityEvent<string> unityEvent = this.updateTextCallback;
			if (unityEvent != null)
			{
				unityEvent.Invoke(failText);
			}
			this.currentMaterials = (Material[])this.originalMaterials.Clone();
			this.currentMaterials[0] = this.failureMaterial;
			UnityEvent<Material[]> unityEvent2 = this.updateMaterialCallback;
			if (unityEvent2 == null)
			{
				return;
			}
			unityEvent2.Invoke(this.currentMaterials);
		}

		// Token: 0x06002914 RID: 10516 RVA: 0x000CA560 File Offset: 0x000C8760
		public void DisableFailedState()
		{
			this.failedState = true;
			UnityEvent<string> unityEvent = this.updateTextCallback;
			if (unityEvent != null)
			{
				unityEvent.Invoke(this.originalText);
			}
			this.failureText = "";
			this.currentMaterials = this.originalMaterials;
			UnityEvent<Material[]> unityEvent2 = this.updateMaterialCallback;
			if (unityEvent2 == null)
			{
				return;
			}
			unityEvent2.Invoke(this.currentMaterials);
		}

		// Token: 0x04002C17 RID: 11287
		[SerializeField]
		private Text text;

		// Token: 0x04002C18 RID: 11288
		private string failureText;

		// Token: 0x04002C19 RID: 11289
		private string originalText = string.Empty;

		// Token: 0x04002C1A RID: 11290
		private bool failedState;

		// Token: 0x04002C1B RID: 11291
		private Material[] originalMaterials;

		// Token: 0x04002C1C RID: 11292
		private Material failureMaterial;

		// Token: 0x04002C1D RID: 11293
		internal Material[] currentMaterials;

		// Token: 0x04002C1E RID: 11294
		private UnityEvent<string> updateTextCallback;

		// Token: 0x04002C1F RID: 11295
		private UnityEvent<Material[]> updateMaterialCallback;
	}
}
