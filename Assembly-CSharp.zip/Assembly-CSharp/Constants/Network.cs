﻿using System;

namespace Constants
{
	// Token: 0x020005A5 RID: 1445
	public static class Network
	{
		// Token: 0x0400230A RID: 8970
		public const byte PLAYER_TAGGED = 1;

		// Token: 0x0400230B RID: 8971
		public const byte PLAYER_INFECTED = 2;

		// Token: 0x0400230C RID: 8972
		public const byte ROOM_SYSTEM = 3;

		// Token: 0x0400230D RID: 8973
		public const byte COSMETIC_PURCHASE = 9;

		// Token: 0x0400230E RID: 8974
		public const byte REPORT_PLAYER = 50;

		// Token: 0x0400230F RID: 8975
		public const byte REPORT_MUTE = 51;

		// Token: 0x04002310 RID: 8976
		public const byte COSMETIC_EVENT = 176;

		// Token: 0x04002311 RID: 8977
		public const byte COSMETICS_LOOKUP = 199;
	}
}
