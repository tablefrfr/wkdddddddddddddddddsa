﻿using System;
using GorillaLocomotion;
using UnityEngine;

// Token: 0x02000341 RID: 833
public class EnclosedSpaceVolume : GorillaTriggerBox
{
	// Token: 0x060012A5 RID: 4773 RVA: 0x000635BE File Offset: 0x000617BE
	private void Awake()
	{
		this.audioSourceInside.volume = this.quietVolume;
		this.audioSourceOutside.volume = this.loudVolume;
	}

	// Token: 0x060012A6 RID: 4774 RVA: 0x000635E2 File Offset: 0x000617E2
	private void OnTriggerEnter(Collider other)
	{
		if (other.attachedRigidbody.GetComponentInParent<Player>() != null)
		{
			this.audioSourceInside.volume = this.loudVolume;
			this.audioSourceOutside.volume = this.quietVolume;
		}
	}

	// Token: 0x060012A7 RID: 4775 RVA: 0x00063619 File Offset: 0x00061819
	private void OnTriggerExit(Collider other)
	{
		if (other.attachedRigidbody.GetComponentInParent<Player>() != null)
		{
			this.audioSourceInside.volume = this.quietVolume;
			this.audioSourceOutside.volume = this.loudVolume;
		}
	}

	// Token: 0x040015B9 RID: 5561
	public AudioSource audioSourceInside;

	// Token: 0x040015BA RID: 5562
	public AudioSource audioSourceOutside;

	// Token: 0x040015BB RID: 5563
	public float loudVolume;

	// Token: 0x040015BC RID: 5564
	public float quietVolume;
}
