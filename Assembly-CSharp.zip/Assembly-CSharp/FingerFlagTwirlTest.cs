﻿using System;
using UnityEngine;

// Token: 0x02000049 RID: 73
public class FingerFlagTwirlTest : MonoBehaviour
{
	// Token: 0x0600016C RID: 364 RVA: 0x0000BC8C File Offset: 0x00009E8C
	protected void FixedUpdate()
	{
		this.animTimes += Time.deltaTime * this.rotAnimDurations;
		this.animTimes.x = this.animTimes.x % 1f;
		this.animTimes.y = this.animTimes.y % 1f;
		this.animTimes.z = this.animTimes.z % 1f;
		base.transform.localRotation = Quaternion.Euler(this.rotXAnimCurve.Evaluate(this.animTimes.x) * this.rotAnimAmplitudes.x, this.rotYAnimCurve.Evaluate(this.animTimes.y) * this.rotAnimAmplitudes.y, this.rotZAnimCurve.Evaluate(this.animTimes.z) * this.rotAnimAmplitudes.z);
	}

	// Token: 0x040001F1 RID: 497
	public Vector3 rotAnimDurations = new Vector3(0.2f, 0.1f, 0.5f);

	// Token: 0x040001F2 RID: 498
	public Vector3 rotAnimAmplitudes = Vector3.one * 360f;

	// Token: 0x040001F3 RID: 499
	public AnimationCurve rotXAnimCurve;

	// Token: 0x040001F4 RID: 500
	public AnimationCurve rotYAnimCurve;

	// Token: 0x040001F5 RID: 501
	public AnimationCurve rotZAnimCurve;

	// Token: 0x040001F6 RID: 502
	private Vector3 animTimes = Vector3.zero;
}
