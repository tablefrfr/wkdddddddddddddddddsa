﻿using System;
using System.Runtime.CompilerServices;

namespace Fusion.CodeGen
{
	// Token: 0x02000848 RID: 2120
	internal struct ReaderWriter@Fusion_NetworkString : IElementReaderWriter<NetworkString<_32>>
	{
		// Token: 0x06003325 RID: 13093 RVA: 0x001004A9 File Offset: 0x000FE6A9
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public unsafe NetworkString<_32> Read(byte* data, int index)
		{
			return *(NetworkString<_32>*)(data + index * 132);
		}

		// Token: 0x06003326 RID: 13094 RVA: 0x001004B9 File Offset: 0x000FE6B9
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public unsafe ref NetworkString<_32> ReadRef(byte* data, int index)
		{
			return ref *(NetworkString<_32>*)(data + index * 132);
		}

		// Token: 0x06003327 RID: 13095 RVA: 0x001004C4 File Offset: 0x000FE6C4
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public unsafe void Write(byte* data, int index, NetworkString<_32> val)
		{
			*(NetworkString<_32>*)(data + index * 132) = val;
		}

		// Token: 0x06003328 RID: 13096 RVA: 0x001004D5 File Offset: 0x000FE6D5
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public int GetElementWordCount()
		{
			return 33;
		}

		// Token: 0x06003329 RID: 13097 RVA: 0x001004DC File Offset: 0x000FE6DC
		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public static IElementReaderWriter<NetworkString<_32>> GetInstance()
		{
			if (ReaderWriter@Fusion_NetworkString.Instance == null)
			{
				ReaderWriter@Fusion_NetworkString.Instance = default(ReaderWriter@Fusion_NetworkString);
			}
			return ReaderWriter@Fusion_NetworkString.Instance;
		}

		// Token: 0x04003652 RID: 13906
		public static IElementReaderWriter<NetworkString<_32>> Instance;
	}
}
