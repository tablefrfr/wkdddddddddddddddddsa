﻿using System;
using UnityEngine;

// Token: 0x02000479 RID: 1145
[CreateAssetMenu(menuName = "ScriptableObjects/FXSystemSettings", order = 2)]
public class FXSystemSettings : ScriptableObject
{
	// Token: 0x06001A8C RID: 6796 RVA: 0x00088110 File Offset: 0x00086310
	public void Awake()
	{
		int num = (this.callLimits != null) ? this.callLimits.Length : 0;
		int num2 = (this.CallLimitsCooldown != null) ? this.CallLimitsCooldown.Length : 0;
		for (int i = 0; i < num; i++)
		{
			FXType key = this.callLimits[i].Key;
			int num3 = (int)key;
			if (this.callSettings[num3] != null)
			{
				Debug.Log("call setting for " + key.ToString() + " already exists, skipping");
			}
			else
			{
				this.callSettings[num3] = this.callLimits[i];
			}
		}
		for (int i = 0; i < num2; i++)
		{
			FXType key = this.CallLimitsCooldown[i].Key;
			int num3 = (int)key;
			if (this.callSettings[num3] != null)
			{
				Debug.Log("call setting for " + key.ToString() + " already exists, skipping");
			}
			else
			{
				this.callSettings[num3] = this.CallLimitsCooldown[i];
			}
		}
	}

	// Token: 0x04001E84 RID: 7812
	[SerializeField]
	private LimiterType[] callLimits;

	// Token: 0x04001E85 RID: 7813
	[SerializeField]
	private CooldownType[] CallLimitsCooldown;

	// Token: 0x04001E86 RID: 7814
	[NonSerialized]
	public bool forLocalRig;

	// Token: 0x04001E87 RID: 7815
	[NonSerialized]
	public CallLimitType<CallLimiter>[] callSettings = new CallLimitType<CallLimiter>[5];
}
