﻿using System;

namespace Constants
{
	// Token: 0x020005A7 RID: 1447
	public static class Strings
	{
	}
}
