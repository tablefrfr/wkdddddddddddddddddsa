﻿using System;
using UnityEngine;

namespace BoingKit
{
	// Token: 0x0200082B RID: 2091
	[AttributeUsage(AttributeTargets.Field)]
	public class ConditionalFieldAttribute : PropertyAttribute
	{
		// Token: 0x17000578 RID: 1400
		// (get) Token: 0x060032BB RID: 12987 RVA: 0x000FEA87 File Offset: 0x000FCC87
		public bool ShowRange
		{
			get
			{
				return this.Min != this.Max;
			}
		}

		// Token: 0x060032BC RID: 12988 RVA: 0x000FEA9C File Offset: 0x000FCC9C
		public ConditionalFieldAttribute(string propertyToCheck = null, object compareValue = null, object compareValue2 = null, object compareValue3 = null, object compareValue4 = null, object compareValue5 = null, object compareValue6 = null)
		{
			this.PropertyToCheck = propertyToCheck;
			this.CompareValue = compareValue;
			this.CompareValue2 = compareValue2;
			this.CompareValue3 = compareValue3;
			this.CompareValue4 = compareValue4;
			this.CompareValue5 = compareValue5;
			this.CompareValue6 = compareValue6;
			this.Label = "";
			this.Tooltip = "";
			this.Min = 0f;
			this.Max = 0f;
		}

		// Token: 0x0400352A RID: 13610
		public string PropertyToCheck;

		// Token: 0x0400352B RID: 13611
		public object CompareValue;

		// Token: 0x0400352C RID: 13612
		public object CompareValue2;

		// Token: 0x0400352D RID: 13613
		public object CompareValue3;

		// Token: 0x0400352E RID: 13614
		public object CompareValue4;

		// Token: 0x0400352F RID: 13615
		public object CompareValue5;

		// Token: 0x04003530 RID: 13616
		public object CompareValue6;

		// Token: 0x04003531 RID: 13617
		public string Label;

		// Token: 0x04003532 RID: 13618
		public string Tooltip;

		// Token: 0x04003533 RID: 13619
		public float Min;

		// Token: 0x04003534 RID: 13620
		public float Max;
	}
}
