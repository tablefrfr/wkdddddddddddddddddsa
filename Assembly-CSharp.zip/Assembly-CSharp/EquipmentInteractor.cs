﻿using System;
using System.Collections.Generic;
using GorillaLocomotion.Climbing;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x0200023C RID: 572
public class EquipmentInteractor : MonoBehaviour
{
	// Token: 0x06000C1C RID: 3100 RVA: 0x000409FC File Offset: 0x0003EBFC
	private void Awake()
	{
		if (EquipmentInteractor.instance == null)
		{
			EquipmentInteractor.instance = this;
			EquipmentInteractor.hasInstance = true;
		}
		else if (EquipmentInteractor.instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		this.leftHandSet = false;
		this.rightHandSet = false;
		this.autoGrabLeft = true;
		this.autoGrabRight = true;
		this.gorillaInteractableLayerMask = LayerMask.GetMask(new string[]
		{
			"GorillaInteractable"
		});
	}

	// Token: 0x06000C1D RID: 3101 RVA: 0x00040A77 File Offset: 0x0003EC77
	private void OnDestroy()
	{
		if (EquipmentInteractor.instance == this)
		{
			EquipmentInteractor.hasInstance = false;
			EquipmentInteractor.instance = null;
		}
	}

	// Token: 0x06000C1E RID: 3102 RVA: 0x00040A98 File Offset: 0x0003EC98
	public void ReleaseRightHand()
	{
		if (this.rightHandHeldEquipment != null)
		{
			this.rightHandHeldEquipment.OnRelease(null, this.rightHand);
		}
		if (this.leftHandHeldEquipment != null)
		{
			this.leftHandHeldEquipment.OnRelease(null, this.rightHand);
		}
		this.autoGrabRight = true;
	}

	// Token: 0x06000C1F RID: 3103 RVA: 0x00040AF0 File Offset: 0x0003ECF0
	public void ReleaseLeftHand()
	{
		if (this.rightHandHeldEquipment != null)
		{
			this.rightHandHeldEquipment.OnRelease(null, this.leftHand);
		}
		if (this.leftHandHeldEquipment != null)
		{
			this.leftHandHeldEquipment.OnRelease(null, this.leftHand);
		}
		this.autoGrabLeft = true;
	}

	// Token: 0x06000C20 RID: 3104 RVA: 0x00040B46 File Offset: 0x0003ED46
	public void ForceStopClimbing()
	{
		this.leftClimber.ForceStopClimbing(false, false);
		this.rightClimber.ForceStopClimbing(false, false);
	}

	// Token: 0x06000C21 RID: 3105 RVA: 0x00040B62 File Offset: 0x0003ED62
	public bool GetIsHolding(XRNode node)
	{
		if (node == XRNode.LeftHand)
		{
			return this.leftHandHeldEquipment;
		}
		return this.rightHandHeldEquipment;
	}

	// Token: 0x06000C22 RID: 3106 RVA: 0x00040B80 File Offset: 0x0003ED80
	private void LateUpdate()
	{
		if (ApplicationQuittingState.IsQuitting)
		{
			return;
		}
		this.CheckInputValue(true);
		this.isLeftGrabbing = ((this.wasLeftGrabPressed && this.grabValue > this.grabThreshold - this.grabHysteresis) || (!this.wasLeftGrabPressed && this.grabValue > this.grabThreshold + this.grabHysteresis));
		if (this.leftClimber && this.leftClimber.isClimbing)
		{
			this.isLeftGrabbing = false;
		}
		this.CheckInputValue(false);
		this.isRightGrabbing = ((this.wasRightGrabPressed && this.grabValue > this.grabThreshold - this.grabHysteresis) || (!this.wasRightGrabPressed && this.grabValue > this.grabThreshold + this.grabHysteresis));
		if (this.rightClimber && this.rightClimber.isClimbing)
		{
			this.isRightGrabbing = false;
		}
		this.FireHandInteractions(this.leftHand, true, this.builderPieceInteractor.heldPiece[0]);
		this.FireHandInteractions(this.rightHand, false, this.builderPieceInteractor.heldPiece[1]);
		if (!this.isRightGrabbing && this.wasRightGrabPressed)
		{
			this.ReleaseRightHand();
		}
		if (!this.isLeftGrabbing && this.wasLeftGrabPressed)
		{
			this.ReleaseLeftHand();
		}
		this.builderPieceInteractor.OnLateUpdate();
		this.wasLeftGrabPressed = this.isLeftGrabbing;
		this.wasRightGrabPressed = this.isRightGrabbing;
	}

	// Token: 0x06000C23 RID: 3107 RVA: 0x00040CFC File Offset: 0x0003EEFC
	private void FireHandInteractions(GameObject interactingHand, bool isLeftHand, BuilderPiece pieceInHand)
	{
		float scaleFactor = GorillaTagger.Instance.offlineVRRig.scaleFactor;
		if (isLeftHand)
		{
			this.justGrabbed = ((this.isLeftGrabbing && !this.wasLeftGrabPressed) || (this.isLeftGrabbing && this.autoGrabLeft));
			this.justReleased = (this.leftHandHeldEquipment != null && !this.isLeftGrabbing && this.wasLeftGrabPressed);
		}
		else
		{
			this.justGrabbed = ((this.isRightGrabbing && !this.wasRightGrabPressed) || (this.isRightGrabbing && this.autoGrabRight));
			this.justReleased = (this.rightHandHeldEquipment != null && !this.isRightGrabbing && this.wasRightGrabPressed);
		}
		List<InteractionPoint> list = isLeftHand ? this.overlapInteractionPointsLeft : this.overlapInteractionPointsRight;
		bool flag = isLeftHand ? (this.leftHandHeldEquipment != null) : (this.rightHandHeldEquipment != null);
		bool flag2 = pieceInHand != null;
		bool flag3 = isLeftHand ? this.disableLeftGrab : this.disableRightGrab;
		bool flag4 = !flag && !flag2 && !flag3;
		foreach (InteractionPoint interactionPoint in list)
		{
			if (flag4 && interactionPoint != null)
			{
				if (this.justGrabbed)
				{
					interactionPoint.Holdable.OnGrab(interactionPoint, interactingHand);
				}
				else
				{
					interactionPoint.Holdable.OnHover(interactionPoint, interactingHand);
				}
			}
			if (this.justReleased)
			{
				this.tempZone = interactionPoint.GetComponent<DropZone>();
				if (this.tempZone != null)
				{
					if (interactingHand == this.leftHand)
					{
						if (this.leftHandHeldEquipment != null)
						{
							this.leftHandHeldEquipment.OnRelease(this.tempZone, interactingHand);
						}
					}
					else if (this.rightHandHeldEquipment != null)
					{
						this.rightHandHeldEquipment.OnRelease(this.tempZone, interactingHand);
					}
				}
			}
		}
	}

	// Token: 0x06000C24 RID: 3108 RVA: 0x00040F00 File Offset: 0x0003F100
	public void UpdateHandEquipment(HoldableObject newEquipment, bool forLeftHand)
	{
		if (forLeftHand)
		{
			if (newEquipment != null && newEquipment == this.rightHandHeldEquipment && !newEquipment.TwoHanded)
			{
				this.rightHandHeldEquipment = null;
			}
			if (this.leftHandHeldEquipment != null)
			{
				this.leftHandHeldEquipment.DropItemCleanup();
			}
			this.leftHandHeldEquipment = newEquipment;
			this.autoGrabLeft = false;
			return;
		}
		if (newEquipment != null && newEquipment == this.leftHandHeldEquipment && !newEquipment.TwoHanded)
		{
			this.leftHandHeldEquipment = null;
		}
		if (this.rightHandHeldEquipment != null)
		{
			this.rightHandHeldEquipment.DropItemCleanup();
		}
		this.rightHandHeldEquipment = newEquipment;
		this.autoGrabRight = false;
	}

	// Token: 0x06000C25 RID: 3109 RVA: 0x00040FAC File Offset: 0x0003F1AC
	public void CheckInputValue(bool isLeftHand)
	{
		if (isLeftHand)
		{
			this.grabValue = ControllerInputPoller.GripFloat(XRNode.LeftHand);
			this.tempValue = ControllerInputPoller.TriggerFloat(XRNode.LeftHand);
		}
		else
		{
			this.grabValue = ControllerInputPoller.GripFloat(XRNode.RightHand);
			this.tempValue = ControllerInputPoller.TriggerFloat(XRNode.RightHand);
		}
		this.grabValue = Mathf.Max(this.grabValue, this.tempValue);
	}

	// Token: 0x06000C26 RID: 3110 RVA: 0x00041005 File Offset: 0x0003F205
	public void ForceDropEquipment(HoldableObject equipment)
	{
		if (this.rightHandHeldEquipment == equipment)
		{
			this.rightHandHeldEquipment = null;
		}
		if (this.leftHandHeldEquipment == equipment)
		{
			this.leftHandHeldEquipment = null;
		}
	}

	// Token: 0x06000C27 RID: 3111 RVA: 0x00041034 File Offset: 0x0003F234
	public void ForceDropManipulatableObject(HoldableObject manipulatableObject)
	{
		if (this.rightHandHeldEquipment == manipulatableObject)
		{
			this.rightHandHeldEquipment.OnRelease(null, this.rightHand);
			this.rightHandHeldEquipment = null;
			this.autoGrabRight = false;
		}
		if (this.leftHandHeldEquipment == manipulatableObject)
		{
			this.leftHandHeldEquipment.OnRelease(null, this.leftHand);
			this.leftHandHeldEquipment = null;
			this.autoGrabLeft = false;
		}
	}

	// Token: 0x04000D83 RID: 3459
	[OnEnterPlay_SetNull]
	public static volatile EquipmentInteractor instance;

	// Token: 0x04000D84 RID: 3460
	[OnEnterPlay_Set(false)]
	public static bool hasInstance;

	// Token: 0x04000D85 RID: 3461
	public BuilderPieceInteractor builderPieceInteractor;

	// Token: 0x04000D86 RID: 3462
	public HoldableObject leftHandHeldEquipment;

	// Token: 0x04000D87 RID: 3463
	public HoldableObject rightHandHeldEquipment;

	// Token: 0x04000D88 RID: 3464
	public Transform leftHandTransform;

	// Token: 0x04000D89 RID: 3465
	public Transform rightHandTransform;

	// Token: 0x04000D8A RID: 3466
	public Transform chestTransform;

	// Token: 0x04000D8B RID: 3467
	public Transform leftArmTransform;

	// Token: 0x04000D8C RID: 3468
	public Transform rightArmTransform;

	// Token: 0x04000D8D RID: 3469
	public GameObject rightHand;

	// Token: 0x04000D8E RID: 3470
	public GameObject leftHand;

	// Token: 0x04000D8F RID: 3471
	private bool leftHandSet;

	// Token: 0x04000D90 RID: 3472
	private bool rightHandSet;

	// Token: 0x04000D91 RID: 3473
	public InputDevice leftHandDevice;

	// Token: 0x04000D92 RID: 3474
	public InputDevice rightHandDevice;

	// Token: 0x04000D93 RID: 3475
	public List<InteractionPoint> overlapInteractionPointsLeft = new List<InteractionPoint>();

	// Token: 0x04000D94 RID: 3476
	public List<InteractionPoint> overlapInteractionPointsRight = new List<InteractionPoint>();

	// Token: 0x04000D95 RID: 3477
	public List<GameObject> collisionDisabledPiecesLeft = new List<GameObject>();

	// Token: 0x04000D96 RID: 3478
	public List<GameObject> collisionDisabledPiecesRight = new List<GameObject>();

	// Token: 0x04000D97 RID: 3479
	private int gorillaInteractableLayerMask;

	// Token: 0x04000D98 RID: 3480
	public float grabRadius;

	// Token: 0x04000D99 RID: 3481
	public float grabThreshold = 0.7f;

	// Token: 0x04000D9A RID: 3482
	public float grabHysteresis = 0.05f;

	// Token: 0x04000D9B RID: 3483
	public bool wasLeftGrabPressed;

	// Token: 0x04000D9C RID: 3484
	public bool wasRightGrabPressed;

	// Token: 0x04000D9D RID: 3485
	public bool isLeftGrabbing;

	// Token: 0x04000D9E RID: 3486
	public bool isRightGrabbing;

	// Token: 0x04000D9F RID: 3487
	public bool justReleased;

	// Token: 0x04000DA0 RID: 3488
	public bool justGrabbed;

	// Token: 0x04000DA1 RID: 3489
	public bool disableLeftGrab;

	// Token: 0x04000DA2 RID: 3490
	public bool disableRightGrab;

	// Token: 0x04000DA3 RID: 3491
	public bool autoGrabLeft;

	// Token: 0x04000DA4 RID: 3492
	public bool autoGrabRight;

	// Token: 0x04000DA5 RID: 3493
	private float grabValue;

	// Token: 0x04000DA6 RID: 3494
	private float tempValue;

	// Token: 0x04000DA7 RID: 3495
	private InteractionPoint tempPoint;

	// Token: 0x04000DA8 RID: 3496
	private DropZone tempZone;

	// Token: 0x04000DA9 RID: 3497
	[SerializeField]
	private GorillaHandClimber leftClimber;

	// Token: 0x04000DAA RID: 3498
	[SerializeField]
	private GorillaHandClimber rightClimber;

	// Token: 0x04000DAB RID: 3499
	private static RaycastHit[] tempHitResults = new RaycastHit[64];
}
