﻿using System;

// Token: 0x02000475 RID: 1141
public enum FXType
{
	// Token: 0x04001E7B RID: 7803
	BalloonPop,
	// Token: 0x04001E7C RID: 7804
	PlayHandTap,
	// Token: 0x04001E7D RID: 7805
	HWIngredients,
	// Token: 0x04001E7E RID: 7806
	Impact,
	// Token: 0x04001E7F RID: 7807
	Projectile,
	// Token: 0x04001E80 RID: 7808
	Length
}
