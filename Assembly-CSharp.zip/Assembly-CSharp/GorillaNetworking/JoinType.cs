﻿using System;

namespace GorillaNetworking
{
	// Token: 0x020006D7 RID: 1751
	public enum JoinType
	{
		// Token: 0x04002C67 RID: 11367
		Solo,
		// Token: 0x04002C68 RID: 11368
		JoinWithNearby,
		// Token: 0x04002C69 RID: 11369
		JoinWithParty,
		// Token: 0x04002C6A RID: 11370
		ForceJoinWithParty,
		// Token: 0x04002C6B RID: 11371
		FollowingNearby,
		// Token: 0x04002C6C RID: 11372
		FollowingParty
	}
}
