﻿using System;
using GorillaLocomotion;
using UnityEngine;

// Token: 0x02000340 RID: 832
public class ElderGorilla : MonoBehaviour
{
	// Token: 0x060012A0 RID: 4768 RVA: 0x00063418 File Offset: 0x00061618
	private void Update()
	{
		if (Player.Instance == null)
		{
			return;
		}
		if (Player.Instance.inOverlay || !Player.Instance.isUserPresent)
		{
			return;
		}
		this.tHMD = Player.Instance.headCollider.transform;
		this.tLeftHand = Player.Instance.leftControllerTransform;
		this.tRightHand = Player.Instance.rightControllerTransform;
		if (Time.time - this.timeLastValidArmDist > 1f)
		{
			this.CheckHandDistance(this.tLeftHand);
			this.CheckHandDistance(this.tRightHand);
		}
		this.CheckHeight();
		this.CheckMicVolume();
	}

	// Token: 0x060012A1 RID: 4769 RVA: 0x000634B8 File Offset: 0x000616B8
	private void CheckHandDistance(Transform hand)
	{
		float num = Vector3.Distance(hand.localPosition, this.tHMD.localPosition);
		if (num >= 1f)
		{
			return;
		}
		if (num >= 0.75f)
		{
			this.countValidArmDists++;
			this.timeLastValidArmDist = Time.time;
		}
	}

	// Token: 0x060012A2 RID: 4770 RVA: 0x00063508 File Offset: 0x00061708
	private void CheckHeight()
	{
		float y = this.tHMD.localPosition.y;
		if (!this.trackingHeadHeight)
		{
			this.trackedHeadHeight = y - 0.05f;
			this.timerTrackedHeadHeight = 0f;
		}
		else if (this.trackedHeadHeight < y)
		{
			this.trackingHeadHeight = false;
		}
		if (this.trackingHeadHeight)
		{
			if (this.timerTrackedHeadHeight >= 1f)
			{
				this.savedHeadHeight = y;
				this.trackingHeadHeight = false;
				return;
			}
			this.timerTrackedHeadHeight += Time.deltaTime;
		}
	}

	// Token: 0x060012A3 RID: 4771 RVA: 0x0006358E File Offset: 0x0006178E
	private void CheckMicVolume()
	{
		float currentPeakAmp = GorillaTagger.Instance.myRecorder.LevelMeter.CurrentPeakAmp;
	}

	// Token: 0x040015AC RID: 5548
	private const float MAX_HAND_DIST = 1f;

	// Token: 0x040015AD RID: 5549
	private const float COOLDOWN_HAND_DIST = 1f;

	// Token: 0x040015AE RID: 5550
	private const float VALID_HAND_DIST = 0.75f;

	// Token: 0x040015AF RID: 5551
	private const float TIME_VALID_HEAD_HEIGHT = 1f;

	// Token: 0x040015B0 RID: 5552
	private Transform tHMD;

	// Token: 0x040015B1 RID: 5553
	private Transform tLeftHand;

	// Token: 0x040015B2 RID: 5554
	private Transform tRightHand;

	// Token: 0x040015B3 RID: 5555
	private int countValidArmDists;

	// Token: 0x040015B4 RID: 5556
	private float timeLastValidArmDist;

	// Token: 0x040015B5 RID: 5557
	private bool trackingHeadHeight;

	// Token: 0x040015B6 RID: 5558
	private float trackedHeadHeight;

	// Token: 0x040015B7 RID: 5559
	private float timerTrackedHeadHeight;

	// Token: 0x040015B8 RID: 5560
	private float savedHeadHeight = 1.5f;
}
