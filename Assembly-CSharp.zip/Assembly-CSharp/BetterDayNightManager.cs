﻿using System;
using System.Collections;
using System.Collections.Generic;
using GorillaNetworking;
using UnityEngine;

// Token: 0x020003EB RID: 1003
public class BetterDayNightManager : MonoBehaviour, ITimeOfDaySystem
{
	// Token: 0x0600175D RID: 5981 RVA: 0x00077955 File Offset: 0x00075B55
	public static void Register(PerSceneRenderData data)
	{
		BetterDayNightManager.allScenesRenderData.Add(data);
	}

	// Token: 0x0600175E RID: 5982 RVA: 0x00077962 File Offset: 0x00075B62
	public static void Unregister(PerSceneRenderData data)
	{
		BetterDayNightManager.allScenesRenderData.Remove(data);
	}

	// Token: 0x170002DF RID: 735
	// (get) Token: 0x0600175F RID: 5983 RVA: 0x00077970 File Offset: 0x00075B70
	// (set) Token: 0x06001760 RID: 5984 RVA: 0x00077978 File Offset: 0x00075B78
	public string currentTimeOfDay { get; private set; }

	// Token: 0x170002E0 RID: 736
	// (get) Token: 0x06001761 RID: 5985 RVA: 0x00077981 File Offset: 0x00075B81
	double ITimeOfDaySystem.currentTimeInSeconds
	{
		get
		{
			return this.currentTime;
		}
	}

	// Token: 0x170002E1 RID: 737
	// (get) Token: 0x06001762 RID: 5986 RVA: 0x00077989 File Offset: 0x00075B89
	double ITimeOfDaySystem.totalTimeInSeconds
	{
		get
		{
			return this.totalSeconds;
		}
	}

	// Token: 0x06001763 RID: 5987 RVA: 0x00077994 File Offset: 0x00075B94
	private void OnEnable()
	{
		if (BetterDayNightManager.instance == null)
		{
			BetterDayNightManager.instance = this;
		}
		else if (BetterDayNightManager.instance != this)
		{
			Object.Destroy(base.gameObject);
		}
		this.currentLerp = 0f;
		this.totalHours = 0.0;
		for (int i = 0; i < this.timeOfDayRange.Length; i++)
		{
			this.totalHours += this.timeOfDayRange[i];
		}
		this.totalSeconds = this.totalHours * 60.0 * 60.0;
		this.currentTimeIndex = 0;
		this.baseSeconds = 0.0;
		this.computerInit = false;
		this.randomNumberGenerator = new Random(this.mySeed);
		this.GenerateWeatherEventTimes();
		this.ChangeMaps(0, 1);
		base.StartCoroutine(this.UpdateTimeOfDay());
	}

	// Token: 0x06001764 RID: 5988 RVA: 0x00009A05 File Offset: 0x00007C05
	private void OnDisable()
	{
		base.StopAllCoroutines();
	}

	// Token: 0x06001765 RID: 5989 RVA: 0x00003051 File Offset: 0x00001251
	protected void OnDestroy()
	{
	}

	// Token: 0x06001766 RID: 5990 RVA: 0x00077A80 File Offset: 0x00075C80
	private Vector4 MaterialColorCorrection(Vector4 color)
	{
		if (color.x < 0.5f)
		{
			color.x += 3E-08f;
		}
		if (color.y < 0.5f)
		{
			color.y += 3E-08f;
		}
		if (color.z < 0.5f)
		{
			color.z += 3E-08f;
		}
		if (color.w < 0.5f)
		{
			color.w += 3E-08f;
		}
		return color;
	}

	// Token: 0x06001767 RID: 5991 RVA: 0x00077B02 File Offset: 0x00075D02
	private IEnumerator UpdateTimeOfDay()
	{
		yield return 0;
		for (;;)
		{
			if (this.animatingLightFlash != null)
			{
				yield return new WaitForSeconds(this.currentTimestep);
			}
			else
			{
				try
				{
					if (!this.computerInit && GorillaComputer.instance != null && GorillaComputer.instance.startupMillis != 0L)
					{
						this.computerInit = true;
						this.initialDayCycles = (long)(TimeSpan.FromMilliseconds((double)GorillaComputer.instance.startupMillis).TotalSeconds * this.timeMultiplier / this.totalSeconds);
						this.currentWeatherIndex = (int)(this.initialDayCycles * (long)this.dayNightLightmapNames.Length) % this.weatherCycle.Length;
						this.baseSeconds = TimeSpan.FromMilliseconds((double)GorillaComputer.instance.startupMillis).TotalSeconds * this.timeMultiplier % this.totalSeconds;
						this.currentTime = (this.baseSeconds + (double)Time.realtimeSinceStartup * this.timeMultiplier) % this.totalSeconds;
						this.currentIndexSeconds = 0.0;
						for (int i = 0; i < this.timeOfDayRange.Length; i++)
						{
							this.currentIndexSeconds += this.timeOfDayRange[i] * 3600.0;
							if (this.currentIndexSeconds > this.currentTime)
							{
								this.currentTimeIndex = i;
								break;
							}
						}
						this.currentWeatherIndex += this.currentTimeIndex;
					}
					else if (!this.computerInit && this.baseSeconds == 0.0)
					{
						this.initialDayCycles = (long)(TimeSpan.FromTicks(DateTime.UtcNow.Ticks).TotalSeconds * this.timeMultiplier / this.totalSeconds);
						this.currentWeatherIndex = (int)(this.initialDayCycles * (long)this.dayNightLightmapNames.Length) % this.weatherCycle.Length;
						this.baseSeconds = TimeSpan.FromTicks(DateTime.UtcNow.Ticks).TotalSeconds * this.timeMultiplier % this.totalSeconds;
						this.currentTime = this.baseSeconds % this.totalSeconds;
						this.currentIndexSeconds = 0.0;
						for (int j = 0; j < this.timeOfDayRange.Length; j++)
						{
							this.currentIndexSeconds += this.timeOfDayRange[j] * 3600.0;
							if (this.currentIndexSeconds > this.currentTime)
							{
								this.currentTimeIndex = j;
								break;
							}
						}
						this.currentWeatherIndex += this.currentTimeIndex - 1;
						if (this.currentWeatherIndex < 0)
						{
							this.currentWeatherIndex = this.weatherCycle.Length - 1;
						}
					}
					this.currentTime = ((this.currentSetting == TimeSettings.Normal) ? ((this.baseSeconds + (double)Time.realtimeSinceStartup * this.timeMultiplier) % this.totalSeconds) : this.currentTime);
					this.currentIndexSeconds = 0.0;
					for (int k = 0; k < this.timeOfDayRange.Length; k++)
					{
						this.currentIndexSeconds += this.timeOfDayRange[k] * 3600.0;
						if (this.currentIndexSeconds > this.currentTime)
						{
							this.currentTimeIndex = k;
							break;
						}
					}
					if (this.currentTimeIndex != this.lastIndex)
					{
						this.currentWeatherIndex = (this.currentWeatherIndex + 1) % this.weatherCycle.Length;
						this.ChangeMaps(this.currentTimeIndex, (this.currentTimeIndex + 1) % this.timeOfDayRange.Length);
					}
					this.currentLerp = (float)(1.0 - (this.currentIndexSeconds - this.currentTime) / (this.timeOfDayRange[this.currentTimeIndex] * 3600.0));
					this.ChangeLerps(this.currentLerp);
					this.lastIndex = this.currentTimeIndex;
					this.currentTimeOfDay = this.dayNightLightmapNames[this.currentTimeIndex];
				}
				catch (Exception ex)
				{
					string str = "Error in BetterDayNightManager: ";
					Exception ex2 = ex;
					Debug.LogError(str + ((ex2 != null) ? ex2.ToString() : null), this);
				}
				this.gameEpochDay = (long)((this.baseSeconds + (double)Time.realtimeSinceStartup * this.timeMultiplier) / this.totalSeconds + (double)this.initialDayCycles);
				foreach (BetterDayNightManager.ScheduledEvent scheduledEvent in BetterDayNightManager.scheduledEvents.Values)
				{
					if (scheduledEvent.lastDayCalled != this.gameEpochDay && scheduledEvent.hour == this.currentTimeIndex)
					{
						scheduledEvent.lastDayCalled = this.gameEpochDay;
						scheduledEvent.action();
					}
				}
				yield return new WaitForSeconds(this.currentTimestep);
			}
		}
		yield break;
	}

	// Token: 0x06001768 RID: 5992 RVA: 0x00077B14 File Offset: 0x00075D14
	private void ChangeLerps(float newLerp)
	{
		Shader.SetGlobalFloat(this._GlobalDayNightLerpValue, newLerp);
		for (int i = 0; i < this.standardMaterialsUnlit.Length; i++)
		{
			this.tempLerp = Mathf.Lerp(this.colorFrom, this.colorTo, newLerp);
			this.standardMaterialsUnlit[i].color = new Color(this.tempLerp, this.tempLerp, this.tempLerp);
		}
		for (int j = 0; j < this.standardMaterialsUnlitDarker.Length; j++)
		{
			this.tempLerp = Mathf.Lerp(this.colorFromDarker, this.colorToDarker, newLerp);
			Color.RGBToHSV(this.standardMaterialsUnlitDarker[j].color, out this.h, out this.s, out this.v);
			this.standardMaterialsUnlitDarker[j].color = Color.HSVToRGB(this.h, this.s, this.tempLerp);
		}
	}

	// Token: 0x06001769 RID: 5993 RVA: 0x00077BF4 File Offset: 0x00075DF4
	private void ChangeMaps(int fromIndex, int toIndex)
	{
		this.fromWeatherIndex = this.currentWeatherIndex;
		this.toWeatherIndex = (this.currentWeatherIndex + 1) % this.weatherCycle.Length;
		if (this.weatherCycle[this.fromWeatherIndex] == BetterDayNightManager.WeatherType.Raining)
		{
			this.fromSky = this.dayNightWeatherSkyboxTextures[fromIndex];
		}
		else
		{
			this.fromSky = this.dayNightSkyboxTextures[fromIndex];
		}
		this.fromSky2 = this.cloudsDayNightSkyboxTextures[fromIndex];
		this.fromSky3 = this.beachDayNightSkyboxTextures[fromIndex];
		if (this.weatherCycle[this.toWeatherIndex] == BetterDayNightManager.WeatherType.Raining)
		{
			this.toSky = this.dayNightWeatherSkyboxTextures[toIndex];
		}
		else
		{
			this.toSky = this.dayNightSkyboxTextures[toIndex];
		}
		this.toSky2 = this.cloudsDayNightSkyboxTextures[toIndex];
		this.toSky3 = this.beachDayNightSkyboxTextures[toIndex];
		this.PopulateAllLightmaps(fromIndex, toIndex);
		Shader.SetGlobalTexture(this._GlobalDayNightSkyTex1, this.fromSky);
		Shader.SetGlobalTexture(this._GlobalDayNightSkyTex2, this.toSky);
		Shader.SetGlobalTexture(this._GlobalDayNightSky2Tex1, this.fromSky2);
		Shader.SetGlobalTexture(this._GlobalDayNightSky2Tex2, this.toSky2);
		Shader.SetGlobalTexture(this._GlobalDayNightSky3Tex1, this.fromSky3);
		Shader.SetGlobalTexture(this._GlobalDayNightSky3Tex2, this.toSky3);
		this.colorFrom = this.standardUnlitColor[fromIndex];
		this.colorTo = this.standardUnlitColor[toIndex];
		this.colorFromDarker = this.standardUnlitColorWithPremadeColorDarker[fromIndex];
		this.colorToDarker = this.standardUnlitColorWithPremadeColorDarker[toIndex];
	}

	// Token: 0x0600176A RID: 5994 RVA: 0x00077D7C File Offset: 0x00075F7C
	private void Update()
	{
		if (!this.shouldRepopulate)
		{
			using (List<PerSceneRenderData>.Enumerator enumerator = BetterDayNightManager.allScenesRenderData.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					if (enumerator.Current.CheckShouldRepopulate())
					{
						this.shouldRepopulate = true;
					}
				}
			}
		}
		if (this.shouldRepopulate)
		{
			this.PopulateAllLightmaps();
			this.shouldRepopulate = false;
		}
	}

	// Token: 0x0600176B RID: 5995 RVA: 0x00077DF4 File Offset: 0x00075FF4
	public void RequestRepopulateLightmaps()
	{
		this.shouldRepopulate = true;
	}

	// Token: 0x0600176C RID: 5996 RVA: 0x00077DFD File Offset: 0x00075FFD
	public void PopulateAllLightmaps()
	{
		this.PopulateAllLightmaps(this.currentTimeIndex, (this.currentTimeIndex + 1) % this.timeOfDayRange.Length);
	}

	// Token: 0x0600176D RID: 5997 RVA: 0x00077E1C File Offset: 0x0007601C
	public void PopulateAllLightmaps(int fromIndex, int toIndex)
	{
		string fromTimeOfDay;
		if (this.weatherCycle[this.fromWeatherIndex] == BetterDayNightManager.WeatherType.Raining)
		{
			fromTimeOfDay = this.dayNightWeatherLightmapNames[fromIndex];
		}
		else
		{
			fromTimeOfDay = this.dayNightLightmapNames[fromIndex];
		}
		string toTimeOfDay;
		if (this.weatherCycle[this.toWeatherIndex] == BetterDayNightManager.WeatherType.Raining)
		{
			toTimeOfDay = this.dayNightWeatherLightmapNames[toIndex];
		}
		else
		{
			toTimeOfDay = this.dayNightLightmapNames[toIndex];
		}
		LightmapData[] lightmaps = LightmapSettings.lightmaps;
		foreach (PerSceneRenderData perSceneRenderData in BetterDayNightManager.allScenesRenderData)
		{
			perSceneRenderData.PopulateLightmaps(fromTimeOfDay, toTimeOfDay, lightmaps);
		}
		LightmapSettings.lightmaps = lightmaps;
	}

	// Token: 0x0600176E RID: 5998 RVA: 0x00077EC4 File Offset: 0x000760C4
	public BetterDayNightManager.WeatherType CurrentWeather()
	{
		return this.weatherCycle[this.currentWeatherIndex];
	}

	// Token: 0x0600176F RID: 5999 RVA: 0x00077ED3 File Offset: 0x000760D3
	public BetterDayNightManager.WeatherType NextWeather()
	{
		return this.weatherCycle[(this.currentWeatherIndex + 1) % this.weatherCycle.Length];
	}

	// Token: 0x06001770 RID: 6000 RVA: 0x00077EED File Offset: 0x000760ED
	public BetterDayNightManager.WeatherType LastWeather()
	{
		return this.weatherCycle[(this.currentWeatherIndex - 1) % this.weatherCycle.Length];
	}

	// Token: 0x06001771 RID: 6001 RVA: 0x00077F08 File Offset: 0x00076108
	private void GenerateWeatherEventTimes()
	{
		this.weatherCycle = new BetterDayNightManager.WeatherType[100 * this.dayNightLightmapNames.Length];
		this.rainChance = this.rainChance * 2f / (float)this.maxRainDuration;
		for (int i = 1; i < this.weatherCycle.Length; i++)
		{
			this.weatherCycle[i] = (((float)this.randomNumberGenerator.Next(100) < this.rainChance * 100f) ? BetterDayNightManager.WeatherType.Raining : BetterDayNightManager.WeatherType.None);
			if (this.weatherCycle[i] == BetterDayNightManager.WeatherType.Raining)
			{
				this.rainDuration = this.randomNumberGenerator.Next(1, this.maxRainDuration + 1);
				for (int j = 1; j < this.rainDuration; j++)
				{
					if (i + j < this.weatherCycle.Length)
					{
						this.weatherCycle[i + j] = BetterDayNightManager.WeatherType.Raining;
					}
				}
				i += this.rainDuration - 1;
			}
		}
	}

	// Token: 0x06001772 RID: 6002 RVA: 0x00077FE0 File Offset: 0x000761E0
	public static int RegisterScheduledEvent(int hour, Action action)
	{
		int num = (int)(DateTime.Now.Ticks % 2147483647L);
		while (BetterDayNightManager.scheduledEvents.ContainsKey(num))
		{
			num++;
		}
		BetterDayNightManager.scheduledEvents.Add(num, new BetterDayNightManager.ScheduledEvent
		{
			lastDayCalled = -1L,
			hour = hour,
			action = action
		});
		return num;
	}

	// Token: 0x06001773 RID: 6003 RVA: 0x0007803D File Offset: 0x0007623D
	public static void UnregisterScheduledEvent(int id)
	{
		BetterDayNightManager.scheduledEvents.Remove(id);
	}

	// Token: 0x06001774 RID: 6004 RVA: 0x0007804C File Offset: 0x0007624C
	public void SetOverrideIndex(int index)
	{
		this.overrideIndex = index;
		this.currentWeatherIndex = this.overrideIndex;
		this.currentTimeIndex = this.overrideIndex;
		this.currentTimeOfDay = this.dayNightLightmapNames[this.currentTimeIndex];
		this.ChangeMaps(this.currentTimeIndex, (this.currentTimeIndex + 1) % this.timeOfDayRange.Length);
	}

	// Token: 0x06001775 RID: 6005 RVA: 0x000780A8 File Offset: 0x000762A8
	public void AnimateLightFlash(int index, float fadeInDuration, float holdDuration, float fadeOutDuration)
	{
		if (this.animatingLightFlash != null)
		{
			base.StopCoroutine(this.animatingLightFlash);
		}
		this.animatingLightFlash = base.StartCoroutine(this.AnimateLightFlashCo(index, fadeInDuration, holdDuration, fadeOutDuration));
	}

	// Token: 0x06001776 RID: 6006 RVA: 0x000780D5 File Offset: 0x000762D5
	private IEnumerator AnimateLightFlashCo(int index, float fadeInDuration, float holdDuration, float fadeOutDuration)
	{
		int startMap = (this.currentLerp < 0.5f) ? this.currentTimeIndex : ((this.currentTimeIndex + 1) % this.timeOfDayRange.Length);
		this.ChangeMaps(startMap, index);
		float endTimestamp = Time.time + fadeInDuration;
		while (Time.time < endTimestamp)
		{
			this.ChangeLerps(1f - (endTimestamp - Time.time) / fadeInDuration);
			yield return null;
		}
		this.ChangeMaps(index, index);
		this.ChangeLerps(0f);
		endTimestamp = Time.time + fadeInDuration;
		while (Time.time < endTimestamp)
		{
			yield return null;
		}
		this.ChangeMaps(index, startMap);
		endTimestamp = Time.time + fadeOutDuration;
		while (Time.time < endTimestamp)
		{
			this.ChangeLerps(1f - (endTimestamp - Time.time) / fadeInDuration);
			yield return null;
		}
		this.ChangeMaps(this.currentTimeIndex, (this.currentTimeIndex + 1) % this.timeOfDayRange.Length);
		this.ChangeLerps(this.currentLerp);
		this.animatingLightFlash = null;
		yield break;
	}

	// Token: 0x06001777 RID: 6007 RVA: 0x000780FC File Offset: 0x000762FC
	public void SetTimeOfDay(int timeIndex)
	{
		double num = 0.0;
		for (int i = 0; i < timeIndex; i++)
		{
			num += this.timeOfDayRange[i];
		}
		this.currentTime = num * 3600.0;
		this.currentSetting = TimeSettings.Static;
	}

	// Token: 0x06001778 RID: 6008 RVA: 0x00078142 File Offset: 0x00076342
	public void FastForward(float seconds)
	{
		this.baseSeconds += (double)seconds;
	}

	// Token: 0x04001A7A RID: 6778
	[OnEnterPlay_SetNull]
	public static volatile BetterDayNightManager instance;

	// Token: 0x04001A7B RID: 6779
	[OnEnterPlay_Clear]
	public static List<PerSceneRenderData> allScenesRenderData = new List<PerSceneRenderData>();

	// Token: 0x04001A7C RID: 6780
	public Shader standard;

	// Token: 0x04001A7D RID: 6781
	public Shader standardCutout;

	// Token: 0x04001A7E RID: 6782
	public Shader gorillaUnlit;

	// Token: 0x04001A7F RID: 6783
	public Shader gorillaUnlitCutout;

	// Token: 0x04001A80 RID: 6784
	public Material[] standardMaterialsUnlit;

	// Token: 0x04001A81 RID: 6785
	public Material[] standardMaterialsUnlitDarker;

	// Token: 0x04001A82 RID: 6786
	public Material[] dayNightSupportedMaterials;

	// Token: 0x04001A83 RID: 6787
	public Material[] dayNightSupportedMaterialsCutout;

	// Token: 0x04001A84 RID: 6788
	public string[] dayNightLightmapNames;

	// Token: 0x04001A85 RID: 6789
	public string[] dayNightWeatherLightmapNames;

	// Token: 0x04001A86 RID: 6790
	public Texture2D[] dayNightSkyboxTextures;

	// Token: 0x04001A87 RID: 6791
	public Texture2D[] cloudsDayNightSkyboxTextures;

	// Token: 0x04001A88 RID: 6792
	public Texture2D[] beachDayNightSkyboxTextures;

	// Token: 0x04001A89 RID: 6793
	public Texture2D[] dayNightWeatherSkyboxTextures;

	// Token: 0x04001A8A RID: 6794
	public float[] standardUnlitColor;

	// Token: 0x04001A8B RID: 6795
	public float[] standardUnlitColorWithPremadeColorDarker;

	// Token: 0x04001A8C RID: 6796
	public float currentLerp;

	// Token: 0x04001A8D RID: 6797
	public float currentTimestep;

	// Token: 0x04001A8E RID: 6798
	public double[] timeOfDayRange;

	// Token: 0x04001A8F RID: 6799
	public double timeMultiplier;

	// Token: 0x04001A90 RID: 6800
	private float lastTime;

	// Token: 0x04001A91 RID: 6801
	private double currentTime;

	// Token: 0x04001A92 RID: 6802
	private double totalHours;

	// Token: 0x04001A93 RID: 6803
	private double totalSeconds;

	// Token: 0x04001A94 RID: 6804
	private float colorFrom;

	// Token: 0x04001A95 RID: 6805
	private float colorTo;

	// Token: 0x04001A96 RID: 6806
	private float colorFromDarker;

	// Token: 0x04001A97 RID: 6807
	private float colorToDarker;

	// Token: 0x04001A98 RID: 6808
	public int currentTimeIndex;

	// Token: 0x04001A99 RID: 6809
	public int currentWeatherIndex;

	// Token: 0x04001A9A RID: 6810
	private int lastIndex;

	// Token: 0x04001A9B RID: 6811
	private double currentIndexSeconds;

	// Token: 0x04001A9C RID: 6812
	private float tempLerp;

	// Token: 0x04001A9D RID: 6813
	private double baseSeconds;

	// Token: 0x04001A9E RID: 6814
	private bool computerInit;

	// Token: 0x04001A9F RID: 6815
	private float h;

	// Token: 0x04001AA0 RID: 6816
	private float s;

	// Token: 0x04001AA1 RID: 6817
	private float v;

	// Token: 0x04001AA2 RID: 6818
	public int mySeed;

	// Token: 0x04001AA3 RID: 6819
	public Random randomNumberGenerator = new Random();

	// Token: 0x04001AA4 RID: 6820
	public BetterDayNightManager.WeatherType[] weatherCycle;

	// Token: 0x04001AA6 RID: 6822
	public float rainChance = 0.3f;

	// Token: 0x04001AA7 RID: 6823
	public int maxRainDuration = 5;

	// Token: 0x04001AA8 RID: 6824
	private int rainDuration;

	// Token: 0x04001AA9 RID: 6825
	private float remainingSeconds;

	// Token: 0x04001AAA RID: 6826
	private long initialDayCycles;

	// Token: 0x04001AAB RID: 6827
	private long gameEpochDay;

	// Token: 0x04001AAC RID: 6828
	private int currentWeatherCycle;

	// Token: 0x04001AAD RID: 6829
	private int fromWeatherIndex;

	// Token: 0x04001AAE RID: 6830
	private int toWeatherIndex;

	// Token: 0x04001AAF RID: 6831
	private Texture2D fromSky;

	// Token: 0x04001AB0 RID: 6832
	private Texture2D fromSky2;

	// Token: 0x04001AB1 RID: 6833
	private Texture2D fromSky3;

	// Token: 0x04001AB2 RID: 6834
	private Texture2D toSky;

	// Token: 0x04001AB3 RID: 6835
	private Texture2D toSky2;

	// Token: 0x04001AB4 RID: 6836
	private Texture2D toSky3;

	// Token: 0x04001AB5 RID: 6837
	public AddCollidersToParticleSystemTriggers[] weatherSystems;

	// Token: 0x04001AB6 RID: 6838
	public List<Collider> collidersToAddToWeatherSystems = new List<Collider>();

	// Token: 0x04001AB7 RID: 6839
	public int overrideIndex = -1;

	// Token: 0x04001AB8 RID: 6840
	[OnEnterPlay_Clear]
	private static readonly Dictionary<int, BetterDayNightManager.ScheduledEvent> scheduledEvents = new Dictionary<int, BetterDayNightManager.ScheduledEvent>(256);

	// Token: 0x04001AB9 RID: 6841
	public TimeSettings currentSetting;

	// Token: 0x04001ABA RID: 6842
	private ShaderHashId _Color = "_Color";

	// Token: 0x04001ABB RID: 6843
	private ShaderHashId _GlobalDayNightLerpValue = "_GlobalDayNightLerpValue";

	// Token: 0x04001ABC RID: 6844
	private ShaderHashId _GlobalDayNightSkyTex1 = "_GlobalDayNightSkyTex1";

	// Token: 0x04001ABD RID: 6845
	private ShaderHashId _GlobalDayNightSkyTex2 = "_GlobalDayNightSkyTex2";

	// Token: 0x04001ABE RID: 6846
	private ShaderHashId _GlobalDayNightSky2Tex1 = "_GlobalDayNightSky2Tex1";

	// Token: 0x04001ABF RID: 6847
	private ShaderHashId _GlobalDayNightSky2Tex2 = "_GlobalDayNightSky2Tex2";

	// Token: 0x04001AC0 RID: 6848
	private ShaderHashId _GlobalDayNightSky3Tex1 = "_GlobalDayNightSky3Tex1";

	// Token: 0x04001AC1 RID: 6849
	private ShaderHashId _GlobalDayNightSky3Tex2 = "_GlobalDayNightSky3Tex2";

	// Token: 0x04001AC2 RID: 6850
	private bool shouldRepopulate;

	// Token: 0x04001AC3 RID: 6851
	private Coroutine animatingLightFlash;

	// Token: 0x020003EC RID: 1004
	public enum WeatherType
	{
		// Token: 0x04001AC5 RID: 6853
		None,
		// Token: 0x04001AC6 RID: 6854
		Raining,
		// Token: 0x04001AC7 RID: 6855
		All
	}

	// Token: 0x020003ED RID: 1005
	private class ScheduledEvent
	{
		// Token: 0x04001AC8 RID: 6856
		public long lastDayCalled;

		// Token: 0x04001AC9 RID: 6857
		public int hour;

		// Token: 0x04001ACA RID: 6858
		public Action action;
	}
}
