﻿using System;
using UnityEngine;

// Token: 0x02000387 RID: 903
public class GorillaMouthFlap : MonoBehaviour
{
	// Token: 0x06001495 RID: 5269 RVA: 0x0006C783 File Offset: 0x0006A983
	private void Start()
	{
		this.speaker = base.GetComponent<GorillaSpeakerLoudness>();
	}

	// Token: 0x06001496 RID: 5270 RVA: 0x0006C794 File Offset: 0x0006A994
	public void InvokeUpdate()
	{
		if (this.speaker == null)
		{
			this.speaker = base.GetComponent<GorillaSpeakerLoudness>();
			return;
		}
		float currentLoudness = 0f;
		if (this.speaker.IsSpeaking)
		{
			currentLoudness = this.speaker.Loudness;
		}
		this.CheckMouthflapChange(this.speaker.IsMicEnabled, currentLoudness);
		MouthFlapLevel mouthFlap = this.noMicFace;
		if (this.useMicEnabled)
		{
			mouthFlap = this.mouthFlapLevels[this.activeFlipbookIndex];
		}
		this.UpdateMouthFlapFlipbook(mouthFlap);
	}

	// Token: 0x06001497 RID: 5271 RVA: 0x0006C818 File Offset: 0x0006AA18
	private void CheckMouthflapChange(bool isMicEnabled, float currentLoudness)
	{
		if (isMicEnabled)
		{
			this.useMicEnabled = true;
			int i = this.mouthFlapLevels.Length - 1;
			while (i >= 0)
			{
				if (currentLoudness >= this.mouthFlapLevels[i].maxRequiredVolume)
				{
					return;
				}
				if (currentLoudness > this.mouthFlapLevels[i].minRequiredVolume)
				{
					if (this.activeFlipbookIndex != i)
					{
						this.activeFlipbookIndex = i;
						this.activeFlipbookPlayTime = 0f;
						return;
					}
					return;
				}
				else
				{
					i--;
				}
			}
			return;
		}
		if (this.useMicEnabled)
		{
			this.useMicEnabled = false;
			this.activeFlipbookPlayTime = 0f;
		}
	}

	// Token: 0x06001498 RID: 5272 RVA: 0x0006C8A4 File Offset: 0x0006AAA4
	private void UpdateMouthFlapFlipbook(MouthFlapLevel mouthFlap)
	{
		Material material = this.targetFace.GetComponent<Renderer>().material;
		this.activeFlipbookPlayTime += Time.deltaTime;
		this.activeFlipbookPlayTime %= mouthFlap.cycleDuration;
		int num = Mathf.FloorToInt(this.activeFlipbookPlayTime * (float)mouthFlap.faces.Length / mouthFlap.cycleDuration);
		material.SetTextureOffset(this._MouthMap, mouthFlap.faces[num]);
	}

	// Token: 0x04001783 RID: 6019
	public GameObject targetFace;

	// Token: 0x04001784 RID: 6020
	public MouthFlapLevel[] mouthFlapLevels;

	// Token: 0x04001785 RID: 6021
	public MouthFlapLevel noMicFace;

	// Token: 0x04001786 RID: 6022
	private bool useMicEnabled;

	// Token: 0x04001787 RID: 6023
	private int activeFlipbookIndex;

	// Token: 0x04001788 RID: 6024
	private float activeFlipbookPlayTime;

	// Token: 0x04001789 RID: 6025
	private GorillaSpeakerLoudness speaker;

	// Token: 0x0400178A RID: 6026
	private ShaderHashId _MouthMap = "_MouthMap";
}
