﻿using System;
using UnityEngine;

// Token: 0x0200036C RID: 876
public class GorillaCTFUI : MonoBehaviour
{
	// Token: 0x060013E9 RID: 5097 RVA: 0x00003051 File Offset: 0x00001251
	private void Start()
	{
	}

	// Token: 0x060013EA RID: 5098 RVA: 0x00003051 File Offset: 0x00001251
	private void Update()
	{
	}
}
