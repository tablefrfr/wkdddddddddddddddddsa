﻿using System;
using Photon.Pun;
using UnityEngine;

namespace GorillaNetworking
{
	// Token: 0x020006C3 RID: 1731
	public class GorillaNetworkDisconnectTrigger : GorillaTriggerBox
	{
		// Token: 0x06002916 RID: 10518 RVA: 0x000CA5CC File Offset: 0x000C87CC
		public override void OnBoxTriggered()
		{
			base.OnBoxTriggered();
			if (this.makeSureThisIsEnabled != null)
			{
				this.makeSureThisIsEnabled.SetActive(true);
			}
			GameObject[] array = this.makeSureTheseAreEnabled;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].SetActive(true);
			}
			if (PhotonNetwork.InRoom)
			{
				if (this.componentTypeToRemove != "" && this.componentTarget.GetComponent(this.componentTypeToRemove) != null)
				{
					Object.Destroy(this.componentTarget.GetComponent(this.componentTypeToRemove));
				}
				PhotonNetwork.Disconnect();
				SkinnedMeshRenderer[] array2 = this.photonNetworkController.offlineVRRig;
				for (int i = 0; i < array2.Length; i++)
				{
					array2[i].enabled = true;
				}
				PhotonNetwork.ConnectUsingSettings();
			}
		}

		// Token: 0x04002C20 RID: 11296
		public PhotonNetworkController photonNetworkController;

		// Token: 0x04002C21 RID: 11297
		public GameObject offlineVRRig;

		// Token: 0x04002C22 RID: 11298
		public GameObject makeSureThisIsEnabled;

		// Token: 0x04002C23 RID: 11299
		public GameObject[] makeSureTheseAreEnabled;

		// Token: 0x04002C24 RID: 11300
		public string componentTypeToRemove;

		// Token: 0x04002C25 RID: 11301
		public GameObject componentTarget;
	}
}
