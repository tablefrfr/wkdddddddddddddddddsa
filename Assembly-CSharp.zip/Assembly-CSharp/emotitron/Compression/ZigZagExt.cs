﻿using System;

namespace emotitron.Compression
{
	// Token: 0x020007BF RID: 1983
	public static class ZigZagExt
	{
		// Token: 0x06002FE7 RID: 12263 RVA: 0x000EB971 File Offset: 0x000E9B71
		public static ulong ZigZag(this long s)
		{
			return (ulong)(s << 1 ^ s >> 63);
		}

		// Token: 0x06002FE8 RID: 12264 RVA: 0x000EB97B File Offset: 0x000E9B7B
		public static long UnZigZag(this ulong u)
		{
			return (long)(u >> 1 ^ -(long)(u & 1UL));
		}

		// Token: 0x06002FE9 RID: 12265 RVA: 0x000EB986 File Offset: 0x000E9B86
		public static uint ZigZag(this int s)
		{
			return (uint)(s << 1 ^ s >> 31);
		}

		// Token: 0x06002FEA RID: 12266 RVA: 0x000EB990 File Offset: 0x000E9B90
		public static int UnZigZag(this uint u)
		{
			return (int)((ulong)(u >> 1) ^ (ulong)((long)(-(long)(u & 1U))));
		}

		// Token: 0x06002FEB RID: 12267 RVA: 0x000EB99D File Offset: 0x000E9B9D
		public static ushort ZigZag(this short s)
		{
			return (ushort)((int)s << 1 ^ s >> 15);
		}

		// Token: 0x06002FEC RID: 12268 RVA: 0x000EB9A8 File Offset: 0x000E9BA8
		public static short UnZigZag(this ushort u)
		{
			return (short)(u >> 1 ^ (int)(-(int)((short)(u & 1))));
		}

		// Token: 0x06002FED RID: 12269 RVA: 0x000EB9B4 File Offset: 0x000E9BB4
		public static byte ZigZag(this sbyte s)
		{
			return (byte)((int)s << 1 ^ s >> 7);
		}

		// Token: 0x06002FEE RID: 12270 RVA: 0x000EB9BE File Offset: 0x000E9BBE
		public static sbyte UnZigZag(this byte u)
		{
			return (sbyte)(u >> 1 ^ (int)(-(int)((sbyte)(u & 1))));
		}
	}
}
