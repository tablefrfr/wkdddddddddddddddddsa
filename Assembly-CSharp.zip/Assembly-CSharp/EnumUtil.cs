﻿using System;

// Token: 0x02000427 RID: 1063
public static class EnumUtil
{
	// Token: 0x06001888 RID: 6280 RVA: 0x0007F495 File Offset: 0x0007D695
	public static string[] GetNames<TEnum>() where TEnum : struct, Enum
	{
		return ArrayUtils.Copy<string>(EnumData<TEnum>.Shared.Names);
	}

	// Token: 0x06001889 RID: 6281 RVA: 0x0007F4A6 File Offset: 0x0007D6A6
	public static TEnum[] GetValues<TEnum>() where TEnum : struct, Enum
	{
		return ArrayUtils.Copy<TEnum>(EnumData<TEnum>.Shared.Values);
	}

	// Token: 0x0600188A RID: 6282 RVA: 0x0007F4B7 File Offset: 0x0007D6B7
	public static long[] GetLongValues<TEnum>() where TEnum : struct, Enum
	{
		return ArrayUtils.Copy<long>(EnumData<TEnum>.Shared.LongValues);
	}

	// Token: 0x0600188B RID: 6283 RVA: 0x0007F4C8 File Offset: 0x0007D6C8
	public static string EnumToName<TEnum>(TEnum e) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.EnumToName[e];
	}

	// Token: 0x0600188C RID: 6284 RVA: 0x0007F4DA File Offset: 0x0007D6DA
	public static TEnum NameToEnum<TEnum>(string n) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.NameToEnum[n];
	}

	// Token: 0x0600188D RID: 6285 RVA: 0x0007F4EC File Offset: 0x0007D6EC
	public static int EnumToIndex<TEnum>(TEnum e) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.EnumToIndex[e];
	}

	// Token: 0x0600188E RID: 6286 RVA: 0x0007F4FE File Offset: 0x0007D6FE
	public static TEnum IndexToEnum<TEnum>(int i) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.IndexToEnum[i];
	}

	// Token: 0x0600188F RID: 6287 RVA: 0x0007F510 File Offset: 0x0007D710
	public static long EnumToLong<TEnum>(TEnum e) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.EnumToLong[e];
	}

	// Token: 0x06001890 RID: 6288 RVA: 0x0007F522 File Offset: 0x0007D722
	public static TEnum LongToEnum<TEnum>(long l) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.LongToEnum[l];
	}

	// Token: 0x06001891 RID: 6289 RVA: 0x0007F534 File Offset: 0x0007D734
	public static TEnum GetValue<TEnum>(int index) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.Values[index];
	}

	// Token: 0x06001892 RID: 6290 RVA: 0x0007F4EC File Offset: 0x0007D6EC
	public static int GetIndex<TEnum>(TEnum value) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.EnumToIndex[value];
	}

	// Token: 0x06001893 RID: 6291 RVA: 0x0007F4C8 File Offset: 0x0007D6C8
	public static string GetName<TEnum>(TEnum value) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.EnumToName[value];
	}

	// Token: 0x06001894 RID: 6292 RVA: 0x0007F4DA File Offset: 0x0007D6DA
	public static TEnum GetValue<TEnum>(string name) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.NameToEnum[name];
	}

	// Token: 0x06001895 RID: 6293 RVA: 0x0007F510 File Offset: 0x0007D710
	public static long GetLongValue<TEnum>(TEnum value) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.EnumToLong[value];
	}

	// Token: 0x06001896 RID: 6294 RVA: 0x0007F522 File Offset: 0x0007D722
	public static TEnum GetValue<TEnum>(long longValue) where TEnum : struct, Enum
	{
		return EnumData<TEnum>.Shared.LongToEnum[longValue];
	}
}
