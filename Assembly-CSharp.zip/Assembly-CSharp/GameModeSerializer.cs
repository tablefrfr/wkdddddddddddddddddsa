﻿using System;
using GorillaExtensions;
using GorillaGameModes;
using GorillaTag;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine;

// Token: 0x0200034A RID: 842
internal class GameModeSerializer : GorillaSerializerMasterOnly, IOnPhotonViewPreNetDestroy, IPhotonViewCallback
{
	// Token: 0x170001F0 RID: 496
	// (get) Token: 0x060012D2 RID: 4818 RVA: 0x0006455C File Offset: 0x0006275C
	public GorillaGameManager GameModeInstance
	{
		get
		{
			return this.gameModeInstance;
		}
	}

	// Token: 0x060012D3 RID: 4819 RVA: 0x00064564 File Offset: 0x00062764
	protected override bool OnInstantiateSetup(PhotonMessageInfo info, out GameObject outTargetObject, out Type outTargetType)
	{
		outTargetObject = null;
		outTargetType = null;
		GorillaNot.IncrementRPCCall(info, "OnInstantiateSetup");
		GameModeSerializer activeNetworkHandler = GameMode.ActiveNetworkHandler;
		if (info.Sender != null && info.Sender.InRoom())
		{
			if (info.Sender != PhotonNetwork.MasterClient)
			{
				GorillaNot.instance.SendReport("trying to inappropriately create game managers", info.Sender.UserId, info.Sender.NickName);
				return false;
			}
			if (!this.photonView.IsRoomView)
			{
				GorillaNot.instance.SendReport("creating game manager as player object", info.Sender.UserId, info.Sender.NickName);
				return false;
			}
			if (activeNetworkHandler.IsNotNull() && activeNetworkHandler != this)
			{
				GorillaNot.instance.SendReport("trying to create multiple game managers", info.Sender.UserId, info.Sender.NickName);
				return false;
			}
		}
		else if ((activeNetworkHandler.IsNotNull() && activeNetworkHandler != this) || !this.photonView.IsRoomView)
		{
			return false;
		}
		object[] instantiationData = info.photonView.InstantiationData;
		if (instantiationData != null && instantiationData.Length >= 1)
		{
			object obj = instantiationData[0];
			if (obj is int)
			{
				int num = (int)obj;
				this.gameModeKey = (GameModeType)num;
				this.gameModeInstance = GameMode.GetGameModeInstance(this.gameModeKey);
				if (this.gameModeInstance.IsNull() || !this.gameModeInstance.ValidGameMode())
				{
					string str = "gamemode invalid null? ";
					GorillaGameManager gorillaGameManager = this.gameModeInstance;
					Debug.LogError(str + ((gorillaGameManager != null) ? gorillaGameManager.ToString() : null));
					return false;
				}
				this.serializeTarget = this.gameModeInstance;
				base.transform.parent = VRRigCache.Instance.NetworkParent;
				return true;
			}
		}
		Debug.LogError("missing instantiation data");
		return false;
	}

	// Token: 0x060012D4 RID: 4820 RVA: 0x00064716 File Offset: 0x00062916
	protected override void OnSuccessfullInstantiate(PhotonMessageInfo info)
	{
		this.photonView.AddCallbackTarget(this);
		GameMode.SetupGameModeRemote(this);
	}

	// Token: 0x060012D5 RID: 4821 RVA: 0x0006472A File Offset: 0x0006292A
	void IOnPhotonViewPreNetDestroy.OnPreNetDestroy(PhotonView rootView)
	{
		GameMode.RemoveNetworkLink(this);
	}

	// Token: 0x060012D6 RID: 4822 RVA: 0x00064732 File Offset: 0x00062932
	[PunRPC]
	private void ReportTagRPC(Player taggedPlayer, PhotonMessageInfo info)
	{
		this.gameModeInstance.ReportTag(taggedPlayer, info.Sender);
	}

	// Token: 0x060012D7 RID: 4823 RVA: 0x00064748 File Offset: 0x00062948
	[PunRPC]
	private void ReportHitRPC(PhotonMessageInfo info)
	{
		GorillaNot.IncrementRPCCall(info, "ReportContactWithLavaRPC");
		InfectionLavaController instance = InfectionLavaController.Instance;
		RigContainer rigContainer;
		if (VRRigCache.Instance.TryGetVrrig(info.Sender, out rigContainer) && instance != null && instance.LavaCurrentlyActivated && (instance.SurfaceCenter - rigContainer.Rig.syncPos).sqrMagnitude < 2500f && instance.LavaPlane.GetDistanceToPoint(rigContainer.Rig.syncPos) < 5f)
		{
			this.GameModeInstance.HitPlayer(info.Sender);
		}
	}

	// Token: 0x04001607 RID: 5639
	private GameModeType gameModeKey;

	// Token: 0x04001608 RID: 5640
	private GorillaGameManager gameModeInstance;
}
