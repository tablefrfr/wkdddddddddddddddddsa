﻿using System;
using UnityEngine;

namespace GorillaNetworking
{
	// Token: 0x020006C5 RID: 1733
	public class GorillaNetworkLobbyJoinTrigger : GorillaTriggerBox
	{
		// Token: 0x04002C32 RID: 11314
		public GameObject[] makeSureThisIsDisabled;

		// Token: 0x04002C33 RID: 11315
		public GameObject[] makeSureThisIsEnabled;

		// Token: 0x04002C34 RID: 11316
		public string gameModeName;

		// Token: 0x04002C35 RID: 11317
		public PhotonNetworkController photonNetworkController;

		// Token: 0x04002C36 RID: 11318
		public string componentTypeToRemove;

		// Token: 0x04002C37 RID: 11319
		public GameObject componentRemoveTarget;

		// Token: 0x04002C38 RID: 11320
		public string componentTypeToAdd;

		// Token: 0x04002C39 RID: 11321
		public GameObject componentAddTarget;

		// Token: 0x04002C3A RID: 11322
		public GameObject gorillaParent;

		// Token: 0x04002C3B RID: 11323
		public GameObject joinFailedBlock;
	}
}
