﻿using System;
using UnityEngine;

namespace CjLib
{
	// Token: 0x020007D6 RID: 2006
	[ExecuteInEditMode]
	public class DrawLine : DrawBase
	{
		// Token: 0x06003082 RID: 12418 RVA: 0x000ED803 File Offset: 0x000EBA03
		private void OnValidate()
		{
			this.Wireframe = true;
			this.Style = DebugUtil.Style.Wireframe;
		}

		// Token: 0x06003083 RID: 12419 RVA: 0x000ED813 File Offset: 0x000EBA13
		protected override void Draw(Color color, DebugUtil.Style style, bool depthTest)
		{
			DebugUtil.DrawLine(base.transform.position, base.transform.position + base.transform.TransformVector(this.LocalEndVector), color, depthTest);
		}

		// Token: 0x040032F2 RID: 13042
		public Vector3 LocalEndVector = Vector3.right;
	}
}
