﻿using System;
using UnityEngine;

// Token: 0x02000470 RID: 1136
[Serializable]
public class CallLimiterWithCooldown : CallLimiter
{
	// Token: 0x06001A7D RID: 6781 RVA: 0x00087F7D File Offset: 0x0008617D
	public CallLimiterWithCooldown(float coolDownSpam, int historyLength, float coolDown) : base(historyLength, coolDown, 0.5f)
	{
		this.spamCoolDown = coolDownSpam;
	}

	// Token: 0x06001A7E RID: 6782 RVA: 0x00087F93 File Offset: 0x00086193
	public CallLimiterWithCooldown(float coolDownSpam, int historyLength, float coolDown, float latencyMax) : base(historyLength, coolDown, latencyMax)
	{
		this.spamCoolDown = coolDownSpam;
	}

	// Token: 0x06001A7F RID: 6783 RVA: 0x00087FA6 File Offset: 0x000861A6
	public override bool CheckCallTime(float time)
	{
		if (this.blockCall && time < this.blockStartTime + this.spamCoolDown)
		{
			this.blockStartTime = time;
			return false;
		}
		return base.CheckCallTime(time);
	}

	// Token: 0x04001E79 RID: 7801
	[SerializeField]
	private float spamCoolDown;
}
