﻿using System;
using UnityEngine;

namespace GorillaLocomotion.Swimming
{
	// Token: 0x020005B1 RID: 1457
	[CreateAssetMenu(fileName = "Data", menuName = "ScriptableObjects/PlayerSwimmingParameters", order = 1)]
	public class PlayerSwimmingParameters : ScriptableObject
	{
		// Token: 0x0400240E RID: 9230
		[Header("Base Settings")]
		public float floatingWaterLevelBelowHead = 0.6f;

		// Token: 0x0400240F RID: 9231
		public float buoyancyFadeDist = 0.3f;

		// Token: 0x04002410 RID: 9232
		public bool extendBouyancyFromSpeed;

		// Token: 0x04002411 RID: 9233
		public float buoyancyExtensionDecayHalflife = 0.2f;

		// Token: 0x04002412 RID: 9234
		public float baseUnderWaterDampingHalfLife = 0.25f;

		// Token: 0x04002413 RID: 9235
		public float swimUnderWaterDampingHalfLife = 1.1f;

		// Token: 0x04002414 RID: 9236
		public AnimationCurve speedToBouyancyExtension = AnimationCurve.Linear(0f, 0f, 1f, 1f);

		// Token: 0x04002415 RID: 9237
		public Vector2 speedToBouyancyExtensionMinMax = Vector2.zero;

		// Token: 0x04002416 RID: 9238
		public float swimmingVelocityOutOfWaterDrainRate = 3f;

		// Token: 0x04002417 RID: 9239
		[Range(0f, 1f)]
		public float underwaterJumpsAsSwimVelocityFactor = 1f;

		// Token: 0x04002418 RID: 9240
		[Range(0f, 1f)]
		public float swimmingHapticsStrength = 0.5f;

		// Token: 0x04002419 RID: 9241
		[Header("Surface Jumping")]
		public bool allowWaterSurfaceJumps;

		// Token: 0x0400241A RID: 9242
		public float waterSurfaceJumpHandSpeedThreshold = 1f;

		// Token: 0x0400241B RID: 9243
		public float waterSurfaceJumpAmount;

		// Token: 0x0400241C RID: 9244
		public float waterSurfaceJumpMaxSpeed = 1f;

		// Token: 0x0400241D RID: 9245
		public AnimationCurve waterSurfaceJumpPalmFacingCurve = AnimationCurve.Linear(0f, 0f, 1f, 1f);

		// Token: 0x0400241E RID: 9246
		public AnimationCurve waterSurfaceJumpHandVelocityFacingCurve = AnimationCurve.Linear(0f, 0f, 1f, 1f);

		// Token: 0x0400241F RID: 9247
		[Header("Diving")]
		public bool applyDiveSteering;

		// Token: 0x04002420 RID: 9248
		public bool applyDiveDampingMultiplier;

		// Token: 0x04002421 RID: 9249
		public float diveDampingMultiplier = 1f;

		// Token: 0x04002422 RID: 9250
		[Tooltip("In degrees")]
		public float maxDiveSteerAnglePerStep = 1f;

		// Token: 0x04002423 RID: 9251
		public float diveVelocityAveragingWindow = 0.1f;

		// Token: 0x04002424 RID: 9252
		public bool applyDiveSwimVelocityConversion;

		// Token: 0x04002425 RID: 9253
		[Tooltip("In meters per second")]
		public float diveSwimVelocityConversionRate = 3f;

		// Token: 0x04002426 RID: 9254
		public float diveMaxSwimVelocityConversion = 3f;

		// Token: 0x04002427 RID: 9255
		public bool reduceDiveSteeringBelowVelocityPlane;

		// Token: 0x04002428 RID: 9256
		public float reduceDiveSteeringBelowPlaneFadeStartDist = 0.4f;

		// Token: 0x04002429 RID: 9257
		public float reduceDiveSteeringBelowPlaneFadeEndDist = 0.55f;

		// Token: 0x0400242A RID: 9258
		public AnimationCurve palmFacingToRedirectAmount = AnimationCurve.Linear(0f, 0f, 1f, 1f);

		// Token: 0x0400242B RID: 9259
		public Vector2 palmFacingToRedirectAmountMinMax = Vector2.zero;

		// Token: 0x0400242C RID: 9260
		public AnimationCurve swimSpeedToRedirectAmount = AnimationCurve.Linear(0f, 0f, 1f, 1f);

		// Token: 0x0400242D RID: 9261
		public Vector2 swimSpeedToRedirectAmountMinMax = Vector2.zero;

		// Token: 0x0400242E RID: 9262
		public AnimationCurve swimSpeedToMaxRedirectAngle = AnimationCurve.Linear(0f, 0f, 1f, 1f);

		// Token: 0x0400242F RID: 9263
		public Vector2 swimSpeedToMaxRedirectAngleMinMax = Vector2.zero;

		// Token: 0x04002430 RID: 9264
		public AnimationCurve handSpeedToRedirectAmount = AnimationCurve.Linear(0f, 1f, 1f, 0f);

		// Token: 0x04002431 RID: 9265
		public Vector2 handSpeedToRedirectAmountMinMax = Vector2.zero;

		// Token: 0x04002432 RID: 9266
		public AnimationCurve handAccelToRedirectAmount = AnimationCurve.Linear(0f, 1f, 1f, 0f);

		// Token: 0x04002433 RID: 9267
		public Vector2 handAccelToRedirectAmountMinMax = Vector2.zero;

		// Token: 0x04002434 RID: 9268
		public AnimationCurve nonDiveDampingHapticsAmount = AnimationCurve.Linear(0f, 0f, 1f, 1f);

		// Token: 0x04002435 RID: 9269
		public Vector2 nonDiveDampingHapticsAmountMinMax = Vector2.zero;
	}
}
