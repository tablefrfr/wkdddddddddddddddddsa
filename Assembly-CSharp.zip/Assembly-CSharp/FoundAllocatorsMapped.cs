﻿using System;
using System.Collections.Generic;

// Token: 0x02000079 RID: 121
[Serializable]
public class FoundAllocatorsMapped
{
	// Token: 0x04000383 RID: 899
	public string path;

	// Token: 0x04000384 RID: 900
	public List<ViewsAndAllocator> allocators = new List<ViewsAndAllocator>();

	// Token: 0x04000385 RID: 901
	public List<FoundAllocatorsMapped> subGroups = new List<FoundAllocatorsMapped>();
}
