﻿using System;
using UnityEngine;

// Token: 0x0200035A RID: 858
public class GeoSoundArg : FXSArgs
{
	// Token: 0x0400164C RID: 5708
	public Vector3 position;
}
