﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000348 RID: 840
public class GiantSnowflakeAudio : MonoBehaviour
{
	// Token: 0x060012D0 RID: 4816 RVA: 0x000644E4 File Offset: 0x000626E4
	private void Start()
	{
		foreach (GiantSnowflakeAudio.SnowflakeScaleOverride snowflakeScaleOverride in this.audioOverrides)
		{
			if (base.transform.lossyScale.x < snowflakeScaleOverride.scaleMax)
			{
				base.GetComponent<GorillaSurfaceOverride>().overrideIndex = snowflakeScaleOverride.newOverrideIndex;
			}
		}
	}

	// Token: 0x04001604 RID: 5636
	public List<GiantSnowflakeAudio.SnowflakeScaleOverride> audioOverrides;

	// Token: 0x02000349 RID: 841
	[Serializable]
	public struct SnowflakeScaleOverride
	{
		// Token: 0x04001605 RID: 5637
		public float scaleMax;

		// Token: 0x04001606 RID: 5638
		[GorillaSoundLookup]
		public int newOverrideIndex;
	}
}
