﻿using System;
using UnityEngine;

namespace GameObjectScheduling
{
	// Token: 0x020007D0 RID: 2000
	[CreateAssetMenu(fileName = "New Options", menuName = "Game Object Scheduling/Options", order = 0)]
	public class SchedulingOptions : ScriptableObject
	{
		// Token: 0x17000548 RID: 1352
		// (get) Token: 0x06003071 RID: 12401 RVA: 0x000ED439 File Offset: 0x000EB639
		public DateTime DtDebugServerTime
		{
			get
			{
				return this.dtDebugServerTime.AddSeconds((double)(Time.time * this.timescale));
			}
		}

		// Token: 0x040032DB RID: 13019
		[SerializeField]
		private string debugServerTime;

		// Token: 0x040032DC RID: 13020
		[SerializeField]
		private DateTime dtDebugServerTime;

		// Token: 0x040032DD RID: 13021
		[SerializeField]
		[Range(-60f, 3660f)]
		private float timescale = 1f;
	}
}
